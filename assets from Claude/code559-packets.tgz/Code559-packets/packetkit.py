"""Shared packet template parts (2026-10-12): the "About this module" page (Modules 1-13, built from the post's
collapsed About block, so blog and packet stay the same) and the Contents page with page numbers and links (all modules)."""
import re, os, html as H
from markdown_it import MarkdownIt
from mdit_py_plugins.tasklists import tasklists_plugin
from mdit_py_plugins.footnote import footnote_plugin
from mdit_py_plugins.anchors import anchors_plugin

def slug(text):
    s = re.sub(r"[^\w\- ]", "", text.strip().lower())
    return "l-" + s.replace(" ", "-")

def lesson_md():
    return (MarkdownIt("commonmark", {"html": True}).enable("table")
            .use(tasklists_plugin).use(footnote_plugin)
            .use(anchors_plugin, min_level=2, max_level=3, slug_func=slug))

def split_post(src):
    """Return (post without its About and Contents blocks, About markdown or None)."""
    about = None
    m = re.search(r"<!-- about:start -->.*?<summary>.*?</summary>\n(.*?)</details>.*?<!-- about:end -->", src, re.S)
    if m:
        about = m.group(1).strip()
    src = re.sub(r"\n*<!-- about:start -->.*?<!-- about:end -->\n*", "\n\n", src, flags=re.S)
    src = re.sub(r"\n*<!-- contents:start -->.*?<!-- contents:end -->\n*", "\n\n", src, flags=re.S)
    return src, about

COPYRIGHT = "\u00a9 2026 559 Solutions LLC"  # decided 2026-10-12: year of first publication; add years as packets are updated
CREDITS = ("Portions adapted from Visual Studio Code documentation (CC BY 3.0 US), GitHub Docs (CC BY 4.0), "
           "and GitHub Skills (MIT). Screenshots used with permission from Microsoft.")

def rights_html(module_n):
    terms = ("All rights reserved." if module_n == 0 else
             "This packet is licensed to the purchaser for personal use. Do not share, resell or post it.")
    return f'<h2>Rights and credits</h2><p class="rights">{COPYRIGHT}. {terms}</p><p class="rights">{CREDITS}</p>'

def about_page(about_md, module_n):
    body = MarkdownIt("commonmark", {"html": True}).render(about_md)
    body = re.sub(r"<p><strong>([^<]+)</strong></p>", r"<h2>\1</h2>", body)  # the three section labels
    return f'<section class="about" id="about"><h1>About this module</h1>{body}{rights_html(module_n)}</section>'

def footer(module_label):
    return ("<div style='font-size:7.5pt;color:#6b7280;width:100%;padding:0 0.7in;display:flex;justify-content:space-between;font-family:Arial,sans-serif'>"
            f"<span>Code559 - {module_label} - Powered by <a href='https://559solutions.com' style='color:#1A52BB;text-decoration:none'>559 Solutions</a></span>"
            f"<span>{COPYRIGHT} &nbsp;&middot;&nbsp; <span class='pageNumber'></span> / <span class='totalPages'></span></span></div>")

ABOUT_559 = """<section class="part closing" id="about-559"><h1>About 559 Solutions</h1>
<p>559 isn't just a name. It's where I started: 559 East 37th Street, in the Ida B. Wells Homes on Chicago's South Side. 559 Solutions carries that start into the work: plain language, steady delivery, and solutions people actually use.</p>
<h2>The blueprint and the open door</h2>
<p>Every 559 Solutions page is drawn like a floor plan: a wall, a window, another wall, and an open door. The plan is how we solve problems, large or small, in any corner of information technology. That covers a nonprofit's tangled spreadsheet and a company's enterprise architecture alike. Every solution moves through the same four steps:</p>
<ul>
<li><b>Inform:</b> name the problem, and why it matters.</li>
<li><b>Explain:</b> show how the solution works, one idea at a time.</li>
<li><b>Illustrate:</b> draw it, so everyone sees the same plan.</li>
<li><b>Apply:</b> build it, and put it to work.</li>
</ul>
<p>In every module, the same four steps sit behind the badges; there the first one is called Introduce. The open door is the point of the plan: a way in, for clients and learners alike.</p>
<h2>Code559</h2>
<p>Code559 is the teaching side of 559 Solutions. It teaches more than code. It teaches a developer's mindset: predict before you run, read the error, change one thing at a time, test it, save it, and check it live. You work with the real tools developers use every day: VS Code, Git, GitHub, the browser's DevTools and Node. You build working code you can publish, the way a developer does on the job. Think of it as a day in the life of a developer, built into every module.</p>
<p class="sign-off">No jargon. No drama. Just solutions that serve the mission.</p>
<p class="sig">&mdash; J. R. Wells</p>
<p class="site"><a href="https://559solutions.com">559solutions.com</a></p>
</section>"""

TOC_CSS = """
.about, .toc-page { break-before: page; }
.about { font-size: 10pt; line-height: 1.42; }
.about h1 { margin-bottom: 4pt; }
.about h2 { margin: 10pt 0 3pt; }
.about p { margin: 4pt 0; }
.about .rights { font-size: 9pt; color: #374151; margin: 3pt 0; }
.about img[src*="brand/marker-"] { width: 17pt; height: 17pt; }
.closing h2 { margin-top: 14pt; }
.closing .sign-off { margin-top: 16pt; font-weight: 600; color: #0F2849; }
.closing .sig { margin: 2pt 0; }
.closing .site { margin-top: 10pt; }
.toc { margin-top: 6pt; }
.toc a { display: flex; align-items: baseline; color: inherit; text-decoration: none; }
.toc .t { flex: 0 1 auto; } .toc .dots { flex: 1 1 auto; border-bottom: 1px dotted #9aa3ad; margin: 0 5pt; min-width: 12pt; }
.toc .n { flex: 0 0 auto; min-width: 16pt; text-align: right; color: #1A52BB; }
.toc .lv0 { font-weight: 700; color: #0F2849; margin: 9pt 0 2pt; }
.toc .lv1 { margin: 1.5pt 0 1.5pt 14pt; }
.toc .lv2 { margin: 1pt 0 1pt 30pt; font-size: 9.5pt; color: #374151; }
.toc code { font-size: 8.5pt; }
"""

def toc_entries(doc_html):
    """Parts (sections with an id, a part label and an h1), plus the lesson's h2s and its Core concepts h3s."""
    entries = []
    for m in re.finditer(r'<section class="(part[^"]*|about)" id="([^"]+)">(.*?)</section>', doc_html, re.S):
        cls, sid, inner = m.groups()
        label = re.search(r'<p class="part-label">(.*?)</p>', inner)
        title = re.search(r"<h1>(.*?)</h1>", inner, re.S).group(1)
        entries.append((0, sid, (label.group(1) + ": " if label else "") + title))
        if "lesson" in cls:
            core = False
            for h in re.finditer(r'<h([23]) id="([^"]+)">(.*?)</h\1>', inner, re.S):
                lvl, hid, text = h.groups()
                if lvl == "2":
                    core = re.sub("<.*?>", "", text) == "Core concepts"
                    entries.append((1, hid, text))
                elif core:
                    entries.append((2, hid, text))
    return entries

def toc_page(entries, pages=None):
    rows = "".join(
        f'<div class="lv{lv}"><a href="#{i}"><span class="t">{t}</span><span class="dots"></span>'
        f'<span class="n">{(pages or {}).get(i, "00")}</span></a></div>' for lv, i, t in entries)
    return f'<section class="toc-page" id="contents"><h1>Contents</h1><div class="toc">{rows}</div></section>'

def dest_pages(pdf_path):
    from pypdf import PdfReader
    r = PdfReader(pdf_path)
    return {k.lstrip("/"): r.get_destination_page_number(v) + 1 for k, v in (r.named_destinations or {}).items()}


# Shared print styles (from the Module 0 packet, v3, 2026-10-12)
PACKET_CSS = """
@page { size: Letter; margin: 0.75in 0.7in 0.85in 0.7in; }
* { box-sizing: border-box; }
body { font: 10.5pt/1.5 "Segoe UI", "DejaVu Sans", Arial, sans-serif; color: #1f2328; margin: 0; }
h1 { font-size: 20pt; margin: 0 0 10pt; color: #0F2849; }
h2 { font-size: 13.5pt; margin: 16pt 0 6pt; color: #0F2849; break-after: avoid; }
h3 { font-size: 11.5pt; margin: 12pt 0 4pt; break-after: avoid; }
p, li { orphans: 3; widows: 3; }
code { font-family: Consolas, "DejaVu Sans Mono", monospace; font-size: 9.5pt; background: #f2f4f7; padding: 0 3px; border-radius: 3px; }
pre { background: #f2f4f7; padding: 8pt 10pt; border-radius: 5px; font-size: 9.5pt; white-space: pre-wrap; break-inside: avoid; }
pre code { background: none; padding: 0; }
img { max-width: 100%; max-height: 3.0in; object-fit: contain; display: block; margin: 6pt auto; break-inside: avoid; }
img[src*="brand/marker-"] { display: inline-block; width: 15pt; height: 15pt; margin: 0 3pt 0 0; vertical-align: -0.3em; }
div[role="separator"] { break-after: avoid; }
div[role="separator"] img { display: block; margin: 0; max-height: none; object-fit: fill; }
blockquote { margin: 8pt 0; padding: 6pt 12pt; border-left: 4px solid #1A52BB; background: #eef3fc; }
table { border-collapse: collapse; width: 100%; font-size: 9.5pt; break-inside: avoid; }
th, td { border: 1px solid #c9d1da; padding: 5pt 6pt; vertical-align: top; text-align: left; }
th { background: #eef2f7; }
.part { break-before: page; }
.part-label { text-transform: uppercase; letter-spacing: 0.12em; font-size: 9pt; color: #6b7280; margin: 0 0 2pt; }
.task-list-item { list-style: none; margin-left: -1.2em; padding-left: 1.5em; text-indent: -1.5em; }
.task-list-item input { margin-right: 6pt; }
.lesson h2 { border-top: 1px solid #e5e7eb; padding-top: 8pt; }
/* cover */
.cover { height: 9.0in; display: flex; flex-direction: column; padding-top: 0.4in; }
.brand { font-size: 30pt; font-weight: 800; color: #0F2849; margin: 0; letter-spacing: -0.5px; }
.sub { font-size: 12pt; color: #4b5563; margin: 0 0 1.1in; }
.cover-title .mod { font-size: 13pt; color: #1A52BB; font-weight: 700; margin: 0; text-transform: uppercase; letter-spacing: 0.1em; }
.cover-title h1 { font-size: 46pt; margin: 0; line-height: 1.05; }
.tag-line { font-size: 13pt; color: #374151; margin-top: 8pt; }
.contents { margin-top: 0.8in; border-top: 2px solid #0F2849; padding-top: 10pt; }
.c-head { font-weight: 700; margin: 0 0 4pt; }
.contents li { margin: 3pt 0; }
.parent { color: #6b7280; margin: auto 0 0; }
.free-link { font-size: 10.5pt; color: #374151; margin-top: 10pt; }
.cover img.logo { width: 3in; max-height: none; margin: 0 0 4pt; }
.next { margin-top: 24pt; border-top: 2px solid #0F2849; padding-top: 8pt; }
.next-label { text-transform: uppercase; letter-spacing: 0.12em; font-size: 9pt; color: #1A52BB; font-weight: 700; margin: 0; }
a { color: #1A52BB; }
/* setup log */
.log td.write { height: 26pt; min-width: 1.8in; }
.log td:last-child, .log th:last-child { text-align: center; width: 0.55in; } .log td:last-child { font-size: 14pt; }
.fill p { margin: 10pt 0; }
.line { display: inline-block; border-bottom: 1px solid #555; width: 4.2in; height: 12pt; vertical-align: bottom; }
.line.short { width: 2in; }
.checks { display: grid; grid-template-columns: 1fr; gap: 10pt; }
.checks-intro { break-after: avoid; } h2.checks-head { break-before: page; }
.checks figure { margin: 0; break-inside: avoid; }
.checks img { max-height: 2.6in; }
figcaption { font-size: 9pt; color: #374151; break-before: avoid; }
figure { break-inside: avoid; }
p:has(> img:not([src*="brand/"])) { break-after: avoid; break-inside: avoid; }
p:has(+ pre), p:has(+ div[role="separator"]) { break-after: avoid; }
pre { break-inside: auto; }

.tag { font-size: 8pt; color: #6b7280; white-space: nowrap; }
/* troubleshooting */
.prob { border: 1px solid #d6dbe1; border-radius: 6px; padding: 4pt 12pt 6pt; margin: 0 0 10pt; break-inside: avoid; }
.prob h3 { margin-top: 6pt; color: #0F2849; }
.prob p { margin: 4pt 0; }
.prob .sym { background: #f6f8fa; padding: 4pt 6pt; border-radius: 4px; }
figure.wide { margin: 4pt 0; }
figure.wide img { max-width: 85%; }
/* self-assessment */
.rubric td.c { text-align: center; font-size: 14pt; width: 0.75in; }
.rubric th:not(:first-child) { text-align: center; }
.write-qs { margin-bottom: 0; } .write-qs li { margin-bottom: 4pt; } .write-qs li:last-child { margin-bottom: 0; }
.answers li { margin-bottom: 8pt; }
.lines { height: 58pt; background: repeating-linear-gradient(to bottom, transparent 0 19pt, #9aa3ad 19pt 20pt); margin-top: 4pt; }
"""
