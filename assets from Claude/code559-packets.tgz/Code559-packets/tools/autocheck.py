import re, glob, os, json, subprocess, tempfile
from markdown_it import MarkdownIt
from mdit_py_plugins.footnote import footnote_plugin
from playwright.sync_api import sync_playwright
import sys
BLOG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "Code559", "blog")
md=MarkdownIt("commonmark",{"html":True}).enable("table").use(footnote_plugin)
TEMPLATE=["Why this matters","Before you start","Core concepts","Exercise","Project","Common misconception","Summary","Check your understanding","Before next module","Go further","What to keep"]
BANNED=re.compile(r"\b(genuinely|honestly|straightforward|germain|codingjrwells|frontendmentor)\b|J:\\\\",re.I)
out={}
os.makedirs("render",exist_ok=True)
files=sorted(glob.glob(BLOG+"/module-*.md"))+[BLOG+"/index.md"]
with sync_playwright() as p:
    b=p.chromium.launch()
    for f in files:
        name=os.path.basename(f); src=open(f,encoding="utf-8").read()
        body=re.sub(r"^---\n.*?\n---\n","",src,flags=re.S)
        r={}
        h2=[re.sub(r"\s*\(.*\)$","",h).strip() for h in re.findall(r"(?m)^## (.+)$",body)]
        if name!="index.md":
            got=[h for h in h2 if any(h.startswith(t) for t in TEMPLATE)]
            want=[t for t in TEMPLATE]
            seq=[next(t for t in TEMPLATE if h.startswith(t)) for h in got]
            r["missing_sections"]=[t for t in TEMPLATE if t not in seq]
            r["out_of_order"]= seq!=sorted(seq,key=TEMPLATE.index)
            r["extra_h2"]=[h for h in h2 if not any(h.startswith(t) for t in TEMPLATE)]
        r["unverified"]=len(re.findall(r"\[unverified",body,re.I))
        r["banned"]=sorted(set(m.group(0) for m in BANNED.finditer(body)))
        r["build_path_in_text"]=len(re.findall(r"/home/claude",body))
        r["placeholders"]=sorted(set(re.findall(r"(PACKET_LINK_\w+|AFFILIATE_\w+)",body)))
        imgs=re.findall(r"!\[([^\]]*)\]\(([^)]+)\)",body)
        r["md_images"]=len(imgs); r["empty_alt"]=[s for a,s in imgs if not a.strip()]
        html=md.render(body)
        page=os.path.join(BLOG,"__qa_"+name+".html")
        open(page,"w",encoding="utf-8").write(f"<!doctype html><meta charset=utf-8><body>{html}</body>")
        pg=b.new_page(); pg.goto("file://"+page); pg.wait_for_timeout(400)
        res=pg.evaluate("""()=>({
          broken:[...document.images].filter(i=>!i.complete||i.naturalWidth===0).map(i=>i.getAttribute('src')),
          nimg:document.images.length,
          links:[...document.querySelectorAll('a[href]')].map(a=>a.getAttribute('href')),
          text:document.body.innerText})""")
        pg.close(); os.remove(page)
        r["rendered_images"]=res["nimg"]; r["broken_images"]=res["broken"]
        rel=[h for h in res["links"] if not re.match(r"^(https?:|mailto:|#|PACKET_LINK|AFFILIATE)",h)]
        r["broken_rel_links"]=[h for h in rel if not os.path.exists(os.path.join(BLOG,h.split('#')[0]))]
        r["ext_links"]=[h for h in res["links"] if h.startswith("http")]
        t=res["text"]
        r["leftover_md"]=[m for m in re.findall(r".{0,25}(?:\*\*|```|\]\(|<img|<div).{0,25}",t)][:5]
        r["words"]=len(t.split())
        # code blocks
        blocks=re.findall(r"```(\w*)\n(.*?)```",body,re.S)
        r["code_blocks"]={}
        for lang,code in blocks: r["code_blocks"][lang or "none"]=r["code_blocks"].get(lang or "none",0)+1
        bad=[]
        for lang,code in blocks:
            if lang in("js","javascript"):
                with tempfile.NamedTemporaryFile("w",suffix=".mjs" if "import " in code else ".js",delete=False) as tf: tf.write(code); fn=tf.name
                cp=subprocess.run(["node","--check",fn],capture_output=True,text=True); os.unlink(fn)
                if cp.returncode: bad.append(cp.stderr.strip().splitlines()[-1][:120] if cp.stderr.strip() else "error")
        r["js_syntax_errors"]=bad
        out[name]=r
    b.close()
json.dump(out,open("autocheck.json","w"),indent=1,ensure_ascii=False)
for n,r in out.items():
    flags={k:v for k,v in r.items() if v and k not in("placeholders","rendered_images","md_images","words","code_blocks","ext_links","unverified")}
    print(f"{n:38s} words={r['words']:5d} imgs={r['rendered_images']:3d} unverified={r['unverified']} code={r['code_blocks']}")
    for k,v in flags.items(): print("    ",k,":",v)
