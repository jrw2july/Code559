# Module 4 packet plan

- Free Exercise (already in the post): Contact form and keyboard checks in `practice-04`
- Packet project (the public promise in the post's teaser): The **rating card** (HTML, then CSS; JavaScript waits for Module 10), plus a Contact page added to `my-site`
- Finishing work in Git: Save routine. **Decided 2026-10-12:** the rating card is a page inside `my-site`, not its own repository

## Files to write (see build_packet.py header)
- [ ] project.md: "# Project: ..." then The brief (picture of the finished thing, what the visitor can do, exact words) and The steps (skeleton snippets, a comment where the reader continues alone)
- [ ] finishing.md: Git steps; NEW items marked
- [ ] troubleshooting.md (only if this module has common failures)
- [ ] selfcheck.md: "## Rubric" list (one line per concept, the §4 rubric) + written questions
- [ ] answers.md: Check your understanding, Common misconception, Exercise checks
- [ ] images/: packet-only pictures pNN-*.png (real renders / real captured output; drawn screens tagged ILLUSTRATION)

## Verification before delivery
- [ ] every project snippet run for real (Chromium for pages, Node for scripts, Git in a throwaway repo)
- [ ] teaser in the post matches the project delivered
- [ ] style rules: names (my-site, styles.css, practice-NN), F5 viewing, focus rings, banned words, no build paths
- [ ] built PDF: Contents page numbers match, no broken images, cover has no footer
- [ ] independent check by a reviewer that did not write it
