# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **What `required` is attached to.** It is written on one radio, but for radios it works on the whole **group**: every radio with the same `name`. MDN: if any radio in a same-named group has `required`, "a radio button in that group must be checked, although it doesn't have to be the one with the attribute applied." In the lesson's Console check, the third radio had no `required` but still reported `valueMissing: true`. On your rating card, only `rating-1` has `required`, and Send rating with nothing chosen was refused. (Core concept 3; Exercise step 6; Project step 5)
2. **The message never appears in the address.** The two most likely causes: the textarea has **no `name`** (a control with no name is not sent; on the sample page the address then ended after `visitor-email`), or the textarea sits **outside the `<form>` tags**, so it is not part of the form. (An aside: an empty field that is not required still sends its name with nothing after it, `message=`. Your Contact form's textarea is `required`, so the browser will not send it empty.) (Core concept 2; *Troubleshooting*, problem 3)
3. **Proving five labels are joined.** Click each label's text, one by one, with the mouse, not the circles. Each click must check its own radio and turn the one before off. Then send the form after choosing each number and read the address: `?rating=1` to `?rating=5`. A label with a wrong `for` checks nothing (Project step 17). With the keyboard you can test the group, but not the labels, because the arrow keys move between radios without using the labels. (Core concepts 1 and 3; Project steps 5 and 17)

## Common misconception

*"The radio circle is what the visitor clicks, so that is where the styling and the behavior go."* In step 3 of the Exercise you clicked the **label**, the words, and the label checked its radio through `for` and `id`. In step 8, the CSS turned the label into the round button, and the radio itself became a 1-pixel, invisible control. The behavior (the group, the arrow keys, `required`, the `name=value` that is sent) still belongs to the real radio. The look belongs to the label, styled from the radio's state with `input:checked + label` and `input:focus-visible + label`. Your rating card works the same way: you never see a radio, yet Tab, the arrow keys and `?rating=4` all come from the radios. (Core concept 8; Project steps 7 and 8)

## Exercise checks

- **Step 1.** Clicking each label puts the cursor in its field. After a full submit, the address ends in `?visitor-name=…&visitor-email=…&message=…`: three pairs, and no nickname, because that input has no `name`. `@` shows as `%40` and a space as `+`. (Core concepts 1 and 2)
- **Steps 3 and 4.** Clicking a label selects its radio and turns the others off. With "3 to 5" chosen, the address ends in `?hours=3-5`. (Core concept 3)
- **Step 5.** Sample sentence: "The arrow keys move the choice inside the group; Tab leaves the group and goes to the next control." The first Tab into the group focuses it without choosing anything. (Core concept 6)
- **Step 6.** Send with nothing chosen is refused, focus moves to the group, and `checkValidity()` returns `false`. After you choose any radio, it returns `true`. (Core concept 3)
- **Step 7.** With `hourz` on the second radio, two radios can be on at once, because a different `name` makes a second group. (Core concept 3)
- **Step 8.** The mouse colors a choice on hover and fills it when checked. With the keyboard, the ring sits on the label of the focused radio and moves with the arrow keys. (Core concept 8)
- **Step 9.** Sample sentence: "With `display: none`, that radio left the Tab order, so the keyboard could no longer reach that choice." (Core concepts 5 and 8; *Troubleshooting*, problem 5)

## Self-assessment questions

1. **Why `display: none` broke the Send rating button.** `display: none` takes the radios out of the page, so the keyboard cannot reach them and nothing can focus them. The first radio has `required`. When you press Send rating with nothing chosen, the browser refuses to send, and it wants to move focus to the group to show its message. It cannot focus a radio with `display: none`, so it shows nothing at all. The Console says `An invalid form control with name='rating' is not focusable.` `.visually-hidden` keeps each radio on the page, only 1 × 1 px. So it stays in the Tab order, it can take focus, a screen reader can still read it, and the browser can show its message. (Project steps 5, 7 and 15)
2. **A mistake you made.** There is no single answer. A good answer names the mistake, quotes what the page, the address bar or the Console really showed, for example `?ratng=2&rating=4`, and says how you found the cause, for example by clicking every label one by one.
3. **A "How did you find me?" field.** First, a `<fieldset>`. Second, a `<legend>` that says **How did you find me?** Third, three radios, each right before its own label: `<input type="radio" name="found-by" value="search" id="found-search">` with `<label for="found-search">Search</label>`, then the same for `friend` with the label **A friend**, and for `github` with the label **GitHub**. All three share one `name`, each has its own `id` and `value`, and each label's `for` matches its radio's `id`. If you put the fieldset after the Message field and a visitor chose A friend, the address would end in `&found-by=friend`: the group's `name`, then the checked radio's `value`. Your `name` and `value` words may differ; the pattern is what matters. (The brief; Project steps 4, 5, 13, 16 and 17)

## Project checks

- **Step 2.** The address ends in `rate.html?rating=4`: the group's `name`, then the checked radio's `value`.
- **Step 5.** Tab order in Chromium: the five nav links, the group (radio 1, nothing chosen), then Send rating. The empty submit leaves the address unchanged and moves focus to radio 1.
- **Step 7.** The radios and the legend disappear, but Tab still reaches the group. Each hidden radio measures 1 × 1 px.
- **Step 8, continue alone.** The checked state:

  ```css
  .choices input:checked + label {
    background-color: var(--accent);
    border-color: var(--accent);
    color: white;
  }
  ```

  The button hover and the thanks rule:

  ```css
  .rating-form button:hover,
  .contact-form button:hover {
    background-color: var(--accent);
    border-color: var(--accent);
  }

  .thanks {
    text-align: center;
  }
  ```

- **Step 10.** Without `hidden`, the thank-you shows under the form with an empty space where the number goes. With `hidden`, Chromium measured the section at height 0 with `display: none`. Adding `display: block` to `.thanks` in the CSS made it show (144 px tall) even with `hidden` in the HTML: that is why the brief says to give `.thanks` no `display`.
- **Step 12, continue alone.**

  ```css
  .contact-form label {
    display: block;
    font-weight: 700;
    margin-top: 16px;
  }

  .contact-form input,
  .contact-form textarea {
    width: 100%;
    padding: 8px;
    font: inherit;
    border: 2px solid var(--ink);
    border-radius: 4px;
  }

  .contact-form button {
    margin-top: 24px;
  }
  ```

- **Step 13.** The empty submit stops at Your name. A full submit gives `contact.html?visitor-name=Sam&visitor-email=sam%40example.com&message=Hello+there` with the sample text.
- **Step 14.** One change in `:root` changes every place that uses `var(--accent)`. White on `#7c3aed` is 5.7:1, so that color passes too.
- **Step 15.** Tab skips the group; the mouse still works; an empty Send does nothing, and the Console says `An invalid form control with name='rating' is not focusable.`
- **Step 16.** `?ratng=2&rating=4`.
- **Step 17.** The broken part is the label: its `for` points to `rating4`, an id that does not exist.
