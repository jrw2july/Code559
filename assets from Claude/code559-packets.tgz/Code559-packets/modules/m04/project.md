# Project: A rating card and a Contact page

*Your hands, about 2 hours (estimate).* In the Exercise you built a practice contact page and a styled radio group in `practice-04`. Now you add two pages to your real site. The first is the **rating card**: a small card that asks "Rate this lesson," offers five round choices from 1 to 5, and has a **Send rating** button. You build it from a written brief, HTML first, then CSS. The second is a **Contact** page with a real form, built the way you built your practice contact page. Both pages join the nav on every page, and the nav learns to mark the page you are on. You use only HTML and CSS. There is no JavaScript: the card's JavaScript comes in Module 10.

This project starts from the Module 3 packet's site: Home, About and Interests, one shared `styles.css` with a mobile-first header, and an `images` folder. If your site does not have that yet, finish the Module 3 packet project first (Part 2), then come back.

## The brief

Read the whole brief twice before you type anything. This is the kind of brief you get at work: a picture, what the visitor can do, the exact words, and the colors.

When you finish, `my-site` holds two new pages, `rate.html` and `contact.html`, next to `index.html`, `about.html`, `interests.html`, `styles.css`, `image-one.jpg` and the `images` folder. All five pages link the same `styles.css`.

**The nav.** Every page's nav has five links, in this order: **Home**, **About**, **Interests**, **Rate**, **Contact**. Rate goes to `rate.html`. Contact now goes to `contact.html` (in Modules 2 and 3 it went to `index.html#contact`). On each page, the link to that page has `aria-current="page"`, and no other link has it. So the headers are now the same on every page except for where that one attribute sits.

**The rating card page.** It has the same `<head>`, header and footer as your other pages, with the title `Rate this lesson - Your Name`. Its `<main>` holds one `<div class="rating-card">` with two parts:

- A `<form class="rating-form">` with an `<h2>` that says **Rate this lesson**, one sentence: **How clear was today's lesson? Choose 1 if you felt lost, 5 if it all made sense.**, then a `<fieldset class="choices">` and a `<button type="submit">` that says **Send rating**.
- The fieldset starts with a `<legend>` that says **Rate the lesson from 1 to 5**. Sighted visitors do not see it, but screen readers read it. Then come five radios, each right before its own label. All five share `name="rating"`. Their values are `1` to `5`, their ids `rating-1` to `rating-5`, and each label shows its number. The first radio has `required`.
- A `<section class="thanks" hidden>` after the form. It holds a paragraph **You chose <span id="chosen-rating"></span> out of 5**, an `<h2>` **Thanks for the feedback**, and one more sentence of your own. The check icon in the lesson's picture of the thank-you state is optional; the card works without it. The section stays hidden in this module. In Module 10, JavaScript fills the span, hides the form and shows this section.

**What the visitor can do.** With a mouse: click a number to choose it, and see it change color when the pointer is over it. With a keyboard: press Tab to reach the group, use the arrow keys to choose, see a dark orange ring around the focused number, then Tab to **Send rating** and press Enter. If nothing is chosen, the browser refuses to send and says so. If 4 is chosen, the address ends in `?rating=4`.

**The colors.** Five custom properties on `:root`, used everywhere the card needs a color:

| Name | Value | Used for |
|---|---|---|
| `--card` | `#ffffff` | the card background |
| `--ink` | `#1d3557` | borders, number text, the button (the navy of your header) |
| `--accent` | `#0f766e` | a checked number, and the button on hover (teal) |
| `--soft` | `#e6f2f0` | a number under the mouse (pale teal) |
| `--ring` | `#b45309` | the focus ring (dark orange) |

The accent colors are your choice: pick your own `--accent` and `--soft`, as long as white text on `--accent` and `--ink` text on `--soft` both reach 4.5:1. `--ink` and `--ring` stay fixed, as in the table. The values above were checked with the WCAG contrast formula: white on the teal is 5.5:1, the navy on the pale teal is 10.8:1, the dark orange ring is 5.0:1 on the white card and 4.7:1 on your cream page background.

**The Contact page.** Same `<head>`, header and footer, with the title `Contact - Your Name`. Its `<main>` holds a `<section>` with an `<h2>` **Contact me**, one sentence with `class="lead"`, and a `<form class="contact-form">` with three labeled fields and a button:

- **Your name:** `<input type="text">`, id and name `visitor-name`, `required`.
- **Email:** `<input type="email">`, id and name `visitor-email`, `required`.
- **Message:** `<textarea>`, id and name `message`, `rows="5"`, `required`.
- A `<button type="submit">` that says **Send message**.

Unlike the practice page, every field has a `name`. There is no nickname trap this time.

**Focus rings.** Every link, input, textarea and button gets a 3 px dark orange ring (`#b45309`) when it has keyboard focus. The nav links sit on the navy bar, where that ring is too dark (2.5:1), so they get the light orange ring `#fdba74` (7.3:1 on the navy). The link with `aria-current="page"` is bold, with a thicker underline.

On a phone, the card is as wide as the page allows, and the five numbers sit in one row. On a laptop, the card stays 400 px wide in the middle of the page. Nothing scrolls sideways at 390 px. The class names, ids, names, values and file names must match the brief; the sentences you write yourself are yours.

![The rating card page at 390 pixels wide: the navy header with Your Name and the links Home, About, Interests, Rate in bold, and Contact on a second line, then a white card with a navy border. The card says Rate this lesson, then the question, then five round numbers 1 to 5. Number 4 is filled teal with white text and has a dark orange ring around it. Below is a wide navy Send rating button.](images/p04-rate-390.png)
*The finished rating card on a phone, driven by keyboard only: six Tabs, then three presses of the right arrow. 4 is checked (teal) and has keyboard focus (dark orange ring). Rate is bold in the nav because this page's link has `aria-current="page"`. (real: rendered in Chromium at 390 px)*

![The Contact page at 390 pixels wide: the same header with Contact in bold, then Contact me, a sentence, three labeled fields filled in with Sam, sam@example.com and Hello there, and a wide Send message button with a dark orange ring.](images/p04-contact-390.png)
*The Contact page filled in, with the Send message button reached by Tab. Each label sits above its field. (real: rendered in Chromium at 390 px)*

## The steps

Type every line. Do not paste. The one exception is the header and footer, which you copy from an existing page, as you did in Modules 1 and 3.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`.
2. **Read the brief like a builder.** On paper, sketch the card. Next to each part, write the element it becomes, as in the lesson's Concept 9: the heading, the sentence, the group of five, the button, the thank-you. Do not write any CSS yet. Then write down one prediction: when you submit the card with 4 chosen, what will the end of the address say?
3. **Update the nav on the three old pages.** In `index.html`, change the nav to five links and mark the current page:

   ```html
   <nav>
     <a href="index.html" aria-current="page">Home</a>
     <a href="about.html">About</a>
     <a href="interests.html">Interests</a>
     <a href="rate.html">Rate</a>
     <a href="contact.html">Contact</a>
   </nav>
   ```

   Make the same change in `about.html` and `interests.html`, but move `aria-current="page"` to that page's own link: About on the About page, Interests on the Interests page. Then read the three navs line by line. They must match except for where `aria-current` sits. If you already added `aria-current` after the lesson, check it and add the two new links. Your Home page can keep its old Contact section; the nav simply does not point to it any more.
4. **Build the rating card HTML.** In the Explorer, create `rate.html`. Copy all of `about.html` into it. Change the title to `Rate this lesson - Your Name`, move `aria-current="page"` to the Rate link, and replace everything between `<main>` and `</main>` with this skeleton:

   ```html
   <main>
     <div class="rating-card">
       <form class="rating-form">
         <h2>Rate this lesson</h2>
         <p>How clear was today's lesson? Choose 1 if you felt lost, 5 if it all made sense.</p>
         <fieldset class="choices">
           <legend class="visually-hidden">Rate the lesson from 1 to 5</legend>
           <input class="visually-hidden" type="radio" name="rating" value="1" id="rating-1" required>
           <label for="rating-1">1</label>
           <input class="visually-hidden" type="radio" name="rating" value="2" id="rating-2">
           <label for="rating-2">2</label>
           <!-- Continue alone: radios 3, 4 and 5, each input right
                before its label, the same pattern as 2. -->
         </fieldset>
         <button type="submit">Send rating</button>
       </form>
       <!-- Continue alone: the section with class="thanks" and the
            hidden attribute, with the three parts from the brief. -->
     </div>
   </main>
   ```

   Read one radio to yourself, out loud: what do its `id`, `name` and `value` each do, and which label points to it? The class `visually-hidden` does nothing yet. Its rule comes in step 7, so for now you see plain radios and the legend.
5. **Test the HTML before any CSS.** Save, open `rate.html` in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window), and press **F5** after each save. The card has no look yet: plain circles in a box with the legend in its border.

   ![The rate page at 390 pixels before the card CSS: the header, the heading Rate this lesson, the sentence, then a plain gray box whose border holds the words Rate the lesson from 1 to 5, five small radio circles numbered 1 to 5 with 4 selected, and a small plain Send rating button.](images/p04-rate-nocss-390.png)
   *The card's HTML with only the old site styles. It already works: the legend is visible, the radios are real, and 4 is selected. (real: rendered in Chromium at 390 px)*

   Now test it four ways, and tick each one:

   - [ ] **Labels.** Click the number 3, not the circle. Circle 3 turns on. Click 5: 3 turns off.
   - [ ] **Keyboard.** Press F5, put the mouse aside, and press Tab. Chromium visited the five nav links, then the group (circle 1, with nothing chosen), then **Send rating**. Inside the group, the arrow keys move the choice.
   - [ ] **Nothing chosen.** Press F5 and press **Send rating**. The address does not change, focus moves to circle 1, and a small message appears (Chromium's says "Please select one of these options."; yours may be worded differently).
   - [ ] **A real submit.** Choose 4 and press Send rating. The address now ends in `rate.html?rating=4`. Compare it with your prediction from step 2.

   If one test fails, fix the HTML now. CSS will not fix it later; it will only hide it.
6. **Add the focus rings and the current-page style.** Open `styles.css`. In the site-wide basics, after the `a` rule, add one rule for every control a keyboard can reach:

   ```css
   a:focus-visible,
   input:focus-visible,
   textarea:focus-visible,
   button:focus-visible {
     outline: 3px solid var(--ring);
     outline-offset: 2px;
   }
   ```

   A comma between selectors means "the same rule for each of these." `var(--ring)` reads a custom property you define in the next step. Then, in the header and nav group, after your `nav a` rule:

   ```css
   nav a:focus-visible {
     outline-color: #fdba74;
   }

   nav a[aria-current="page"] {
     font-weight: 700;
     text-decoration-thickness: 3px;
   }
   ```

   `outline-color` swaps only the ring's color on the navy bar; it keeps the width and style. `text-decoration-thickness` makes the underline thicker.
7. **Add the colors and the hiding class.** At the top of `styles.css`, right after the box-sizing rule and before the site-wide basics, add the colors from the brief:

   ```css
   /* Colors: custom properties */
   :root {
     --card: #ffffff;
     --ink: #1d3557;
     --accent: #0f766e;
     --soft: #e6f2f0;
     --ring: #b45309;
   }
   ```

   Then, at the end of the reusable classes group, add the class from Concept 8, exactly:

   ```css
   /* Hidden from sight, still there for keyboards and screen readers */
   .visually-hidden {
     position: absolute;
     width: 1px;
     height: 1px;
     margin: -1px;
     padding: 0;
     overflow: hidden;
     clip-path: inset(50%);
     white-space: nowrap;
     border: 0;
   }
   ```

   Save and press F5 on `rate.html`. The circles and the legend disappear, and only the numbers are left. Press Tab until you pass the nav: focus still enters the group, even though you cannot see the radios. Chromium measured each hidden radio at 1 × 1 px.
8. **Style the card.** Add a new group after the Interests page group and **before** the wider-screens block, which stays last:

   ```css
   /* Rating card */
   .rating-card {
     max-width: 400px;
     margin: 24px auto;
     padding: 24px;
     background-color: var(--card);
     border: 2px solid var(--ink);
     border-radius: 8px;
   }

   .rating-card h2 {
     margin-top: 0;
   }

   .choices {
     border: 0;
     margin: 0 0 24px;
     padding: 0;
     display: flex;
     justify-content: space-between;
   }

   .choices label {
     width: 48px;
     height: 48px;
     display: grid;
     place-items: center;
     border: 2px solid var(--ink);
     border-radius: 50%;
     font-weight: 700;
     cursor: pointer;
   }

   .choices label:hover {
     background-color: var(--soft);
   }

   .choices input:focus-visible + label {
     outline: 3px solid var(--ring);
     outline-offset: 3px;
   }

   /* Continue alone: the checked state. A label right after a checked
      input gets var(--accent) as its background and border color,
      and white text. */
   ```

   `margin: 24px auto` puts the card in the middle once the page is wider than 400 px. `display: grid` with `place-items: center` puts the number in the middle of its circle. The `border: 0` and `padding: 0` on `.choices` remove the box every fieldset has by default. The legend is still there for screen readers; only the box goes.

   Then style the button. Both forms use the same button, so one rule covers both:

   ```css
   .rating-form button,
   .contact-form button {
     width: 100%;
     padding: 12px;
     font-size: 16px;
     font-weight: 700;
     color: white;
     background-color: var(--ink);
     border: 2px solid var(--ink);
     border-radius: 4px;
     cursor: pointer;
   }

   /* Continue alone: the same two selectors with :hover, using
      var(--accent) for the background and the border. Then a .thanks
      rule with text-align: center. Give .thanks no display value:
      a display rule would beat the hidden attribute. */
   ```

9. **Run the card.** Save, press F5, and check it against the picture in the brief. Then repeat the four tests from step 5 with the new look: labels, keyboard, nothing chosen, a real submit. This time, watch the ring: it follows the keyboard onto the numbers and the button, and it is light orange on the nav links. Move the mouse over a number to see the pale hover color.
10. **Peek at the thank-you, then hide it again.** In `rate.html`, delete the word `hidden` from the thanks section and save. Press F5: the thank-you section appears under the form, with an empty space where the number will go. Put `hidden` back, save, and press F5. In Module 10, JavaScript does this swap for you.
11. **Build the Contact page.** Create `contact.html`. Copy all of `about.html` into it, change the title to `Contact - Your Name`, move `aria-current="page"` to the Contact link, and replace the inside of `<main>`:

    ```html
    <main>
      <section>
        <h2>Contact me</h2>
        <p class="lead">One sentence that invites a message.</p>
        <form class="contact-form">
          <label for="visitor-name">Your name</label>
          <input type="text" id="visitor-name" name="visitor-name" required>

          <!-- Continue alone: the Email label and input, the Message
               label and textarea (rows="5"), and the Send message
               button, as in the brief. Every field gets a name. -->
        </form>
      </section>
    </main>
    ```

12. **Style the Contact form.** After the rating card group, and still before the wider-screens block, add:

    ```css
    /* Contact page */
    .contact-form {
      max-width: 480px;
    }

    /* Continue alone: .contact-form label is a block with bold text
       and 16px space above it. .contact-form input and .contact-form
       textarea are 100% wide, with 8px padding, font: inherit, a 2px
       border in var(--ink) and a 4px radius. .contact-form button gets
       24px space above it. */
    ```

    `font: inherit` matters: browsers give inputs and textareas their own smaller font unless you tell them to use the page's.
13. **Test the Contact page.** Save and press F5. Click each label: the cursor jumps into its field. Press F5 and press **Send message** with everything empty: the browser stops at Your name. Fill in all three fields and send. On the sample page, Chromium's address ended in:

    ```
    contact.html?visitor-name=Sam&visitor-email=sam%40example.com&message=Hello+there
    ```

    Three pairs, because all three fields have a `name`.
14. **Modify.** In `:root`, change `--accent` to another dark color, for example `#7c3aed`. Save and press F5 on `rate.html`. The checked number and the button's hover color both change, from one line. Check that white text is still easy to read on your new color, then put `#0f766e` back (or keep your color if it reaches 4.5:1 with white).
15. **Break it on purpose: `display: none`.** Add this rule to the reusable classes group, then change all five `class="visually-hidden"` on the **radios** (not the legend) to `class="gone"`:

    ```css
    .gone {
      display: none;
    }
    ```

    Save, press F5, and predict before you press Tab. The card looks the same. Now Tab through the page. Chromium went from the Contact link straight to **Send rating**: the group was skipped. The mouse still works, because clicking a label still checks its radio. Press F5 and press Send rating with nothing chosen. Nothing happens at all: no message, no change in the address. Open the Console (**F12**, then the **Console** tab). Chromium printed `An invalid form control with name='rating' is not focusable.` (once for each radio, so you may see it five times) The browser wants to send focus to the group to show its message, and it cannot. Put `class="visually-hidden"` back on all five radios and delete the `.gone` rule.
16. **Break it on purpose: one wrong name.** Change the second radio's `name="rating"` to `name="ratng"`. Save, press F5, click 2, then click 4. Both stay teal. Press Send rating. Chromium's address ended in `?ratng=2&rating=4`: two groups, two pairs. Put the name back.
17. **Debug: a number that will not turn on.** Change the fourth label to `<label for="rating4">` (drop the dash). Save and press F5. Click 4. Nothing turns teal. Click 5, then 4 again: 5 stays on. Before you look at the code, write down which part is broken: the radio, the label, or the CSS. Then find it. The label's `for` points to an id that does not exist, so the click goes nowhere, and nothing is shown in the Console. The test from Check your understanding 3 in the lesson is how you catch this: click every label, one by one. Fix the `for` and test all five.
18. **Test the site.** Tick each box, at 390 px in device mode (F12, then Ctrl+Shift+M) and in a full-width window.

    - [ ] All five pages show the same five nav links, and each page's own link is bold
    - [ ] Every nav click works: five links on five pages
    - [ ] Nothing scrolls sideways at 390 px on any page
    - [ ] With the keyboard only, you can choose a rating and send it; the ring is dark orange on the card and light orange on the nav
    - [ ] Send rating with nothing chosen is refused; with 4 chosen, the address ends in `?rating=4`
    - [ ] The thank-you section is not visible
    - [ ] Every Contact label puts the cursor in its field, and a full submit shows three pairs in the address

19. **Put it online.** Go to Part 3, *Finishing work in Git*, and publish both pages with the save routine. Then run the test from step 18 again on the live site.
