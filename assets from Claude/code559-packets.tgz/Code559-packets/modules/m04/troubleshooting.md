# Troubleshooting: five common problems

Each problem has the symptom you see, why it happens, and the fix. Each one was made on purpose on the sample site and tested in Chromium. After each fix, save, press F5, and run the test from Project step 18 again.

### 1. Clicking a label does nothing

**Symptom.** On the rating card, clicking one number does not turn it teal, and the choice you made before stays on. Or, on the Contact page, clicking a label does not put the cursor in its field. There is no error in the Console.

**Why.** The label's `for` does not match the control's `id`, letter for letter. On the sample card, `<label for="rating4">` next to `id="rating-4"` left the label joined to nothing: clicking 4 checked no radio, and after clicking 5, clicking 4 left 5 on. A screen reader user has the same problem in a worse form: the control has no name read out at all.

**Fix.** Click every label, one by one. For the one that fails, compare its `for` with the `id` of the control right before it (rating card) or right after it (Contact page). Look for a missing dash, a capital letter, or a number that was not changed when you copied a line.

### 2. Two numbers stay on at the same time

**Symptom.** You click 2, then 4, and both stay teal. Sending puts two pairs in the address.

**Why.** The radios are not one group. The `name` makes the group, so one radio with a different name starts a group of its own. On the sample card, `name="ratng"` on the second radio gave `rate.html?ratng=2&rating=4`.

**Fix.** Check that all five radios say exactly `name="rating"`. Then click 1 to 5 in turn: each click must turn the one before it off.

### 3. A field is missing from the address

**Symptom.** You fill in the whole Contact form and press Send message. The address shows `visitor-name` and `visitor-email`, but not `message`.

**Why.** A control with no `name` is not sent. On the sample page, a textarea without `name="message"` gave `contact.html?visitor-name=Sam&visitor-email=sam%40example.com`. A radio with a `name` but no `value` sends the word `on` (MDN, `<input type="radio">`), so you cannot tell which number was chosen.

**Fix.** Every control that should send data needs a `name`; every radio also needs its own `value`. Remember the split from the lesson: `id` is for the page (the label, the CSS), `name` is for the data.

### 4. The focus ring is hard to see on the nav

**Symptom.** You Tab through the nav and the ring around each link is a dark, muddy line on the navy bar. You can hardly tell which link has focus.

![The navy header with the Interests link focused by a dark orange ring that barely shows against the navy.](images/p04-navring-bad.png)
*Without the nav rule, the Interests link gets the dark orange ring meant for light backgrounds: 2.5:1 against the navy. (real: rendered in Chromium at 390 px)*

![The same header with a light orange ring around Interests.](images/p04-navring-good.png)
*With `nav a:focus-visible { outline-color: #fdba74; }` the ring is light orange: 7.3:1 against the navy. (real: rendered in Chromium at 390 px)*

**Why.** The site-wide rule gives every focused link a `#b45309` ring. That is 5.0:1 on white, but only 2.5:1 on `#1d3557`, below the 3:1 that MDN's *Color contrast* asks for interface parts. The `nav a:focus-visible` rule is missing or misspelled. Its place in the file does not matter: `nav a:focus-visible` names one more element than `a:focus-visible`, so it has higher specificity (Module 2) and wins wherever it sits.

**Fix.** In the header and nav group, check for exactly:

```css
nav a:focus-visible {
  outline-color: #fdba74;
}
```

Then Tab through the nav again. Each ring should be light orange.

### 5. The keyboard skips the rating group

**Symptom.** The card looks right and works with the mouse. But Tab goes from the Contact link straight to **Send rating**. Pressing Send rating with nothing chosen does nothing at all: no message, no change in the address.

**Why.** The radios were hidden with `display: none` instead of the `.visually-hidden` class. That takes them out of the Tab order, and the browser can no longer move focus to the group to show its "please select" message. On the sample card, Chromium printed this in the Console each time Send rating was pressed (once for each radio, so you may see it five times):

```
An invalid form control with name='rating' is not focusable.
```

The same happens if the `.visually-hidden` rule itself has `display: none` in it.

**Fix.** Give each radio `class="visually-hidden"`, and check that the rule is the one from Project step 7, with `clip-path: inset(50%)` and no `display` line. Then press Tab: focus should land on the group, and the arrow keys should move the teal number.
