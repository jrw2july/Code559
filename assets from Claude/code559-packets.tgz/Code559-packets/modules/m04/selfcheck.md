# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 5. If a line is a 1 or a 2, reread that Core Concept and redo its Exercise or Project step.

## Rubric

- I can join every label to its control with for and id, and test it by clicking the label
- I can explain the difference between id and name, and predict the name=value pairs a form will put in the address
- I can build a radio group with one shared name, a value on each radio, and required on one radio that covers the group
- I can wrap a group in fieldset and legend, and keep the legend for screen readers with .visually-hidden
- I can use the hidden attribute and say what it removes: sight, screen readers and the Tab order
- I can move through a form with Tab, Shift+Tab, the arrow keys and Enter, and say where focus should go
- I can add :focus-visible rings that reach 3:1 against what is behind them, and mark the current nav link with aria-current="page"
- I can turn a written brief into HTML elements before any CSS
- I can store colors in custom properties on :root and style a hidden radio's label with :hover, :checked and :focus-visible

## Three questions to answer in writing

1. In Project step 15, `display: none` on the radios made the Send rating button do nothing when no number was chosen. Explain why, in your own words, and say what `.visually-hidden` keeps that `display: none` takes away.
2. Pick one mistake you made in this module. What did the page, the address bar or the Console show, and how did you find the cause?
3. Your Contact page needs a fourth field: a "How did you find me?" choice of Search, A friend or GitHub. List every element and attribute you would write, in order, and say what the address would end in if a visitor chose A friend.
