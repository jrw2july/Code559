# Finishing work in Git

Your rating card and Contact page work on your computer. Now you put them online with the same save routine: `git status`, `git add .`, `git commit`, `git push`, then check the live page. What is new this time is two new pages in one commit, and testing a live form with the keyboard.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 to 3.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **See what changed.** Type:

   ```
   git status
   ```

   Under **Changes not staged for commit** you should see `modified:` for `about.html`, `index.html`, `interests.html` and `styles.css`: the three old pages changed because of the nav. Under **Untracked files** you should see `contact.html` and `rate.html`. If one of the three old pages is missing from the list, you forgot to update its nav. Fix it before you go on.
3. **Stage the changes.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. Run `git status` again. Under **Changes to be committed** you should now see six lines: four `modified:` and two `new file:` (`contact.html` and `rate.html`).
4. **Commit (NEW: two pages in one commit).** Type:

   ```
   git commit -m "Add a rating card page and a Contact page"
   ```

   On the sample site, Git printed `6 files changed` on the second line, then one `create mode 100644` line for each new page. Your commit id and line counts will differ. The two pages share the new nav, the focus rings and the colors in `styles.css`, so they go into one commit. A nav with a link to a page that is not there yet would be a broken site.
5. **Push.** Type:

   ```
   git push
   ```

   The last line ends in `main -> main`.
6. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. Your new commit is on top, with your Module 3 commit under it.
7. **Check the live pages.** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/rate.html` and press F5. Click each of the five nav links and check that each page's own link is bold.
8. **Test the live forms with the keyboard (NEW).** On the live `rate.html`, put the mouse aside. Tab to the group, choose 4 with the arrow keys, Tab to **Send rating** and press Enter. The address should end in `rate.html?rating=4`. The page looks the same after the submit: GitHub Pages only serves files, so nothing receives or stores the rating. In Module 10, the card's JavaScript shows the thank-you section on the page instead. Do the same on the live `contact.html` with all three fields filled in.
9. **Test on a phone.** If you have a phone, open your live Rate page on it. Tap a number, tap **Send rating**, and read the address.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows your new commit on top. On the live site, all five nav links work on all five pages, a keyboard-only rating sends `?rating=4`, and the Contact form sends three pairs.
