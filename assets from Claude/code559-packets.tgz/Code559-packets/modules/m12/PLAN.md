# Module 12 packet plan

- Free Exercise (already in the post): Local Git practice in `practice-12`
- Packet project (the public promise in the post's teaser): `my-site` through the full workflow: `.gitignore`, README, Issue, branch, pull request with `Closes #n`, line comments, merge, `git pull`, `v1.0` tag and release
- Finishing work in Git: Full workflow (the module's subject)

## Files to write (see build_packet.py header)
- [ ] project.md: "# Project: ..." then The brief (picture of the finished thing, what the visitor can do, exact words) and The steps (skeleton snippets, a comment where the reader continues alone)
- [ ] finishing.md: Git steps; NEW items marked
- [ ] troubleshooting.md (only if this module has common failures)
- [ ] selfcheck.md: "## Rubric" list (one line per concept, the §4 rubric) + written questions
- [ ] answers.md: Check your understanding, Common misconception, Exercise checks
- [ ] images/: packet-only pictures pNN-*.png (real renders / real captured output; drawn screens tagged ILLUSTRATION)

## Verification before delivery
- [ ] every project snippet run for real (Chromium for pages, Node for scripts, Git in a throwaway repo)
- [ ] teaser in the post matches the project delivered
- [ ] style rules: names (my-site, styles.css, practice-NN), F5 viewing, focus rings, banned words, no build paths
- [ ] built PDF: Contents page numbers match, no broken images, cover has no footer
- [ ] independent check by a reviewer that did not write it
