# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 13. If a line is a 1 or a 2, reread that Core concept and redo its Exercise or Project step.

## Rubric

- I can name Git's four places, and read the two columns of git status --short
- I can check changes with git diff and git diff --staged, one change per commit
- I can keep files out of Git with a .gitignore, and prove it with git status
- I can write a README with the four headings for a visitor
- I can work on a branch, merge it, delete it with -d, and say when -D fits
- I can fix a merge conflict by removing the markers, then git add and git commit
- I can push a new branch with -u, and open a pull request with Closes #n
- I can review my own pull request and answer each line comment with a commit
- I can git pull a merged pull request on main, then tag it and publish a release

## Three questions to answer in writing

1. Suppose you had tagged `v1.0` on `main` right after Finishing step 2 (the merge on GitHub), without `git pull`. Which commit would carry the tag in the sample, and what would a visitor who downloads v1.0 be missing?
2. Pick one thing your review found that you had missed in the terminal, or one wrong prediction. What did you expect, what did you see, and what will you do differently?
3. A friend's pull request is merged into `main`, but Issue #4 is still open. The description ends with `This fixes issue 4.` What went wrong, and what should they do now and next time?
