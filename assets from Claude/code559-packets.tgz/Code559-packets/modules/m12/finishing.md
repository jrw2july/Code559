# Finishing work in Git

In Modules 1 to 11 you finished each project with the short save routine. This time the work is already on GitHub, in a pull request. What is left is the end of the team workflow: merge on GitHub, bring the merge to your computer, check it on the live site, then name the version with a tag and a release. The order matters. A tag goes on the commit you are on, so you tag only after `git pull`.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 to 11 or in the Project. The sample's numbers below assume the three commits from Project steps 8, 14 and 15; if you made the Modify commit in Project step 16, your counts are one file or one commit higher.

1. **Check the terminal.** The prompt must end in `my-site>`. Type `git status`. It should say `On branch add-footer-link` and `nothing to commit, working tree clean`. If a file is modified, commit it on the branch and push it first, or it stays out of the merge.
2. **Merge the pull request on GitHub (NEW).** Open the pull request and scroll to the bottom of the **Conversation** tab. GitHub Docs (*Merging a pull request*) gives the steps: click **Merge pull request**, accept the commit message GitHub suggests, and click **Confirm merge**. If you see a menu instead, choose **Create a merge commit**. GitHub makes one new commit on `main`, a merge commit like the one in Exercise step 7.
3. **Watch the Issue close (NEW).** Click the **Issues** tab. Issue #1 is no longer in the open list: "When you merge a linked pull request into the default branch of a repository, its linked issue is automatically closed" (GitHub Docs, *Linking a pull request to an issue*). Open it from the closed list and read its timeline. If it is still open, see Problem 5 in Part 4, *Troubleshooting*.
4. **Bring the merge home (NEW).** The merge exists only on GitHub so far. Type:

   ```
   git switch main
   git pull
   ```

   `git switch main` said `Your branch is up to date with 'origin/main'.` It has not asked GitHub yet (Core concept 12), so pull anyway. After a few lines about the download, the sample's `git pull` printed:

   ```
   Updating 7ffddbe..0ae4a77
   Fast-forward
    about.html     | 2 +-
    contact.html   | 2 +-
    index.html     | 2 +-
    interests.html | 2 +-
    rate.html      | 2 +-
    test-plan.md   | 2 ++
    6 files changed, 7 insertions(+), 5 deletions(-)
   ```

   `Fast-forward` means your `main` simply moved ahead to GitHub's merge commit. Open `index.html` in VS Code: the footer on `main` now has the link.
5. **Read the history (NEW: the graph of a real pull request).** Type `git log --oneline --graph -7`.

   ![A terminal in my-site running git log --oneline --graph -7. The top line is 0ae4a77, marked HEAD -> main, tag: v1.0, origin/main, Merge pull request #2 from your-username/add-footer-link. A second line branches off with three commits: 6bc0995 Add footer link tests to test plan, marked origin/add-footer-link, b0b7b79 Fix footer link address on Contact page, and fddb8e3 Add GitHub link to footer. The lines join at 7ffddbe Add README, then 3dc78d4 Add .gitignore and 8eb841d Add test plan for every interactive feature.](images/p12-history.png)
   *The sample's history after step 8 below, so `tag: v1.0` is already on the top line; right after `git pull` that label is not there yet. The three branch commits sit on their own line and join at the merge. `origin/add-footer-link` is your computer's record of the branch on GitHub, which is still there. The bottom commit stands for your last Module 11 commit. (real output, rendered; captured on Linux, with the folder path changed to the course folder. The merge commit was made in a local repository standing in for GitHub.)*

   Check that the top line says `Merge pull request #2` and `(HEAD -> main, origin/main)`. Git 2.48 and later may also add `origin/HEAD` there (Core concept 12).
6. **Delete the local branch.** Its work is on `main` now:

   ```
   git branch -d add-footer-link
   ```

   The sample printed `Deleted branch add-footer-link (was 6bc0995).` The commits stay; only the name goes. The branch on GitHub can stay too. It does no harm.
7. **Check the live site.** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/`. Run your two new test-plan rows on the live site, on all five pages: a click on the footer link, then Tab and Enter. If a page still shows the old footer, press **Ctrl+Shift+R** to reload without the browser's saved copy (Module 9). 

   Also run one row of your test plan for each other feature, to see that nothing else changed. The steps in this packet were tested with files opened from disk, not on a live site, so this check is yours.
8. **Tag the version (NEW on your site).** First, check where you are:

   ```
   git log --oneline -1
   ```

   It must show the merge commit, `Merge pull request #2 …`. If it shows `Add README` or a branch commit, stop and see Problem 3 in Part 4. Then:

   ```
   git tag v1.0
   git tag
   git log --oneline -1
   git push origin v1.0
   ```

   `git tag` printed `v1.0`. The log line now has `tag: v1.0` beside `HEAD -> main`. The push ended with `* [new tag]         v1.0 -> v1.0`. A plain `git push` would not have sent it (Core concept 10).
9. **Publish the release (NEW on your site).** On your repository page, GitHub Docs (*Managing releases in a repository*) gives the steps. To the right of the file list, click **Releases**, then **Draft a new release**. In **Choose a tag**, pick `v1.0`. In **Release title**, type `My Site v1.0`. In **Describe this release**, write two or three sentences: what the site has, and what is new in this version (the README and the footer link). Click **Publish release**. It looks like the release picture in Core concept 10 of the lesson.
10. **Look at your repository as a visitor.** Open `https://github.com/your-username/my-site` in a private window, so you see what a stranger sees. Check four things: the README under the file list, a v1.0 release beside the files, Issue #1 in the closed Issues with its link to the pull request, and pull request #2 marked as merged. Then, in the terminal, type `git log --oneline` and read your whole history the way a visitor would: small commits, clear messages.
11. **Check that Git is done.** Type `git status`. It should say `On branch main`, `Your branch is up to date with 'origin/main'.` and `nothing to commit, working tree clean`.

> **Checkpoint.** `git status` is clean on `main`. `git log --oneline -1` shows the merge commit with `tag: v1.0`. On GitHub, Issue #1 is closed, pull request #2 is merged, and the release **My Site v1.0** is published. On the live site, the footer link works on all five pages with the mouse and the keyboard, and your test plan still passes.
