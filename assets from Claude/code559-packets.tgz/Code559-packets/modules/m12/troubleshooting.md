# Troubleshooting: six common problems

Each problem has the symptom you see, why it happens, and the fix. Problems 1 to 4 and 6 were made on purpose in a copy of the sample site and run with Git 2.43.0; their messages are quoted as Git printed them. Problem 5 happens only on GitHub.com, which could not be used here, so it follows GitHub Docs. After each fix, run `git status` and read it before you go on.

### 1. The current branch has no upstream branch

**Symptom.** You type `git push` on your new branch, and nothing is sent:

```
fatal: The current branch add-footer-link has no upstream branch.
To push the current branch and set the remote as upstream, use

    git push --set-upstream origin add-footer-link

To have this happen automatically for branches without a tracking
upstream, see 'push.autoSetupRemote' in 'git help config'.
```

**Why.** The branch exists only on your computer. A plain `git push` does not know which branch on GitHub it belongs to (Core concept 12).

**Fix.** Push it once with `-u`: `git push -u origin add-footer-link`. `--set-upstream` in the message is the long form of `-u`. After that, a plain `git push` works on this branch.

### 2. Git refuses to switch branches

**Symptom.** You type `git switch main` with a page still edited:

```
error: Your local changes to the following files would be overwritten by checkout:
	contact.html
Please commit your changes or stash them before you switch branches.
Aborting
```

**Why.** The file is different on the two branches, and you have an edit in it that is not committed. Switching would replace the file and lose your edit, so Git stops. You stay on your branch, and nothing changes.

**Fix.** Run `git diff contact.html` and decide. If the edit belongs to the branch, commit it there (`git add`, `git commit -m "…"`), then switch. If you do not want it, `git restore contact.html` throws it away (Core concept 7), then switch. `stash` is a Git command this course does not teach; you do not need it.

### 3. The tag is on the wrong commit

**Symptom.** `git log --oneline -1` after `git tag v1.0` does not show `Merge pull request`. The sample got this two ways:

| What happened | What the sample showed |
|---|---|
| Tagged on `main` before `git pull` | `7ffddbe (HEAD -> main, tag: v1.0, origin/main) Add README` |
| Ran `git pull` while still on the branch | `git pull` said `Already up to date.`, and the log showed `6bc0995 (HEAD -> add-footer-link, origin/add-footer-link) …` |

**Why.** `git tag` puts the name on the commit you are on (Core concept 10). Before `git pull`, your `main` does not have GitHub's merge commit yet. And `git pull` on a branch brings that branch up to date, not `main`.

**Fix.** If you have **not** pushed the tag yet, delete it on your computer: `git tag -d v1.0`. The git-tag manual describes `-d` as "Delete existing tags with the given names." The sample printed `Deleted tag 'v1.0' (was 7ffddbe)`. Then `git switch main`, `git pull`, check `git log --oneline -1`, and tag again. If you already pushed the wrong tag, stop and ask for help before you make a release from it.

### 4. A branch that will not delete

**Symptom.**

```
error: the branch 'try-conflict' is not fully merged.
If you are sure you want to delete it, run 'git branch -D try-conflict'
```

**Why.** The branch has commits that no other branch holds. `-d` protects them (Core concept 6). For `try-conflict` in Project step 9 that is expected: its merge was practice. In the sample, `git branch -d add-footer-link` in Finishing step 6 worked without this message, because after `git pull` its commits were on `main`.

A branch you pushed may delete with a warning instead; its commits are safe on GitHub.

**Fix.** For a practice branch you want to lose, use `-D`, as in Project step 9. For a real branch, do not use `-D`. Check first that its pull request is merged, then run `git switch main` and `git pull`, and try `-d` again.

### 5. The Issue stayed open after the merge

**Symptom.** The pull request is merged, but Issue #1 is still in the open list.

**Why.** GitHub links the two only when the keyword and the number follow its rules (GitHub Docs, *Linking a pull request to an issue*):

| Cause | Example |
|---|---|
| No `#` before the number, or the wrong number | `Closes 1`, or `Closes #2` (the pull request's own number) |
| The keyword was only in a comment | `Closes #1` typed as a reply on the Conversation tab; the docs name the description (and commit messages) as the places it is read |
| The pull request went into another branch | base was not `main`; the keywords are read only when it targets the default branch |

The keywords that work are close, closes, closed, fix, fixes, fixed, resolve, resolves and resolved, followed by `#` and the Issue's number.

**Fix.** Close the Issue by hand: open it and click **Close issue** (GitHub Docs, *Closing an issue*). In a comment, write `Done in #2`, so a visitor can still find the work. Next time, check the description before you merge.

### 6. `.vscode` is still tracked after the `.gitignore`

**Symptom.** In Project step 3, `git ls-files .vscode` lists a file, such as `.vscode/settings.json`.

**Why.** "Files already tracked by Git are not affected" by a `.gitignore` (*gitignore*). That folder was committed in an earlier module.

**Fix.** Take it out of Git, but keep it in your folder (Core concept 8):

```
git rm -r --cached .vscode
git status --short
```

The sample printed `rm '.vscode/settings.json'`. Then the status showed `D  .vscode/settings.json` (staged to be removed from Git) and `?? .gitignore`. Add the `.gitignore` and commit both in one commit, with a message such as `Stop tracking .vscode and add .gitignore`. The sample's commit printed `delete mode 100644 .vscode/settings.json`. The file is still in your folder; Git just stops tracking it.
