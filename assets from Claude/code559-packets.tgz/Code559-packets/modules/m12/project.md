# Project: my-site through the full team workflow

*Your hands, about 2 hours (estimate).* In the Exercise you used branches, merges and a tag in a throwaway folder. Now you use them on your real site, the way a team does. You add a `.gitignore` and a README. Then you make one real improvement, a link to your site's code in the footer of every page. It goes all the way through: an Issue, a branch, a pull request, your own review, a merge, `git pull`, a `v1.0` tag and a release. You use only what Modules 1 to 12 taught:

- `git status --short`, `git diff`, `git diff --stat`, `git diff --staged`, `git add` with a file name, `git commit -m`
- `git log --oneline`, with `--graph` and a number such as `-3` (as `-1` in the Exercise), and `git ls-files`
- `git switch -c`, `git switch`, `git branch`, `git merge`, `git branch -d` and `-D`
- `git push -u origin`, `git push`, `git pull`, `git tag` and `git push origin v1.0`
- a `.gitignore` and a `README.md` with the four headings (Core concepts 8 and 9)
- on GitHub: an Issue, a pull request with `Closes #n`, line comments and a review, the merge, and a release (Core concepts 10 and 12)
- a link with a full address (Module 1), the DevTools Console (Module 5) and device mode (Module 3), and your test plan, `test-plan.md` (Module 11)

This project starts from the site you built in the packet projects of Modules 1 to 11: five pages (Home, About, Interests, Rate, Contact), one `styles.css`, your scripts, and `test-plan.md` with its five sections, "Every page: navigation and keyboard" last. Every change is committed and pushed, and the live site loads.

A note on what was tested. Every Git command in this part was run for real, with Git 2.43.0 on Linux, in a copy of the sample site. A local repository stood in for GitHub, so pushes and pulls were real, but nothing reached GitHub.com.

The work on the GitHub website (the Issue, the pull request, the review, the merge and the release) could not be done here. The pictures of those pages are drawings, and their button names come from GitHub Docs. The merge commit in the sample was made in the stand-in repository, with the message the lesson shows for a GitHub merge.

## The brief

Read the whole brief twice before you type anything.

When you finish, `my-site` holds two new files, `.gitignore` and `README.md`. The footer line of all five pages has changed, and `test-plan.md` has two new rows at the end of its "Every page" section. No other file changes, so the live site looks the same except for the new link.

**The `.gitignore`.** Exactly the three lines from Core concept 8: `.vscode/`, `Thumbs.db` and `*.log`. None of them is a file your pages use.

**The README.** A `#` heading with your site's name, then the four `##` headings in this order: **What it does**, **Built with**, **What I learned**, **Live site**. One to three sentences under each. What it does names your pages and says that the test plan is in `test-plan.md`. Live site is your address, `https://your-username.github.io/my-site/`. Your pages do not link to either new file, so visitors to the live site see no change from them.

**The improvement.** The footer of every page ends with a link to your repository. The footer line becomes:

```html
<p>Built by hand by Your Name. <a href="https://github.com/your-username/my-site">See the code on GitHub</a></p>
```

Use your own name and username. The link text is **See the code on GitHub** on every page. The link is navy `#1d3557` on the beige footer `#e9dcc9`, 9.1:1. With the keyboard it gets the dark orange ring from Module 4, 3.7:1 on the beige (both checked with the WCAG contrast formula). You write no new CSS.

![The bottom of the Home page at 390 pixels wide: the Contact section with its light orange box, then the beige footer band with the text Built by hand by Your Name, followed by the underlined link See the code on GitHub, which wraps onto a second line and has a dark orange focus ring around both parts.](images/p12-footer-390.png)
*The new footer link on a phone, reached with Tab only. The ring follows the link when it wraps onto two lines. Nothing scrolls sideways on any of the five pages at 390 px. (real: rendered in Chromium at 390 px)*

**On GitHub.** Issue **Add a link to the code in the footer**, with one or two sentences on why. A branch, `add-footer-link`. A pull request, **Add a GitHub link to the footer**, from `add-footer-link` into `main`. Its description says what changed and how you tested it, and its last line is `Closes #1`. Your own review leaves at least two line comments, and each one is answered by a commit on the branch. You merge it with **Merge pull request**, and the Issue closes.

**On your computer, then on GitHub again.** `main` brought up to date with `git pull`, the tag `v1.0` on the merge commit and pushed, and a release, **My Site v1.0**, built on that tag.

**What a visitor to your repository sees.** The README under the file list. A history of small commits with clear messages. A closed Issue linked to a merged pull request. A v1.0 release.

Your Issue and pull request numbers may differ. They are #1 and #2 if your repository has none yet; use the numbers GitHub shows you, everywhere this part says #1 or #2.

## The steps

Type every command and every line. Do not paste.

1. **Open `my-site` and check that it is clean.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`. Type `git status`. It must say `nothing to commit, working tree clean`.

   If the only thing listed is an untracked folder such as `.vscode/`, Git says `nothing added to commit but untracked files present` instead. That is fine too; step 3 deals with it. If a page is modified, finish or undo that change first: this project should start from a clean `main`. Then type `git log --oneline -3` and read your last three messages.
2. **Plan on paper.** Write three things. The Issue title and one or two sentences on why a visitor needs the link. Your README's four sections, with the "What I learned" draft from Core concept 9. The five pages whose footer will change. Then write the order of the work: `.gitignore`, README, Issue, branch, commits, pull request, review, merge, pull, tag, release.
3. **The `.gitignore`.** **Predict:** what will `git status --short` show? Type it. The sample showed one line, `?? .vscode/`, because VS Code had saved a settings file there. Yours may show nothing. In the Explorer, create `.gitignore` at the top of `my-site`, next to `index.html`. Type the three lines, each followed by Enter:

   ```
   .vscode/
   Thumbs.db
   *.log
   ```

   Save. Run `git status --short` again. The sample showed only `?? .gitignore`: the `.vscode/` line was gone. Then type `git ls-files .vscode`. It should print nothing. If it lists a file, that folder was committed in an earlier module; see Problem 6 in Part 4, *Troubleshooting*. Now check and commit:

   ```
   git add .gitignore
   git diff --staged
   git commit -m "Add .gitignore"
   ```

   The staged diff shows three `+` lines under `new file mode 100644`. The sample's commit printed `1 file changed, 3 insertions(+)` and `create mode 100644 .gitignore`.
4. **The README.** Create `README.md` next to `index.html`. Type the start:

   ```
   # My Site

   ## What it does
   My personal website: a Home page, an About page with questions people ask me,
   an Interests page with a photo gallery, a rating card, and a Contact page whose
   form checks what you type. The test plan for every interactive feature is in
   test-plan.md.

   ## Built with
   HTML, CSS and JavaScript, written by hand in VS Code. Saved with Git and
   published with GitHub Pages.

   <!-- Continue alone: the headings What I learned and Live site,
        with your own sentences and your own address. -->
   ```

   Use your own words in What it does. Add the last two sections, then delete the comment. Save, then:

   ```
   git status --short
   git add README.md
   git diff --staged --stat
   git commit -m "Add README"
   git push
   ```

   The status line is `?? README.md`. The sample's README was 19 lines, so `--stat` showed `README.md | 19 +++++++++++++++++++` and `1 file changed, 19 insertions(+)`. The push ended with `main -> main`. Open `https://github.com/your-username/my-site`: the README now shows under the file list, with the four headings as headings.

   Then check the live site, `https://your-username.github.io/my-site/`, after a few minutes. It looks exactly as before. This build could not test GitHub Pages, so this check is yours: if a page looks different, compare it with the last version before you go on.
5. **Open the Issue (NEW on your site).** On your repository page, click the **Issues** tab, then **New issue**. GitHub Docs (*Creating an issue*) gives the rest. Type the title in the **Title** field: `Add a link to the code in the footer`. In the description, write your one or two sentences from step 2, for example *Visitors who like the site cannot find its code. Add a link to this repository in the footer of every page.* Click **Submit new issue**. Note the number GitHub gives it, such as **#1**.
6. **Make the branch.** Back in the terminal:

   ```
   git switch -c add-footer-link
   ```

   Git prints `Switched to a new branch 'add-footer-link'`. Every commit until the merge goes on this branch, so `main` and the live site stay as they are.
7. **Change the footer.** Open `index.html` and find the footer line. Change it to the line from the brief, with your own name and username:

   ```html
   <p>Built by hand by Your Name. <a href="https://github.com/your-username/my-site">See the code on GitHub</a></p>
   ```

   Save. Open `index.html` in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window). After each save, press **F5** to reload. The link shows in the footer. Click it: your repository opens on GitHub. Press F5 on the Home page again, then press Tab until the link has the dark orange ring, and press Enter. The same page opens.

   Now change the footer of `about.html`, `interests.html` and `rate.html` the same way. On `contact.html`, make one change on purpose, for the review to find: type the address without `https://`, as `href="github.com/your-username/my-site"`. Do not test the Contact link yet.
8. **Check and commit.** **Predict:** how many files will `git status --short` list, and how many `+` and `-` lines will `git diff --stat` count? Then:

   ```
   git status --short
   git diff --stat
   git diff index.html
   ```

   The sample listed five lines starting with ` M`, one per page, and `5 files changed, 5 insertions(+), 5 deletions(-)`. Changing a line shows as one `-` line (the old one) and one `+` line (the new one), so each page has one of each. In `git diff index.html`, read the `-` and `+` pair beside `<footer>`. Then commit all five:

   ```
   git add .
   git commit -m "Add GitHub link to footer"
   ```

   (A warning from `git add` that mentions LF and CRLF is harmless.)

   The sample printed `[add-footer-link fddb8e3] Add GitHub link to footer` and `5 files changed, 5 insertions(+), 5 deletions(-)`. The branch name in the brackets tells you where the commit went.
9. **Break it on purpose: a merge conflict.** A pull request cannot be merged while it has a conflict: "the **Merge pull request** button is deactivated until the conflicts are resolved" (GitHub Docs, *About merge conflicts*). Practice on a throwaway branch, so your real branch is not touched. You will change the Home footer line two ways, as in Exercise step 6:

   ```
   git switch main
   git switch -c try-conflict
   ```

   On `main` the footer has no link yet. Change the Home footer line to `<p>Built by hand by Your Name in 2026.</p>` and save. Then `git add index.html` and `git commit -m "Add year to footer"`. **Predict:** which files will merge by themselves, and which one will stop? Then:

   ```
   git merge add-footer-link
   git status --short
   ```

   The sample printed:

   ```
   Auto-merging index.html
   CONFLICT (content): Merge conflict in index.html
   Automatic merge failed; fix conflicts and then commit the result.
   ```

   `git status --short` showed `UU index.html` and an `M` in the left column for the other four pages. Those four merged by themselves, because only one side changed them. In `index.html`, the footer now holds the markers:

   ```
   <<<<<<< HEAD
         <p>Built by hand by Your Name in 2026.</p>
   =======
         <p>Built by hand by Your Name. <a href="https://github.com/your-username/my-site">See the code on GitHub</a></p>
   >>>>>>> add-footer-link
   ```

   Fix it in VS Code: click **Accept Incoming Change** above the conflict, to keep the branch's line with the link. Save. Then:

   ```
   git add index.html
   git commit -m "Merge add-footer-link, keep the link"
   git log --oneline --graph -5
   ```

   The graph splits after `Add README` and joins at the merge commit, as in the Exercise. Now throw the practice away:

   ```
   git switch add-footer-link
   git branch -d try-conflict
   git branch -D try-conflict
   ```

   `-d` refused: `error: the branch 'try-conflict' is not fully merged.` That is Git protecting work. Here you do want to lose it, so `-D` deleted it: `Deleted branch try-conflict (was 04ffdf2).` Type `git branch`: only `add-footer-link` (with the `*`) and `main` are left.
10. **Push the branch.** The branch is new, so it needs `-u` the first time (Core concept 12):

    ```
    git push -u origin add-footer-link
    ```

    Git prints a few lines of progress and your GitHub address. The sample ended with these two lines:

    ```
     * [new branch]      add-footer-link -> add-footer-link
    branch 'add-footer-link' set up to track 'origin/add-footer-link'.
    ```

    A push to GitHub may add a few more lines that start with `remote:`. You do not need them.
11. **Open the pull request (NEW on your site).** On your repository page, GitHub Docs (*Creating a pull request*) says to choose your branch in the **Branch** menu and click the yellow **Compare & pull request** banner. Check that **base** is `main` and **compare** is `add-footer-link`. Type the title `Add a GitHub link to the footer`. In the description, write what changed and how you tested it, and end with `Closes #1` on its own line (your Issue's number). Click **Create Pull Request**. Note its number, such as **#2**.
12. **Review your own pull request.** Click **Files changed**. Read every file's diff slowly, as if someone else wrote it. Check three things: the footer line is the same on all five pages; every address starts with `https://`; and the test plan covers the new link. When something is wrong, hover the line number, click the blue comment icon, type a note and click **Start a review** (*Commenting on a pull request*). Leave at least these two:

    - on the `+` line of `contact.html`: the address has no `https://`
    - on the `+` line of `index.html`: `test-plan.md` has no rows for this link yet

    ![A drawn GitHub Files changed view of contact.html in pull request 2. Line 39 is removed in red, and the new line 39 in green has a link whose address is github.com/your-username/my-site with no https. A blue plus icon sits beside it, and a comment box says the address has no https, so the link looks for a file inside my-site. Buttons Start a review and Comment are under it, and Review changes is at the top right.](images/p12-review.png)
    *The first line comment of the sample's review, pinned to the exact line it is about. Your line numbers may differ.*

    Then finish the review. Click **Review changes** above the code, write a one-line summary, choose **Comment** and click **Submit review**. Until you do, your notes are "pending and only visible to you" (*Reviewing proposed changes in a pull request*). **Approve** is not for you here: "Pull request authors cannot approve their own pull requests" (same page).
13. **Debug: where does the Contact link go?** Before you fix it, find out what the mistake does. **Predict**, in writing: what will a click on the Contact page's footer link open? Then open `contact.html` from disk, press F5 and click it.

    In the sample, Chromium did not reach GitHub. It could not open the page and reported `ERR_FILE_NOT_FOUND`. To see why, go back to the Contact page, press **F12** (or **Ctrl+Shift+J**) to open DevTools, click the **Console** tab, and type:

    ```js
    document.querySelector("footer a").href
    ```

    `.href` gives the full address the browser built from the link. The sample answered `'file:///C:/Users/you/Documents/code559/my-site/github.com/your-username/my-site'`. Without a scheme, the address is a **relative path** (Module 1): "a folder called `github.com` next to this page." That folder does not exist. On the live site, the same link would ask GitHub Pages for a page inside your site that does not exist.
14. **Answer the first comment with a commit.** Add `https://` back to the address in `contact.html`, save, press F5 and click the link: your repository opens. Then:

    ```
    git diff
    git add contact.html
    git commit -m "Fix footer link address on Contact page"
    git push
    ```

    The diff shows one `-` line without `https://` and one `+` line with it. This time a plain `git push` works, because `-u` linked the branch in step 10. It ended with `add-footer-link -> add-footer-link`. On GitHub, the pull request updates by itself: "You can continue to commit and push changes in response to the reviews. Your pull request will update automatically" (GitHub Docs, *GitHub flow*). Find your comment on the **Conversation** tab and reply under it with the commit id from your commit line, such as `Fixed in b0b7b79.`
15. **Answer the second comment with a commit.** Open `test-plan.md` and add two rows at the end of the file, which is the end of the "Every page: navigation and keyboard" table (Module 11 kept that section last for this). The first is:

    ```
    | Click See the code on GitHub in the footer of each page | The my-site repository opens on GitHub | |
    ```

    ```
    <!-- Continue alone: a second row for the keyboard. Action: Tab to
         the footer link on each page and press Enter. Expected: what the
         ring looks like, and what opens. -->
    ```

    Write the second row alone. Run both rows on all five pages, opened from disk, and fill in Actual with what really happened, such as `Pass on all five pages`. Then:

    ```
    git diff --stat
    git add test-plan.md
    git commit -m "Add footer link tests to test plan"
    git push
    ```

    `--stat` showed `test-plan.md | 2 ++`: two new lines, nothing removed. Reply under your second comment with this commit's id.
16. **Read the pull request again.** Open the **Conversation** tab. Then click **Commits** (three commits in the sample) and **Files changed** (six files: five pages and `test-plan.md`). The Contact line now has `https://`.

    ![A drawn GitHub pull request page: Add a GitHub link to the footer, number 2, Open, your-username wants to merge 3 commits into main from add-footer-link. The description ends with Closes #1. Below are the commit fddb8e3, two comment threads, on contact.html and index.html, each answered with Fixed in b0b7b79 and Two rows added in 6bc0995, then the commits b0b7b79 and 6bc0995, and a green Merge pull request button.](images/p12-pr.png)
    *The sample's pull request before the merge: each comment is answered by a commit, and the description ends with `Closes #1`.*

    **Modify.** Make one more small change of your own on the branch, for example a clearer sentence in the README's What it does. Predict what `git diff --stat` will show, then commit it with a message that finishes "This commit will…", push, and watch the pull request add it.
17. **Explain it, in writing.** In your notebook, write one sentence for each commit on the branch: what it changed and why it is its own commit. Then write why the conflict in step 9 stopped at `index.html` only, and why step 10 needed `-u` but step 14 did not. If you cannot explain one, reread Core concepts 6 and 12.
18. **Test before you merge.** Tick each box.

    - [ ] `git status` says `nothing to commit, working tree clean`, on the branch `add-footer-link`
    - [ ] The footer link opens your repository from all five pages, with the mouse and with Tab and Enter, and has a dark orange ring
    - [ ] Every footer address starts with `https://`; the Contact mistake from step 7 is gone
    - [ ] Nothing scrolls sideways at 390 px (F12, then Ctrl+Shift+M) on any page
    - [ ] `test-plan.md` has the two new rows, with Actual filled in
    - [ ] The pull request goes from `add-footer-link` into `main`, its description ends with `Closes #1`, and every review comment has a reply that names a commit
    - [ ] `try-conflict` is gone (`git branch` lists only `add-footer-link` and `main`)

19. **Merge, pull, tag and release.** Go to Part 3, *Finishing work in Git*.
