# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **Which file is ready to commit?** `styles.css`. Its `M` is in the **left** column, the staging area, so it is staged and goes into the next commit. `index.html` has its `M` in the **right** column, the working folder: it is changed but not staged, so `git commit` leaves it out. To commit it too, run `git add index.html` first. (Core concept 2)
2. **Fast-forward in step 5, a conflict in step 6.** In step 5, `main` had not changed since you made `add-hobby`. Git only had to move `main` forward to the branch's last commit, with no new commit. In step 6, both branches had a new commit, and both changed the same line, `Favorite color`, in two different ways. Git cannot choose between green and orange, so it merges what it can (the hobby line) and stops at that line for you to decide. (Core concept 6; Exercise steps 5 to 7)
3. **What would you test to prove the `.gitignore` works?** Make a file that matches each pattern and one that does not, then read `git status --short`. A file named `debug.log`, a `Thumbs.db` and a file inside `.vscode/` must not appear in the list, while a new `.html` file must. 

   Then check that the ignored files are still in the folder (they are: Git stops reporting them, it does not delete them). Last, run `git ls-files .vscode`: it must print nothing, because a file committed before the `.gitignore` is still tracked. In a check run for this packet, a new `notes.log` and a `Thumbs.db` in `my-site` did not appear in `git status --short` at all. (Core concept 8)

## Common misconception

*"When I commit, my work is saved on GitHub."* A commit is saved in the hidden `.git` folder on your computer, in the Commits box of the mental model. Only the `git push` arrow leads from there to GitHub. Until you push, your commit is not on GitHub and not on the live site, and a lost laptop loses it. 

`git status` tells you: after a commit without a push, the sample said `Your branch is ahead of 'origin/main' by 1 commit.` and suggested `git push`. The same is true the other way: a merge on GitHub is not on your computer until `git pull`. (Core concepts 1 and 12)

## Exercise checks

These are the results of a real run of the Exercise with the lesson's lines. Your commit ids will differ.

- **Step 2.** `?? notes.txt`: untracked. The commit printed `[main (root-commit) …] Add notes` and `1 file changed, 1 insertion(+)`.
- **Step 3.** Both `git diff` and `git diff --staged` showed one context line, `Favorite color: blue`, and one `+` line, `+Hobby: drawing`. (`git diff` showed it before `git add`, `git diff --staged` after.)
- **Step 4.** On `main`, `notes.txt` has only the color line.
- **Step 5.** `Updating …`, `Fast-forward`, and `notes.txt | 1 +`. After `git branch -d add-hobby` (`Deleted branch add-hobby …`), the log has two commits, the newest marked `(HEAD -> main)`.
- **Step 6.** `Auto-merging notes.txt`, `CONFLICT (content): Merge conflict in notes.txt` and `Automatic merge failed; fix conflicts and then commit the result.` `git status --short` shows `UU notes.txt`. The file holds `<<<<<<< HEAD`, `Favorite color: orange`, `=======`, `Favorite color: green`, `>>>>>>> change-color`, then `Hobby: drawing`.
- **Step 7.** After the fix, the commit is a merge commit. `git log --oneline --graph` shows five commits: the line splits after `Add hobby line` into `Change color to orange` on one side and `Change color to green` on the other, and joins at `Merge change-color, keep green`.
- **Step 8.** `git log --oneline -1` shows the merge commit with `(HEAD -> main, tag: v0.1)`.
- **Step 9.** If you committed only on the new branch, the merge is a fast-forward: `main` had not moved since you made the branch. The check run printed `Fast-forward` and `notes.txt | 2 +-`. If you also committed on `main`, Git makes a merge commit and opens the editor for its message.

## Self-assessment questions

1. **A tag made before `git pull`.** After Finishing step 2, the merge exists only on GitHub. You are on `add-footer-link`; to tag `main` you would run `git switch main`, which says `up to date` because it has not asked GitHub. The tag lands on the newest commit your `main` has. In the sample, that was `7ffddbe Add README`: a check run showed `7ffddbe (HEAD -> main, tag: v1.0, origin/main) Add README`.

   A visitor who downloads v1.0 gets the README and the `.gitignore`, but not the footer link on any page and not the two test-plan rows: everything from the pull request is missing. That is why you pull first and read `git log --oneline -1` before you tag. (Core concepts 10 and 12; Finishing steps 4 and 8; Problem 3 in Part 4)
2. **Something you missed, or a wrong prediction.** There is no single answer. A good answer quotes what you expected (written before you looked), says exactly what the review, the terminal or the page showed, and names the habit that would have caught it sooner. For example: a missing `https://` that `git diff --stat` could not show, because it counts lines and does not read them; or a conflict you expected in five files that stopped at one.
3. **The friend's Issue #4.** `This fixes issue 4.` has a keyword, `fixes`, but not the form GitHub reads: the keyword followed by `#` and the number, as in `Fixes #4` (GitHub Docs, *Linking a pull request to an issue*). The friend's line does not match that form, which is why the merge did not close the Issue. 

   Now: open Issue #4, comment with the pull request's number (such as `Done in #5`), and click **Close issue**. Next time: write `Fixes #4` (or `Closes #4`) on its own line in the description, check that the pull request goes into `main`, and read the description once more before you merge. (Core concept 12; Problem 5 in Part 4)

## Project checks

- **Step 3.** Before: `?? .vscode/` in the sample (yours may be empty). After the `.gitignore`: only `?? .gitignore`. `git ls-files .vscode` printed nothing. The commit: `1 file changed, 3 insertions(+)`, `create mode 100644 .gitignore`. The whole file, each line ending with Enter:

  ```
  .vscode/
  Thumbs.db
  *.log
  ```

- **Step 4, continue alone.** The sample's last two sections, below Built with:

  ```
  ## What I learned
  How to build pages that work with a keyboard as well as a mouse, and how to
  find a bug from the message in the Console. How to keep a project's history
  with Git: one change per commit, branches, and pull requests.

  ## Live site
  https://your-username.github.io/my-site/
  ```

  With them the README is 19 lines: `README.md | 19 +++++++++++++++++++`. The push ended with `main -> main`.
- **Step 7, continue alone.** The footer line in `about.html`, `interests.html` and `rate.html` is the same line as in `index.html`, letter for letter:

  ```html
  <p>Built by hand by Your Name. <a href="https://github.com/your-username/my-site">See the code on GitHub</a></p>
  ```

  `contact.html` gets the planted mistake: `href="github.com/your-username/my-site"`.
- **Step 8.** Five ` M` lines, `5 files changed, 5 insertions(+), 5 deletions(-)`. In `git diff index.html`, the `-` line is `<p>Built by hand by Your Name.</p>` and the `+` line is the new footer line, with the unchanged `<footer>` and `</footer>` lines around them.
- **Step 9.** The conflict stops at `index.html` only (`UU index.html`); the other four pages show `M` in the left column. After **Accept Incoming Change** and the commit, `git log --oneline --graph -5` shows the split after `Add README` and the join at `Merge add-footer-link, keep the link`. `-d` refuses with `not fully merged`; `-D` prints `Deleted branch try-conflict (was …)`.
- **Step 10.** `* [new branch]      add-footer-link -> add-footer-link` and `branch 'add-footer-link' set up to track 'origin/add-footer-link'.`
- **Step 13.** The click does not reach GitHub: Chromium reports `ERR_FILE_NOT_FOUND`. The Console line gives the full address of a file inside `my-site`, ending in `/my-site/github.com/your-username/my-site`.
- **Step 14.** The diff has one `-` line without `https://` and one `+` line with it; `1 file changed, 1 insertion(+), 1 deletion(-)`.
- **Step 15, continue alone.** The sample's two rows, with Actual filled in after the run:

  ```
  | Click See the code on GitHub in the footer of each page | The my-site repository opens on GitHub | Pass on all five pages |
  | Tab to the footer link on each page and press Enter | A dark orange ring on the link; Enter opens the repository | Pass on all five pages |
  ```

  `test-plan.md | 2 ++`, `1 file changed, 2 insertions(+)`.
- **Step 18.** If you followed the brief, every box is ticked. The most common misses: a page whose footer still has the old line (`git diff --stat` on the branch lists fewer than five pages), and a `Closes` line with the wrong number.

