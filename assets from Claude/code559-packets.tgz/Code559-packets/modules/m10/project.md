# Project: A Contact form that checks itself, and a rating card that answers

*Your hands, about 2½ hours (estimate).* In the Exercise you built the whole validation cycle in `practice-10`. Now you put it on your real site, twice. The **Contact page** gets the full cycle: messages in your own voice, focus on the first problem, a confirmation that names the visitor, four form states, and a keyboard-only test you write down and run. The **rating card** from Module 4 gets its JavaScript at last: it reads the chosen rating and swaps the form for the thank-you section. You use only what Modules 4 to 10 taught:

- `<script src="…" defer>` in the `<head>`, one script per page, and the three blocks: find elements, define behavior, connect events (Module 9)
- `novalidate`, `required`, `type="email"`, `minlength`, `aria-describedby` and `role="status"` in the HTML
- a `submit` listener whose first line is `event.preventDefault()`
- `.value`, `.trim()`, `.length`, `=== ""` and `checkValidity()` to check what was typed
- `querySelector('input[name="rating"]:checked')`, and `null` checked with `===` (Core concept 2)
- `textContent`, `classList.add()` and `.remove()`, `hidden`, `.disabled`, `.focus()` and `.reset()`
- `setTimeout(finishSending, 1000)`, the lesson's one-second stand-in for a server
- functions that return a value or `null` (Module 7), and a `let` you change from the Console
- custom properties, `.visually-hidden` (Module 4), and the `:empty` and `+` selectors from the Exercise CSS

This project starts from the Module 9 packet's site: five pages, one shared `styles.css` with the colors and focus rings, `gallery.js` on the Interests page and `faq.js` on the About page. The Rate and Contact pages are as you built them in the Module 4 packet, with no script yet.

## The brief

Read the whole brief twice before you type anything.

When you finish, `my-site` holds two new files, `contact.js` and `rate.js`, next to `index.html`. `contact.html`, `rate.html` and `styles.css` have changed. No other file changes. As in Module 9, each page loads only its own script: `contact.html` loads `contact.js`, and `rate.html` loads `rate.js`, each with one `<script src="…" defer>` line under the stylesheet link.

**One sentence to keep in mind.** These checks help honest visitors fix mistakes quickly. They protect nothing: anyone can switch them off (Core concept 9). Client-side validation is user experience, not security. If you connect this form to a real server one day, that server must check every message again.

**The Contact page HTML.** The page keeps its heading, its lead sentence and its three labeled fields. These things are new:

- Under the lead sentence, a `<p class="note">` that says exactly: **This form checks your message, but it is not connected to a server yet. Nothing you type here is sent.** The `note` class is your Module 2 box.
- The form gets `novalidate`, and the class `idle` next to `contact-form`.
- Under each field, an empty `<p class="error">`. The ids are `name-error`, `email-error` and `message-error`. Each field points to its own with `aria-describedby`.
- The Message box also gets `minlength="10"`. The `required` attributes stay (Check your understanding 3).
- Right after the form, an empty `<p id="contact-status" role="status">`.

**What the Contact page does.** On **Send message**, the script checks three things. The name, trimmed, is not empty. The email is not empty, and the browser's `type="email"` rule accepts it. The message, trimmed, is at least 10 characters long. It shows every problem at once, each under its own field, and puts focus in the first field with a problem. A field with a problem also gets a red border, but the words carry the meaning, not the color.

When everything passes, the form goes through the states from Core concept 8. **Sending:** the button fades and is disabled for one second, and the status line says **One moment...**. **Sent:** the status line thanks the visitor by name, as in **Thanks, Sam. Your message passed every check.**, and the form is empty again. **Failed:** for testing only, typed in the Console. The status line says what went wrong, and the visitor's words stay in the fields. The form always has exactly one of the four classes: `idle`, `sending`, `sent` or `failed`.

<p><img src="images/p10-contact-390.png" alt="Two real renders of the Contact page at 390 pixels wide. Left, after Send with Sam, sam@ and hi: the Name box is fine, the Email box has a dark orange focus ring around its red border and the bold red message That email looks incomplete. Check the @ and the part after it. The Message box has a red border and Tell me a little more: at least 10 characters. Right, one second after a valid Send: all three fields are empty and a pale green box under the button says Thanks, Sam. Your message passed every check." style="max-height:2.4in"></p>

*The finished Contact page. Left: Name was fine, so focus went to Email, the first field with a problem. Right: the `sent` state, with the name read before the form was cleared. Labels added above each render. (real: rendered in Chromium at 390 px)*

**Your own voice.** The three error messages, the thank-you and the failed message are yours to write. Each error says what to do, not only what is wrong. None of them blames the visitor. And because nothing is sent, no message may say it was sent: the sample says "passed every check," not "was sent."

**The rating card HTML.** The card keeps everything from Module 4. These things are new:

- The rating form gets `novalidate`.
- The fieldset gets `aria-describedby="rating-error"`, and right after the fieldset comes an empty `<p id="rating-error" class="error">`.
- At the end of the card, after the thank-you section, an empty `<p id="rating-status" class="visually-hidden" role="status">`.

**What the rating card does.** On **Send rating** with nothing chosen, the card says **Please choose a number from 1 to 5.** under the numbers and puts focus on number 1. The dark orange ring shows on 1 only when you used the keyboard: after a mouse click, Chromium moves focus but draws no ring, because `:focus-visible` follows the keyboard.

With a number chosen, the form disappears and the thank-you section appears, with the number in its span: **You chose 4 out of 5**. The button that had focus is now hidden, so focus goes back to the page itself, and the next Tab starts again from the top of the page.

At the same moment, the hidden status line gets one sentence, **Thanks for the feedback. You chose 4 out of 5.** Sighted visitors never see it. It is there because the thank-you section starts hidden, so it cannot be a live region from the start (Core concept 7). The status line can.

<p><img src="images/p10-rate-390.png" alt="Two real renders of the rating card at 390 pixels wide. Left: the five round numbers, number 1 with a dark orange focus ring, and under them the bold red message Please choose a number from 1 to 5, above the Send rating button. Right: the card now shows You chose 4 out of 5, the heading Thanks for the feedback, and Every rating helps me plan the next lesson." style="max-height:2.2in"></p>

*The rating card driven by keyboard only. Left: Tab to Send rating, then Enter, with nothing chosen. Right: three presses of the right arrow, Tab, then Enter. Labels added above each render. (real: rendered in Chromium at 390 px)*

**The colors.** One new custom property, `--error: #b3261e`, for the messages and the red border. It is 6.1:1 on your cream page background and 6.5:1 on the white card. The status line uses `--ink` on `--soft` while sending (10.8:1), dark green `#1e5b2a` on pale green `#e3f4e5` when sent (7.1:1), and dark red `#8c1d18` on pale red `#fbe4e2` when failed (7.5:1). These values were checked with the WCAG contrast formula.

The faded button is disabled for that one second, and WCAG sets no contrast minimum for "an inactive user interface component" (WCAG 2.2, Success Criterion 1.4.3). The focus rings are your Module 4 rings. Nothing scrolls sideways at 390 px.

The ids, classes, file names and the note must match the brief. The error messages, the thank-you and the failed message are yours.

## The steps

Type every line. Do not paste. Many lines look like the Exercise: type them again anyway, and notice what changed.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`.
2. **Write your messages on paper.** Write the five sentences that are yours: an error for an empty name, for an empty email, for an incomplete email, and for a short message, then the thank-you with a place for the name. Read each one as a visitor who just made that mistake. Does it say what to do next? Then write the three block headings from Module 9 for `contact.js`, and under each, what goes there.
3. **The Contact HTML.** Open `contact.html`. In the `<head>`, under the stylesheet link, add:

   ```html
   <script src="contact.js" defer></script>
   ```

   Then change the inside of the `<section>`, under the `<h2>`. Your lead sentence stays where it is. Read it once more: now that the page says nothing is sent, it must not promise a reply.

   ```html
   <!-- your lead sentence stays here -->
   <p class="note">This form checks your message, but it is not connected to a server yet. Nothing you type here is sent.</p>
   <form class="contact-form idle" novalidate>
     <label for="visitor-name">Your name</label>
     <input type="text" id="visitor-name" name="visitor-name" required aria-describedby="name-error">
     <p id="name-error" class="error"></p>

     <!-- Continue alone: give the email input aria-describedby="email-error"
          and put an empty p with id="email-error" and class="error" under it.
          Do the same for the textarea with message-error, and give the
          textarea minlength="10". -->

     <button type="submit">Send message</button>
   </form>
   <p id="contact-status" role="status"></p>
   ```

   **Predict** before you test: `contact.js` does not exist yet, and the form now has `novalidate`. What happens when you press **Send message** with all three fields empty? Write it down. Then open `contact.html` in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window). After each save, press **F5** to reload. Press **F12** (or **Ctrl+Shift+J**) to open DevTools, then click the **Console** tab. Press Send message.

   The sample page reloaded at once. The address ended in `contact.html?visitor-name=&visitor-email=&message=`, and the Console had one red line, `Failed to load resource: net::ERR_FILE_NOT_FOUND`, with `contact.js` beside it. Nobody checked anything. `novalidate` switched off the browser's checks, and the script that should replace them is missing. Delete the `?…` part of the address and press Enter to load the page again.
4. **The CSS for messages and states.** Open `styles.css`. In `:root`, under `--ring`, add one line:

   ```css
   --error: #b3261e;
   ```

   Then, above the `/* Wider screens: 700px and up */` comment, under your FAQ group, add a new group:

   ```css
   /* Forms: error messages and states */
   .error {
     color: var(--error);
     font-weight: 700;
     margin: 4px 0 0;
   }

   .error:empty {
     display: none;
   }

   .contact-form input.invalid,
   .contact-form textarea.invalid {
     border-color: var(--error);
   }

   .sending button {
     opacity: 0.6;
     cursor: wait;
   }

   #contact-status {
     max-width: 480px;
     margin: 16px 0 0;
     padding: 12px 16px;
     border-radius: 4px;
   }

   #contact-status:empty {
     margin: 0;
     padding: 0;
   }

   .sending + #contact-status {
     color: var(--ink);
     background-color: var(--soft);
   }

   /* Continue alone: .sent + #contact-status gets color #1e5b2a on
      background-color #e3f4e5. .failed + #contact-status gets color
      #8c1d18 on background-color #fbe4e2. */
   ```

   Why `.contact-form input.invalid`? Your Module 4 rule `.contact-form input` scores 0-1-1 and sets a navy border. The new selector scores 0-2-1, so it wins wherever it matches (Module 2). It changes only `border-color`, so the width stays 2 px.
5. **`contact.js`, block 1.** In the Explorer, create `contact.js` next to `contact.html`. Type:

   ```js
   // contact.js: checks the Contact form, shows clear messages, and shows four states

   // 1. Find elements
   const form = document.querySelector(".contact-form");
   const nameInput = document.querySelector("#visitor-name");
   const emailInput = document.querySelector("#visitor-email");
   const messageInput = document.querySelector("#message");
   const nameError = document.querySelector("#name-error");
   // Continue alone: emailError and messageError, then sendButton
   // (the selector ".contact-form button") and statusMessage ("#contact-status").

   // For testing only: type pretendFail = true in the Console to see the failed state.
   let pretendFail = false;
   ```

   The form has a class, not an id, so the selector starts with a dot. `pretendFail` replaces the practice checkbox from the Exercise. A test switch does not belong on a public page, so it lives in the script, where only you will change it. It is a `let`, because you change it from the Console in step 10.

   Save and press F5. The red line about `contact.js` is gone. Test block 1 in the Console: type `emailError`, then `pretendFail`. The sample showed the empty paragraph `<p id="email-error" class="error"></p>`, then `false`.
6. **Block 2: three small functions.** Under block 1, leave one blank line and type:

   ```js
   // 2. Define behavior
   function setState(stateName) {
     form.classList.remove("idle", "sending", "sent", "failed");
     form.classList.add(stateName);
   }

   // Continue alone: showError(input, errorElement, text) puts the text
   // in errorElement and adds the class "invalid" to input.
   // clearError(input, errorElement) empties errorElement and removes "invalid".
   ```

   Write `showError` and `clearError` from their descriptions, as you wrote helpers in Module 7. Then test all three by hand. Save, press F5, and type `showError(nameInput, nameError, "Test")`. The sample showed **Test** in bold red under the Name box, and the box got a red border. Type `clearError(nameInput, nameError)`: both were gone. Then type `setState("sent")` and `form.className`. The sample gave `'contact-form sent'`: the `idle` class was gone, and `contact-form` stayed.
7. **`findFirstProblem`: your own messages.** Under the small functions, type:

   ```js
   // Checks every field. Returns the first field with a problem, or null.
   function findFirstProblem() {
     let firstProblem = null;
     clearError(nameInput, nameError);
     clearError(emailInput, emailError);
     clearError(messageInput, messageError);

     const name = nameInput.value.trim();
     if (name === "") {
       showError(nameInput, nameError, "I'd love to know who is writing. Please add your name.");
       firstProblem = nameInput;
     }

     // Continue alone: the email (empty, or checkValidity() is false)
     // and the message (trimmed length under 10). Use your own messages.
     // Set firstProblem only if it is still null.

     return firstProblem;
   }
   ```

   The shape is the Exercise's: clear every message, check every field, remember only the first problem. Put your own sentences from step 2 in the quotes. The sample's are in Part 6, *Answers*.

   Test it by hand before any button uses it. Save, press F5, and type `findFirstProblem()` with all three fields empty. The Console showed the Name box itself, `<input type="text" id="visitor-name" …>`, and all three messages appeared on the page. Fill in `Sam`, `sam@example.com` and `Hello, I like your site.`, then call it again. The sample gave `null`, and every message was gone.
8. **Finish, submit, connect.** Under `findFirstProblem`, type `finishSending` and `handleSubmit`, then block 3:

   ```js
   function finishSending() {
     if (pretendFail) {
       // Continue alone: set the state to "failed" and put your
       // failed message in statusMessage. Do not reset the form.
     } else {
       const name = nameInput.value.trim();
       setState("sent");
       statusMessage.textContent = "Thanks, " + name + ". Your message passed every check.";
       form.reset();
     }
     sendButton.disabled = false;
   }

   function handleSubmit(event) {
     event.preventDefault();
     statusMessage.textContent = "";
     const firstProblem = findFirstProblem();
     if (firstProblem !== null) {
       setState("idle");
       firstProblem.focus();
       return;
     }
     setState("sending");
     statusMessage.textContent = "One moment...";
     sendButton.disabled = true;
     // Stand-in for a real server: wait one second, then finish.
     setTimeout(finishSending, 1000);
   }

   // 3. Connect events
   form.addEventListener("submit", handleSubmit);
   ```

   The thank-you reads the name into `name` **before** `form.reset()` empties the box (Core concept 7). `if (pretendFail)` is short for `if (pretendFail === true)`: an `if` only needs a true or false value, and `pretendFail` already is one.
9. **Test the five paths.** Save and press F5. For each line, write down what you expect, then do it and compare:

   - **Empty.** Press Send with all three fields empty. The sample showed three messages, and focus went to Your name.
   - **Spaces only.** Type three spaces in Your name, `sam@` in Email and `hi` in Message, and press Send. All three messages appeared, and focus went to Your name. Three spaces are not a name, because `.trim()` turned them into `""`.
   - **Bad email.** Change the name to `Sam` and press Send. Name's message went away, and focus went to Email: the left render in the brief.
   - **Short message.** Change the email to `sam@example.com` and press Send. Only the Message line was left, and focus went to Message.
   - **Success.** Change the message to `Hello, I like your site.` and press Send. The button faded, and the status line said **One moment...**. One second later it said **Thanks, Sam. Your message passed every check.**, and all three fields were empty.

   With the Console open the whole time, nothing went red.
10. **See the failed state.** Fill in all three fields correctly again. In the Console, type `pretendFail = true` and press Enter. Then press Send. After one second, the sample showed its failed message in dark red on pale red, with Sam's name, email and message still in the fields. Press **F5** when you are done: the page starts fresh, so `pretendFail` is `false` again.
11. **Modify.** In `findFirstProblem`, around the message check, change `if (firstProblem === null) { firstProblem = messageInput; }` to just `firstProblem = messageInput;`. **Predict:** with an empty name, a good email and `hi` as the message, where will focus go? Write it down, save, press F5 and try it. The sample showed both messages, but focus went to **Message**, the last problem, not the first. The message check ran last and overwrote `firstProblem`. Put the `if` back.
12. **Break it on purpose: reset too early.** In `finishSending`, move `form.reset();` up, so it is the first line of the `else` block, above `const name = …`. Predict what the thank-you will say. Save, press F5, and send a valid form. The sample said **Thanks, . Your message passed every check.** There was no red line: `form.reset()` emptied the name box, and an empty name is a perfectly good string. Move `form.reset();` back to the end of the block.
13. **Debug: a form that ignores you.** In block 1, change `"#visitor-email"` to `"#visitor-mail"`. Save, press F5, and press Send with all three fields empty. Before you read on, write down what you see, and which block you would check first. Then look at the Console.

    In the sample, nothing happened on the page: no messages, no reload. The Console showed:

    ```
    Uncaught TypeError: Cannot read properties of null (reading 'classList')
        at clearError (contact.js:30:9)
        at findFirstProblem (contact.js:37:3)
        at HTMLFormElement.handleSubmit (contact.js:80:24)
    ```

    This message has three lines under it, and you read them from the bottom up. `handleSubmit` ran on the submit, on line 80. It called `findFirstProblem`, which on line 37 called `clearError(emailInput, emailError)`. Inside `clearError`, line 30 read `input.classList`, and `input` was `null`.

    So `emailInput` holds `null`, and a name gets its value in block 1. There, `"#visitor-mail"` matches no element. The page did not reload, because `event.preventDefault()` had already run. Your line numbers match only if your file has the sample's shape. Put the `e` back and test again.
14. **The rating card HTML.** Open `rate.html`. In the `<head>`, under the stylesheet link, add `<script src="rate.js" defer></script>`. Then make three changes to the card:

    ```html
    <form class="rating-form" novalidate>
    ```

    ```html
    <fieldset class="choices" aria-describedby="rating-error">
    ```

    ```html
    <p id="rating-error" class="error"></p>
    ```

    The first two replace the opening tags you have. The error paragraph goes right after `</fieldset>`, before the button. Then, at the end of the card, after `</section>` and before the card's closing `</div>`, add the status line:

    ```html
    <p id="rating-status" class="visually-hidden" role="status"></p>
    ```

    **Predict:** `rate.js` does not exist yet. What will the address end in after Send rating with nothing chosen? And with 4 chosen? Save, open `rate.html`, press F5, and try both. The sample's address ended in `rate.html?` with nothing chosen: the form sent, with no pairs at all, because a group with no choice sends nothing. With 4 chosen, it ended in `rate.html?rating=4`, as in Module 4. Each time, the Console had the red `ERR_FILE_NOT_FOUND` line for `rate.js`. Delete the `?…` part of the address before you go on.
15. **The rating error's spacing.** In `styles.css`, under the `.error:empty` rule, add:

    ```css
    .rating-form .error {
      margin: 0 0 16px;
    }
    ```
16. **`rate.js`: read the chosen rating.** Create `rate.js` next to `rate.html`. Type:

    ```js
    // rate.js: reads the chosen rating and swaps the form for the thank-you section

    // 1. Find elements
    const ratingForm = document.querySelector(".rating-form");
    const thanks = document.querySelector(".thanks");
    const chosenRating = document.querySelector("#chosen-rating");
    const firstChoice = document.querySelector("#rating-1");
    const ratingError = document.querySelector("#rating-error");
    const ratingStatus = document.querySelector("#rating-status");

    // 2. Define behavior
    // Returns the value of the chosen radio, such as "4", or null if none is chosen.
    function getChosenRating() {
      const chosen = document.querySelector('input[name="rating"]:checked');
      // Continue alone: if chosen is null, return null.
      // Otherwise, return the value of chosen.
    }
    ```

    This function only answers a question. It does not touch the page, so you can test it alone. Save, press F5, and type `getChosenRating()` in the Console. The sample gave `null`. Click **4** on the card and type it again. The sample gave `'4'`, with quotes: the value of a radio is text, a string. If you see a red `TypeError` about reading `'value'` instead of `null`, your `if` is missing or comes too late (Problem 4 in Part 4, *Troubleshooting*).
17. **The swap.** Under `getChosenRating`, type:

    ```js
    function handleRating(event) {
      event.preventDefault();
      const rating = getChosenRating();
      if (rating === null) {
        ratingError.textContent = "Please choose a number from 1 to 5.";
        firstChoice.focus();
        return;
      }
      // Continue alone: empty the error, put rating in chosenRating,
      // hide the form, show thanks, and put this sentence in
      // ratingStatus: "Thanks for the feedback. You chose " + rating + " out of 5."
    }

    // 3. Connect events
    ratingForm.addEventListener("submit", handleRating);
    ```

    Read the `if` as a door at the top: the nothing-chosen case leaves right there, with `return`, as in `handleSubmit`. Every line after it can be sure a rating exists. The swap is two `hidden` lines, one `true` and one `false`, because the HTML already holds both states (Module 4).

    Save and press F5. Test three ways. **No choice:** click Send rating. The sample showed **Please choose a number from 1 to 5.**, and focus moved to number 1, but with no ring: after a mouse click, Chromium draws the ring only for the keyboard (`:focus-visible`). The keyboard test below shows it.

    **With 4:** click 4, then Send rating. The form was gone, and the card said **You chose 4 out of 5**.

    **Keyboard only:** press F5, put the mouse aside, and press Tab seven times, to Send rating. Press Enter: the message appears, and 1 gets the dark orange ring. Press the right arrow three times, then Tab and Enter. The sample showed the right-hand render in the brief. The hidden button had focus, so focus went back to the page: the next Tab started again at Home, at the top.
18. **Break it on purpose: the whole radio.** In `getChosenRating`, change the last `return` to `return chosen;` (drop `.value`). Predict what the card will say with 4 chosen. Save, press F5, choose 4 and send. The sample said **You chose [object HTMLInputElement] out of 5**, with no red line. `chosen` is the radio element itself. `textContent` turned it into text, and that is the text an element becomes. Put `.value` back.
19. **Write the keyboard test, then run it.** On paper, write one line for each thing a keyboard user must be able to do on these two pages: the key you press, and what should happen. Then put the mouse aside and run every line, on the Contact page and on the Rate page, ticking each one. The sample's plan was nine lines:

    - [ ] F5, then Tab: the five nav links, then Your name, Email, Message and Send message, in that order, each with a ring
    - [ ] On Send message, Enter with all fields empty: three messages, focus in Your name
    - [ ] With a name filled in, in Email with `sam@`, Enter: the form submits, focus stays in Email with its message
    - [ ] In Message, Enter: a new line, no submit
    - [ ] On Send message with a valid form, Enter: **One moment...**, then the thank-you
    - [ ] After the thank-you, Shift+Tab: focus goes back into the form (Core concept 8)
    - [ ] Rate page: six Tabs reach number 1; Tab and Enter with nothing chosen: the message, focus on 1
    - [ ] Arrows choose a number; Tab, Enter: the thank-you section shows the number
    - [ ] After the thank-you, Tab: focus starts again at the top of the page

    Keep your plan. Module 11 turns a list like this into a test plan.
20. **Explain it.** Read `contact.js` to yourself, out loud, from top to bottom. For each function, say what causes it to run: a submit, a timer, or another function. Then read `rate.js` the same way, and say why `getChosenRating` returns `null` instead of showing a message itself.
21. **Test the site.** Tick each box in a full-width window and at 390 px in device mode (F12, then Ctrl+Shift+M). Keep the Console open the whole time.

    - [ ] No red line in the Console on any of the five pages, and the gallery and FAQ still work
    - [ ] Empty, spaces-only, bad email and short message each show the right messages, with focus on the first problem
    - [ ] A valid send goes through **sending** to **sent**, names the visitor, and empties the form; `pretendFail = true` shows **failed** with the words kept
    - [ ] In the Elements tab, the form has exactly one of `idle`, `sending`, `sent` or `failed` at a time
    - [ ] The rating card refuses an empty choice with its message, and shows the chosen number after a send
    - [ ] Every line of your keyboard test from step 19 is ticked
    - [ ] Nothing scrolls sideways at 390 px on the Contact page or the Rate page
    - [ ] The changes from steps 11, 12, 13 and 18 are undone, and no message on the page says your message was sent

22. **Save it in Git.** Go to Part 3, *Finishing work in Git*, and publish both features with the save routine.
