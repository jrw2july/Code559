# Troubleshooting: six common problems

Each problem has the symptom you see, why it happens, and the fix. Each one was made on purpose in the sample site and run in Chromium 141, with the files opened from disk as in the steps. The Console messages are quoted as Chromium printed them. The line numbers are the sample's: yours match only if your file has the same shape. After each fix, save, press **F5**, and run the test from Project step 21 again.

### 1. The page reloads, and the address gains `?visitor-name=…`

**Symptom.** You press Send message, the page flashes, and the form comes back empty. The address now ends in something like `contact.html?visitor-name=Sam&visitor-email=&message=`. Any message you saw is gone.

**Why.** The browser did its default: it sent the form and loaded the page again. With `novalidate` on the form, the browser does not check anything itself, so an empty form goes straight through. Your handler either never ran, or did not stop the default. The sample got this three ways:

| What was wrong | What the Console showed |
|---|---|
| A misspelled file name, `<script src="contacts.js" defer>` | `Failed to load resource: net::ERR_FILE_NOT_FOUND`, with `contacts.js` beside it |
| `defer` missing from the `<script>` line | `Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')` at `contact.js:94:6`, the line in block 3 |
| `event.preventDefault();` commented out or missing | nothing at all; the handler writes its messages, then the reload wipes them |

**Fix.** Read the Console first. A red line names the file or the line to fix: compare the file name with the Explorer, or add `defer` (Module 9). No red line means the handler ran: check that `event.preventDefault();` is its first line. Then delete the `?…` part of the address and press Enter, so you test a clean page.

### 2. Nothing happens, and the Console shows a TypeError about `null`

**Symptom.** You press Send message. No message appears, and the page does not reload. The Console shows a red message with three lines under it, such as:

```
Uncaught TypeError: Cannot set properties of null (setting 'textContent')
    at clearError (contact.js:29:28)
    at findFirstProblem (contact.js:36:3)
    at HTMLFormElement.handleSubmit (contact.js:80:24)
```

**Why.** A name in block 1 holds `null`, because its selector matches no element. The script found out only when a function used that name. Here the selector was `"#nameerror"` for `id="name-error"`, so `nameError` was `null`, and `clearError` tried to set its `textContent`. With `"#visitor-mail"`, the message was `Cannot read properties of null (reading 'classList')` at `contact.js:30:9` instead (Project step 13). The page did not reload, because `event.preventDefault()` ran before the error.

**Fix.** Read the lines under the message from the bottom up: which function called which, and with what. The top line is where `null` was used. Find which name was passed in, then compare its selector in block 1 with the id in `contact.html`, character by character.

### 3. The status line has no color

**Symptom.** The status line says **One moment...** and then the thank-you, but in plain dark text on the page background, with no pale green or pale red box.

**Why.** Each state rule, such as `.sent + #contact-status`, matches only when the status paragraph comes **right after** the form, with nothing between them. In the sample, with `<p id="contact-status">` moved inside the form, the text still changed, but its background stayed transparent. The padding from `#contact-status` still applied, so the text sat a little indented. The same happens if another element sits between `</form>` and the status line.

**Fix.** Put `<p id="contact-status" role="status"></p>` directly after `</form>`, as in the brief. Then check in the Elements tab (F12) that it is the form's next sibling.

### 4. TypeError: Cannot read properties of null (reading 'value')

**Symptom.** On the Rate page, Send rating with nothing chosen does nothing at all: no message, no ring on 1. The Console shows:

```
Uncaught TypeError: Cannot read properties of null (reading 'value')
    at getChosenRating (rate.js:15:17)
    at HTMLFormElement.handleRating (rate.js:20:18)
```

With a number chosen, the card works.

**Why.** With nothing chosen, `querySelector('input[name="rating"]:checked')` gives `null` (Core concept 2). The sample's `getChosenRating` had no `if`, so it went straight to `return chosen.value;`, and `null` has no properties. The same message comes if the `if` is there but checks something else, such as `chosen === undefined`.

**Fix.** Check for `null` first, with `===`, and return `null` from inside that `if`. Only the line after it reads `.value`, when `chosen` is sure to be a radio.

### 5. The thank-you section shows when the page loads

**Symptom.** The Rate page opens with the form **and** the thank-you section, and the span is empty: **You chose  out of 5**. After a send, the form disappears and the number fills in.

**Why.** A `display` rule on the section beats the `hidden` attribute (Module 9, Core concept 8). In the sample, with `display: block;` added to `.thanks`, the section's `hidden` was `true` at load, but its display was `block`, so it showed anyway.

**Fix.** Give `.thanks` no `display` rule, as in the Module 4 brief. The same goes for `.rating-form`: a `display` rule there would keep the form visible after the swap.

### 6. The form accepts `sam@example`

**Symptom.** You type `sam@example`, with no dot, and the email passes. `sam@` is refused, but `sam@example` is not.

**Why.** Your script asks the browser, with `emailInput.checkValidity()`, and the browser's `type="email"` rule needs only something before the `@` and something after it. In the sample, `checkValidity()` gave `true` for `sam@example` and `sam@example.com`, and `false` for `sam@`, `@example.com`, `sam@@example.com` and `sam example@x.com`.

**Fix.** Nothing is broken. The check in the browser only catches typing mistakes; no rule in the browser can prove an address is real. The way to know is to send a message to it, and that happens on a server, after the form. Leave the rule as it is.
