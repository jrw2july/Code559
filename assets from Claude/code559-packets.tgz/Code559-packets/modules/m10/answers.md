# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **Errors that flash and vanish.** `event.preventDefault()` is missing, or it is not the handler's first line, or it never runs. Your handler wrote the messages, then the browser did its default: it sent the form, which adds the `?name=value` pairs to the address, and loaded the page again. The new page starts fresh, so the messages are gone. Make `event.preventDefault();` the first line of the submit handler. (Core concept 1; Exercise step 9)
2. **What value does this variable hold?** `nameInput.value` holds every character the visitor typed: two spaces, `Ana`, one space. That is the string `"  Ana "`, six characters long. `nameInput.value.trim()` gives a new string without the spaces at both ends: `"Ana"`, three characters. The box itself still holds the six; `.trim()` does not change the original. (Core concept 2)
3. **Why keep `required` and `minlength`.** `novalidate` only stops the browser's message bubbles and its block on the submit. The attributes still describe the rules, and the browser still uses them: `checkValidity()` and `validationMessage` read them, and the Exercise's email check is `emailInput.checkValidity()`, which uses `type="email"`. They also tell assistive technology about the field: in Chromium's accessibility tree, the project's Name box was a required textbox. And anyone who reads your HTML sees the rules at a glance. (Core concepts 3 and 4)

## Common misconception

*"If my JavaScript checks every field, the data that reaches me will always be clean."* Your checks run in the visitor's browser, and the visitor controls that browser. One line in the Console removed every `required` attribute in Core concept 9. A visitor can also switch JavaScript off, change your script in DevTools, or skip your page and send data straight to the server.

So your checks help honest visitors fix mistakes, and stop nobody who wants to get around them. Client-side validation is user experience, not security. The server must check every value again, every time, before it trusts it. (Core concept 9)

## Exercise checks

These are the results with the lesson's code, checked in Chromium.

- **Step 4.** Three messages: **Please enter your name.**, **Please enter your email address.** and **Please write at least 10 characters.** Focus goes to Name, the first field with a problem. The form keeps the class `idle`. (Core concepts 5 and 6)
- **Step 5.** Three messages again. Name says **Please enter your name.**, because `.trim()` turned the three spaces into `""`. Email says **That email address looks incomplete. Check the @ and the part after it.** Message says **Please write at least 10 characters.** Focus goes to Name. (Core concepts 2 and 4)
- **Step 6.** First the `sending` state: the button fades and is disabled, and the status says **Sending...**. One second later, the `sent` state: **Thanks, Your Name. Your message was sent.** in green, and all three fields are empty. (Core concepts 7 and 8)
- **Step 7.** After one second, the `failed` state: **Sorry, your message did not go through. Please try again.** in red, and your values are still in the fields. (Core concept 8)
- **Step 8.** Enter in the Name or Email box submits the form, and focus lands on the first field with a mistake. With a name and `you@`, focus went to Email. In the Message box, Enter starts a new line, so you Tab to Send and press Enter there. (Core concepts 1 and 6)
- **Step 9.** The page reloads, the address ends in `index.html?name=Your+Name&email=&message=`, and the form is empty with no messages. The Console shows nothing red. (Core concept 1)
- **Step 10.** Three spaces pass the check, and the form "sends." The thank-you trims the name, so it says **Thanks, . Your message was sent.** (Core concept 2)

## Self-assessment questions

1. **Why one mistake gives an error and the other does not.** In step 12, every line is valid. `form.reset()` empties the Name box, and `nameInput.value.trim()` then gives `""`, an empty string. Joining `""` into a sentence is allowed, so nothing fails and nothing is printed. The clue is the page itself: the comma right after **Thanks,** with no name.

   In step 13, `querySelector("#visitor-mail")` gave `null`, and `clearError` read `input.classList` with `input` holding `null`. `null` has no properties at all, so the browser stopped the handler with a `TypeError`. The clue is the message: its three lines lead from `handleSubmit` to `clearError`, and back to the selector in block 1.
2. **A prediction you got wrong.** There is no single answer. A good answer quotes what you wrote down before you saved, says what the page or the Console really showed, and names the idea you understand now. For example: that `novalidate` with no script lets an empty form through (Project step 3), or that a group with no choice sends no pair at all (Project step 14).
3. **The friend's `handleRating`.** With nothing chosen, `getChosenRating()` gives `null`, not `""`. `null === ""` is `false`, so the `if` is skipped, and there is no red line. The form disappears and the thank-you shows **You chose  out of 5**, with nothing in the span: setting `textContent` to `null` empties it. With 3 chosen, the card works and shows **You chose 3 out of 5**.

   Tell them to compare with what the function really returns: `if (rating === null)`. Their version also never fills `ratingStatus`, so a screen reader hears nothing after the swap. They should add that line from Project step 17. (Core concept 2; Project steps 16 and 17)

## Project checks

- **Step 3.** The page reloads with the address ending in `contact.html?visitor-name=&visitor-email=&message=`, and the Console has one red line, `Failed to load resource: net::ERR_FILE_NOT_FOUND`, for `contact.js`.
- **Step 3, continue alone.** The email and message fields of the sample form:

  ```html
    <label for="visitor-email">Email</label>
    <input type="email" id="visitor-email" name="visitor-email" required aria-describedby="email-error">
    <p id="email-error" class="error"></p>

    <label for="message">Message</label>
    <textarea id="message" name="message" rows="5" required minlength="10" aria-describedby="message-error"></textarea>
    <p id="message-error" class="error"></p>
  ```

- **Step 4, continue alone.**

  ```css
  .sent + #contact-status {
    color: #1e5b2a;
    background-color: #e3f4e5;
  }

  .failed + #contact-status {
    color: #8c1d18;
    background-color: #fbe4e2;
  }
  ```

- **Step 5, continue alone.** The four lines are in the whole `contact.js` at the end of this section. `emailError` gave `<p id="email-error" class="error"></p>` and `pretendFail` gave `false`.
- **Step 6, continue alone.**

  ```js
  function showError(input, errorElement, text) {
    errorElement.textContent = text;
    input.classList.add("invalid");
  }

  function clearError(input, errorElement) {
    errorElement.textContent = "";
    input.classList.remove("invalid");
  }
  ```

  `showError(nameInput, nameError, "Test")` showed **Test** in bold red and a red border; `clearError` removed both; `form.className` gave `'contact-form sent'`.
- **Step 7, continue alone.** The sample's email and message checks, with its own messages:

  ```js
    const email = emailInput.value.trim();
    if (email === "") {
      showError(emailInput, emailError, "Please add your email, so I can write back.");
      if (firstProblem === null) { firstProblem = emailInput; }
    } else if (!emailInput.checkValidity()) {
      showError(emailInput, emailError, "That email looks incomplete. Check the @ and the part after it.");
      if (firstProblem === null) { firstProblem = emailInput; }
    }

    const message = messageInput.value.trim();
    if (message.length < 10) {
      showError(messageInput, messageError, "Tell me a little more: at least 10 characters.");
      if (firstProblem === null) { firstProblem = messageInput; }
    }
  ```

  With empty fields, `findFirstProblem()` returned the Name box; with all three filled in correctly, it returned `null`.
- **Step 8, continue alone.** The failed branch:

  ```js
      setState("failed");
      statusMessage.textContent = "Sorry, that did not work. Your message is still here, so please try again.";
  ```

- **Steps 9 and 10.** As described in the steps. In the failed state, the form's class is `contact-form failed` and the three values stay.
- **Step 11.** Both messages show, and focus goes to Message instead of Your name.
- **Step 12.** **Thanks, . Your message passed every check.**, with no red line.
- **Step 13.** No messages and no reload. The Console shows `Uncaught TypeError: Cannot read properties of null (reading 'classList')`, then `at clearError (contact.js:30:9)`, `at findFirstProblem (contact.js:37:3)` and `at HTMLFormElement.handleSubmit (contact.js:80:24)`.
- **Step 14.** `rate.html?` with nothing chosen, `rate.html?rating=4` with 4 chosen, and the red `ERR_FILE_NOT_FOUND` line for `rate.js` each time.
- **Step 16, continue alone.**

  ```js
    if (chosen === null) {
      return null;
    }
    return chosen.value;
  ```

  `getChosenRating()` gave `null`, then `'4'` after a click on 4.
- **Step 17, continue alone.** The swap:

  ```js
    ratingError.textContent = "";
    chosenRating.textContent = rating;
    ratingForm.hidden = true;
    thanks.hidden = false;
    ratingStatus.textContent = "Thanks for the feedback. You chose " + rating + " out of 5.";
  ```

  The first line clears the message left from an earlier try with nothing chosen.
- **Step 18.** **You chose [object HTMLInputElement] out of 5**, with no red line.
- **Step 21.** If you followed the brief, every box is ticked. The most common misses: a status line that is not right after the form (Problem 3 in Part 4), and a test change from steps 11 to 13 or 18 that was never undone.

Here are the sample's finished files. First, the whole `contact.js`, 94 lines:

```js
// contact.js: checks the Contact form, shows clear messages, and shows four states

// 1. Find elements
const form = document.querySelector(".contact-form");
const nameInput = document.querySelector("#visitor-name");
const emailInput = document.querySelector("#visitor-email");
const messageInput = document.querySelector("#message");
const nameError = document.querySelector("#name-error");
const emailError = document.querySelector("#email-error");
const messageError = document.querySelector("#message-error");
const sendButton = document.querySelector(".contact-form button");
const statusMessage = document.querySelector("#contact-status");

// For testing only: type pretendFail = true in the Console to see the failed state.
let pretendFail = false;

// 2. Define behavior
function setState(stateName) {
  form.classList.remove("idle", "sending", "sent", "failed");
  form.classList.add(stateName);
}

function showError(input, errorElement, text) {
  errorElement.textContent = text;
  input.classList.add("invalid");
}

function clearError(input, errorElement) {
  errorElement.textContent = "";
  input.classList.remove("invalid");
}

// Checks every field. Returns the first field with a problem, or null.
function findFirstProblem() {
  let firstProblem = null;
  clearError(nameInput, nameError);
  clearError(emailInput, emailError);
  clearError(messageInput, messageError);

  const name = nameInput.value.trim();
  if (name === "") {
    showError(nameInput, nameError, "I'd love to know who is writing. Please add your name.");
    firstProblem = nameInput;
  }

  const email = emailInput.value.trim();
  if (email === "") {
    showError(emailInput, emailError, "Please add your email, so I can write back.");
    if (firstProblem === null) { firstProblem = emailInput; }
  } else if (!emailInput.checkValidity()) {
    showError(emailInput, emailError, "That email looks incomplete. Check the @ and the part after it.");
    if (firstProblem === null) { firstProblem = emailInput; }
  }

  const message = messageInput.value.trim();
  if (message.length < 10) {
    showError(messageInput, messageError, "Tell me a little more: at least 10 characters.");
    if (firstProblem === null) { firstProblem = messageInput; }
  }

  return firstProblem;
}

function finishSending() {
  if (pretendFail) {
    setState("failed");
    statusMessage.textContent = "Sorry, that did not work. Your message is still here, so please try again.";
  } else {
    const name = nameInput.value.trim();
    setState("sent");
    statusMessage.textContent = "Thanks, " + name + ". Your message passed every check.";
    form.reset();
  }
  sendButton.disabled = false;
}

function handleSubmit(event) {
  event.preventDefault();
  statusMessage.textContent = "";
  const firstProblem = findFirstProblem();
  if (firstProblem !== null) {
    setState("idle");
    firstProblem.focus();
    return;
  }
  setState("sending");
  statusMessage.textContent = "One moment...";
  sendButton.disabled = true;
  // Stand-in for a real server: wait one second, then finish.
  setTimeout(finishSending, 1000);
}

// 3. Connect events
form.addEventListener("submit", handleSubmit);
```

The whole `rate.js`, 37 lines:

```js
// rate.js: reads the chosen rating and swaps the form for the thank-you section

// 1. Find elements
const ratingForm = document.querySelector(".rating-form");
const thanks = document.querySelector(".thanks");
const chosenRating = document.querySelector("#chosen-rating");
const firstChoice = document.querySelector("#rating-1");
const ratingError = document.querySelector("#rating-error");
const ratingStatus = document.querySelector("#rating-status");

// 2. Define behavior
// Returns the value of the chosen radio, such as "4", or null if none is chosen.
function getChosenRating() {
  const chosen = document.querySelector('input[name="rating"]:checked');
  if (chosen === null) {
    return null;
  }
  return chosen.value;
}

function handleRating(event) {
  event.preventDefault();
  const rating = getChosenRating();
  if (rating === null) {
    ratingError.textContent = "Please choose a number from 1 to 5.";
    firstChoice.focus();
    return;
  }
  ratingError.textContent = "";
  chosenRating.textContent = rating;
  ratingForm.hidden = true;
  thanks.hidden = false;
  ratingStatus.textContent = "Thanks for the feedback. You chose " + rating + " out of 5.";
}

// 3. Connect events
ratingForm.addEventListener("submit", handleRating);
```

In `styles.css`, the only changes are the `--error` line in `:root` and the new group above the wider-screens block: the rules from Project steps 4 and 15, with the "Continue alone" part above filled in. In `contact.html` and `rate.html`, the changes are the `<script>` line in the `<head>` and the new and changed lines from Project steps 3 and 14.
