# Finishing work in Git

The Contact page and the rating card work on your computer. Now you put them online with the same save routine as in Modules 1 to 9: `git status`, `git add .`, `git commit`, `git push`, then check the live site. Two things are new this time. You search your files for the test changes you made on purpose, so none of them is published. And you run your keyboard test from Project step 19 again, on the live pages.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 to 9.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **Search for leftover test changes (NEW).** This project asked you to break things on purpose four times. Make sure every change is undone before Git saves it. In VS Code, open **Edit → Find in Files** (**Ctrl+Shift+F**) and search for `visitor-mail`, then for `return chosen;`. Each search should find nothing. Then open `finishSending` and check that `form.reset();` is the last line of the `else` block, and open `findFirstProblem` and check that every `firstProblem = …` after the name check sits inside `if (firstProblem === null)`.
3. **Read the Console before you commit.** Open each of your five pages in Edge or Chrome with the Console open (**F12**, then the **Console** tab), and press **F5** on each. There should be no red line on any of them. On the Contact page and the Rate page, press the send button once with everything empty: an error in a submit handler only shows up after a submit. Commit only pages whose test from Project step 21 you have just run and seen pass.
4. **See what changed.** Type:

   ```
   git status
   ```

   Under **Changes not staged for commit** you should see `modified:` for `contact.html`, `rate.html` and `styles.css`. Under **Untracked files** you should see `contact.js` and `rate.js`. If another page or script shows up, you changed a file this project does not touch. Open it and check what changed before you go on.
5. **Stage the changes.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. (A warning that mentions LF and CRLF is harmless.) Run `git status` again. Under **Changes to be committed** you should now see five lines: `modified:` for the two pages and `styles.css`, and `new file:` for the two scripts.
6. **Commit.** Type:

   ```
   git commit -m "Add form checks to Contact and JavaScript to the rating card"
   ```

   On the sample site, Git printed `5 files changed, 199 insertions(+), 6 deletions(-)` on the second line, then `create mode 100644 contact.js` and `create mode 100644 rate.js`. The six deletions are the old versions of lines you changed: the two `<form>` tags, the three fields and the `<fieldset>` tag. Your commit id and line counts will differ.
7. **Push.** Type:

   ```
   git push
   ```

   The last line ends in `main -> main`.
8. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. Your new commit is on top, with your Module 9 commit (or your latest one) under it.
9. **Check the live pages with the Console open.** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/contact.html` with the Console open, and press F5. If the page acts like the old version, press **Ctrl+Shift+R** to reload without the saved copy, as in Module 9. Then run the five paths from Project step 9. The live page sends nothing, exactly like the copy on your computer: the note on the page says so.
10. **Run your keyboard test on the live site (NEW).** Put the mouse aside and run your plan from Project step 19 again, line by line, on the live Contact and Rate pages. Tick each line again. A test you wrote down can be run the same way every time, by you or by someone else. That is the idea Module 11 builds on.
11. **Test on a phone.** If you have a phone, open your live Contact page on it. Press Send with the fields empty and check that you can read every message. Then rate the lesson on the live Rate page. Nothing should scroll sideways.

The steps in this packet were tested with files opened from disk in Chromium, not on a live site.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows your new commit on top. On the live site, the Console shows no red line on the Contact or Rate page, every line of your keyboard test is ticked, and no message on the Contact page says your message was sent.
