# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 11. If a line is a 1 or a 2, reread that Core concept and redo its Exercise or Project step.

## Rubric

- I can catch a form with a submit listener, stop the reload with event.preventDefault(), and name two ways a visitor fires submit
- I can read a field with .value, trim it, and refuse a value that is empty or only spaces
- I can read the chosen radio with :checked, and check for null with === before I read its value
- I can say what required, type="email", minlength and pattern check, and why minlength needs required
- I can use novalidate with my own checks, and explain why the HTML rules stay in place
- I can tie an error message to its field with aria-describedby, and say why that is the only ARIA the form needs
- I can find the first field with a problem, move focus to it, and write messages that say what to do
- I can confirm success in a role="status" element, read what I need before .reset(), and show four states as classes
- I can explain why client-side validation is user experience, not security, and what a server must still do

## Three questions to answer in writing

1. In Project step 12, moving `form.reset()` up gave **Thanks, . Your message passed every check.** with no red line. In Project step 13, one wrong selector gave a red `TypeError` and no messages at all. Explain why one mistake gives an error and the other does not, and what the clue was in each case.
2. Pick one prediction from the Exercise or the project where your first answer was wrong. What did you write down, what did the page or the Console show, and what do you understand now that you did not before?
3. A friend wrote this `handleRating`. What does the card do when the visitor presses Send rating with nothing chosen? What does it do with 3 chosen? And what would you tell them to change?

   ```js
   function handleRating(event) {
     event.preventDefault();
     const rating = getChosenRating();
     if (rating === "") {
       ratingError.textContent = "Please choose a number from 1 to 5.";
       firstChoice.focus();
       return;
     }
     ratingError.textContent = "";
     chosenRating.textContent = rating;
     ratingForm.hidden = true;
     thanks.hidden = false;
   }
   ```
