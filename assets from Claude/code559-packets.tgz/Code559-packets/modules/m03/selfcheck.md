# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 4. If a line is a 1 or a 2, reread that Core Concept and redo its Exercise or Project step.

## Rubric

- I can name the four layers of the box model and work out a box's real width with and without box-sizing: border-box
- I can explain what the viewport meta tag does and spot a page that is missing it
- I can write phone rules first and put a min-width media query after the rules it changes
- I can make a header stack on a phone and become a row on a wider screen, with nav links that wrap
- I can build a card grid with repeat(auto-fit, minmax(220px, 1fr)) and gap, and make one card span two columns only on wide screens
- I can write an img with srcset, sizes, width, height, loading="lazy" and alt, inside a figure with a figcaption
- I can explain why the browser chose a given srcset file, using the width and the pixel ratio
- I can test a page at 390, 800 and 1200 px with the DevTools device toolbar and read the results in the Console

## Three questions to answer in writing

1. In Project step 15, the featured card's span moved outside the media query and the phone layout broke. Explain why, in your own words, and say why the same rule is fine inside the media query.
2. Pick one mistake you made in this module. What did the page or the Console show, and how did you find the cause?
3. You add a sixth interest to the page. List everything you must make, add or check, in order, from the photo files to the live site.
