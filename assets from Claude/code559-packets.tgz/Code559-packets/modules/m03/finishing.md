# Finishing work in Git

Your Interests page works on your computer. Now you put it online with the same save routine: `git status`, `git add .`, `git commit`, `git push`, then check the live page. What is new this time is a new folder full of image files, and checking the live site at more than one width.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 and 2.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **See what changed (NEW: a new folder).** Type:

   ```
   git status
   ```

   Under **Changes not staged for commit** you should see `modified:` for `about.html`, `index.html` and `styles.css`. Under **Untracked files** you should see `images/` and `interests.html`. Git lists a new folder as one line, `images/`, with a slash at the end. It does not list the files inside until you stage them.
3. **Stage the changes.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. Run `git status` again. Now every photo is listed on its own line under **Changes to be committed**, as `new file:   images/interest-one-400.jpg` and so on, next to `new file:   interests.html` and the three `modified:` files. Count the photo lines: three per interest. If one is missing, check its name in the Explorer before you commit.
4. **Commit.** Type:

   ```
   git commit -m "Add a responsive Interests page with responsive images"
   ```

   The first line of the summary starts with `[main`, a seven-character commit id and your message. The next line says how many files changed: with five interests, `19 files changed` (15 photos, the new page, and three changed files). Then comes one `create mode 100644` line for each new file. Your commit id and numbers will differ. The new page, its photos, the new nav link and the stylesheet changes belong together, so they go into one commit.
5. **Push.** Type:

   ```
   git push
   ```

   Photos are bigger than text files, so this push may take a little longer. The last line ends in `main -> main`.
6. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. Your new commit is on top, with your Module 2 commit under it.
7. **Check the live page (NEW: checking the photos online).** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/interests.html` and press F5. Every card should show its photo. A broken photo online that works on your computer is almost always a capital letter: `Images` or `Interest-One-400.jpg` works on Windows, but the web server treats it as a different name (Module 1, *Troubleshooting*). Press F12, open the **Console** tab, and look for a red `404 (Not Found)` error with the file name.
8. **Test the live site at three widths (NEW).** With the live page open, turn on device mode (F12, then Ctrl+Shift+M) and run the test from Project step 18 again at 390, 800 and 1200 px. If you have a phone, open your live address on it too. Chrome's documentation calls device mode "a first-order approximation" of a phone, and the real phone is the final check.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows your new commit on top. Your live Interests page shows every photo at 390, 800 and 1200 px, and the Console has no red errors.
