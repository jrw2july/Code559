# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **The 200 px box.** Without a `box-sizing` rule, `width` sets only the content, so the box is 200 + 10 + 10 (padding) + 2 + 2 (border) = **224 px** wide on screen. With `box-sizing: border-box`, the padding and border fit inside the width, so it is **200 px**, and the content area shrinks to 176 px. (Core concepts 1 and 2)
2. **The query never fires on the phone.** Check the viewport meta tag first: `<meta name="viewport" content="width=device-width, initial-scale=1">` in the `<head>`, spelled exactly. Without it, the phone lays the page out at a wide virtual width, close to 980 px, and shrinks it to fit. Your `min-width: 700px` query is then *true* on the phone, so the phone gets the laptop layout. (Core concept 3; Exercise step 8a; *Troubleshooting*, problem 1)
3. **`minmax(400px, 1fr)`.** Fewer columns fit. On the Exercise page at 800 px, the grid has 768 px of room, and two 400 px columns plus the gap need 816, so there is only **one column** (Chromium measured `768px`). At 390 px there is only 358 px of room, but the minimum in `minmax()` always holds: the one column is **400 px** wide, sticks out past the edge, and the page scrolls sideways (Chromium measured a page 416 px wide in a 390 px window). (Core concept 6)

## Common misconception

*"Responsive design means writing a separate stylesheet for phones."* The Exercise page used one HTML file, one stylesheet and **one** media query, and the number of grid columns still changed three times: 1, 3 and 4 at 390, 800 and 1200 px. Most of that came from `repeat(auto-fit, minmax(220px, 1fr))`, which has no media query at all. Responsive design is one set of base rules for the phone, plus small changes for wider screens. Your Interests page works the same way: three pages, one `styles.css`, one `@media` block. (Core concepts 4 and 6; Project steps 10 and 12)

## Exercise checks

- **Step 5.** At 390, 800 and 1200 px you see 1, 3 and 4 columns. At 1000 px the Exercise page shows 4 columns: `main` is 968 px wide inside its padding, and four 220 px columns plus three 16 px gaps (928 px) fit, while five (1164 px) do not. (Core concept 6)
- **Step 6.** In device mode (pixel ratio 2), `currentSrc` ends in `photo-one-800.jpg` at 390 and 800 px, and `photo-one-1600.jpg` at 1200 px, as in the right column of the table in Concept 7. If you get a bigger file at a narrow width, press F5 and ask again. (Core concept 7)
- **Step 7.** The answer is a list of widths: one value at 390 px, three at 800 px, four at 1200 px. (Core concept 6)
- **Step 8a.** Without the viewport line, the page shrinks, the text is tiny, and `innerWidth` no longer says 390; the lesson measured 980. (Core concept 3)
- **Step 8b.** With the `@media` block at the top, the header is stacked at 1200 px. Both header rules have the same specificity, and the base rule now comes later, so it wins. (Core concept 4)

## Self-assessment questions

1. **Why the span broke the phone layout.** At 390 px, the grid has room for only one 220 px column. Outside the media query, the `.featured` rule works at every width, so the featured card asks for two columns on a phone too. Grid makes a second, narrow column for it, and every other card squeezes into that column. Inside the media query, the rule works only at 700 px and up. There the grid has three or four columns, so the featured card can span two of them, and the other cards still fit. (Project steps 10, 12 and 15)
2. **A mistake you made.** There is no single answer. A good answer names the mistake, quotes what the page or the Console really showed, for example a red error for one photo file, and says how you found the cause, for example by testing at more than one width.
3. **A sixth interest.** First, save one photo three times in `images`, at 400, 800 and 1200 px wide, named `interest-six-400.jpg`, `interest-six-800.jpg` and `interest-six-1200.jpg`. Write down the real size of the 1200 file. Second, add a new `<li class="card">` to the grid, with an `<h3>`, a `<figure>` and a `<p>`. Third, give its `<img>` a `srcset` with all three files, `sizes="(min-width: 700px) 33vw, 100vw"`, `width` and `height` from the real 1200 file, `loading="lazy"` and real `alt` text, plus a `<figcaption>`. You do not change the CSS. Fourth, save, press F5 and check the page at 390, 800 and 1200 px in device mode. Fifth, check in the Console that the new photo loads at every width with no red errors. Last, publish and run the site test again on the live site. (The brief; Project steps 3, 8, 11, 13, 17, 18 and 19)

## Project checks

- **Brief.** `my-site` holds `index.html`, `about.html`, `interests.html`, `image-one.jpg`, `styles.css` and an `images` folder with three files per interest. All three pages have the same four-link nav. `styles.css` starts with the `box-sizing` rule and ends with the one `@media (min-width: 700px)` block. (The brief)
- **Step 6.** At 390 px the site name sits above the links on the Home page. The links stay in one row while they fit and wrap onto a second line when they do not. (Step 6; Core concept 5)
- **Step 12.** One column at 390 px, three at 800 px, four at 1200 px. The sample measured `342px`, `240px` (three times) and `276px` (four times). (Step 12; Core concept 6)
- **Step 13.** At pixel ratio 2 in device mode, a normal card shows the 800 file at all three widths; the featured card shows the 800 file at 390 px and the 1200 file at 800 and 1200 px, because `sizes` says it is about two thirds of the window on wide screens. (Step 13; Core concept 7)
- **Step 14.** With `minmax(300px, 1fr)`, fewer and wider columns fit at 800 and 1200 px. (Step 14; Core concept 6)
- **Step 15.** With `.featured` outside the media query, the phone layout gets two columns, and the second is narrow: the sample measured `220px 129.172px` at 390 px. The second width depends on your card text; what matters is a second, narrow column. (Step 15; Core concepts 4 and 6)
- **Step 16.** Without `height: auto`, the photos keep the `height` attribute as a fixed height and stretch: 308 px wide and 800 px tall on the sample. (Step 16; Core concept 7)
- **Step 17.** With a typo in the 800 entry, the featured photo breaks only where the browser chooses that file: at 390 px with pixel ratio 2, but not with pixel ratio 1. The Console names the missing file. (Step 17; Core concepts 7 and 8)
- **Finishing work.** `git status` says `nothing to commit, working tree clean`, `git log --oneline` shows `Add a responsive Interests page with responsive images` on top, and the live Interests page shows every photo at 390, 800 and 1200 px with no red errors in the Console. (Part 3, steps 6 to 8)
