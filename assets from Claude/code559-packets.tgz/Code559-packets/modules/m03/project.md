# Project: A responsive Interests page

*Your hands, about 90 minutes (estimate).* In the Exercise you built a responsive practice page in `practice-03`. Now you add a third page to your real site. You build an **Interests** page in `my-site` as a card grid: one card per interest, each with a photo, a caption and a sentence about why you like it. On a phone the cards sit in one column. On a laptop they spread into a grid, and your favorite spans two columns. Every photo comes in three sizes, and the browser picks the one it needs. You also make the shared header mobile first, so all three pages work on a phone. You use only HTML and CSS from Modules 1 to 3. There is no JavaScript.

This project starts from the Module 2 packet's site: Home, About and one shared `styles.css`. If your site does not have that yet, finish the Module 2 packet project first (Part 2), then come back.

## The brief

When you finish, `my-site` holds `index.html`, `about.html`, the new `interests.html`, `image-one.jpg`, `styles.css`, and a new folder `images` with your interest photos. All three pages link the same `styles.css`. The live address is `https://your-username.github.io/my-site/`.

**The nav.** Every page's nav has four links, in this order: **Home**, **About**, **Interests**, **Contact**. The new link is `<a href="interests.html">Interests</a>`. The header is still the same, letter for letter, on all three pages.

**The Interests page.** It has the same `<head>`, header and footer as the About page, with the title `Interests - Your Name`. Its `<main>` has one `<section>` with an `<h2>` that says **My interests**, a short opening paragraph with `class="lead"`, and a `<ul class="card-grid">` with one `<li class="card">` for each interest. Use four to six interests; the sample has five. Each card holds, in this order:

- an `<h3>` with the name of the interest,
- a `<figure>` with the `<img>` and a `<figcaption>` that says what the photo shows,
- a `<p>` with one sentence about why you like it.

Your favorite interest is the first card, and it has `class="card featured"`.

**The photos.** Each interest has one photo saved in three widths: 400, 800 and 1200 pixels. They live in `my-site\images` and are named `interest-one-400.jpg`, `interest-one-800.jpg`, `interest-one-1200.jpg`, then `interest-two-…` and so on. Each `<img>` has a `srcset` with all three files and their `w` descriptors, a `sizes` attribute, `width` and `height` set to the real size of the 1200 file, `loading="lazy"`, and real `alt` text.

**The stylesheet.** `styles.css` gets three changes, and you keep the four groups from Module 2:

- At the very top, the `box-sizing: border-box` rule from Concept 2, and in the site-wide basics, an `img` rule with `max-width: 100%` and `height: auto`.
- The header and nav rules become mobile first. On a phone, the site name sits above the nav, and the nav links can wrap onto a second line.
- Two new groups at the end: **Interests page** (the grid, the cards, the figure and the caption), and last of all **Wider screens**, one `@media (min-width: 700px)` block that turns the header into a row and makes `.featured` span two columns.

A visitor on a phone sees the site name above the four links, then the cards in one column. A visitor on a laptop sees the header as one row and the cards in a grid of three or four columns. Nothing scrolls sideways, and the text does not jump down while the photos load. All the words and photos are yours. The class names, file names, the `700px` breakpoint and the `minmax(220px, 1fr)` grid line must match.

The pictures in this packet use simple colored placeholder images with their own file name painted on them, so you can see which file the browser chose. You use your own photos.

![The Interests page at 390 pixels wide: the navy header with the site name above the four links Home, About, Interests and Contact, then the My interests heading, an opening paragraph, and the first cards stacked in one column, each with a heading, a photo, an italic caption and a sentence.](images/p03-interests-390.png)
*The Interests page on a phone. The header stacks, and the cards sit in one column, each photo as wide as its card. At pixel ratio 1 the browser chose the 400 files. Only the top of the page is shown. (real: rendered in Chromium at 390 px)*

![The same page at 1200 pixels wide: the header is one row with the site name on the left and the links on the right, and the cards form four columns. The Hiking card spans two columns and shows the 800 file; the others show 400 files.](images/p03-interests-1200.png)
*The same page on a laptop: four columns of 276 px each, measured by Chromium. The featured card spans two of them, so the browser chose a bigger file for it. (real: rendered in Chromium at 1200 px)*

The new card colors were checked: the dark text `#2b2d42` on the white cards is 13.5:1 (computed with the WCAG contrast formula). The card border uses the footer's beige `#e9dcc9`. It is decoration, so it has no contrast minimum.

## The steps

Type every line. Do not paste. The one exception is the header and footer, which you copy from `about.html`, as you did in Module 1.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`.
2. **Plan on paper.** Write down four to six interests. Circle your favorite: it becomes the featured card. For each one, write a short caption (what the photo shows) and one sentence about why you like it.
3. **Prepare the photos.** Pick one photo for each interest. In the VS Code Explorer, create a folder called `images` inside `my-site`. Save each photo three times into it, resized to 400, 800 and 1200 pixels wide, with the names from the brief: `interest-one-400.jpg`, `interest-one-800.jpg`, `interest-one-1200.jpg`, and so on. The Windows Photos app can resize; any image editor works. Then write down the real size of each 1200 file (right-click it in File Explorer, **Properties → Details**). A photo resized to 1200 wide from a 3 by 2 photo is 1200 × 800, but phone photos are often 4 by 3 (1200 × 900) or tall. Write down what Windows tells you, not what you expect.
4. **Predict.** Write down how many columns of cards you expect at 390, 800 and 1200 px, and which file (400, 800 or 1200) you expect the browser to choose for a normal card at 390 px. You will check both in steps 12 and 13.
5. **Add the box rules.** Open `styles.css`. At the very top, above the site-wide basics, type the rule from Concept 2 with its own comment:

   ```css
   /* Every box: width includes padding and border */
   *, *::before, *::after {
     box-sizing: border-box;
   }
   ```

   Then, in the site-wide basics group, after the `a` rule, add an `img` rule:

   ```css
   img {
     max-width: 100%;
     height: auto;
     display: block;
   }
   ```

   `max-width: 100%` keeps a photo from ever being wider than its box. `height: auto` keeps its shape when it shrinks. `display: block` removes the small gap that an inline image leaves under itself. Save, open `about.html` in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window), and press **F5** after each save. The About page should look the same as before: your picture is still 320 px wide.
6. **Make the header mobile first.** Look at your Home page in device mode first. Press **F12**, then **Ctrl+Shift+M**, and type 390 as the width. In the Module 2 header, the site name and the links share one row, so on a phone the name may break onto two lines and the links get squeezed. Now change the header and nav rules so the phone layout is the base:

   ```css
   /* Header and nav */
   header {
     background-color: #1d3557;
     color: white;
     padding: 16px 24px;
     display: flex;
     flex-direction: column;
     align-items: flex-start;
     gap: 8px;
   }

   nav {
     display: flex;
     flex-wrap: wrap;
     gap: 8px 16px;
   }
   ```

   The header lost `justify-content: space-between` and `align-items: center`; they come back in step 10, for wide screens only. `flex-direction: column` stacks the site name above the nav, and `align-items: flex-start` keeps both at the left edge. In the `nav` rule, `flex-wrap: wrap` lets the links move onto a second line if they run out of room. A `gap` with two values sets the space between rows first (8px), then between columns (16px). It replaces Module 2's `gap: 24px`, so four links fit in one row on a phone. In your `nav a` rule, add `padding: 4px 0;` so each link is a little taller and easier to tap. Save and press F5. At 390 px the name now sits above the links.
7. **Add the Interests link.** In `index.html`, add the new link between About and Contact:

   ```html
   <nav>
     <a href="index.html">Home</a>
     <a href="about.html">About</a>
     <a href="interests.html">Interests</a>
     <a href="index.html#contact">Contact</a>
   </nav>
   ```

   Make the same change in `about.html`. Then read the two headers line by line: they must still match.
8. **Make the Interests page.** In the Explorer, create `interests.html`. Copy all of `about.html` into it. Change the title to `Interests - Your Name`, and replace everything between `<main>` and `</main>` with this skeleton:

   ```html
   <main>
     <section>
       <h2>My interests</h2>
       <p class="lead">One sentence that introduces your interests.</p>
       <ul class="card-grid">
         <li class="card featured">
           <h3>Your favorite interest</h3>
           <figure>
             <img src="images/interest-one-800.jpg"
                  srcset="images/interest-one-400.jpg 400w,
                          images/interest-one-800.jpg 800w,
                          images/interest-one-1200.jpg 1200w"
                  sizes="(min-width: 700px) 66vw, 100vw"
                  width="1200" height="800"
                  loading="lazy"
                  alt="Describe what the photo shows">
             <figcaption>A short caption.</figcaption>
           </figure>
           <p>One sentence about why you like it.</p>
         </li>
         <!-- Continue alone: one li class="card" for each other interest, with the
              same parts. Use sizes="(min-width: 700px) 33vw, 100vw" for these. -->
       </ul>
     </section>
   </main>
   ```

   Set `height` to the real height of your `interest-one-1200.jpg` from step 3. The `800` in the skeleton is right only for a 1200 × 800 photo. Do the same for every card. The card headings are `<h3>`, because they sit inside a section whose heading is an `<h2>`.

   Read the `sizes` values to yourself. On a screen 700 px or wider, the featured card is about two thirds of the window and a normal card about one third; below 700 px every card is the full width. These are estimates for the browser, made before the CSS loads. They do not have to be exact. They only help it pick a file.
9. **Style the cards.** At the end of `styles.css`, add the Interests page group:

   ```css
   /* Interests page */
   .card-grid {
     display: grid;
     grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
     gap: 16px;
     list-style: none;
     padding: 0;
   }

   /* Continue alone: a .card rule with a white background, a 1px border in a
      light color, and 16px padding; a .card h3 rule with margin-top: 0;
      figure with margin: 0; and figcaption with a smaller, italic font. */
   ```

   `list-style: none` and `padding: 0` remove the bullets and the indent that every `<ul>` has by default. `figure { margin: 0; }` matters: browsers give every figure a margin, and without this rule your photos do not fill their cards.
10. **Add the wider-screens block last.** At the very end of `styles.css`, below everything else:

    ```css
    /* Wider screens: 700px and up */
    @media (min-width: 700px) {
      header {
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
      }

      /* Continue alone: a .featured rule that spans two grid columns. */
    }
    ```

    Inside the block you write only what is different on a wide screen. The header keeps its color, padding and `display: flex` from the base rule.
11. **Run.** Save everything. Open `interests.html` in the browser and press F5. Turn on device mode (F12, then Ctrl+Shift+M) and try 390, 800 and 1200. Then click **Home**, **About** and **Interests** at each width. The header should look the same on all three pages: stacked at 390, one row at 800 and 1200.
12. **Count the columns.** Press **F12** (or **Ctrl+Shift+J**) to open DevTools, then click the **Console** tab. Type this line exactly as shown. You will learn how it works in Module 9; for now, read the answer it gives.

    ```js
    getComputedStyle(document.querySelector('.card-grid')).gridTemplateColumns
    ```

    Compare with your prediction from step 4. On the sample page, Chromium measured one column (`342px`) at 390, three (`240px` each) at 800, and four (`276px` each) at 1200. Your numbers match if your `main` padding and grid gap match the sample; the column count is what matters.
13. **Check which photo loaded.** Still in the Console, type this line exactly as shown. You will learn how it works in Module 9; for now, read the answer it gives.

    ```js
    document.querySelector('.featured img').currentSrc
    ```

    The answer ends in the file name the browser chose. Device mode's Responsive setting counts 2 device pixels per CSS pixel, so it chooses bigger files than a plain laptop window. On the sample page, Chromium chose:

    | Viewport | Featured card, 1 pixel per CSS px | Featured card, 2 pixels per CSS px | Normal card, 1 pixel | Normal card, 2 pixels |
    |---|---|---|---|---|
    | 390 px | 400 | 800 | 400 | 800 |
    | 800 px | 800 | 1200 | 400 | 800 |
    | 1200 px | 800 | 1200 | 400 | 800 |

    Change the width, press **F5**, and ask again. Press F5 each time: a browser that already has a bigger file may keep showing it when you narrow the window. To ask about a normal card, change `.featured img` to `.card:nth-child(2) img`.
14. **Modify.** Change `minmax(220px, 1fr)` to `minmax(300px, 1fr)`. Save, press F5, and count the columns at 800 and 1200 again. Fewer, wider columns fit. Put back `220px`.
15. **Break it on purpose: the span outside the media query.** Cut the `.featured` rule out of the media query and paste it just above the `/* Wider screens */` comment. Save, and look at 390 px. Predict first, then look.

    The cards no longer sit in one wide column. Chromium measured `220px 129.172px` on the sample page: the featured card asked for two columns, so Grid made a second, narrow column, and every other card squeezed into it. The exact width of that second column depends on your card text; what matters is that there is a second, narrow column. This is the same thing you saw in the lesson's Concept 6. A span belongs in the wide-screen block. Move the rule back into the media query, save, and refresh.
16. **Break it on purpose: no `height: auto`.** In the `img` rule, delete `height: auto;`. Save and look at 390 px.

    ![The Interests page at 390 pixels with the first photo stretched into a tall, narrow rectangle, the painted file name squashed sideways.](images/p03-stretched.png)
    *Without `height: auto`, the photo is 308 px wide but 800 px tall, because the browser used the `height="800"` from the HTML. (real: rendered in Chromium at 390 px)*

    The photo is now 800 px tall and squashed. `max-width: 100%` shrank its width to fit the card, but nothing told the height to follow, so the browser used the `height` attribute as a fixed height. With `height: auto`, the browser still uses `width` and `height` to reserve the right *shape*, and it scales the height with the width. Put the line back.
17. **Debug: a photo that breaks at one width only.** In the featured card's `srcset`, change `images/interest-one-800.jpg 800w` to `images/intrest-one-800.jpg 800w` (drop the first `e`). Save. Turn device mode off, make the window narrow, and press F5: the photo may look fine. Now turn device mode on at 390 and press F5. The featured photo is broken, and the Console shows a red error for `intrest-one-800.jpg`. On the sample page at 390, Chromium loaded the 400 file at pixel ratio 1 and the missing 800 file at pixel ratio 2. A mistake in one `srcset` entry shows only on screens that choose that entry. That is why you test every width. Fix the name, save, and refresh.
18. **Test the site.** Tick each box.

    - [ ] At 390 px, all three pages show the site name above the four links, and nothing scrolls sideways
    - [ ] At 800 and 1200 px, the header is one row on all three pages
    - [ ] The Interests page shows 1, 3 and 4 columns at 390, 800 and 1200 px
    - [ ] The featured card spans two columns at 800 and 1200 px, and not at 390 px
    - [ ] Every photo loads at 390, 800 and 1200 px in device mode, with no red errors in the Console
    - [ ] Every photo has a caption and real `alt` text
    - [ ] All twelve nav clicks work: four links on three pages

19. **Put it online.** Go to Part 3, *Finishing work in Git*, and publish your Interests page with the save routine. Then run the test from step 18 again on the live site, and on your own phone if you have one.
