# Troubleshooting: five common problems

Each problem has the symptom you see, why it happens, and the fix. After each fix, save, press F5, and run the test from Project step 18 again.

### 1. The page is tiny and zoomed out on a phone

**Symptom.** In device mode at 390 px, or on your real phone, the Interests page looks like a shrunk copy of the laptop page: tiny text, the header in one row, and the cards in several columns.

**Why.** The page has no viewport meta tag, or it is misspelled. Without it, the phone lays the page out in a wider "virtual viewport" and shrinks it to fit (Concept 3). Your `min-width: 700px` query is then true on a phone. On the sample page without the tag, Chromium's phone emulation at 390 px reported `innerWidth` of about 980 and made four grid columns. The usual cause in this project is a new page made from scratch instead of copied from `about.html`.

**Fix.** Make sure the `<head>` of `interests.html` has this line, spelled exactly:

```html
<meta name="viewport" content="width=device-width, initial-scale=1">
```

Check the other two pages too. Save and press F5 in device mode.

### 2. The cards stay in one column at every width

**Symptom.** At 1200 px the cards are still one on top of the other, each as wide as the page.

**Why.** The grid is not on the parent of the cards. Grid lays out the *children* of the element that has `display: grid`. If `display: grid` is in the `.card` rule, each card becomes a grid of its own, and the `<ul>` around them is a plain list. On the sample page with that mistake, every card measured 1152 px wide at 1200 px. A class name that does not match (`class="cards-grid"` in the HTML and `.card-grid` in the CSS) has the same result, with no error message.

**Fix.** Put `display: grid` and the `grid-template-columns` line in the `.card-grid` rule, and check that the `<ul>` in your HTML has exactly `class="card-grid"`. In the Console, the line from Project step 12 should give a list of pixel widths, such as `276px 276px 276px 276px`. If it gives the word `none`, the `<ul>` is not a grid: that is what Chromium returns when `display: grid` and the columns line are both in the `.card` rule. If it gives back your `repeat(…)` text, the columns line stayed on `.card-grid` but `display: grid` did not.

### 3. A photo is stretched, or the text jumps while photos load

**Symptom.** A photo is squashed into a tall, narrow shape. Or, on a slow connection, the caption and sentence sit right under the heading and then jump down when the photo arrives.

**Why.** These are the two halves of one job. The `width` and `height` attributes let the browser reserve space of the right shape before the photo loads (Concept 7). If they are missing, the browser reserves nothing, and the text jumps. If they are there but the CSS has no `height: auto`, the browser shrinks the width to fit the card but keeps the `height` attribute as a fixed height, so the photo stretches (Project step 16). If `height` does not match the real photo, the shape is wrong too.

**Fix.** Every `<img>` needs `width` and `height` set to the real size of its 1200 file, as Windows shows it in **Properties → Details**. Your `img` rule needs both `max-width: 100%` and `height: auto`.

### 4. The browser picks a different file than you expected

**Symptom.** You expected `interest-two-400.jpg` at 390 px, but the Console line from Project step 13 says `interest-two-800.jpg`. Or a narrow window still shows a 1200 file.

**Why.** The browser chooses from `srcset` by device pixels, not CSS pixels. A screen with 2 device pixels per CSS pixel needs twice as many pixels to look sharp, so at 390 px it wants about 780 and picks the 800 file. Device mode's Responsive setting uses a pixel ratio of 2, and many phones use 2 or 3. That is the browser doing its job. Two other causes: a browser that already loaded a bigger file may keep using it when you make the window narrower, and a `w` number that does not match the file's real width misleads the browser.

**Fix.** Compare your answer with the 2-pixels-per-CSS-px column for your card type in the table in Project step 13. Press F5 after every change of width before you ask again. Check that each `w` number matches the real width of its file: `400w` for the 400 file, and so on.

### 5. The header stays stacked on a wide screen

**Symptom.** At 1200 px, the site name still sits above the links on every page, even though your media query says `flex-direction: row`.

**Why.** The `@media` block comes before the `header` rule in `styles.css`. A rule inside a media query has the same specificity as the same rule outside it, so the later one wins (Concept 4). On the sample page with the block moved above the header rules, Chromium measured `flex-direction: column` at 1200 px. The featured card still spanned two columns, because no later rule disagrees about `grid-column`. So a media query in the wrong place can break one thing and not another, which makes it easy to miss.

**Fix.** Move the whole `@media (min-width: 700px)` block to the very end of `styles.css`, below every rule it changes. Keep it last whenever you add new rules later.
