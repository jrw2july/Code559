# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **`"5" + 3` and `"5" - 3`.** `+` has two jobs. If either side is a string, it joins the two sides into one longer string, so `"5" + 3` is the string `"53"`. `-` has only one job, math, so JavaScript turns the text `"5"` into the number 5 and subtracts: `"5" - 3` is the number `2`. (Core concept 4)
2. **`if (answer == 0)`.** Change `==` to `===`, so the line reads `if (answer === 0)`. Loose equality converts types before it compares, so `answer == 0` is also true when `answer` is `false`, an empty string `""`, or the text `"0"`, and the code would treat those as the number 0. With `===`, only the number 0 makes the condition true, and a value of the wrong type shows up as `false` instead of hiding. (Core concept 5)
3. **What value does `total` hold?** `total` holds `"105"`, and its type is string. It starts as the string `"10"`, because of the quotes. On the second line, JavaScript reads the right side first: `"10" + 5`. One side is a string, so `+` joins, and `"105"` is stored back in `total`. `typeof total` gives `"string"`. (Core concepts 2 and 4)

## Common misconception

*"`=` means equals, like in math."* In JavaScript, one `=` means "becomes." It takes the value on the right and stores it in the name on the left. `visits = visits + 1` would be impossible in math, because no number equals itself plus one. In JavaScript it is an instruction: work out `visits + 1`, then store the answer in `visits`. To ask whether two values are the same, you use `===`, which changes nothing and answers `true` or `false`. Project step 8 shows what happens when the two are mixed up: `if (hour = 12)` does not ask a question, it tries to change `hour`, and with `const` that stops the script. (Core concepts 2 and 3; Project step 8)

## Exercise checks

- **Steps 1 and 2.** The results are in the lesson's table. The two worth checking twice: e, `7 + 7 + "7"`, is `"147"`, because JavaScript works left to right, adds `7 + 7` to get 14, then joins `"7"`; f, `"7" + 7 + 7`, is `"777"`, because the first `+` already has a string on one side, so every `+` after it joins. (Core concepts 1, 4 and 5)
- **Step 3.** `"7" * 7` gives `49`, a number. `*` only does math, so the text `"7"` becomes the number 7. (Core concept 4)
- **Step 4.** One possible answer: `const count = 7;` and `const countText = "7";`. Then `count == countText` gives `true`, and `count === countText` gives `false`. Any number and a string with the same digits work. (Core concepts 2 and 5)
- **Step 5.** `city = "Chicago"` gives `Uncaught TypeError: Assignment to constant variable.`, and typing `city` afterwards shows `"Fresno"`: the value did not change. (Core concept 2)
- **Step 6.** Nothing prints. Name: `TypeError`. Message: `Assignment to constant variable.` The error points at line 2, with the caret under the `=`, and line 3 never runs. With `let` on line 1, the script prints `Chicago`. Whether `let` is the right fix depends on the program: if the city should change, `let` is right; if it never should, the real fix is to delete line 2 and keep `const`. (Core concept 2)

## Self-assessment questions

1. **Why hour 8 worked and hour 15 did not.** JavaScript checks the conditions from top to bottom and stops at the first true one. For hour 8, `hour < 12` on the morning line was true, so Node ran the morning block and skipped the rest of the chain. It never reached line 23, where the broken `hour = 12` was. For hour 15, every condition above line 23 was false, so Node reached it, tried to put 12 into a `const`, and stopped with a `TypeError`. A bug in one branch shows only for an hour that reaches that branch. So you need at least one test hour for every branch, plus the hours on each side of every edge, as in the step 6 table. (Core concept 7; Project steps 6 and 8)
2. **A prediction you got wrong.** There is no single answer. A good answer quotes what you wrote down before the run, quotes what the terminal or the Console really showed, and names the idea you understand now, for example that `+` joins as soon as one side is a string, or that `"12" < 17` converts the string but `"12" === 12` does not.
3. **The friend's script.** Every hour from 0 to 16 prints `Day`, so hours 0 to 11 print the wrong plan: they should print `Morning`. The branch `hour < 17` comes before `hour < 12`, and every hour below 12 is also below 17, so the `Day` branch catches them first and the `Morning` branch can never run. The one change: move the `hour < 12` branch above the `hour < 17` branch. Then 8 prints `Morning`, and 12 and 16 print `Day`. (Core concept 7; Project step 7)

## Project checks

- **Step 3.** One line: `Plan for hour 8`. Comments print nothing.
- **Step 4.** With `hour` at 8: `Plan for hour 8`, `Good morning!` and your morning plan. With `hour` at 15: only `Plan for hour 15`. Both conditions are false, and with no `else` there is nothing left to run.
- **Step 5, continue alone.** The sample's whole `if`, comment block included. The file has 35 lines in all.

  ```js
  // The plan, checked from top to bottom (the first true condition wins):
  // below 0: sorry message
  // 0 to 11: morning
  // 12: noon
  // 13 to 16: afternoon
  // 17 to 23: evening
  // 24 and up: sorry message
  if (hour < 0) {
    console.log("Sorry, " + hour + " is not an hour of the day.");
    console.log("Please set hour to a number from 0 to 23.");
  } else if (hour < 12) {
    console.log("Good morning!");
    console.log("Breakfast, then one hour of coding practice.");
  } else if (hour === 12) {
    console.log("It is noon!");
    console.log("Lunch, then a short walk.");
  } else if (hour < 17) {
    console.log("Good afternoon!");
    console.log("Work on my site, then read one MDN page.");
  } else if (hour < 24) {
    console.log("Good evening!");
    console.log("Dinner, then save my work with Git.");
  } else {
    console.log("Sorry, " + hour + " is not an hour of the day.");
    console.log("Please set hour to a number from 0 to 23.");
  }
  ```

- **Step 6.** With the sample's ranges and words, every row passed. The branch for each hour:

  | Hour | Branch | Second line printed |
  |---|---|---|
  | 8, 0, 11 | morning | `Good morning!` |
  | 12 | noon | `It is noon!` |
  | 13, 16 | afternoon | `Good afternoon!` |
  | 17, 23 | evening | `Good evening!` |
  | -1, 24 | sorry | `Sorry, -1 is not an hour of the day.` and `Sorry, 24 is not an hour of the day.` |

- **Step 7.** With the noon branch moved below the afternoon branch, hour 12 prints `Good afternoon!`: `12 < 17` is the first true condition. With `hour <= 17`, only hour 17 changes, from `Good evening!` to `Good afternoon!`. In the test table, only row 17 fails; row 16 passes either way.
- **Step 8.** Hour 8 prints the morning plan with no error. Hour 15 prints `Plan for hour 15`, then `TypeError: Assignment to constant variable.`, pointing at line 23 in the sample with the caret under the `=`.
- **Step 9.** With `"12"`, the script prints the afternoon plan, and the `typeof` line prints `string`. A test with the number 12 could not catch this bug, because the bug is in the value, not in the conditions: with a number, every condition works. `typeof` showed the type, which the printed text hides.
- **Step 11.** If you followed the brief, every box is ticked. The most common miss is the last box: the file still holds the last hour you tested, or the `typeof` line. Check both before Part 3.
