# Troubleshooting: five common problems

Each problem has the symptom you see, why it happens, and the fix. Each one was made on purpose with the sample script and run with Node 22. The messages were captured on Linux, with the folder path changed to the course folder; on Windows, Node prints the same words with your own path. The `at` lines under each message are left out here. After each fix, save, and run `node plan-my-day.js` again from the `my-site` folder, for every hour in your test table.

### 1. TypeError: Assignment to constant variable

**Symptom.** Nothing from your plan prints, or only the first line does. Node shows one of your lines with a caret under it, then the message. With an extra line `hour = 15;` added under `const hour = 8;`, the sample printed:

```
C:\Users\you\Documents\code559\my-site\plan-my-day.js:7
hour = 15;
     ^

TypeError: Assignment to constant variable.
```

**Why.** `hour` was made with `const`, so it can hold only the value it started with. Any later line that uses one `=` to give it a new value stops the script. It is the error from Exercise steps 5 and 6.

**Fix.** Do not test another hour by adding a line. Change the number on the `const hour` line itself, save, and run. Do not change `const` to `let` to make the error go away: the script never needs to change `hour` while it runs, so the extra line is the mistake. Delete it.

### 2. A single = in a condition

**Symptom.** Some hours work and others stop with `TypeError: Assignment to constant variable.`, and the caret sits under an `=` inside the parentheses of an `if` or `else if`, as in Project step 8. Or, if you changed `const` to `let`, there is no error, but the wrong plan prints: with `let hour = 15;` and `} else if (hour = 12) {`, the sample printed `Plan for hour 15` and then `It is noon!`.

**Why.** One `=` assigns; it does not ask a question. With `const`, the assignment fails as soon as Node reaches that line. Hours caught by an earlier branch never reach it, so they seem fine. With `let`, the assignment works: `hour` becomes 12, and `if` treats the number 12 as true, so the noon branch runs for the wrong hour.

**Fix.** Use `===` in every equality check: `} else if (hour === 12) {`. Read each condition with "is it…?" in place of the operator. Keep `const`, which turns this mistake into an error you can see. Then run every hour in your test table, not only the one you started with.

### 3. The string "12" and the number 12

**Symptom.** No error, but the wrong branch. With `const hour = "12";`, the sample printed `Plan for hour 12`, then `Good afternoon!` instead of `It is noon!` (Project step 9). The first line looks normal, because printed text has no quotes.

**Why.** With quotes, `"12"` is a string. `===` never converts types, so `"12" === 12` is false and the noon branch is skipped. `<` does convert: it turns `"12"` into the number 12, so `"12" < 17` is true and the afternoon branch wins.

**Fix.** Remove the quotes: `const hour = 12;`. When the output looks right but the branch is wrong, add `console.log(typeof hour);` for one run. It prints `string` or `number`, which the output alone cannot show you. Delete the line when you are done.

### 4. One hour lands in the wrong part of the day

**Symptom.** Every hour in the middle of a range works, but an edge hour gets the wrong plan. With `hour <= 17` on the afternoon line, the sample printed `Good afternoon!` for hour 17, where the plan said evening. Hours 16 and 18 were both correct (Project step 7).

**Why.** `<` and `<=` differ at exactly one number: the edge itself. `17 < 17` is false, but `17 <= 17` is true. A test with hour 15 or 20 cannot show the difference.

**Fix.** Compare each condition with the comment block. "13 to 16: afternoon" means the next range starts at 17, so the condition is `hour < 17`. Then test the hour on each side of every edge: 11 and 12, 12 and 13, 16 and 17, 23 and 24, -1 and 0.

### 5. ReferenceError: a misspelled name

**Symptom.** Some hours work, and others print the first line and then stop. With `houre` typed in place of `hour` on the afternoon line, the sample worked for hour 8, but for hour 15 it printed `Plan for hour 15` and then:

```
C:\Users\you\Documents\code559\my-site\plan-my-day.js:26
} else if (houre < 17) {
       ^

ReferenceError: houre is not defined
```

Here the caret sits under `if`, not under the misspelled word. The message names the word. Capital letters count too: `Hour` in place of `hour` gave `ReferenceError: Hour is not defined`.

**Why.** JavaScript knows only the names you created. `hour` exists because of the `const` line; `houre` and `Hour` do not. As with the `=` mistake, the hours that never reach the bad line seem fine.

**Fix.** Go to the line number in the first line of the error, find the name from the message, and correct its spelling to match the `const` line exactly, all lowercase. Then run every hour in your test table again.
