# Finishing work in Git

Your script works and every row of your test table passes. Now you save it to GitHub with the same save routine as in Modules 1 to 5: `git status`, `git add .`, `git commit`, `git push`, then check the live site. What is new this time is when you commit: only after the tests pass, and with the file put back the way you want to keep it. You also see what Git does when you change the hour again to run one more test.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 to 5.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **Check the file before you save it (NEW: commit what you tested).** Git saves the file exactly as it is on the disk, with whatever hour you tested last. Open `plan-my-day.js` and check three things: the `typeof` test line from Project step 9 is gone, the hour is a number with no quotes, and it is set to the hour you want to keep, such as `8`. Then save and run `node plan-my-day.js` one last time. Commit only a version you have just run.
3. **See what changed.** Type:

   ```
   git status
   ```

   Under **Untracked files** you should see one line: `plan-my-day.js`. Git has never saved it before. `about-me.js` is not listed, because it was saved in Module 5 and has not changed since. Your `practice-06` folder never shows up here, because it is outside `my-site`.
4. **Stage the change.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. (A warning that mentions LF and CRLF is harmless.) Run `git status` again. Under **Changes to be committed** you should now see `new file:   plan-my-day.js`.
5. **Commit.** Type:

   ```
   git commit -m "Add a plan-my-day script with every branch tested"
   ```

   On the sample site, Git printed `1 file changed, 35 insertions(+)` on the second line and `create mode 100644 plan-my-day.js` on the third. The 35 is the number of lines in the sample file, comments and blank lines included. Your commit id and line count will differ. The message says the branches were tested, which is true only because you filled in the test table first.
6. **Push.** Type:

   ```
   git push
   ```

   The last line ends in `main -> main`.
7. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. Your new commit is on top, with your Module 5 commit (or your latest one) under it.
8. **Test again after the commit (NEW: Git sees a changed hour).** Change the hour to `15`, save, and run the script. Then type `git status`. This time it lists `modified:   plan-my-day.js` under **Changes not staged for commit**. Git compares the file on the disk with the saved version, and the number is different. Changing the hour to test is a real change to the file, even if you meant it only for one run. Put the hour back to the number you committed, save, and type `git status` again. On the sample, it said `nothing to commit, working tree clean` once more, because the file matched the saved version again. Make this check a habit: before you commit, put the test value back, or you save a test by accident.
9. **Check the live site.** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/` and press F5. Your pages look exactly as before, because no page loads `plan-my-day.js`. Then open `https://your-username.github.io/my-site/plan-my-day.js`. As with `about-me.js` in Module 5, the browser shows your code as text or offers to download it, and nothing runs. Anyone with the address can read it, so check once more that it holds nothing private.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows your new commit on top. The hour in the saved file is the one you meant to keep, your live pages look the same as before, and the live address of `plan-my-day.js` shows your code without running it.
