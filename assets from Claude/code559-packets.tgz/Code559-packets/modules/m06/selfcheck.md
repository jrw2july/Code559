# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 7. If a line is a 1 or a 2, reread that Core concept and redo its Exercise or Project step.

## Rubric

- I can name this module's five basic types, check any value with typeof, and explain why typeof null gives "object"
- I can store values with const and let, choose const first, and fix "Assignment to constant variable" in the right way
- I can read = as "becomes" and === as "is it…?", and spot a single = inside a condition
- I can predict the result of +, -, *, / and %, and explain why "5" + 3 is "53" but "5" - 3 is 2
- I can use >, <, >=, <=, === and !==, and explain why this course uses === and never ==
- I can store a comparison's true or false in a variable with a question-style name
- I can write an if / else if / else chain in the right order, and say which block runs for a given value
- I can test every branch on purpose, edge values included, with a table of expected and actual results
- I can find a wrong branch with no error message by checking the value's type with typeof

## Three questions to answer in writing

1. In Project step 8, the broken noon line made no error for hour 8 but stopped the script for hour 15. Explain why, and say what this tells you about how many hours you need to test.
2. Pick one row of your test table, or one prediction from the Exercise, where your first answer was wrong. What did you write down, what did the terminal or the Console show, and what do you understand now that you did not before?
3. A friend's script has these lines, in this order. For which hours does it print the wrong plan, and what one change fixes it?

   ```js
   if (hour < 0) {
     console.log("Sorry");
   } else if (hour < 17) {
     console.log("Day");
   } else if (hour < 12) {
     console.log("Morning");
   } else {
     console.log("Evening or sorry");
   }
   ```
