# Project: Plan my day

*Your hands, about 60 minutes (estimate).* In the Exercise you predicted values and types, and you caused a `TypeError` in the Console and in Node. Now you write a script that makes a decision. The script is `plan-my-day.js`. You set one number at the top, the hour of the day, and the script prints a different plan for the morning, for noon, for the afternoon and for the evening. When the hour makes no sense, like 25 or -1, it prints a polite message instead. Then you test every branch on purpose, one hour at a time, and write down what you expected next to what you got. You use only what Modules 5 and 6 taught: comments, `console.log()`, `const`, joining text with `+`, the comparison operators, and `if`, `else if` and `else`.

This project goes in `my-site`, next to `about-me.js` from Module 5. Any `my-site` that is a Git repository connected to GitHub works, because the script does not touch your pages.

## The brief

Read the whole brief twice before you type anything.

When you finish, `my-site` holds a new file, `plan-my-day.js`, at the top level, next to `index.html` and `about-me.js`. Not inside `practice-06`. No page links to it and no page runs it: like `about-me.js`, it runs in the terminal only.

**The hour.** The script uses the 24-hour clock, the one on train timetables and on many phones. The day runs from hour 0 (midnight) to hour 23 (11 PM). Hour 12 is noon, and hour 15 is 3 PM. The hour is stored once, near the top of the file, as a number in a `const`:

```js
const hour = 8;
```

To plan another hour, you change that number in the file, save, and run the script again. The program itself never changes `hour` while it runs, so `const` is the right choice.

**What it prints.** Run from the `my-site` folder, `node plan-my-day.js` printed exactly these lines for the sample student, with `hour` set to the number in the first line:

```
Plan for hour 8
Good morning!
Breakfast, then one hour of coding practice.
```

```
Plan for hour 12
It is noon!
Lunch, then a short walk.
```

```
Plan for hour 15
Good afternoon!
Work on my site, then read one MDN page.
```

```
Plan for hour 20
Good evening!
Dinner, then save my work with Git.
```

```
Plan for hour 25
Sorry, 25 is not an hour of the day.
Please set hour to a number from 0 to 23.
```

With `hour` set to `-1`, the last two lines were `Sorry, -1 is not an hour of the day.` and `Please set hour to a number from 0 to 23.`

Your script prints the same shape with your own plans:

- **The first line** is always `Plan for hour ` followed by the number. It prints for every hour, even one that makes no sense, because its statement sits above the `if`.
- **Six branches, in this order on the number line.** Below 0: the sorry message. 0 to 11: morning. Exactly 12: noon. 13 to 16: afternoon. 17 to 23: evening. 24 and up: the sorry message again. Exactly one branch runs for any hour.
- **Two lines per branch.** For the four parts of the day: a greeting, then a plan. For the sorry message: the line with the hour in it, then the line that says what to do.
- **Your own words and your own ranges.** You can start the evening at 18 instead of 17, or call hour 0 night instead of morning. If you change a range, change your comments and your test table to match.

**What is inside the file.**

- The first two lines are comments: the file name with one sentence about what it does, and how to run it.
- A comment above `const hour` says what the number means and how to test another hour.
- A comment block above the `if` lists every range in order. It is your plan, and anyone who reads the file can check the code against it.
- Only `const`, never `let` and never `var`. Comparisons use `===`, never `==`.

![A terminal in the my-site folder running node plan-my-day.js five times. The outputs are: Plan for hour 8, Good morning!, Breakfast, then one hour of coding practice. Plan for hour 12, It is noon!, Lunch, then a short walk. Plan for hour 15, Good afternoon!, Work on my site, then read one MDN page. Plan for hour 20, Good evening!, Dinner, then save my work with Git. Plan for hour 25, Sorry, 25 is not an hour of the day., Please set hour to a number from 0 to 23.](images/p06-plan-runs.png)
*The finished script for the sample student, run five times. The file was edited and saved between runs, with `hour` set to 8, 12, 15, 20 and 25. Each run printed the first line and then exactly one branch. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*

## The steps

Type every line. Do not paste. The one exception is the sorry message: once you have typed its two lines in the first branch, you may copy them for the last branch.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`.
2. **Plan on paper.** Draw a line and mark the numbers 0 to 23 on it. Mark where each part of your day starts: the sample's morning starts at 0, noon is 12, the afternoon starts at 13 and the evening at 17. Write -1 just left of the line and 24 just right of it: those are the hours that make no sense. Then write, for each part, the two lines your script will print. This page is your plan, and later it is your list of predictions.
3. **Plan with comments first.** In the VS Code Explorer, create `plan-my-day.js` at the top level of `my-site`, next to `index.html`. Type the lines below, with your own ranges in the comment block, then save with Ctrl+S:

   ```js
   // plan-my-day.js: prints a plan for the hour you set
   // Run it from the my-site folder with: node plan-my-day.js

   // The hour to plan for, on the 24-hour clock: 0 to 23.
   // To test another hour, change this number, save, and run again.
   const hour = 8;

   console.log("Plan for hour " + hour);

   // The plan, checked from top to bottom (the first true condition wins):
   // below 0: sorry message
   // 0 to 11: morning
   // 12: noon
   // 13 to 16: afternoon
   // 17 to 23: evening
   // 24 and up: sorry message
   ```

   The `+` joins the text `"Plan for hour "` and the number in `hour` into one string, as in Core concept 4. Mind the space before the closing quote: without it, the output reads `Plan for hour8`. **Predict** before you run: what will `node plan-my-day.js` print? Write it down. Then type `node plan-my-day.js` and press Enter. The sample printed one line, `Plan for hour 8`. The comment block printed nothing, because there is no code under it yet.
4. **The first two branches.** Under the comment block, type the start of the `if`:

   ```js
   if (hour < 0) {
     console.log("Sorry, " + hour + " is not an hour of the day.");
     console.log("Please set hour to a number from 0 to 23.");
   } else if (hour < 12) {
     console.log("Good morning!");
     console.log("Breakfast, then one hour of coding practice.");
   }
   // Continue alone: noon (exactly 12), afternoon (up to 16),
   // evening (up to 23), then a final else for 24 and up.
   ```

   Use your own morning plan in place of the sample's. Indent the lines inside each block two spaces, and put no semicolon after `if (...)` or between `}` and `else`. Save and run. With `hour` at 8, the sample printed `Plan for hour 8` and the two morning lines.

   Now a quick test before you go on. **Think this through:** with only these two branches, what prints for hour 15? Write down your answer. Change `8` to `15` on the `const hour` line, save, and run. The sample printed only `Plan for hour 15`. Neither condition was true, and there is no `else` yet to catch what is left over, so no block ran. Change the hour back to `8` and save.
5. **Continue alone: noon, afternoon, evening and the final `else`.** Each new branch starts on the line of the closing brace before it: `} else if (...) {`. Use this order, the same as your comment block:

   - Noon: the condition asks whether `hour` is exactly 12. Use `===`.
   - Afternoon: the condition asks whether `hour` is less than 17. Only hours from 13 to 16 get this far, because every smaller hour was caught by a branch above it.
   - Evening: the condition asks whether `hour` is less than 24.
   - Last, `} else {` with the same two sorry lines as the first branch, and the final `}` that closes the whole `if`.

   Delete the two "Continue alone" comment lines, because they described work that is now done. Save and run with `hour` at 8: the output should not change. If Node prints `SyntaxError: Unexpected token '}'` or `SyntaxError: Unexpected end of input`, and not even `Plan for hour` prints, count your braces: every `{` needs its own `}`. `SyntaxError: Unexpected token 'else'` means a semicolon sits between a `}` and the `else` after it, as the lesson warned, or a `}` is missing just before the `else`: count your braces.
6. **Test every branch.** Copy this table into your notebook. Fill in the **Expected** column for every row first, before you run anything: which branch, and its first plan line. Then, one row at a time, change the number on the `const hour` line, save, run, and write what really printed in the **Actual** column.

   | Hour | Why test it | Expected | Actual |
   |---|---|---|---|
   | 8 | Middle of the morning | | |
   | 0 | Smallest real hour: the lower edge | | |
   | 11 | Last morning hour | | |
   | 12 | Noon, the one exact match | | |
   | 13 | First afternoon hour | | |
   | 16 | Last afternoon hour | | |
   | 17 | First evening hour | | |
   | 23 | Largest real hour: the upper edge | | |
   | -1 | Just below the day | | |
   | 24 | Just above the day | | |

   Most rows sit on an edge, where one part of the day meets the next. As the lesson says, edges are where bugs live: a `<` that should have been `<=` is wrong only at the edge, and an hour in the middle never shows it. When an Actual does not match its Expected, find out which one is wrong, your prediction or your code, before you go on. With the sample's ranges, 0 and 11 printed `Good morning!`, 12 printed `It is noon!`, 13 and 16 printed `Good afternoon!`, 17 and 23 printed `Good evening!`, and -1 and 24 printed the sorry message with their own number in it. Set the hour back to `8` when the table is full.
7. **Modify.** Make two changes, one at a time. Predict each before you run it, then undo it.

   - **Move a branch.** Select the three lines of the noon branch, from `} else if (hour === 12) {` to the end of its second `console.log()` line, and cut them with Ctrl+X. Paste them on the line above `} else if (hour < 24) {`, so the noon branch now comes after the afternoon branch. Set the hour to `12` and save. **Think this through:** which condition is the first true one now? Write down what will print, then run. The sample printed `Good afternoon!`: `12 < 17` is true, so the afternoon branch won, and JavaScript never asked whether the hour was 12. In this order, the noon branch can never run. Move the three lines back, save, and run hour 12 again to check that `It is noon!` is back.
   - **Change `<` to `<=`.** On the afternoon line, change `hour < 17` to `hour <= 17`. Save. Which rows of your test table would show this change? Write them down, then run hours 16, 17 and 18. In the sample, 16 printed `Good afternoon!` as before, 17 printed `Good afternoon!` instead of `Good evening!`, and 18 printed `Good evening!`. Only the edge hour changed. Change `<=` back to `<`, save, and run 17 once more.
8. **Break it on purpose: `=` instead of `===`.** On the noon line, delete two of the three equals signs, so it reads `} else if (hour = 12) {`. Save. Set the hour to `8`. Before you run, write down one prediction: will Node show an error? Then run. Now set the hour to `15`, predict again, save, and run.

   ![A terminal in the my-site folder running node plan-my-day.js twice. The first run, for hour 8, prints Plan for hour 8, Good morning! and Breakfast, then one hour of coding practice. The second run prints Plan for hour 15, then the error: the path to plan-my-day.js with :23, the line } else if (hour = 12) {, a caret under the single equals sign, a blank line, TypeError: Assignment to constant variable., and stack lines starting with at, ending with Node.js v22.22.0.](images/p06-assign-error.png)
   *The same broken file, run for two hours. Hour 8 worked: the morning condition was true, so Node never reached line 23. Hour 15 reached line 23, where `hour = 12` tried to put a new value into a `const`. Your line number may differ. The `node:internal` lines and the last line depend on your Node version. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*

   Find the parts from Module 5's error-reading routine: the file and line, the line itself, the caret under the single `=`, the name `TypeError` and the message `Assignment to constant variable.` It is the same error as Exercise step 6. One `=` assigns, so the condition tried to change `hour`. This is the reason step 6 tests every branch: with only hour 8, this bug would have stayed hidden. Put the `===` back, save, and run hours 8, 12 and 15 to prove all three work.
9. **Debug: a wrong answer with no error.** Change the hour line to `const hour = "12";`, with quotes, and save. Before you run, write down what you expect. Then run. The sample printed:

   ```
   Plan for hour 12
   Good afternoon!
   Work on my site, then read one MDN page.
   ```

   No error, but the wrong branch. The first line looks the same as for the number 12, because printed text has no quotes. To see the type, add one line for testing, right under the `Plan for hour` line:

   ```js
   console.log(typeof hour);
   ```

   Save and run. The sample printed `string` as the second line. Now follow the chain with the value `"12"`, as JavaScript did. `"12" < 0` is false. `"12" < 12` is false: `<` works like `-` in Core concept 4, so it turned the text `"12"` into the number 12 before comparing. `"12" === 12` is false: `===` never converts, and a string is never the same as a number. `"12" < 17` is true, so the afternoon branch ran. Fix the bug where it starts: remove the quotes, so the line is `const hour = 12;`. Save, run, and check that `number` and `It is noon!` print. Then delete the `typeof` line, set the hour back to `8`, save, and run once more. In your notebook, write one sentence on why a test with the hour `12` (a number) could not catch this bug, and one on what `typeof` showed you that the output did not.
10. **Explain it.** With the script working, read the whole file to yourself, out loud, from top to bottom. For each condition, say which hours reach it and which of those make it true. Use "becomes" for `=` on the `const` line and "is it…?" for `===` and `<`. For the noon branch, say why it must come before the afternoon branch. If there is a line you cannot explain, reread the Core concept it comes from.
11. **Check the script.** Tick each box.

    - [ ] `plan-my-day.js` is in `my-site`, next to `index.html`, not in `practice-06`
    - [ ] The prompt ends in `my-site>`, and `node plan-my-day.js` prints `Plan for hour` and one branch
    - [ ] Every row of your test table has an Actual that matches its Expected
    - [ ] Exactly one branch prints for every hour you tried, and the sorry message prints for -1 and 24
    - [ ] The comment block lists every range in the same order as the code
    - [ ] The file uses `const` only, and `===` for the exact match, never `=` or `==` in a condition
    - [ ] No semicolon after `if (...)` and none between `}` and `else`
    - [ ] The `typeof` test line from step 9 is gone, and `hour` is a number with no quotes
    - [ ] The hour is set back to `8` (or the hour you like best), and nothing in the script is private

12. **Save it in Git.** Go to Part 3, *Finishing work in Git*, and save the script with the save routine.
