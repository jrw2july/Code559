# Finishing work in Git

The gallery and the FAQ work on your computer. Now you put them online with the same save routine as in Modules 1 to 8: `git status`, `git add .`, `git commit`, `git push`, then check the live site. Two things are new this time. Your pages now run scripts, so you read the Console before you commit and again on the live site. And a browser may keep an old copy of a script, so you learn to reload without it.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 to 8.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **Read the Console before you commit (NEW).** A page can look right and still have a broken script. Open each of your five pages in Edge or Chrome with the Console open (**F12**, then the **Console** tab), and press **F5** on each. There should be no red line on any of them. Then click **Next** at least once. The mistake from Project step 10 prints no red line at all, so only a click shows it. Commit only pages whose test from Project step 18 you have just run and seen pass.
3. **See what changed.** Type:

   ```
   git status
   ```

   Under **Changes not staged for commit** you should see `modified:` for `about.html`, `interests.html` and `styles.css`. Under **Untracked files** you should see `faq.js` and `gallery.js`. If `index.html`, `rate.html` or `contact.html` shows up, you changed a page this project does not touch. Open it and check what changed before you go on.
4. **Stage the changes.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. (A warning that mentions LF and CRLF is harmless.) Run `git status` again. Under **Changes to be committed** you should now see five lines: `modified:` for the two pages and `styles.css`, and `new file:` for the two scripts.
5. **Commit.** Type:

   ```
   git commit -m "Add an interests gallery and an FAQ about me"
   ```

   On the sample site, Git printed `5 files changed, 225 insertions(+)` on the second line, then `create mode 100644 faq.js` and `create mode 100644 gallery.js`. Your commit id and line count will differ. The two features share the button rule in `styles.css`, so they go into one commit.
6. **Push.** Type:

   ```
   git push
   ```

   The last line ends in `main -> main`.
7. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. Your new commit is on top, with your Module 8 commit (or your latest one) under it.
8. **Check the live pages with the Console open (NEW).** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/interests.html` with the Console open, and press F5. There should be no red line. Go through the gallery both ways, past both ends. Then open the live About page and open and close each question.
9. **Reload without the saved copy (NEW).** Browsers keep copies of files they have loaded, to open pages faster. So after a push, a browser may show the new page with an old script, or an old page for a while.

   If the live page acts like an older version, reload it while ignoring that saved copy: press **Ctrl+Shift+R**. Chrome's and Edge's keyboard shortcut pages both list it as reloading the current page "ignoring cached content" (Chrome Help, *Chrome keyboard shortcuts*; Microsoft Support, *Keyboard shortcuts in Microsoft Edge*).

   The steps in this packet were tested with files opened from disk, not on a live site, so watch for this the first time you check.
10. **Test the live pages with the keyboard.** Put the mouse aside. On the live Interests page, Tab to **Next** and press Enter and Space. On the live About page, Tab to each question and press Enter, then Space. Each press does what a click does, with a dark orange ring on the button that has focus.
11. **Test on a phone.** If you have a phone, open your live Interests page on it. Tap **Next** until the gallery wraps, then open each question on your About page. Nothing should scroll sideways.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows your new commit on top. On the live site, the Console shows no red line on the Interests or About page, the gallery wraps both ways, and each question opens and closes its own answer with a mouse and with the keyboard.
