# Troubleshooting: six common problems

Each problem has the symptom you see, why it happens, and the fix. Each one was made on purpose in the sample site and run in Chromium 141, with the files opened from disk as in the steps. The Console messages are quoted as Chromium printed them. The line numbers are the sample's: yours match only if your file has the same shape. After each fix, save, press **F5**, and run the test from Project step 18 again.

### 1. TypeError: Cannot read properties of null

**Symptom.** A red message in the Console, and some or all buttons do nothing:

```
Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')
    at faq.js:42:11
```

**Why.** The name before `.addEventListener` holds `null`, because `querySelector()` found no element (Core concept 3). The script stops at that line, so every listener below it is never connected. Listeners above it still work. The sample got this message four ways:

| What was wrong | Example | Where the sample stopped |
|---|---|---|
| A selector that does not match the id | `"#question2"` for `id="question-2"` | `faq.js:42:11`; question 1 still worked |
| The `#` missing from the selector | `"next-button"` | `gallery.js:67:12`; Previous still worked |
| `defer` missing from a script in the `<head>` | `<script src="gallery.js">` | `gallery.js:66:16`, the first listener |
| The wrong script on the page | `about.html` loading `gallery.js` | `gallery.js:66:16`, the first listener |

**Fix.** Go to the line the message names, and find the name just before `.addEventListener`. Then go to block 1, find where that name gets its value, and compare the selector with the id in the HTML, character by character. If the message points at your **first** listener line, every element may be `null`. Then check the `<script>` tag: is `defer` there, and is it the right file for this page?

### 2. Failed to load resource: net::ERR_FILE_NOT_FOUND

**Symptom.** A red line in the Console with a file name beside it. If the file is a script, no button on the page works, and there is no `TypeError`. If it is a photo, the gallery shows a small broken-image icon and the alt text for that photo only, and the red line appears when you reach it.

**Why.** The browser asked for a file that is not there. With `<script src="galery.js" defer>`, the sample printed this line with `galery.js` beside it, and none of the gallery code ran. With `images/intrest-two-800.jpg` in the `photos` array, the line appeared on the first click on Next, with `intrest-two-800.jpg` beside it. You also see this line before you create the file, as in Project steps 3 and 11.

**Fix.** Compare the name beside the red line with the real file name in the VS Code Explorer: spelling, dashes, the folder (`images/`) and the ending (`.js`, `.jpg`). Fix the name in the HTML or in the array, not the file, unless the file itself has the typo.

### 3. The caption and the counter change, but the photo does not

**Symptom.** Next changes the caption and says **Photo 2 of 5**, but the first photo stays on screen. No red line.

**Why.** The gallery's `<img>` has a `srcset`, often because it was copied from one of the cards. When an image has a `srcset`, the browser picks its file from that list. In the sample, Chromium showed `interest-one-400.jpg` from the list at load, and kept showing it after `photo.src` changed to the second photo's file. The list still named only the first photo's files.

**Fix.** Remove `srcset` and `sizes` from the gallery's `<img>`, as in the brief. The gallery shows the 800 px files, which suit both a phone and the 640 px gallery on a laptop.

### 4. TypeError: Cannot read properties of undefined (reading 'src')

**Symptom.** The gallery works until it should wrap. Then one click gives this red message, and nothing changes on the page:

```
Uncaught TypeError: Cannot read properties of undefined (reading 'src')
    at showPhoto (gallery.js:43:20)
```

The next click does wrap. So the gallery needs two clicks to go round instead of one.

**Why.** `current` reached an index with no photo, and `photos[current]` gave `undefined` (Module 8). Reading `.src` from `undefined` is not allowed. The sample got this two ways. With `if (current > photos.length)` in `showNext`, `current` became 5 on photo 5 and was not reset, because 5 is not greater than 5. With `current = photos.length;` in `showPrevious`, it became 5 when wrapping back from photo 1.

**Fix.** Wrap exactly at the edges. In `showNext`, reset when `current === photos.length`. In `showPrevious`, the last photo is at `photos.length - 1`, because counting starts at 0.

### 5. An answer that shows all the time, or an icon that is the wrong way round

**Symptom.** Every answer is visible when the page loads. A click changes the icon and the color, but the answer never hides. Or: the answer hides and shows, but a closed question is navy with a `+`, and an open one is white with a `−`.

**Why.** In the first case, a `display` rule on the answers overrides `hidden` (Core concept 8). With `display: block;` added to `.faq-answer`, the sample showed all three answers at load, and `hidden` became `true` and `false` with no change on screen. In the second case, the answer did not start with `hidden` in the HTML. `toggleAnswer` flips the answer and the class separately, so they stay out of step (Project step 15).

**Fix.** Take any `display` rule off `.faq-answer`. Check that every answer in `about.html` starts with `hidden`, and every button starts without `is-open` and with `aria-expanded="false"`.

### 6. TypeError: Assignment to constant variable.

**Symptom.** The page loads with photo 1 and the right counter, but Next and Previous do nothing. Each click adds a red message:

```
Uncaught TypeError: Assignment to constant variable.
    at showNext (gallery.js:50:10)
```

**Why.** `current` was made with `const current = 0;`. A `const` cannot get a new value (Module 6), and `current++` gives it one. The error comes on the first click, not at load: `showPhoto()` only **reads** `current`, so load works. On Previous, the message names `showPrevious` and the `current--` line instead.

**Fix.** Use `let current = 0;`. Everything else in block 1 stays a `const`: the elements and the array never change, only which photo is showing.
