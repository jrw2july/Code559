# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **One card instead of three.** `querySelector()` gives the **first** element that matches, and stops looking. The other two cards match too, but it never gets to them. To get all three, use `document.querySelectorAll(".card")`. It gives a NodeList with all three in page order, and you visit each one with a `for...of` loop. (Core concepts 3 and 4)
2. **`hidden` is `true`, but the paragraph still shows.** Look in the CSS first, for a `display` rule that reaches that paragraph. A rule such as `display: block` overrides the `hidden` state, so the paragraph shows whatever the property says. Take the `display` rule off that element, or make it reach other elements only. (Core concept 8; Problem 5 in Part 4)
3. **What causes this function to run?** `buildList()` has parentheses, so the line in block 3 calls it. It runs once, while the page loads, and builds the list. `toggleDetails` has no parentheses. The line only hands the function to the browser, and nothing runs at load. A click runs it, once per click, and so do Enter and Space on the focused button. So it runs zero times at load, then once each time the visitor clicks or presses a key on it. (Core concepts 6 and 10)

## Common misconception

*"My button does nothing, so my function must be wrong."* A function can be perfect and never run. Before you change a line inside it, check three things, in this order.

First, the Console: a red `TypeError` about `null` means a name in block 1 holds no element, and the script stopped before your listener was connected. Second, block 3: with parentheses, as in `showNext()`, the function ran once at load and the listener got `undefined`. There is no red line, but the page has already changed with no click. 

Third, the selector in block 1: it must match the id in the HTML, character by character. To test the function itself, call it by hand in the Console. If `showNext()` works there, the function is fine, and the problem is the connection. (Core concepts 3, 6 and 10; Project steps 10 and 16)

## Exercise checks

These are the results with the lesson's code and its three sample interests.

- **Step 4.** Three list items. The first and the third have `favorite: true`, so they are bold and end with a star. The second has neither. (Core concept 9)
- **Step 5.** Two `toggleDetails ran` lines after two clicks. After the first, the paragraph shows, the button says **Hide details** and turns dark blue. After the second, everything is back as it started. (Core concepts 6 to 8)
- **Step 6.** `3`. The loop logs three lines, such as `Interest one: a sentence about it`. The star is not in the text: an `<img>` has no text content. (Core concepts 4 and 5)
- **Step 7.** Four list items. The fourth has no star, because its `favorite` is `false`. The HTML did not change: the data decides how many items appear. (Core concept 9)
- **Step 8.** The first Tab from the address bar puts the ring on the button, the only thing on the page that can take focus. Enter shows the paragraph and Space hides it again, and each press adds one `toggleDetails ran` line. (Core concept 11)
- **Step 9.** The paragraph is already showing when the page loads, and the button says **Hide details** and is dark blue. Two clicks change nothing. The Console has exactly one `toggleDetails ran` line, from the load, and no red line. (Core concept 6)
- **Step 10.** The list stays empty and the button does nothing. The Console shows `Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')`, at `script.js:40:14`. Line 40 is `toggleButton.addEventListener(…)`. Without `defer`, the script ran when the browser reached it in the `<head>`, before the `<body>` existed. So `querySelector("#toggle-btn")` found nothing and gave `null`, and line 40 was the first line to use it. The script stopped there, so `buildList()` on line 41 never ran. (Core concept 2)

## Self-assessment questions

1. **Why one mistake gives an error and the other does not.** In step 10, `nextButton.addEventListener("click", showNext())` is valid code. `showNext()` runs at once and returns `undefined`, and the browser accepts `undefined` as "no listener" (Core concept 6). Nothing fails, so nothing is printed. The clue is the page itself: it opened on photo 2 with no click, Next did nothing, and Previous still worked.

   In step 16, `querySelector("#question2")` gave `null`, and `question2.addEventListener(…)` reads a property of `null`. `null` has no properties at all, so the browser stops the script with a `TypeError`. The clue is the message: the line number and the name before `.addEventListener` lead back to the selector in block 1. Question 1 still worked, because its listener was connected before the error.
2. **A prediction you got wrong.** There is no single answer. A good answer quotes what you wrote down before you saved, says what the page or the Console really showed, and names the idea you understand now. For example: that `"Photo " + current + 1` joins the 1 as text, or that `showPhoto()` at the end of block 3 replaces the photo in the HTML.
3. **The friend's block 3.** Right after F5, the first answer is already open, with a `−` and a navy button, before any click. `toggleAnswer(question1, answer1, icon1)` has parentheses, so it ran once at load, and the listener got its return value, `undefined`. Each click on the first question then does nothing, and there is no red line.

   Questions 2 and 3 work, because their lines hand over a reference. A listener can only receive a function, not a call with its arguments. So keep `toggleAnswer` with its three parameters, and connect the small function that makes the call: `question1.addEventListener("click", toggleFirst);`. (Core concept 6; Project steps 10 and 14)

## Project checks

- **Step 3.** The first photo, the caption and **Photo 1 of 5** show under the two buttons, and clicks do nothing. The Console has one red line, `Failed to load resource: net::ERR_FILE_NOT_FOUND`, for `gallery.js`.
- **Step 4, continue alone.** The hover rule:

  ```css
  .gallery-controls button:hover,
  .faq-question:hover {
    background-color: var(--soft);
  }
  ```

- **Step 5, continue alone.** The sample's other four photos are in the whole `gallery.js` at the end of this section. With them, `photos.length` gave `5`, `photos[1].alt` gave `A pot of soup on the stove`, and `current` gave `0`.
- **Step 6.** With `current = 2`, `showPhoto()` showed the third photo, its caption and **Photo 3 of 5**, and the Console printed `undefined`.
- **Step 7, continue alone.** The sample's `showPrevious`:

  ```js
  function showPrevious() {
    current--;
    if (current < 0) {
      current = photos.length - 1;
    }
    showPhoto();
  }
  ```

  `current = 4`, then `showNext()`, showed **Photo 1 of 5**; then `showPrevious()` showed **Photo 5 of 5**.
- **Step 8.** Five clicks on Next go from photo 1 back to photo 1. One click on Previous from photo 1 shows **Photo 5 of 5**. Enter and Space each move one photo.
- **Step 9.** Without the parentheses: **Photo 01 of 5** at load, then **Photo 11 of 5**. With `let current = 4;`: **Photo 5 of 5** at load, then **Photo 1 of 5** after one click on Next.
- **Step 10.** **Photo 2 of 5** at load, Next does nothing, Previous goes to **Photo 1 of 5**, and the Console has no red line.
- **Step 11, continue alone.** The sample's second and third questions, after the first `faq-item`:

  ```html
  <div class="faq-item">
    <h3>
      <button id="question-2" class="faq-question" type="button" aria-expanded="false">
        <span id="icon-2" class="faq-icon">+</span>
        What do you do when you get stuck?
      </button>
    </h3>
    <p id="answer-2" class="faq-answer" hidden>I read the error from the top, then check one thing at a time. A short walk helps too.</p>
  </div>
  <div class="faq-item">
    <h3>
      <button id="question-3" class="faq-question" type="button" aria-expanded="false">
        <span id="icon-3" class="faq-icon">+</span>
        What do you do when you are not coding?
      </button>
    </h3>
    <p id="answer-3" class="faq-answer" hidden>I ride with a bike club every week. Long routes are my favorite.</p>
  </div>
  ```

- **Step 12, continue alone.**

  ```css
  .faq-icon {
    min-width: 24px;
    font-size: 24px;
    line-height: 1;
    text-align: center;
  }

  .faq-answer {
    margin: 0 0 16px;
    padding: 0 12px;
  }
  ```

- **Steps 13 to 15, continue alone.** The six names for questions 2 and 3, the two small functions, and the two listeners are in the whole `faq.js` below. In step 13, `answer2.hidden` gave `true` and `icon3.textContent` gave `+`. In step 14, `toggleFirst()` opened the first answer, `question1.ariaExpanded` gave `true`, and a second call closed it. In step 15, with `hidden` deleted from `answer-1`, the icon and the color were the wrong way round after each click.
- **Step 16.** Question 1 works and questions 2 and 3 do not. The Console shows `Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')`, at `faq.js:42:11`.
- **Step 18.** If you followed the brief, every box is ticked. The most common misses: a leftover pair of parentheses from step 10, which only a click on Next shows, and an answer that lost its `hidden` in step 15.

Here are the sample's finished files. First, the whole `gallery.js`, 68 lines:

```js
// gallery.js: one photo at a time on the Interests page, with Previous and Next

// 1. Find elements
const photo = document.querySelector("#gallery-photo");
const caption = document.querySelector("#gallery-caption");
const counter = document.querySelector("#photo-count");
const previousButton = document.querySelector("#prev-button");
const nextButton = document.querySelector("#next-button");

const photos = [
  {
    src: "images/interest-one-800.jpg",
    alt: "A trail through the hills",
    caption: "Hiking: the view at the top is worth the climb."
  },
  {
    src: "images/interest-two-800.jpg",
    alt: "A pot of soup on the stove",
    caption: "Cooking: chemistry I get to eat."
  },
  {
    src: "images/interest-three-800.jpg",
    alt: "Tomato plants in a raised bed",
    caption: "Gardening: from seed to salad."
  },
  {
    src: "images/interest-four-800.jpg",
    alt: "A guitar on a stand",
    caption: "Music: a little guitar every evening."
  },
  {
    src: "images/interest-five-800.jpg",
    alt: "A stack of library books",
    caption: "Reading: the best way to spend a rainy afternoon."
  }
];

let current = 0;

// 2. Define behavior
function showPhoto() {
  const item = photos[current];
  photo.src = item.src;
  photo.alt = item.alt;
  caption.textContent = item.caption;
  counter.textContent = "Photo " + (current + 1) + " of " + photos.length;
}

function showNext() {
  current++;
  if (current === photos.length) {
    current = 0;
  }
  showPhoto();
}

function showPrevious() {
  current--;
  if (current < 0) {
    current = photos.length - 1;
  }
  showPhoto();
}

// 3. Connect events
previousButton.addEventListener("click", showPrevious);
nextButton.addEventListener("click", showNext);
showPhoto();
```

The whole `faq.js`, 43 lines:

```js
// faq.js: questions about me on the About page; each button opens and closes its own answer

// 1. Find elements
const question1 = document.querySelector("#question-1");
const answer1 = document.querySelector("#answer-1");
const icon1 = document.querySelector("#icon-1");

const question2 = document.querySelector("#question-2");
const answer2 = document.querySelector("#answer-2");
const icon2 = document.querySelector("#icon-2");

const question3 = document.querySelector("#question-3");
const answer3 = document.querySelector("#answer-3");
const icon3 = document.querySelector("#icon-3");

// 2. Define behavior
function toggleAnswer(question, answer, icon) {
  answer.hidden = !answer.hidden;
  if (answer.hidden) {
    icon.textContent = "+";
  } else {
    icon.textContent = "−";
  }
  question.classList.toggle("is-open");
  question.ariaExpanded = !answer.hidden;
}

function toggleFirst() {
  toggleAnswer(question1, answer1, icon1);
}

function toggleSecond() {
  toggleAnswer(question2, answer2, icon2);
}

function toggleThird() {
  toggleAnswer(question3, answer3, icon3);
}

// 3. Connect events
question1.addEventListener("click", toggleFirst);
question2.addEventListener("click", toggleSecond);
question3.addEventListener("click", toggleThird);
```

The two new groups at the end of `styles.css`, above the wider-screens block, are the rules from Project steps 4 and 12 with the two "Continue alone" parts above filled in. In `interests.html` and `about.html`, the only changes are the `<script>` line in the `<head>` and the new section before `</main>`.
