# Project: An interests gallery and an FAQ about you

*Your hands, about 2 hours (estimate).* In the Exercise you found elements, changed them, and connected a function to a click in `practice-09`. Now you do the same on your real site, twice. On the Interests page you add a **gallery** that shows one photo at a time, with **Previous** and **Next** buttons that wrap around. On the About page you add an **FAQ about you**: each question is a button that opens and closes its own answer, with a plus or minus icon. You use only what Modules 5 to 9 taught:

- `<script src="…" defer>` in the `<head>`, and `<button type="button">`
- `document.querySelector()` with an id, stored in a `const`
- `textContent`, and the `src` and `alt` properties of an image (as `star.src` and `star.alt` in Core concept 9)
- `addEventListener("click", …)` with a function reference, never a call
- `classList.toggle()`, and the `hidden` property flipped with `!`
- an array of objects read with an index and a dot, and `.length`
- `let` with `++`, and one new sign, `--`
- `if` with `===` and `<`, functions with parameters, and `+` with parentheses (Module 6)
- the three blocks from Core concept 10: find elements, define behavior, connect events

This project starts from the Module 4 packet's site: five pages (Home, About, Interests, Rate, Contact), one shared `styles.css` with the colors and focus rings, and the `images` folder with your interest photos. The scripts from Modules 5 to 8 can stay where they are. No page uses them, and this project does not either.

## The brief

Read the whole brief twice before you type anything.

When you finish, `my-site` holds two new files, `gallery.js` and `faq.js`, next to `index.html`. `interests.html`, `about.html` and `styles.css` have changed. No other file changes.

**One script per page.** `interests.html` loads `gallery.js`, and `about.html` loads `faq.js`, each with one `<script src="…" defer>` line in the `<head>`, under the stylesheet link. The other pages load no script. Why two files and not one `script.js`? Block 1 of a script looks for its elements. On a page that does not have them, `querySelector()` gives `null`, and the first `addEventListener()` stops the script with a `TypeError`. So each page gets a script that only looks for what that page has.

**The gallery.** A new `<section class="gallery">` on the Interests page, after the section with your cards. It holds:

- an `<h2>` that says **Photo gallery**
- a row (`<div class="gallery-controls">`) with a **Previous** button, a counter that says **Photo 1 of 5**, and a **Next** button. The ids are `prev-button`, `photo-count` and `next-button`.
- a `<figure>` with one `<img id="gallery-photo">` and a `<figcaption id="gallery-caption">`

The photos, their alt text and their captions live in `gallery.js`, as an array of objects. Use the 800 px files you made in Module 3, one object per interest. Each object has three properties: `src` (the file, such as `"images/interest-one-800.jpg"`), `alt` (what the photo shows) and `caption` (a short line about the interest).

**What the gallery does.** Next shows the next photo, with its alt text and caption, and the counter changes to match. Previous goes back. From the last photo, Next goes to the first. From the first photo, Previous goes to the last. The counter always says which photo it is and how many there are, such as **Photo 3 of 5**. The HTML shows the first photo, so the page still makes sense if the script does not run.

![The Photo gallery section at 390 pixels wide: the heading, then a row with a Previous button on the left, the bold text Photo 3 of 5 in the middle, and a Next button on the right with a dark orange focus ring. Under the row is a large placeholder photo labeled interest-three-800.jpg, and under it the italic caption Gardening: from seed to salad.](images/p09-gallery-390.png)
*The finished gallery on a phone, driven by keyboard only: Tab to Next, then Enter twice. The buttons sit above the photo, so they do not move when a photo of another shape loads. The photos here are placeholders with their file name painted on them, as in Module 3. (real: rendered in Chromium at 390 px)*

**The FAQ.** A new `<section class="faq">` on the About page, after your other sections. It holds an `<h2>` that says **Questions people ask me**, then three questions about you. Each question is a `<div class="faq-item">` with two parts:

- An `<h3>` with a `<button class="faq-question" type="button" aria-expanded="false">` inside. The button holds a `<span class="faq-icon">` with a `+`, then the question.
- A `<p class="faq-answer" hidden>` with your answer.

The ids are numbered: `question-1`, `icon-1` and `answer-1` for the first question, then `-2` and `-3`. The heading around each button lets screen-reader users jump from question to question, as they jump between headings.

**What the FAQ does.** A click on a question shows its answer, changes its `+` to a minus sign, `−`, and turns the button navy with white text. It also tells screen readers that the question is now open. A second click hides the answer and puts it all back. Each question opens and closes only its own answer, and any number can be open at once. With a keyboard, Tab reaches each question, and Enter or Space does exactly what a click does.

![The Questions people ask me section at 390 pixels wide: three full-width question buttons with a navy border. The first and third are white with a plus sign. The second, What do you do when you get stuck?, is navy with white text, a minus sign and a dark orange focus ring, and its answer shows below it.](images/p09-faq-390.png)
*The FAQ with the second question opened by keyboard: Tab to it, then Enter. Only its own answer is showing. (real: rendered in Chromium at 390 px)*

**The colors.** Use the custom properties already in your `styles.css`. Every new button has `--ink` text (`#1d3557`) on `--card` (`#ffffff`), 12.4:1. On hover, the background is `--soft` (`#e6f2f0`), 10.8:1. An open question is white on `--ink`, 12.4:1. Every button keeps the dark orange focus ring from Module 4, which is 4.7:1 on your cream page background. These values were checked with the WCAG contrast formula. Nothing scrolls sideways at 390 px.

The ids, classes, file names and button words must match the brief. The photos, captions, questions and answers are yours. Everything on the About page is public, so answer as you would to a stranger: no full name, school or street.

## The steps

Type every line. Do not paste. You may copy one finished HTML block to make the next one, once you have typed the first yourself.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`.
2. **Plan on paper.** Make two lists. For the gallery: each photo's file name, its alt text and a short caption. For the FAQ: three questions people ask you, and a one- or two-sentence answer to each. Then, for each feature, write the three block headings from Core concept 10 and, under each, what goes there: the elements to find, the functions to define, and the events to connect. Do not write any code yet.
3. **The gallery HTML.** Open `interests.html`. In the `<head>`, under the stylesheet link, add:

   ```html
   <script src="gallery.js" defer></script>
   ```

   Then, after the closing `</section>` of your cards and before `</main>`, add the new section. Use your first photo's file, alt text and caption:

   ```html
   <section class="gallery">
     <h2>Photo gallery</h2>
     <div class="gallery-controls">
       <button id="prev-button" type="button">Previous</button>
       <p id="photo-count">Photo 1 of 5</p>
       <button id="next-button" type="button">Next</button>
     </div>
     <figure>
       <img id="gallery-photo" src="images/interest-one-800.jpg"
            width="1200" height="800" alt="A trail through the hills">
       <figcaption id="gallery-caption">Hiking: the view at the top is worth the climb.</figcaption>
     </figure>
   </section>
   ```

   Set `width` and `height` to the real size of your 1200 file, as in Module 3. The image has no `srcset` on purpose: Problem 3 in Part 4, *Troubleshooting*, shows what `srcset` does to a gallery.

   **Predict** before you run: `gallery.js` does not exist yet. What will the page show, and what will the Console say? Save. Open `interests.html` in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window). After each save, press **F5** to reload. Press **F12** (or **Ctrl+Shift+J**) to open DevTools, then click the **Console** tab. The sample page showed the first photo under the two buttons, and the buttons did nothing. The Console had one red line: `Failed to load resource: net::ERR_FILE_NOT_FOUND`, with `gallery.js` beside it. The HTML works alone. The behavior is missing.
4. **The gallery CSS.** Open `styles.css`. Above the `/* Wider screens: 700px and up */` comment, add a new group:

   ```css
   /* Interests page: gallery */
   .gallery {
     max-width: 640px;
   }

   .gallery-controls {
     display: flex;
     justify-content: space-between;
     align-items: center;
     gap: 8px;
     margin-bottom: 12px;
   }

   .gallery-controls p {
     margin: 0;
     font-weight: 700;
   }

   .gallery-controls button,
   .faq-question {
     padding: 8px 16px;
     font: inherit;
     color: var(--ink);
     background-color: var(--card);
     border: 2px solid var(--ink);
     border-radius: 4px;
     cursor: pointer;
   }

   /* Continue alone: one rule for .gallery-controls button:hover
      and .faq-question:hover that sets background-color to var(--soft). */
   ```

   The FAQ buttons share this look, so their class is in the same rule now. Save and press F5. The two buttons are white with a navy border, and the counter sits between them. Press Tab until Previous has a dark orange ring. That ring comes from your Module 4 rule for `button:focus-visible`, so you did not write it again.
5. **`gallery.js`, block 1: find elements.** In the Explorer, create `gallery.js` next to `interests.html`. Type the first line and the first block:

   ```js
   // gallery.js: one photo at a time on the Interests page, with Previous and Next

   // 1. Find elements
   const photo = document.querySelector("#gallery-photo");
   const caption = document.querySelector("#gallery-caption");
   const counter = document.querySelector("#photo-count");
   const previousButton = document.querySelector("#prev-button");
   const nextButton = document.querySelector("#next-button");

   const photos = [
     {
       src: "images/interest-one-800.jpg",
       alt: "A trail through the hills",
       caption: "Hiking: the view at the top is worth the climb."
     },
     // Continue alone: one object for each of your other photos,
     // with the same three properties in the same order.
   ];

   let current = 0;
   ```

   Block 1 holds the five elements, the data, and one more thing: `current`, the index of the photo on screen. It starts at 0, the first photo. It is a `let`, because every click changes it. Add your other photos, then delete the two "Continue alone" lines. Save and press F5. The red line about `gallery.js` is gone, and nothing else changed: block 1 only finds and stores.

   Now test block 1 in the Console. Type `photos.length`, then `photos[1].alt`, then `current`. The sample gave `5`, the text `A pot of soup on the stove`, and `0`. Then type `photo` and press Enter. The Console showed the `<img>` element itself: `photo` holds a reference to the real element (Core concept 3).
6. **Block 2: `showPhoto`.** Under block 1, leave one blank line and type:

   ```js
   // 2. Define behavior
   function showPhoto() {
     const item = photos[current];
     photo.src = item.src;
     photo.alt = item.alt;
     caption.textContent = item.caption;
     counter.textContent = "Photo " + (current + 1) + " of " + photos.length;
   }
   ```

   Read it in two parts. First, `item` is the object at position `current`. Then four lines copy its facts onto the page: the file and the alt text onto the image, and the caption and the counter as text. The counter adds 1 because people count from 1 and arrays count from 0. The parentheses make JavaScript add first and join after, as `"Total: " + (2 + 3)` did in Module 6.

   Nothing runs yet: a function only says what to do. Test it by hand. Save, press F5, and type `current = 2` in the Console, then `showPhoto()`. The sample showed your third photo, its caption, and **Photo 3 of 5**. The Console printed `undefined` under `showPhoto()`, because the function returns nothing (Module 7).
7. **`showNext` and `showPrevious`: wrap around.** Under `showPhoto`, leave one blank line and type:

   ```js
   function showNext() {
     current++;
     if (current === photos.length) {
       current = 0;
     }
     showPhoto();
   }
   ```

   `current++` moves to the next index. With 5 photos the last index is 4, so after photo 5 `current` becomes 5, and there is no photo 5 in the array. That is the moment to wrap: the `if` sends `current` back to 0. Then `showPhoto()` puts the new photo on the page. Calling one of your own functions from inside another works like the summary in Module 8, which used your functions together.

   Now write `showPrevious` alone, under `showNext`. It has the same shape, the other way round. `current--` is the new sign: the opposite of `++`, it takes 1 away. When `current` drops below 0, it wraps to the last index, `photos.length - 1` (Module 8). Then it calls `showPhoto()`.

   ```js
   function showPrevious() {
     // Continue alone: subtract 1 from current; if it is now below 0,
     // set it to the last index; then show the photo.
   }
   ```

   Write the three lines, then delete the comment lines, so your line numbers match the sample's. Save, press F5, and test both by hand in the Console: `current = 4`, then `showNext()`, then `showPrevious()`. The sample showed **Photo 1 of 5**, then **Photo 5 of 5**.
8. **Block 3: connect events.** Under the functions, leave one blank line and type:

   ```js
   // 3. Connect events
   previousButton.addEventListener("click", showPrevious);
   nextButton.addEventListener("click", showNext);
   showPhoto();
   ```

   **Think this through:** what causes each function to run? `showPrevious` and `showNext` run on a click, as many times as there are clicks. `showPhoto()` has parentheses, so it runs once, now, as the page loads, like `buildList()` in the Exercise. It makes the counter match your array. If you have four photos, the HTML still says **of 5**, and this one call corrects it.

   Save and press F5. Test with the mouse: click **Next** until you are back at **Photo 1**, counting the clicks. Then click **Previous** once from photo 1. The sample needed five clicks to get round, and Previous went from **Photo 1 of 5** to **Photo 5 of 5**. Then test with the keyboard: press F5, put the mouse aside, and press Tab until Next has the ring. Press **Enter**, then **Space**. Each press moves one photo, the same as a click. You wrote no code for keys: a real `<button>` gives you that (Core concept 11).
9. **Modify.** Make two changes, one at a time. Predict each before you save, then undo it.

   - **No parentheses.** In `showPhoto`, change the counter line to `"Photo " + current + 1 + " of " + photos.length`. What will the counter say at load, and after one click on Next? Write it down, then save and press F5. The sample said **Photo 01 of 5**, then **Photo 11 of 5**. Without the parentheses, JavaScript works from left to right: `"Photo " + current` is already text, so the `1` is joined on as a character, not added. Put the parentheses back.
   - **Another starting photo.** Change `let current = 0;` to `let current = 4;`. The HTML still holds photo 1. Which photo will the page show after F5? Save and look. The sample showed **Photo 5 of 5** with the fifth photo: block 3's `showPhoto()` ran at load and replaced what the HTML had. One click on Next went to **Photo 1 of 5**. Change it back to `0`.
10. **Break it on purpose.** In block 3, add parentheses after `showNext`:

    ```js
    nextButton.addEventListener("click", showNext());
    ```

    **Predict:** which photo will the page show after F5, and what will a click on Next do? Write it down. Then save, press F5, click **Next** twice and **Previous** once.

    The sample opened on **Photo 2 of 5**, with no click at all. Next did nothing, and Previous went to **Photo 1 of 5**. The Console had no red line. Here is why. With the parentheses, `showNext()` ran once at load, which moved `current` to 1. Then `showPhoto()` at the end showed photo 2. The listener got what `showNext()` returned, `undefined`, so a click on Next runs nothing (Core concept 6). Previous still works, because its line has no parentheses. Remove them, save, and test Next again.
11. **The FAQ HTML.** Open `about.html`. In the `<head>`, under the stylesheet link, add:

    ```html
    <script src="faq.js" defer></script>
    ```

    Then, after your last section and before `</main>`, add the new section with your first question and answer:

    ```html
    <section class="faq">
      <h2>Questions people ask me</h2>
      <div class="faq-item">
        <h3>
          <button id="question-1" class="faq-question" type="button" aria-expanded="false">
            <span id="icon-1" class="faq-icon">+</span>
            How did you start coding?
          </button>
        </h3>
        <p id="answer-1" class="faq-answer" hidden>In 2025, with one hour a day, most days. My first page went live this year.</p>
      </div>
      <!-- Continue alone: two more faq-item blocks, the same shape,
           with the ids question-2, icon-2, answer-2 and question-3,
           icon-3, answer-3. -->
    </section>
    ```

    Add your other two questions, then delete the comment lines. Every answer starts with `hidden`: the page opens with all three closed. Save, open `about.html` in Edge or Chrome, and press F5. The three questions show as plain buttons, no answer shows, and the Console has the same red `ERR_FILE_NOT_FOUND` line as in step 3, this time for `faq.js`.
12. **The FAQ CSS.** In `styles.css`, under the gallery group and above the wider-screens comment, add:

    ```css
    /* About page: FAQ */
    .faq {
      max-width: 640px;
    }

    .faq h3 {
      margin: 0 0 8px;
    }

    .faq-question {
      width: 100%;
      display: flex;
      align-items: center;
      gap: 12px;
      text-align: left;
      font-weight: 700;
    }

    .faq-question.is-open {
      color: white;
      background-color: var(--ink);
    }

    /* Continue alone: .faq-icon has a min-width of 24px, a font-size
       of 24px, a line-height of 1, and centered text. .faq-answer has
       margin 0 0 16px and padding 0 12px. */
    ```

    The border, padding and colors come from the shared rule in step 4. `.faq-question.is-open` has no space between the two classes: it means "a button that has both classes." JavaScript adds `is-open`, and this rule says what it looks like (Core concept 7). The `min-width` keeps every icon the same width, so the questions line up even when one wraps onto two lines. Do not give `.faq-answer` a `display` rule: it would override `hidden` (Core concept 8, and Problem 5 in Part 4).
13. **`faq.js`, block 1.** Create `faq.js` next to `about.html`:

    ```js
    // faq.js: questions about me on the About page; each button opens and closes its own answer

    // 1. Find elements
    const question1 = document.querySelector("#question-1");
    const answer1 = document.querySelector("#answer-1");
    const icon1 = document.querySelector("#icon-1");

    // Continue alone: the same three lines for question 2,
    // then for question 3, each group after a blank line.
    ```

    Nine names in all, three for each question. Type the other six, then delete the comment lines. Save, press F5 and test in the Console: `answer2.hidden` gave `true` in the sample, and `icon3.textContent` gave the text `+`. If one of them gives `null` or an error, compare its selector with the id in `about.html`, character by character.
14. **Block 2: one function for any question.** Under block 1, leave one blank line and type:

    ```js
    // 2. Define behavior
    function toggleAnswer(question, answer, icon) {
      answer.hidden = !answer.hidden;
      if (answer.hidden) {
        icon.textContent = "+";
      } else {
        icon.textContent = "−";
      }
      question.classList.toggle("is-open");
      question.ariaExpanded = !answer.hidden;
    }
    ```

    This is `toggleDetails` from the Exercise with three parameters. It does not know which question it works on. It works on whichever three elements you hand it. So one function serves all three questions.

    The `−` is a real minus sign, not the hyphen key: a hyphen looks shorter than the `+`. It is the one character you may copy from this page and paste. The last line tells screen readers whether the answer is open. `ariaExpanded` is a property, like `hidden`, and it sets the button's `aria-expanded` attribute to `true` or `false`. Chromium then reports the button as expanded or collapsed. The HTML sets the starting value, `aria-expanded="false"`, to match the hidden answer.

    But a listener cannot hand it anything. `addEventListener` takes a function **reference**, and a reference has no parentheses, so it has no place for arguments. Writing `toggleAnswer(question1, answer1, icon1)` in block 3 would run it once at load, the mistake from step 10. The fix is a small function for each question, with no parameters, whose only job is to make the call:

    ```js
    function toggleFirst() {
      toggleAnswer(question1, answer1, icon1);
    }

    // Continue alone: toggleSecond and toggleThird, the same shape.
    ```

    Write the two functions, then delete the comment line. Save, press F5 and test by hand: type `toggleFirst()` in the Console. The first answer opened, its icon became `−`, and the button turned navy. Type `question1.ariaExpanded`: the sample gave the text `true`. Type `toggleFirst()` again: all closed.
15. **Block 3, and the full test.** Under the functions, type:

    ```js
    // 3. Connect events
    question1.addEventListener("click", toggleFirst);
    // Continue alone: connect question2 to toggleSecond
    // and question3 to toggleThird.
    ```

    Connect the other two, then delete the comment lines. Save and press F5. With the mouse: click each question once, then each again. Each one opens and closes only its own answer. Open two at once: both stay open. With the keyboard: press F5, put the mouse aside, and press Tab. In the sample, Tab went through the five nav links, then the three questions in order. On each question, press **Enter**, then **Space**. Each press opens or closes it, with the same icon and color change as a click.

    **Modify.** Delete the word `hidden` from `answer-1` in the HTML. Predict what the page shows at load, then after one click, then after a second click. In the sample, the answer showed at load next to a `+` on a white button. The first click hid it and turned the button navy. The second click showed it with a `−`. The icon and the color were the wrong way round, because `toggleAnswer` flips the class and the answer separately, and they started out of step. The HTML and the CSS must start in the same state. Put `hidden` back.
16. **Debug: two questions that do nothing.** Here is a typing mistake that is easy to make. In block 1 of `faq.js`, change `"#question-2"` to `"#question2"` (drop the dash). Save and press F5. Click all three questions.

    Before you read on, write down what you see, and which block you would check first. Then look at the Console.

    In the sample, question 1 worked, and questions 2 and 3 did nothing. The Console showed one red message:

    ```
    Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')
        at faq.js:42:11
    ```

    Follow the clues in order. Line 42 is `question2.addEventListener(…)`, in block 3. The message says the thing before `.addEventListener` is `null`, so `question2` holds `null`. A name gets its value in block 1, and there, `querySelector("#question2")` found no element with that id: the HTML says `question-2`.

    The script stopped at line 42, so line 43 never connected question 3 either. Line 41 had already run, which is why question 1 still worked. Your line numbers match the sample's if your `faq.js` has the same shape. Put the dash back, save, and test all three.
17. **Explain it.** Read `gallery.js` to yourself, out loud, from top to bottom. For each name in block 1, say what it holds. For each function, say what causes it to run, and how many times. Then do the same for `faq.js`, and say why `toggleFirst` exists at all. If there is a line you cannot explain, reread the Core concept it comes from.
18. **Test the site.** Tick each box in a full-width window and at 390 px in device mode (F12, then Ctrl+Shift+M). Keep the Console open the whole time.

    - [ ] No red line in the Console on any of the five pages
    - [ ] Next goes through every photo and back to photo 1; Previous from photo 1 goes to the last photo
    - [ ] The photo, its alt text, the caption and the counter always match
    - [ ] Each question opens and closes only its own answer, and the icon, the color and `aria-expanded` always match the answer
    - [ ] Tab reaches Previous, Next and every question, each with a dark orange ring; Enter and Space work on each one
    - [ ] Nothing scrolls sideways at 390 px on the Interests page or the About page
    - [ ] The parentheses from step 10 and the typo from step 16 are gone, and every answer has `hidden` again
    - [ ] Nothing in your questions, answers or captions is private

19. **Save it in Git.** Go to Part 3, *Finishing work in Git*, and publish both features with the save routine.
