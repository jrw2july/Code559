# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 10. If a line is a 1 or a 2, reread that Core concept and redo its Exercise or Project step.

## Rubric

- I can name what HTML, CSS and JavaScript each do on a page, and put a new line in the right file
- I can load a script with defer, and explain the null error when a script runs before the body exists
- I can find an element with querySelector(), store it in a const, and fix a selector that gives null
- I can loop through a querySelectorAll() collection with for...of, and say how it differs from one match
- I can change text with textContent, and explain why text never goes in with innerHTML in this course
- I can connect a function with addEventListener(), and spot the parentheses that run it once at load
- I can show and hide with hidden and switch a class with classList, and keep them in step
- I can build page items from an array of objects with createElement() and append()
- I can organize a script as find, define, connect, and test every button with a mouse and with Tab, Enter and Space

## Three questions to answer in writing

1. In Project step 10, `showNext()` with parentheses made the gallery open on photo 2, with no red line. In Project step 16, one wrong selector gave a red `TypeError`, and two questions stopped working. Explain why one mistake gives an error and the other does not, and what the clue was in each case.
2. Pick one prediction from the Exercise or the project where your first answer was wrong. What did you write down, what did the page or the Console show, and what do you understand now that you did not before?
3. A friend wants one function for all three FAQ questions, so they wrote block 3 like this. What does the About page show right after F5? What happens on each click on the first question? And what would you tell them to change?

   ```js
   // 3. Connect events
   question1.addEventListener("click", toggleAnswer(question1, answer1, icon1));
   question2.addEventListener("click", toggleSecond);
   question3.addEventListener("click", toggleThird);
   ```
