# Finishing work in Git

In Modules 1 to 11 you saved each project once, at the end. Here every row is saved on its own: committed, pushed and checked on the live site before the next row starts. That is steps 7 to 9 of the nine, and they are what turn "it works on my computer" into "it works." You use the Module 12 commands, in a new repository of its own, so the planner gets its own page on GitHub and its own live address.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 and 12.

A note on the pictures and numbers. They come from a real run of Git 2.43.0 on Linux, with the sample's files, one commit per row. The pushes went to a local repository standing in for GitHub, so `gh repo create`, the Pages settings and the live checks could not be run for this packet; their steps follow Module 1 and GitHub Docs. Your commit ids, byte sizes and line counts will differ.

1. **Make the folder (NEW: a second project, outside `my-site`).** In File Explorer, open your course folder, `C:\Users\you\Documents\code559`, and create a folder called `pocket-planner`, next to `my-site`. Never put one repository inside another. In VS Code, use **File → Open Folder…** to open `pocket-planner`, then **Terminal → New Terminal**. Check that the prompt ends in `pocket-planner>`.
2. **Start the repository.** Type:

   ```
   git init
   ```

   Git prints `Initialized empty Git repository in` and the path of your folder, ending in `pocket-planner/.git/`. Then type `git status`. It should say `On branch main` and `No commits yet`. If it says `master`, you skipped the `init.defaultBranch` setting from Module 12's Before you start: type `git branch -m main` now.
3. **Commit a `.gitignore` first.** Create `.gitignore` with the three lines from Module 12 (`.vscode/`, `Thumbs.db`, `*.log`), each followed by Enter. Then:

   ```
   git status --short
   git add .
   git commit -m "Add .gitignore"
   ```

   The status line is `?? .gitignore`. The commit's first line starts with `[main (root-commit)`, because it is the first commit in this repository, and the second says `1 file changed, 3 insertions(+)`. Now go back to Project step 2.
4. **Ship row 1: the first push (NEW: a second repository on GitHub).** When row 1 passes its tests on your computer, read your changes and commit:

   ```
   git status --short
   git add .
   git diff --staged --stat
   git commit -m "Add task form for row 1"
   ```

   The status lists four untracked files: `index.html`, `script.js`, `styles.css` and `test-plan.md`. On the sample, the commit printed `4 files changed, 174 insertions(+)` and one `create mode 100644` line per file. Now put the repository on GitHub, as you did for `my-site` in Module 1:

   ```
   gh repo create pocket-planner --public --source=. --remote=origin --push
   ```

   Then turn on Pages for the new repository: open `https://github.com/your-username/pocket-planner`, click **Settings**, then **Pages**. Under **Build and deployment**, choose **Deploy from a branch**, then **main** and **/ (root)**, and click **Save**. GitHub Docs says "It can take up to 10 minutes for changes to your site to publish" (*Creating a GitHub Pages site*). Wait, then open `https://your-username.github.io/pocket-planner/`, press F5, and run row 1's tests there. Your `my-site` address does not change: each repository has its own.
5. **Ship rows 2 to 9: the row routine (NEW: one row, one commit, one live check).** When a row passes its tests on your computer, and every earlier row still passes, do this:

   1. **See what changed.** `git status --short`. You should see ` M` beside each file the row changed, and `test-plan.md` among them. A file you did not expect means a change you did not plan: read it before you go on.
   2. **Read the lines.** `git diff --stat`, then `git diff`. Read every `+` and `-` line (press Space for more and **q** to quit).
   3. **Stage, and read again.** `git add .`, then `git diff --staged --stat`. This is the list of what the commit will hold. Check that it is this row and only this row.
   4. **Commit** with the message from the table below, or your own message in the same style: a verb first, then the row.
   5. **Push.** `git push`. The last line ends in `main -> main`.
   6. **Verify live.** Wait a few minutes, open `https://your-username.github.io/pocket-planner/`, and press F5. If you still see the old version, wait and press F5 again. Then run the row's tests on the live page, with DevTools open. Write "live: pass" and the date beside the row in your notebook. Only then start the next row.

   Row 5 is the first row with new files that are not text. **NEW:** a new file does not show in `git diff --stat` until it is staged. `git status --short` lists the pictures as `?? images/`, but `git diff --stat` shows only the three files Git already tracks. After `git add .`, `git diff --staged --stat` lists all six. For a picture, Git shows its size, such as `Bin 0 -> 8138 bytes`, not lines: a picture has no lines to compare.

   ![A terminal in the pocket-planner folder. git status --short lists index.html, styles.css and test-plan.md as modified and images/ as untracked. git diff --stat lists only the three text files, 40 insertions. After git add ., git diff --staged --stat lists the three hero pictures as Bin 0 -> bytes plus the three text files, 6 files changed, 40 insertions. The commit Add responsive hero picture for row 5 prints 6 files changed and three create mode lines for the pictures.](images/p13-git-row5.png)
   *Row 5 in the sample. Compare the two `--stat` lists: the pictures appear only after `git add .`. If they are missing from the staged list, they will be missing from the live site. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*

   The sample's commits printed these summaries:

   | Row | Message | The commit printed |
   | --- | --- | --- |
   | 2 | `Block empty tasks for row 2` | 4 files changed, 25 insertions(+), 2 deletions(-) |
   | 3 | `Add checkboxes and done count for row 3` | 4 files changed, 64 insertions(+), 2 deletions(-) |
   | 4 | `Place form beside list from 700 px for row 4` | 2 files changed, 17 insertions(+) |
   | 5 | `Add responsive hero picture for row 5` | 6 files changed, 40 insertions(+) |
   | 6 | `Build feature cards from an array for row 6` | 4 files changed, 83 insertions(+) |
   | 7 | `Add tags line and New badge for row 7` | 3 files changed, 33 insertions(+), 1 deletion(-) |
   | 8 | `Lay out features in 1, 2 and 4 columns for row 8` | 2 files changed, 20 insertions(+) |
   | 9 | `Add accessibility checks for row 9` | 1 file changed, 14 insertions(+) |

   Rows 4 and 8 change only `styles.css` and `test-plan.md`. Row 9 changed only `test-plan.md` in the sample, because the sample's pass found nothing to fix.
6. **When a live test fails, or a change is not a row (NEW: fix forward).** Do not start the next row. Find the cause on your computer, fix it, and retest. Then run the routine from step 5 again, with a message that names the fix, such as `Fix hero file name for row 5`. Never change a commit you have already pushed: a new commit on top is the fix, and the history shows both. The most common live-only failure is a file name whose capital letters differ from the code: see Problem 4 in Part 4, *Troubleshooting*. Use the same routine for a change that belongs to no row, such as the code-origin marks from Project step 13.
7. **Add a README.** Create `README.md` with the four headings from Module 12: **What it does**, **Built with**, **What I learned** and **Live site**. Under What it does, also say that the test plan is in `test-plan.md` and the explanation in `explanation.md`. Under Live site, put `https://your-username.github.io/pocket-planner/`. Run the routine with the message `Add README`. On GitHub, the README appears under the file list of the repository.
8. **Commit the final explanation.** When `explanation.md` from Project step 14 is finished, run the routine with the message `Add final explanation`. Open the file on GitHub, which shows its headings as headings, and read it once more there. This is the piece people will read.
9. **Run the whole test plan on the live site (NEW: a full live run).** One row at a time, from row 1 to row 9, run every test on the live page. Use a phone if you have one, and device mode otherwise. If a row fails, fix it as in step 6 and start the full run again. When every row passes, add one line under the note at the top of `test-plan.md`, such as `Last full run on the live site: (your date), all nine rows pass.`, and run the routine with the message `Record full test run on the live site`. This is the line the lesson's portfolio audit asks for: a test plan you reran this week.
10. **Tag `v1.0` and publish a release.** Check `git log --oneline` first: your newest commit must be the full-run record, at the top. Then tag it and push the tag, as in Module 12:

    ```
    git tag v1.0
    git push origin v1.0
    ```

    The push ends with `* [new tag]         v1.0 -> v1.0`. On GitHub, draft a release from the tag: **Choose a tag** `v1.0`, a **Release title** such as `Pocket Planner v1.0`, two sentences of notes, then **Publish release**.

    ![A terminal running git log --oneline in the pocket-planner folder. Thirteen commits, newest first: Record full test run on the live site, marked HEAD -> main, tag: v1.0, origin/main; Add final explanation; Add README; then one commit per row from Add accessibility checks for row 9 down to Add task form for row 1; and Add .gitignore at the bottom.](images/p13-git-log.png)
    *The sample's history: one commit per row, each message naming its row, then the README, the explanation and the full live run. `origin/main` on the top line means GitHub has every commit. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*
11. **Link the planner from your own site.** Open `my-site` in VS Code with **File → Open Folder…** and check that the prompt ends in `my-site>`. On your Home page, add one sentence about the planner with a link to `https://your-username.github.io/pocket-planner/`, where it fits your page. Save, open the page, click the link, and press Back. Then save it with the routine: `git status` → `git add .` → `git commit -m "Link to Pocket Planner"` → `git push` → check the live page and click the link there.

> **Checkpoint.** In `pocket-planner`, `git status` says `nothing to commit, working tree clean`, and `git log --oneline` shows a `.gitignore` commit, one commit per row, the README, the explanation and the full live run, with `tag: v1.0` on top. The live planner passes every row of `test-plan.md`. The repository has a README, a v1.0 release and your explanation. Your live site links to the live planner. Those are the links to share: your live site, its repository, and `pocket-planner`.
