# Project: Pocket Planner

*Your hands, about 8 to 10 hours over several sittings (estimate).* In the lesson you saw a minimal Pocket Planner built from four rows. Now you build the full one from a **nine-row** requirement, in a new repository of its own. The planner lets a visitor add tasks, tick them off and see how many are done. Above it sits a responsive hero picture. Below it, a Features section is built by JavaScript from an array of objects.

You get far less help than in earlier packets. Each row gives you its tasks, a skeleton or a few hints, and its tests. The rest you write alone, and Part 6, *Answers*, has the sample's full code for you to compare after you finish.

You use what Modules 1 to 12 taught, plus a few small new pieces, each explained where it first appears:

- **HTML:** the page skeleton with the viewport line, `header`, `main`, `section`, a `form` with a `label`, an `input` and a `button`, lists, and an `img` in a `figure` with `figcaption`, `srcset`, `sizes`, `width`, `height` and `alt`; `aria-describedby` for the message
- **CSS:** custom properties on `:root`, the `box-sizing` rule, Grid with `fr` columns and `gap`, mobile-first `min-width` media queries, `:focus-visible` rings, and the `img` rule that lets a picture shrink
- **JavaScript:** `const` and `let`, functions with `return`, `if`, `===`, `querySelector()` and `querySelectorAll()`, `createElement()`, `append()`, `textContent`, `classList`, `addEventListener()` for `submit` and `change`, `event.preventDefault()`, `.value`, `.trim()`, `.focus()`, an array of objects, `for...of`, `.includes()` and `.join()`
- **Git:** the Module 12 routine with `git status --short`, `git diff --stat` and `git diff --staged`, `gh repo create` and GitHub Pages from Module 1, a `.gitignore`, a README, and a `v1.0` tag

There is no `innerHTML` anywhere, no framework, and nothing is saved between visits: when you reload the page, the task list is empty again. That is expected. Saving would need a tool this course does not teach.

## The brief

Read the whole brief twice before you type anything. Then read the requirement table a third time, one row at a time, the way Core concept 1 showed you.

When you finish, your course folder holds a new folder, `pocket-planner`, next to `my-site` (not inside it). It is its own Git repository, on GitHub as `pocket-planner`, and live at `https://your-username.github.io/pocket-planner/`. It holds `index.html`, `styles.css`, `script.js`, an `images` folder with three hero files, `test-plan.md`, `README.md`, `explanation.md` and `.gitignore`.

**The requirement.** Rows 1 to 4 are the lesson's sample rows, word for word.

| # | Requirement | Done when |
| --- | --- | --- |
| 1 | A visitor can type a task and add it with the Add button or the Enter key. The text box has a visible label. | The task appears at the end of the list and the box empties. |
| 2 | An empty or spaces-only task is not added. A message says why. | The list does not change, and the message appears under the form. |
| 3 | Each task has a checkbox. Checking it marks the task done, and a line shows how many are done. | The task text is struck through, and the line reads, for example, "1 of 3 done." Unchecking undoes both. |
| 4 | One column on a phone. From 700 px wide, the form sits beside the list. | At 390 px and 699 px the panels stack; at 700 px and 1200 px they sit side by side. |
| 5 | Above the planner, a hero picture with a caption. The picture comes in three widths (400, 800 and 1200 px), and the browser picks one. | In device mode (Responsive, which counts 2 device pixels per CSS pixel, as in Module 3) at 390, 800 and 1200 px, the browser loads the 800, 1200 and 1200 file. The picture never makes the page scroll sideways, keeps its space while it loads, and has alt text. |
| 6 | Below the planner, a Features section shows one card per feature. The cards are made by JavaScript from an array of objects called `features`, with no `innerHTML`. | The page shows one card per object, in the array's order, each with its title and sentence. One more object in the array means one more card. |
| 7 | Each card ends with a line that lists its tags. A feature whose tags include "new" also shows a New badge. | Every card's last line reads "Tags: " and that object's tags with a comma and a space between them. Only the cards tagged "new" show the badge. |
| 8 | The feature cards sit in one column on a phone, two columns from 700 px, and four columns from 1000 px. | At 390, 800 and 1200 px the grid has 1, 2 and 4 columns. Nothing scrolls sideways. |
| 9 | The whole page passes the final accessibility pass: keyboard, labels, alt text and color contrast. | Tab reaches the text box, the Add task button and each checkbox in order, each with a dark orange ring, and Enter and Space work. Every text color is at least 4.5:1 and the ring at least 3:1. The Console shows no red lines. |

**The exact words.**

- Page title and `<h1>`: **Pocket Planner**, with a short tagline of your own under it (the sample's is *Today's tasks, in your pocket.*)
- `<h2>` headings: **Add a task**, **Tasks** and **Features**
- The label: **Task**; the button: **Add task**
- The message for an empty task: **Type a task first.**
- The done line: **No tasks yet.** for an empty list, otherwise **1 of 3 done** with your own numbers and no period
- The badge: **New**; each tag line starts with **Tags:** and a space

The hero caption and its alt text are yours, because the photo is yours.

**The names.** Your code and the tests in this packet use these names, so keep them exactly:

- ids: `task-form`, `task-input`, `task-error`, `task-list`, `summary`, `feature-grid`
- classes: `site-header`, `tagline`, `hero`, `layout`, `panel`, `message`, `summary`, `task-list`, `is-done`, `features`, `feature-grid`, `card`, `badge`, `tags`
- files: `images/hero-400.jpg`, `images/hero-800.jpg`, `images/hero-1200.jpg`
- in `script.js`: the array `features`, and the functions `makeTask`, `addTask`, `updateSummary` and `makeCard`

**The features.** At least four objects in the `features` array, each with three properties in this order: `title` (text), `text` (one short sentence) and `tags` (an array of lowercase words). Write about your planner: what it does and how. Exactly one feature has the tag `"new"`, and at least one feature has two tags.

**The colors.** Nine custom properties on `:root`, used for every color on the page except one: the text box's border is `#8a96a3`, which is 3.01:1 on white, just over the 3:1 that the edge of a form field needs. They are the colors of the lesson's sample planner, plus one for the badge. Each text pair was checked with the WCAG contrast formula, the same one the lesson's `contrast.js` uses:

| Name | Value | Used for |
| --- | --- | --- |
| `--ink` | `#1d2733` | body text |
| `--muted` | `#4f5a66` | the done line, the caption, the tag lines, struck-through tasks |
| `--brand` | `#2f5d8a` | the header and the button |
| `--paper` | `#ffffff` | panels, cards, text on `--brand` and `--new` |
| `--page` | `#f4f6f8` | the page background |
| `--line` | `#d5dbe1` | panel and card borders, lines between tasks |
| `--focus` | `#b45309` | the focus ring (dark orange) |
| `--error` | `#b3261e` | the message |
| `--new` | `#0f766e` | the badge (teal) |

The sample's ratios: `--ink` text 15.11:1 on white; `--muted` text 7.03:1 on white and 6.49:1 on `--page`; white text 6.88:1 on `--brand` and 5.47:1 on `--new`; `--error` text 6.54:1 on white; the `--focus` ring 5.02:1 on white and 4.64:1 on `--page`.

**The photo.** Pick one photo of your own for the hero: your desk, a notebook, a list on a fridge. Nothing private, and no faces of other people without their permission. A wide shape works best, because the hero spans the page. The sample is a drawing with its file name painted on it, so you can see which file the browser chose; it is 1200 × 480 at the largest size.

<div style="display:flex;gap:14pt;align-items:flex-start;break-inside:avoid"><div style="flex:0 0 32%"><img src="images/p13-planner-390.png" alt="The finished Pocket Planner at 390 pixels wide: the blue header with Pocket Planner and the tagline, the hero picture with hero-800.jpg painted on it and the caption under it, the Add a task panel with the Task label, the text box and the Add task button, then the Tasks panel reading 1 of 3 done, with Buy milk checked and struck through above Call the bank and Water the plants." style="max-height:3.6in;margin:0 auto 4pt"><p><em>The finished planner on a phone, after three tasks were added with the Enter key and the first one was checked. Rendered at 2 pixels per CSS pixel, as in device mode, so the browser chose the 800 file. Only the top of the page is shown. (real: rendered in Chromium at 390 px)</em></p></div><div style="flex:1"><img src="images/p13-planner-1200.png" alt="The finished Pocket Planner at 1200 pixels wide: the hero with hero-1200.jpg painted on it, the Add a task panel on the left beside the wider Tasks panel on the right, and below them the Features heading with four cards in one row. The fourth card, No mouse needed, has a small teal New badge above its title. Each card ends with a gray Tags line." style="max-height:3.6in;margin:0 auto 4pt"><p><em>The same page on a laptop: the panels side by side, and four feature cards in a row. Only the last card is tagged "new". (real: rendered in Chromium at 1200 px)</em></p></div></div>

## The steps

Type every line. Do not paste. Work on one row at a time, in order, and do not start a row until the one before it is live.

1. **Set up the repository.** Go to Part 3, *Finishing work in Git*, and do steps 1 to 3. They make the `pocket-planner` folder, open it in VS Code, start a repository and commit a `.gitignore`. Then come back here.
2. **Plan on paper.** Turn every row into four task lines, as in Core concept 2: **Structure** (what HTML must exist), **Look** (what CSS it needs), **Behavior** (what JavaScript makes it act) and **Test** (copied from "done when"). Some rows need nothing in one layer: write "none" there. That is 36 short lines. Here is row 1 from the sample's notebook:

   - **Structure:** a form with the label Task, a text box and an Add task button, and an empty list under a Tasks heading.
   - **Look:** the palette, two white panels, a full-width text box, a blue button, a dark orange focus ring.
   - **Behavior:** on submit, stop the reload, read the trimmed text, add it as the last item, empty the box.
   - **Test:** add one task with the button and one with Enter; each is last, and the box empties.

   Write the other 32 lines yourself before you open VS Code. Part 6 has the sample's lines to compare with afterward.

   Then, in VS Code, create `test-plan.md` in `pocket-planner` with a `# Pocket Planner test plan` heading, a one-line note on what the file is, and a `## Row 1` section that holds an empty Action / Expected / Actual table (Module 11). Fill in Action and Expected from your Test line for row 1. Leave Actual empty. Each row adds its own section to this file, and its rows go into the same commit as the code.
3. **The row routine.** Every row below goes through the nine steps from Core concept 4. In this project they look like this:

   1. **Predict:** write the Expected column for the row's tests before you run anything.
   2. **Run:** save, open `index.html` in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window), press **F5**, and do each Action. Keep DevTools open: press **F12** (or **Ctrl+Shift+J**) and click the **Console** tab. Fill in Actual.
   3. **Explain:** explain each new line to yourself, out loud, in one sentence.
   4. **Modify:** make the change the row suggests, predict, run, and undo it.
   5. **Debug:** when Actual and Expected differ, use the Module 11 method: read the red line, check the selector in the Console, and change one thing at a time.
   6. **Retest:** run the row's tests again from a fresh F5, **and the tests of every earlier row**. A new row can break an old one.
   7. **Commit,** 8. **Push** and 9. **Verify live:** Part 3, step 5.

   Steps 7 to 9 are written once, in Part 3, because they are the same for every row. Each row step below ends with **Ship row N**, which means: do Part 3, step 5 for that row.
4. **Row 1: add a task.** *Structure.* Create `index.html` and type:

   ```html
   <!DOCTYPE html>
   <html lang="en">
   <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <title>Pocket Planner</title>
     <link rel="stylesheet" href="styles.css">
     <script src="script.js" defer></script>
   </head>
   <body>
     <header class="site-header">
       <h1>Pocket Planner</h1>
       <p class="tagline">Today's tasks, in your pocket.</p>
     </header>
     <main>
       <div class="layout">
         <section class="panel">
           <h2>Add a task</h2>
           <form id="task-form">
             <label for="task-input">Task</label>
             <input id="task-input" type="text">
             <button type="submit">Add task</button>
           </form>
         </section>
         <section class="panel">
           <h2>Tasks</h2>
           <ul id="task-list" class="task-list"></ul>
         </section>
       </div>
     </main>
   </body>
   </html>
   ```

   Use your own tagline. The script is in the `<head>` with `defer`, as in Module 9, so it runs after the body exists. The button is a real submit button inside the form, so the click **and** Enter in the text box both fire one `submit` event on the form (Module 10). That one fact covers the "Add button or the Enter key" part of row 1.

   *Look.* Create `styles.css`. Start it with a comment line, the nine custom properties from the brief on `:root`, and the `box-sizing` rule from Module 3. Then type:

   ```css
   body {
     margin: 0;
     font-family: system-ui, sans-serif;
     background: var(--page);
     color: var(--ink);
   }

   main {
     max-width: 1000px;
     margin: 0 auto;
     padding: 16px;
   }

   /* Row 1: the panels, the form and the list */
   .layout {
     display: grid;
     gap: 16px;
   }

   button:focus-visible,
   input:focus-visible {
     outline: 3px solid var(--focus);
     outline-offset: 2px;
   }

   /* Continue alone: .site-header, .site-header h1, .tagline, .panel,
      .panel h2, label, input[type="text"], button, .task-list and
      .task-list li, to match the pictures in the brief. */
   ```

   `system-ui` asks for the computer's own interface font. The ring rule names `input`, not `input[type="text"]`, on purpose: remember that for row 3. For the rest, look at the pictures and use the colors from the table. The text box is as wide as its panel (`width: 100%`), and `font: inherit` on the box and the button makes them use the page's font instead of the browser's smaller default. The list has no bullets and no indent, and each item has a thin `--line` border on top.

   *Behavior.* Create `script.js` and type:

   ```js
   // script.js: Pocket Planner

   // ===== Find elements =====
   const taskForm = document.querySelector("#task-form");
   const taskInput = document.querySelector("#task-input");
   const taskList = document.querySelector("#task-list");

   // ===== Define behavior =====

   // makeTask: takes the task text and returns a new list item.
   function makeTask(text) {
     const item = document.createElement("li");
     item.textContent = text;
     return item;
   }

   // addTask: runs on submit; adds the task to the end of the list.
   function addTask(event) {
     event.preventDefault();
     // Continue alone: read the box with .value.trim() into a const text,
     // append makeTask(text) to the list, empty the box, and put the
     // cursor back in it with .focus().
   }

   // ===== Connect events, and build the page =====
   taskForm.addEventListener("submit", addTask);
   ```

   This is the Module 9 pattern: find elements, define behavior, connect events. `makeTask` returns the new item instead of adding it itself, so it can be tested alone in the Console. Write the four missing lines and delete the comment.

   *Test.* Run row 1's tests. The sample added "Buy milk" with the button and "Call the bank" with Enter; each one appeared last, the box emptied, and the cursor was back in the box. Clicking the word **Task** put the cursor in the box, which proves the label is tied to it. Then **think this through:** what will happen if you press Enter with three spaces in the box? Write down your answer, then try it. The sample added an empty item: a thin line with nothing in it. Row 2 exists for exactly this.

   *Modify.* Delete the line that empties the box, predict, run, and put it back.

   **Ship row 1.** Part 3, step 4 is the first push: it creates the repository on GitHub and turns on Pages. Do it now instead of step 5.
5. **Row 2: no empty tasks.** *Structure.* Under the closing `</form>` tag, still inside the first panel, add an empty paragraph for the message: `<p id="task-error" class="message"></p>`. Tie it to the text box by adding `aria-describedby="task-error"` to the `<input>`, as in Module 10. The paragraph is in the HTML from the start, so the attribute always has something to point at.

   *Look.* Add a `/* Row 2: the message */` comment and a `.message` rule: the `--error` color, `min-height: 1.5em` so the panel does not jump when the message appears, and `margin-bottom: 0`.

   *Behavior.* Find the message paragraph with a new `const taskError` in the "Find elements" part. In `addTask`, right after the line that reads the text, add the check:

   ```js
     if (text === "") {
       // Continue alone: show "Type a task first." in taskError,
       // put the cursor back in the box, and stop the function.
     }
     taskError.textContent = "";
   ```

   `return` with nothing after it stops the function at once (Module 7), so nothing below it runs and nothing is added. The line after the `if` block clears an old message once a real task arrives. Update the comment above `addTask`, too: it now also shows a message.

   *Test.* Write row 2's three test rows (empty, three spaces, then a real task) in `test-plan.md`, predict, then run. The sample kept two items after both bad tries, showed **Type a task first.** under the form both times, and cleared the message when "Water the plants" was added. Now rerun row 1's tests: they must still pass.

   *Modify.* Remove `.trim()` from the line that reads the box. Predict what three spaces do now. The sample added an item that held three spaces and showed no message, because `"   "` is not `""`. Put `.trim()` back.

   **Ship row 2.**
6. **Row 3: tick it off.** *Structure.* Under the **Tasks** heading, add the done line: `<p id="summary" class="summary"></p>`. Each task now needs more than text. The sample's task item is a `<li>` that holds a `<label>`, and the label holds the checkbox and a `<span>` with the words. A label wrapped around its box needs no `for`: clicking the words checks the box.

   *Behavior.* Add `const summary` to the "Find elements" part. Then replace `makeTask` with this skeleton, and give it a new comment that says it returns a list item with a checkbox:

   ```js
   function makeTask(text) {
     const item = document.createElement("li");
     const label = document.createElement("label");
     const box = document.createElement("input");
     box.type = "checkbox";
     const words = document.createElement("span");
     words.textContent = text;
     box.addEventListener("change", function () {
       // Continue alone: if box.checked, add the class is-done to item;
       // otherwise remove it. Then call updateSummary().
     });
     label.append(box, words);
     item.append(label);
     return item;
   }
   ```

   `box.type = "checkbox"` sets the new input's `type` property, the same as writing `type="checkbox"` in HTML, so the input becomes a checkbox. This is the `change` event from Core concept 3. Each new box gets its own listener, and inside it, `box` and `item` are the box and the item made on that same call. `append()` can take several elements at once and adds them in order.

   Now write `updateSummary()` alone, above `makeTask`, with a comment of its own. It counts the items and the checked boxes, and writes **No tasks yet.** when there are no items, or the "1 of 3 done" line otherwise. Two facts help. `querySelectorAll()` works on any element, not only on `document`, and then it searches only inside that element: `taskList.querySelectorAll("li")` finds the items in the list.

   And `:checked` works in a JavaScript selector, as in Module 10, Concept 2, where `document.querySelector('input[name="rating"]:checked')` found the chosen radio: here `"input:checked"` matches only the boxes that are checked now.

   Call `updateSummary()` in three places: in the `change` listener, at the end of `addTask`, and once on its own under the `addEventListener` line, so the line is right when the page loads.

   *Look.* Add a `/* Row 3 */` comment and four rules: `.summary` in `--muted`, `.task-list label` as a flex row with a gap (the box beside the words), `.task-list input` at 20 by 20 px, and `.is-done span` with `text-decoration: line-through` (a line through the text) and the `--muted` color. **Think this through:** will the checkboxes get the dark orange ring when you Tab to them? Look at your row 1 ring rule, write down your answer, then Tab and see.

   *Test.* Write row 3's tests from "done when", plus "Load the page" and "Click the words of a task." The sample showed **No tasks yet.** on load and **0 of 3 done** after three tasks. Checking the first box struck it through and showed **1 of 3 done**; unchecking undid both. Clicking the words of the second task checked its box. And yes, the checkboxes had the ring: `input:focus-visible` matches every `input`, checkboxes included. Rerun rows 1 and 2.

   *Modify.* In the `change` listener, delete the `updateSummary();` line. Predict, then check a box. The sample struck the task through but still said **0 of 2 done**. Adding a third task then showed **1 of 3 done**, because `addTask` calls `updateSummary()` too. A count that is right only some of the time is the kind of bug the "Uncheck" test row catches. Put the line back.

   **Ship row 3.**
7. **Row 4: the layout.** This row is one media query, and you write it alone. Put it at the end of `styles.css`, under a `/* Wider screens */` comment, so it comes after the rules it changes (Module 3). Inside, give `.layout` the columns `1fr 2fr` (the list gets twice the room of the form) and `align-items: start`, so the shorter panel does not stretch to match the taller one.

   *Test.* Turn on device mode (F12, then **Ctrl+Shift+M**) and try 390, 699, 700 and 1200. To be sure of the count, type this in the Console:

   ```js
   getComputedStyle(document.querySelector(".layout")).gridTemplateColumns
   ```

   One value is one column. The sample measured `358px` at 390, `667px` at 699, `217.328px 434.672px` at 700 and `317.328px 634.672px` at 1200. The boundary is exactly where the row asks, because `min-width` is inclusive. Write the four test rows with the real values in Actual.

   *Modify.* Change `700px` to `800px` and measure again at 700, 799 and 800. The sample stacked at 700 and 799 (`668px`, `767px`) and went side by side at 800. Put back `700px`.

   **Ship row 4.**
8. **Row 5: the hero picture.** *Structure.* Save your photo three times in a new `images` folder inside `pocket-planner`, resized to 400, 800 and 1200 pixels wide, with the names from the brief. Write down the real size of the 1200 file (right-click it, **Properties → Details**), as in the Module 3 packet. Then, as the first thing inside `<main>`, above the layout, write a `<figure class="hero">` with the `<img>` and a `<figcaption>`. You did this in Module 3, so it is yours to write. Use these values:

   - `src`: the 800 file, for a browser that does not read `srcset`
   - `srcset`: all three files with `400w`, `800w` and `1200w`
   - `sizes="(min-width: 1000px) 968px, 100vw"`: the picture is the page width on smaller screens, and at most 968 px wide (1000 px minus the 16 px padding on each side of `main`)
   - `width` and `height`: the real size of your 1200 file (the sample's is `width="1200" height="480"`)
   - `alt`: what the photo shows, in a short sentence

   No `loading="lazy"` here. The hero is on screen the moment the page opens, so waiting would gain nothing.

   *Look.* Add a `/* Row 5 */` comment and the `img` rule from Module 3 (`max-width: 100%`, `height: auto`, `display: block`), then a `.hero` rule with a bottom margin, rounded corners for `.hero img`, and the caption in `--muted`. Put these above the `/* Wider screens */` block.

   *Test.* Ask the browser which file it chose. In the Console, type:

   ```js
   document.querySelector(".hero img").currentSrc
   ```

   Test in device mode, as in Module 3: its Responsive setting counts 2 device pixels per CSS pixel, so it picks bigger files than a plain window at 100% display scaling. Compare your answers with the 2-pixels column, which is what row 5's "done when" names. A plain window gives a different answer when Windows display scaling is above 100% (for example 150% in **Settings → System → Display**), because the browser then counts more device pixels per CSS pixel. That is not a bug. Press **F5** after every width change: a browser that already has a bigger file may keep showing it. On the sample page, Chromium chose:

   | Viewport | 1 pixel per CSS px | 2 pixels per CSS px (device mode) |
   | --- | --- | --- |
   | 390 px | hero-400.jpg | hero-800.jpg |
   | 800 px | hero-800.jpg | hero-1200.jpg |
   | 1200 px | hero-1200.jpg | hero-1200.jpg |

   At 390 px the picture was 358 px wide and the page did not scroll sideways.

   To check that its space is kept while it loads, the sample page was served with each picture held back for 2 seconds: the picture's box was already 143 px tall before the file arrived, and nothing below it moved when it did. You do not need to repeat that check. What you can check is the cause: in the Console, `getComputedStyle(document.querySelector(".hero img")).aspectRatio` gave `auto 1200 / 480`, the shape taken from `width` and `height`. Write row 5's test rows and fill in your own Actual.

   *Modify.* In `sizes`, change `968px` to `400px`. Predict which file loads at 1200 px. The sample loaded `hero-400.jpg` at 1 pixel per CSS px (and `hero-800.jpg` in device mode), and the picture looked soft: `sizes` is a promise, and the browser believed it. Put back `968px`.

   **Ship row 5.** This is the first row with new picture files. Part 3, step 5 says how they show up in Git.
9. **Row 6: cards from an array.** *Structure.* After the layout `<div>`, still inside `<main>`, add a `<section class="features">` with the `<h2>` **Features** and an empty `<ul id="feature-grid" class="feature-grid"></ul>`.

   *Behavior.* In `script.js`, add `const featureGrid` to "Find elements". Under it, add a `// ===== The data =====` part with your `features` array. The first object is given; continue alone:

   ```js
   const features = [
     {
       title: "Add in a second",
       text: "Type a task and press Enter. It goes to the end of your list.",
       tags: ["tasks", "keyboard"]
     },
     // Continue alone: three or more objects of your own, with the same
     // three properties. Exactly one has the tag "new".
   ];
   ```

   Then add `makeCard` after `addTask`, with its comment:

   ```js
   // makeCard: takes one feature object and returns a new card.
   function makeCard(feature) {
     const card = document.createElement("li");
     card.classList.add("card");
     // Continue alone: an h3 with feature.title and a p with feature.text,
     // both filled with textContent, appended to card in that order.
     return card;
   }
   ```

   Last, at the very end of the file, write a `for...of` loop that appends `makeCard(feature)` to `featureGrid` for each feature (Module 9, Concept 9). The tags wait for row 7.

   *Look.* Add a `/* Rows 6 and 7 */` comment above the `/* Wider screens */` block: a `.features h2` rule to match the panel headings, `.feature-grid` with no bullets, no indent, `display: grid` and `gap: 16px`, and `.card` like `.panel` (white, a border, rounded corners, padding). One column for now: the columns are row 8.

   *Test.* Load the page and count the cards. Then, in the Console, type `features.length` and `document.querySelectorAll("#feature-grid li").length`. They must match. The sample gave `4` and `4`, and the cards were in the array's order.

   *Debug.* Here is a mistake that is easy to make when an id has a plural-sounding name. In the `featureGrid` line, change `#feature-grid` to `#features-grid`. Save and press F5. Write down what you expect, then look. On the sample page:

   - no cards appeared, and the Console showed one red line, `Uncaught TypeError: Cannot read properties of null (reading 'append')`, with `script.js:102` on the right
   - line 102 was the loop's `featureGrid.append(makeCard(feature));`, not the line with the typo
   - the planner still worked: adding "Buy milk" showed **0 of 1 done**

   Use the Module 11 method. `null` means a `querySelector()` found nothing, and the error shows up later, where the `null` is used. So test the selector itself: in the Console, `document.querySelector("#features-grid")` gave `null`, and `document.querySelector("#feature-grid")` gave the list. The planner kept working because its lines ran before the loop: the error stopped the script only at line 102. Fix the id, F5, and retest rows 1 to 6.

   *Modify.* Under the array, push one more object onto it with `features.push({ ... })`, with a title, a sentence and one tag. Predict the two Console numbers, then F5. The sample showed 5 cards, the new one last. Delete the `push`.

   **Ship row 6.**
10. **Row 7: tags and the New badge.** Write this row alone, inside `makeCard`. Two hints:

    - The tag line is a `<p>` with the class `tags`, appended last. Its text is `"Tags: "` joined with the tags, using `.join(", ")` (Module 8).
    - The badge is a `<p>` with the class `badge` and the text `New`, appended **first**, so it sits above the title. Make it only when `feature.tags.includes("new")` is `true`.

    In the CSS, `.card .tags` is `--muted` and a little smaller (`0.9rem`). `.badge` has a `--new` background, `--paper` text, bold `0.8rem` type, `display: inline-block` (so the colored box is only as wide as the word) and rounded ends, as in the 1200 px picture.

    *Test.* Read every card's last line against your array, and count the badges. The sample showed `Tags: tasks, keyboard`, `Tags: tasks`, `Tags: layout` and `Tags: keyboard, new`, and one badge, on "No mouse needed" only.

    *Break it on purpose.* In the tag line, delete the parentheses and what is in them, so it reads `"Tags: " + feature.tags.join`. **Think this through:** will there be a red line in the Console? Write down your answer, then F5. In the sample, every card's last line read `Tags: function join() { [native code] }`, and the Console stayed clean.

    Without parentheses, `join` is a reference to the method, not a call (Module 7). Joining it to text turns the function itself into text. No error, a wrong page: only reading the result catches it. Put the parentheses back and retest.

    *Modify.* Move the `"new"` tag to a different feature and predict which card gets the badge. Then put it back.

    **Ship row 7.**
11. **Row 8: the feature grid.** Write this row alone, in CSS only. In the `700px` media query, give `.feature-grid` two equal columns (`1fr 1fr`). Then add a second media query, `@media (min-width: 1000px)`, **after** the first one, with four equal columns.

    *Test.* Measure as in row 4, with `.feature-grid` in place of `.layout`. The sample measured one column (`358px`) at 390, two (`376px` each) at 800, two (`475.5px`) at 999, four (`230px` each) at 1000 and four at 1200. Check that nothing scrolls sideways at any width: the scroll bar at the bottom of the page should not appear.

    *Modify.* Swap the two media query blocks, so the 1000 px block comes first. Predict the columns at 1200, then measure. The sample had two columns (`476px 476px`) at 1000 and 1200: both blocks were true, they had the same specificity, and the later `1fr 1fr` won (Module 3). Swap them back.

    **Ship row 8.**
12. **Row 9: the accessibility pass.** This row is the lesson's Core concept 6, done on the whole page. Put the mouse away first. Its test rows go in `test-plan.md` like the others:

    - **Keyboard.** F5, then Tab. Focus goes to the text box first, then the Add task button, then each checkbox. Each one shows the dark orange ring. Enter on the button with an empty box shows the message and puts focus back in the box. Space on a checkbox checks it, and the done line updates. The sample passed all of these.
    - **Labels.** Click the word **Task**: the cursor goes into the box. Click a task's words: its box checks.
    - **Alt text.** Right-click the hero, choose **Inspect**, and read its `alt`. It says what the photo shows.
    - **Contrast.** In DevTools, click the **Inspect** button (the arrow at the top left of DevTools) and hover over your palest text: a tag line, the caption, the done line. The tooltip shows a contrast ratio. Each must be at least 4.5, with no warning icon. The brief's table lists the sample's ratios.
    - **The Console.** After all the tests above, the Console shows no red lines.
    - **No `innerHTML`.** Open `script.js`, press **Ctrl+F** and search for `innerHTML`. No results.

    *Modify.* In `:root`, change `--muted` to `#9aa3ad`, the light gray from the lesson. Hover over a tag line with Inspect again. The lesson's `contrast.js` gives that gray 2.56:1 on white, well under 4.5, so the tooltip should show the warning icon. Put back `#4f5a66`.

    *Debug what you find.* If a check fails, fix it, retest that check, and retest every row. The sample passed every check, so its row 9 commit holds only the new section of `test-plan.md`. Yours may hold fixes too, and that is the point of the row.

    **Ship row 9.**
13. **Code origin.** Read all three files from top to bottom. For each line, ask: did I type this myself, from this packet or from my own head? If a tool, a website or a person wrote any line for you, mark it as Core concept 5 shows, with a comment above it:

    ```js
    // Tool-written: the next line came from [name the tool or site].
    // What it does: [one sentence in your own words].
    // What I changed: [what you changed, or "nothing"].
    ```

    In `styles.css` the comment uses `/* */`, and in `index.html` it uses `<!-- -->`. If you cannot write the "What it does" line, rewrite the code in a way you can explain, then commit the change with a message such as `Mark and explain tool-written lines`. Part 3, step 6 has the routine for a change that is not a row.
14. **Write the final explanation.** This is the required last piece of the capstone. In VS Code, create `explanation.md` in `pocket-planner` and fill in this template. Write in full sentences, in your own words, with the files closed for parts 1 and 2. Then open them to check.

    ```
    # How my Pocket Planner works

    ## 1. What it does
    Three or four sentences: what a visitor sees and can do.

    ## 2. How it works, row by row
    One short paragraph per row, 1 to 9: which file and which lines make
    the row work, and why they work.

    ## 3. The line I was least sure about
    Quote the line. Say what you looked up, where (an MDN page title),
    and how you checked your new understanding in the browser.

    ## 4. What breaks if I delete one line
    Pick one line. Write your prediction, delete it, run the tests,
    write what happened, and put it back.

    ## 5. Code origin
    Which lines a tool or a website wrote, and what you changed.
    Write "None" if you typed every line.

    ## 6. What I would test next
    Two or three Action / Expected rows that are not in test-plan.md yet.
    ```

    Part 6 has the sample student's explanation as a model. Read it **after** you write yours.
15. **Check the project.** Tick each box.

    - [ ] `pocket-planner` is its own folder, next to `my-site`, not inside it
    - [ ] Every row's tests in `test-plan.md` pass, with real values in Actual, and every earlier row was retested after each new row
    - [ ] The exact words, ids, classes and file names match the brief
    - [ ] `features` has at least four objects; exactly one has the tag `"new"`; the cards appear in the array's order
    - [ ] There is no `innerHTML` in `script.js`, and every piece of text goes in with `textContent`
    - [ ] The columns are 1 and 2 for the panels at 699 and 700 px, and 1, 2 and 4 for the cards at 390, 800 and 1200 px
    - [ ] Tab, Enter and Space do everything, with a dark orange ring on every control
    - [ ] Every text color passes 4.5:1 in DevTools, and the hero has real alt text
    - [ ] Any tool-written line is marked and explained, and `explanation.md` has all six parts
    - [ ] The extra lines from the Modify, Debug and Break-it steps are gone
16. **Finish in Git.** Go to Part 3 and do steps 7 to 11: the README, the explanation, a full test run on the live site, the `v1.0` tag, and a link from your own site.
