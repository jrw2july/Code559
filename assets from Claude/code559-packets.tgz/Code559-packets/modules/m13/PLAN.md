# Module 13 packet plan

- Free Exercise (already in the post): Row 1 of the goal counter in `practice-13\goal-counter`
- Packet project (the public promise in the post's teaser): The full Pocket Planner from the nine-row requirement, plus the required final explanation
- Finishing work in Git: Every row committed, pushed and checked live

## Files to write (see build_packet.py header)
- [ ] project.md: "# Project: ..." then The brief (picture of the finished thing, what the visitor can do, exact words) and The steps (skeleton snippets, a comment where the reader continues alone)
- [ ] finishing.md: Git steps; NEW items marked
- [ ] troubleshooting.md (only if this module has common failures)
- [ ] selfcheck.md: "## Rubric" list (one line per concept, the §4 rubric) + written questions
- [ ] answers.md: Check your understanding, Common misconception, Exercise checks
- [ ] images/: packet-only pictures pNN-*.png (real renders / real captured output; drawn screens tagged ILLUSTRATION)

## Verification before delivery
- [ ] every project snippet run for real (Chromium for pages, Node for scripts, Git in a throwaway repo)
- [ ] teaser in the post matches the project delivered
- [ ] style rules: names (my-site, styles.css, practice-NN), F5 viewing, focus rings, banned words, no build paths
- [ ] built PDF: Contents page numbers match, no broken images, cover has no footer
- [ ] independent check by a reviewer that did not write it
