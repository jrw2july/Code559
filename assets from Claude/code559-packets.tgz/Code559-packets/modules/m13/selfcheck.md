# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. This is the last module of the core course, so aim for at least **3 (Proficient)** on every line before you call the capstone finished and share it. If a line is a 1 or a 2, reread that Core concept and redo its row of the project.

## Rubric

- I can read a requirement table, underline its nouns and verbs, and write a "done when" for a row that has none
- I can turn a row into Structure, Look, Behavior and Test lines, and build it in that order
- I can take a row through all nine steps, and retest every earlier row before I commit
- I can write test rows from "done when" and fill in Actual with real values: counts, columns and file names
- I can build page items from an array of objects with createElement, textContent and append, and no innerHTML
- I can find a null selector from a Console error that names a different line than the mistake
- I can commit, push and check one row at a time on the live site, reading git diff --staged --stat first
- I can run the final accessibility pass: keyboard, labels, alt text and color contrast
- I can mark and explain a tool-written line, and explain my whole project in writing

## Three questions to answer in writing

1. In Project step 9, the typo was in the `featureGrid` line near the top of `script.js`, but the Console named line 102, and the planner above the cards still worked. Explain both facts.
2. Which row surprised you most, on your computer or on the live site? Write the Expected you had, the Actual you got, what you changed, and which of the nine steps caught it.
3. A friend wrote this `updateSummary` in row 3, and it passed every row 3 test. After row 6, what does the done line read on load, after adding two tasks, and after checking one of them? Why did the row 3 tests not catch it, which test does, and what one change fixes it?

   ```js
   function updateSummary() {
     const total = document.querySelectorAll("li").length;
     const done = taskList.querySelectorAll("input:checked").length;
     if (total === 0) {
       summary.textContent = "No tasks yet.";
     } else {
       summary.textContent = done + " of " + total + " done";
     }
   }
   ```
