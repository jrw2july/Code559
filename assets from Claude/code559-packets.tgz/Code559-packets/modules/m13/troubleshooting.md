# Troubleshooting: six common problems

Each problem has the symptom you see, why it happens, and the fix. Each one was made on purpose in the sample planner and run in Chromium. The line numbers are the sample's, at the row named; yours will differ. After each fix, press F5 and rerun the tests of the row you are on **and of every earlier row**.

### 1. The page reloads, and the new task is gone

**Symptom.** You add a task, it flashes, and the list is empty again. The address now ends in `index.html?`, with a question mark.

**Why.** A form's normal job is to send its data and load a page. The question mark is the form sending itself: its one field has no `name`, so there is nothing after the `?`. Your `submit` listener must call `event.preventDefault()` to stop that (Module 10). Three mistakes in the sample all let the reload happen:

- `event.preventDefault();` missing from `addTask`. No red line.
- The event name misspelled, `"sumbit"`. No red line: the browser accepts any event name and simply waits for an event that never comes.
- `addTask()` with parentheses in the `addEventListener` line. On load, the Console showed `Uncaught TypeError: Cannot read properties of undefined (reading 'preventDefault')` at the `event.preventDefault();` line (line 19 in the row 1 file). `addTask` ran once at load with no event, and no listener was connected.

**Fix.** Check the listener line first: `taskForm.addEventListener("submit", addTask);`, with the event name spelled right and no parentheses after `addTask`. Then check that `event.preventDefault();` is the first line of `addTask`, and that `addTask` has the parameter `event`.

### 2. TypeError: Cannot read properties of null

**Symptom.** A red line in the Console, and part of the page does not work. In the sample:

| Message | Where | Cause |
| --- | --- | --- |
| `Uncaught TypeError: Cannot read properties of null (reading 'append')` | `script.js:102` (row 6) | `#features-grid` in place of `#feature-grid`: no cards, the planner still works |
| `Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')` | `script.js:61` (row 3) | `defer` missing from the `<script>` tag in the `<head>`: nothing works, and Add task reloads the page |

**Why.** `querySelector()` returns `null` when it finds nothing (Module 11). The error appears where the `null` is **used**, not where it was made. Without `defer`, the script runs before the body exists, so every `querySelector()` finds nothing (Module 9).

**Fix.** Look at the word in brackets, such as `'append'`, and at the name just before it on the named line, here `featureGrid`. Find where that name got its value, and test that selector in the Console: `document.querySelector("#feature-grid")`. If it gives `null`, compare the selector with the HTML letter by letter, including the `#`. If every selector gives `null`, check for `defer`.

### 3. The done count is wrong

**Symptom.** Checking a box strikes the task through, but the line still says **0 of 2 done**. Or the line counts more tasks than you have, such as **0 of 6 done** after two tasks.

**Why.** In the first case, the `change` listener does not call `updateSummary()`. The line is only updated when `addTask` runs, so it catches up one task late: in the sample, adding a third task then showed **1 of 3 done**. In the second case, `updateSummary` counts every `<li>` on the page with `document.querySelectorAll("li")`, and from row 6 the feature cards are `<li>` items too. That bug passes every row 3 test and appears only after row 6.

**Fix.** Call `updateSummary()` at the end of the `change` listener, at the end of `addTask` and once on load. Count with `taskList.querySelectorAll(...)`, which searches only inside the task list. Run the "Uncheck it" test row too: it catches a count that is right only some of the time.

### 4. The hero picture is missing at some widths, or only online

**Symptom.** A broken-picture icon (or no picture at all) at one width, a red line in the Console, or a picture that shows on your computer and not on the live site.

**Why.** Three causes:

- **A wrong name in one `srcset` entry.** The browser loads only the file it chose, so the mistake shows only at the widths that choose that entry. With `images/Hero-400.jpg` in the `srcset` (a capital H), the sample at 390 px showed `Failed to load resource: net::ERR_FILE_NOT_FOUND` for `Hero-400.jpg`.
- **Capital letters, online only.** Windows does not care about capital letters in file names, so on your own computer a wrong capital may still load. The server behind GitHub Pages does care, so the same page fails online. This is the problem Core concept 4 says only "verify live" catches. (This packet could not test on Windows or on GitHub Pages; the run above was on Linux, which, like the server, cares about capital letters.)
- **Pictures not committed.** New files show in `git status --short` as `?? images/` until you `git add` them. If they were never committed, they were never pushed.

**Fix.** Copy each file name from File Explorer into the `srcset`, all in lowercase, and check all three widths with `currentSrc` (Project step 8). Before you push row 5, check that `git diff --staged --stat` lists all three files (Part 3, step 5).

### 5. Some cards are missing, or a card shows strange text

**Symptom.** Fewer cards than objects, with a red line. Or every card's last line shows code instead of tags. In the sample:

| What you see | Cause | Where |
| --- | --- | --- |
| Two cards, then `Uncaught TypeError: Cannot read properties of undefined (reading 'includes')` | `tag:` in place of `tags:` in the third object | `script.js:89`, the `if` line in `makeCard` (row 7) |
| Two cards, then `Uncaught TypeError: feature.tags.join is not a function` | `tags: "layout"`, a string, in place of `tags: ["layout"]` | `script.js:101`, the tag line (row 7) |
| `Tags: function join() { [native code] }` on every card, no red line | `.join` with no parentheses | Project step 10 |

**Why.** The loop builds the cards in order and stops at the first error, so the cards before the bad object are made and the rest are not. An object with no `tags` gives `undefined`, and `undefined` has no `.includes()` (Module 8). A string has its own `.includes()`, so the check passes, but it has no `.join()`: only arrays do.

**Fix.** Count the cards on the page: the bad object is the first one missing. Check that it has all three properties, spelled exactly, and that `tags` has square brackets, even for one tag. Methods need their parentheses: `join(", ")`.

### 6. The grid has the wrong number of columns

**Symptom.** Measured with `getComputedStyle(...).gridTemplateColumns` (Project step 7), the panels or the cards have the wrong count at some width. In the sample:

| What was wrong | Measured |
| --- | --- |
| The `1000px` block above the `700px` block | 2 columns at 1000 and 1200 px, not 4 |
| `@media (min-width: 1000)`, with no `px` | 2 columns at 1000 and 1200 px: the browser ignores a media query it cannot read |
| The `700px` block changed to `800px` | Panels still stacked at 700 and 799 px |

**Why.** Rules inside a media query have the same specificity as rules outside it, so the later rule wins when both apply (Module 3). A media query with a mistake in its condition is never true. And the boundary is wherever the number says.

**Fix.** Keep the base rules first, then the `700px` block, then the `1000px` block, at the end of the file. Write the unit, `px`. Measure at the widths the requirement names, and one pixel each side of each boundary: 699 and 700, 999 and 1000.
