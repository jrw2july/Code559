# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **"The visitor can filter the list."** It has no "done when," so there is no test and no way to know when the row is finished. It is also vague: filter by what, with which control, and what shows when nothing matches? Before you start, rewrite it and add the test. For example: *"A Show only open tasks checkbox hides the done tasks. Unchecking it shows them all again."* Done when: *"With 1 of 3 done, checking the box leaves 2 tasks on screen; unchecking it shows all 3."* (Core concept 1)
2. **Structure before behavior.** CSS and JavaScript both need elements to select. If the HTML is not there yet, `querySelector()` gives `null`, and the first line that uses it stops the script with a `TypeError` (Module 11). Behavior also comes last because it is the hardest layer to test, and a test is easier to read on a page that already looks right. (Core concept 2)
3. **`addOne()` with parentheses.** On load, the count reads **1**. The parentheses call `addOne` at once, while the listener line runs, so `count` becomes 1 and the page shows it.

   What `addEventListener` receives is not the function but its return value, and `addOne` returns nothing: `undefined`. The browser quietly adds no listener for that, so clicking does nothing. There is no error, because nothing in the code is invalid: a function was called, and a value was passed. The code just does something different from what you meant (Module 7: reference versus call; Module 9: why the listener takes `addOne`, not `addOne()`). Checked in Chromium: 1 on load, still 1 after three clicks, no red line. (Exercise step 7)

## Common misconception

*"If it works on my computer, it's done."* "It works" is step 2 of nine, Run. Seven steps come after it: explain, modify, debug, retest, commit, push and verify live.

Each one catches something "it works" misses. Explaining finds the line you cannot defend. Retesting finds the old row the new code broke. Committing and pushing are what put the work where anyone else can see it: until you push, the live site does not have it at all. And verifying live catches the problems that only happen online, such as a file name whose capital letters match on Windows but not on the server, or a new picture you forgot to commit. In this project, a row is done only when its tests pass on `https://your-username.github.io/pocket-planner/`. (Core concept 4)

## Exercise checks

- **Step 1.** Twelve lines. One possible set:

  | Row | Structure | Look | Behavior | Test |
  |---|---|---|---|---|
  | 1 | A count in a `<span>` that starts at 0, and a +1 button | None yet, or a larger font for the count | On click, add 1 to the count and show it | On load 0; after three clicks 3 |
  | 2 | A Reset button | Spacing between the two buttons | On click, set the count to 0 and show it | After any clicks, Reset shows 0 |
  | 3 | An empty paragraph for the message | The message in a color that passes 4.5:1 | Before adding, stop at 10; at 10, show the goal message | The eleventh click leaves 10, and the message appears |

- **Step 5.** On load the count reads 0; after three clicks it reads 3. No red lines in the Console.
- **Step 6.** With `count + 2`, three clicks show 6.
- **Step 7.** 1 on load, clicking does nothing, and no red line. See question 3 above for why.
- **Step 8.** From a fresh load: 0, then 3 after three clicks.
- **Step 9.** `git status --short` shows two lines, `?? index.html` and `?? script.js`. The commit printed `2 files changed, 24 insertions(+)` and two `create mode 100644` lines, one per file: 14 lines in `index.html` and 10 in `script.js`. `git log --oneline` shows one commit.

## Self-assessment questions

1. **The wrong-looking line number.** The typo was in the `featureGrid` line near the top, but nothing goes wrong on that line. `document.querySelector("#features-grid")` finds nothing, so it returns `null`, and storing `null` in a `const` is allowed. The error comes later, at the first line that **uses** that `null`: `featureGrid.append(...)` inside the loop, line 102. You cannot call `append` on nothing, so Chromium stops with `TypeError: Cannot read properties of null (reading 'append')`.

   The planner still worked because a script runs from the top down, and everything above line 102 had already run: the elements were found, the `submit` listener was connected and `updateSummary()` had run. The error stopped only what came after it, the cards. So the line in the message is where the `null` was used; the cause is wherever that variable got its value. (Project step 9; Module 11)
2. **The row that surprised you.** There is no single answer. A good answer names the row and quotes the Expected you wrote before the run and the Actual you got, on your computer or on the live site. Then it says what you changed, and which step of the nine caught it. For example: a row that passed locally and failed live because a file name had a capital letter, or a retest of row 3 that failed after row 6.
3. **The friend's `updateSummary`.** On load it shows **No tasks yet.**, which passes. After two tasks it shows **0 of 6 done**, and after one check, **1 of 6 done**. `document.querySelectorAll("li")` searches the whole page, and the four feature cards are `<li>` items too. On load the count was right only because `updateSummary()` runs before the loop builds the cards.

   When this function was written, in row 3, there were no cards: it passed every row 3 test (checked in Chromium: **0 of 2 done**, then **1 of 2 done**). Row 6 broke it. Retesting row 3 after row 6 catches it, which is why step 6 of the nine says to rerun every earlier row. The fix is `taskList.querySelectorAll("li")`, which searches inside the list only. (Project steps 6 and 9)

## Project checks

- **Step 2.** The sample's lines for rows 2 to 9. Yours will be worded differently; check that each layer is covered.

  - **Row 2.** *Structure:* An empty message paragraph under the form, tied to the box with `aria-describedby`. *Look:* The message in `--error`, with room kept for it. *Behavior:* If the trimmed text is empty: show the message, focus the box, stop; otherwise clear the message. *Test:* Empty and spaces add nothing and show the message; a real task clears it.
  - **Row 3.** *Structure:* A done line under Tasks; each task a label holding a checkbox and a span. *Look:* Box beside the words; struck-through words in `--muted`. *Behavior:* A `change` listener per box toggles `is-done`; `updateSummary` counts. *Test:* No tasks yet; 0 of 3; check gives 1 of 3 and a line; uncheck undoes both.
  - **Row 4.** *Structure:* None. *Look:* One media query from 700 px: `1fr 2fr`. *Behavior:* None. *Test:* 390 and 699 stack; 700 and 1200 side by side.
  - **Row 5.** *Structure:* A figure with the img (srcset, sizes, width, height, alt) and a caption. *Look:* The `img` rule; caption in `--muted`. *Behavior:* None. *Test:* The right file at 390, 800 and 1200; no sideways scroll; alt text.
  - **Row 6.** *Structure:* A Features section with an empty `ul`. *Look:* Grid with a gap; white cards. *Behavior:* The `features` array; `makeCard`; a `for...of` loop that appends. *Test:* One card per object, in order; `features.length` matches.
  - **Row 7.** *Structure:* None (JavaScript makes it). *Look:* Tag line in `--muted`; teal badge. *Behavior:* Tag line with `.join(", ")`; badge if `.includes("new")`. *Test:* Every tag line matches the array; one badge.
  - **Row 8.** *Structure:* None. *Look:* Two columns from 700 px, four from 1000 px, in that order. *Behavior:* None. *Test:* 1, 2 and 4 columns at 390, 800 and 1200.
  - **Row 9.** *Structure, Look and Behavior:* fix anything the checks find. *Test:* Keyboard, labels, alt text, contrast, no red lines, no `innerHTML`.

- **Step 4, continue alone.** The four lines of `addTask` for row 1:

  ```js
  const text = taskInput.value.trim();
  taskList.append(makeTask(text));
  taskInput.value = "";
  taskInput.focus();
  ```

  The sample's CSS for row 1. In the full file at the end of this part, these rules sit above `main` and the row 1 comment; the order of these rules does not change the result.

  ```css
  .site-header {
    background: var(--brand);
    color: var(--paper);
    padding: 20px 16px;
  }

  .site-header h1 {
    margin: 0;
  }

  .tagline {
    margin: 4px 0 0;
  }

  .panel {
    background: var(--paper);
    border: 1px solid var(--line);
    border-radius: 8px;
    padding: 16px;
  }

  .panel h2 {
    margin-top: 0;
    font-size: 1.2rem;
  }

  label {
    display: block;
    margin-bottom: 4px;
  }

  input[type="text"] {
    font: inherit;
    width: 100%;
    padding: 8px;
    margin-bottom: 8px;
    border: 1px solid #8a96a3;
    border-radius: 6px;
  }

  button {
    font: inherit;
    padding: 8px 14px;
    border: 1px solid var(--brand);
    border-radius: 6px;
    background: var(--brand);
    color: var(--paper);
    cursor: pointer;
  }

  .task-list {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  .task-list li {
    border-top: 1px solid var(--line);
    padding: 10px 0;
  }
  ```

- **Step 5, continue alone.** The three lines inside the `if` block: `taskError.textContent = "Type a task first.";`, `taskInput.focus();` and `return;`.
- **Step 6, continue alone.** Inside the `change` listener:

  ```js
  if (box.checked) {
    item.classList.add("is-done");
  } else {
    item.classList.remove("is-done");
  }
  updateSummary();
  ```

  `updateSummary` and the row 3 CSS are in the full files below.
- **Step 7.** The media query is at the end of the full `styles.css`, under `/* Wider screens */`. At first it holds only the `.layout` rule; row 8 adds the rest.
- **Step 8.** The `<figure class="hero">` is at the top of `<main>` in the full `index.html`, and its CSS is under `/* Row 5: the hero */`.
- **Step 9, continue alone.** The sample's other three objects are in the full `script.js`. `makeCard` for row 6, before row 7 changed it:

  ```js
  // makeCard: takes one feature object and returns a new card.
  function makeCard(feature) {
    const card = document.createElement("li");
    card.classList.add("card");
    const heading = document.createElement("h3");
    heading.textContent = feature.title;
    const text = document.createElement("p");
    text.textContent = feature.text;
    card.append(heading, text);
    return card;
  }
  ```

  And the loop, the last three lines of the file:

  ```js
  for (const feature of features) {
    featureGrid.append(makeCard(feature));
  }
  ```

- **Step 10, alone.** The finished `makeCard` is in the full `script.js`. The badge is made inside an `if`, so features without the tag never get one. A misspelled property name in one object, such as `tag:` instead of `tags:`, stops the loop at that object: see Problem 5 in Part 4, *Troubleshooting*.
- **Step 11, alone.** The second media query is the last block of the full `styles.css`.
- **Step 12.** The sample passed every check. With `--muted` set to `#9aa3ad`, the formula gives 2.56:1 on white, under the 4.5:1 that normal text needs.
- **Step 14.** The sample student's `explanation.md`, as a model. Yours describes your own page, in your own words. Notice that part 2 names real lines and says **why** they work, part 3 names its MDN pages and a Console check, and part 4 reports a real run.

  ```
  # How my Pocket Planner works

  ## 1. What it does
  Pocket Planner is one page with three parts. At the top is a picture of a notebook with a caption. In the middle, you type a task and add it with the Add task button or the Enter key; each task gets a checkbox, and a line counts how many are done. At the bottom, four feature cards are built from an array in script.js.

  ## 2. How it works, row by row
  Row 1. In index.html, a form holds the label Task, the text box and a submit button, so a click and the Enter key both fire one submit event. In script.js, addTask is the submit listener. It calls event.preventDefault() so the page does not reload, reads the box with .value.trim(), and appends the item that makeTask returns. Then it empties the box and puts the cursor back in it.

  Row 2. Before it adds anything, addTask checks text === "". If the text is empty, it writes "Type a task first." into the empty #task-error paragraph under the form, puts the cursor back in the box, and returns, so nothing is added. Because of .trim(), three spaces become "" too. The box has aria-describedby="task-error", so a screen reader reads the message with the field.

  Row 3. makeTask builds a label that holds a checkbox and a span with the words, so clicking the words checks the box. Each box gets its own change listener. It adds or removes the class is-done on its item, and the CSS rule .is-done span draws the line through the words. Then it calls updateSummary, which counts the items and the checked boxes inside the list and writes "No tasks yet." or "1 of 3 done".

  Row 4. .layout is a grid with one column. Inside @media (min-width: 700px) it gets the columns 1fr 2fr, so from 700 px the form sits beside the wider list. The media query comes after the base rule, so it wins.

  Row 5. The hero img has a srcset with three files and their w widths. sizes tells the browser the picture is 968 px wide from 1000 px, and the full width below that, so the browser can pick the smallest file that is big enough. width and height give the shape, 1200 by 480, so the space is kept while the file loads, and img { max-width: 100%; height: auto; } lets it shrink.

  Row 6. features is an array of four objects with title, text and tags. A for...of loop at the end of script.js passes each object to makeCard. makeCard makes an li with an h3 and a p, fills them with textContent, and the loop appends the card to #feature-grid. There is no innerHTML, so the text goes in exactly as I wrote it.

  Row 7. makeCard also adds a last line, "Tags: " + feature.tags.join(", "). If feature.tags.includes("new") is true, it first makes a p with the class badge and the text New, so the badge sits above the title.

  Row 8. .feature-grid is a grid with one column. The 700 px media query gives it two 1fr columns, and a second media query from 1000 px gives it four. The 1000 px block comes after the 700 px block. If it came first, the two-column rule would win at 1200 px.

  Row 9. One rule gives every button and every input a 3 px dark orange outline on :focus-visible, so the text box, the button and every checkbox show the same ring. My palest text is the gray --muted color, at 6.49:1 on the page background, and the ring is 5.02:1 on white.

  ## 3. The line I was least sure about
  const done = taskList.querySelectorAll("input:checked").length;

  I did not know that querySelectorAll could be called on an element instead of on document, and I had used :checked only with document. I read the MDN pages "Element: querySelectorAll() method" and ":checked". Called on taskList, it searches only inside the list, and input:checked matches only the boxes that are checked right now. To check, I added four tasks, checked the second one, and typed taskList.querySelectorAll("input:checked").length in the Console. It gave 1.

  ## 4. What breaks if I delete one line
  I picked event.preventDefault(); in addTask. My prediction: the form sends itself, the page reloads, and the new task is gone. I deleted the line and added "Buy milk" with Enter. The address ended in index.html? and the list was empty, with no red line in the Console. I put the line back and reran rows 1 to 3.

  ## 5. Code origin
  None. I typed every line, from the skeletons in the Module 13 packet or from my own notes.

  ## 6. What I would test next
  | Action | Expected |
  | --- | --- |
  | At 390 px, add one task that is a single 80-letter word with no spaces | The word stays inside the Tasks panel, and nothing scrolls sideways |
  | Add 30 tasks, then check the last one | "1 of 30 done", and the page scrolls down, nothing overlaps |
  | Add a task, then reload the page with F5 | The list is empty again: nothing is saved, as the brief says |
  ```

  The sample ran its own part 6 afterward. The 30 tasks gave **1 of 30 done** with nothing overlapping, and the reload emptied the list, as expected. The 80-letter word did **not** pass. At 390 px the page became 806 px wide and scrolled sideways, and at 1200 px the form panel was squeezed to 162 px while the list took 790 px. Row 8 tests normal text; no row tests a very long word. That is what "what I would test next" is for.

  Write it down as a GitHub Issue on the `pocket-planner` repository (Module 12) and fix it next time. The fix that worked on the sample is one rule, `.task-list span { overflow-wrap: anywhere; }` (MDN, *overflow-wrap*): with it, the page stayed 390 px wide and the panels went back to 317 px and 635 px at 1200. The value `break-word` did not help in this grid.
- **Step 15.** The finished sample files. They are the files of the sample's row 9 commit; the README and the explanation came after.

  `index.html`:

  ```html
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pocket Planner</title>
    <link rel="stylesheet" href="styles.css">
    <script src="script.js" defer></script>
  </head>
  <body>
    <header class="site-header">
      <h1>Pocket Planner</h1>
      <p class="tagline">Today's tasks, in your pocket.</p>
    </header>
    <main>
      <figure class="hero">
        <img src="images/hero-800.jpg"
             srcset="images/hero-400.jpg 400w,
                     images/hero-800.jpg 800w,
                     images/hero-1200.jpg 1200w"
             sizes="(min-width: 1000px) 968px, 100vw"
             width="1200" height="480"
             alt="An open notebook with a short list of tasks, two of them ticked">
        <figcaption>Write it down, tick it off.</figcaption>
      </figure>
      <div class="layout">
        <section class="panel">
          <h2>Add a task</h2>
          <form id="task-form">
            <label for="task-input">Task</label>
            <input id="task-input" type="text" aria-describedby="task-error">
            <button type="submit">Add task</button>
          </form>
          <p id="task-error" class="message"></p>
        </section>
        <section class="panel">
          <h2>Tasks</h2>
          <p id="summary" class="summary"></p>
          <ul id="task-list" class="task-list"></ul>
        </section>
      </div>
      <section class="features">
        <h2>Features</h2>
        <ul id="feature-grid" class="feature-grid"></ul>
      </section>
    </main>
  </body>
  </html>
  ```

  `styles.css`:

  ```css
  /* styles.css: Pocket Planner */

  :root {
    --ink: #1d2733;
    --muted: #4f5a66;
    --brand: #2f5d8a;
    --paper: #ffffff;
    --page: #f4f6f8;
    --line: #d5dbe1;
    --focus: #b45309;
    --error: #b3261e;
    --new: #0f766e;
  }

  *, *::before, *::after {
    box-sizing: border-box;
  }

  body {
    margin: 0;
    font-family: system-ui, sans-serif;
    background: var(--page);
    color: var(--ink);
  }

  .site-header {
    background: var(--brand);
    color: var(--paper);
    padding: 20px 16px;
  }

  .site-header h1 {
    margin: 0;
  }

  .tagline {
    margin: 4px 0 0;
  }

  main {
    max-width: 1000px;
    margin: 0 auto;
    padding: 16px;
  }

  /* Row 1: the panels, the form and the list */
  .layout {
    display: grid;
    gap: 16px;
  }

  .panel {
    background: var(--paper);
    border: 1px solid var(--line);
    border-radius: 8px;
    padding: 16px;
  }

  .panel h2 {
    margin-top: 0;
    font-size: 1.2rem;
  }

  label {
    display: block;
    margin-bottom: 4px;
  }

  input[type="text"] {
    font: inherit;
    width: 100%;
    padding: 8px;
    margin-bottom: 8px;
    border: 1px solid #8a96a3;
    border-radius: 6px;
  }

  button {
    font: inherit;
    padding: 8px 14px;
    border: 1px solid var(--brand);
    border-radius: 6px;
    background: var(--brand);
    color: var(--paper);
    cursor: pointer;
  }

  button:focus-visible,
  input:focus-visible {
    outline: 3px solid var(--focus);
    outline-offset: 2px;
  }

  .task-list {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  .task-list li {
    border-top: 1px solid var(--line);
    padding: 10px 0;
  }

  /* Row 2: the message */
  .message {
    color: var(--error);
    min-height: 1.5em;
    margin-bottom: 0;
  }

  /* Row 3: the checkboxes and the done count */
  .summary {
    color: var(--muted);
    margin-top: 0;
  }

  .task-list label {
    display: flex;
    gap: 10px;
    align-items: center;
    margin: 0;
  }

  .task-list input {
    width: 20px;
    height: 20px;
  }

  .is-done span {
    text-decoration: line-through;
    color: var(--muted);
  }

  /* Row 5: the hero */
  img {
    max-width: 100%;
    height: auto;
    display: block;
  }

  .hero {
    margin: 0 0 16px;
  }

  .hero img {
    border-radius: 8px;
  }

  .hero figcaption {
    color: var(--muted);
    margin-top: 6px;
  }

  /* Rows 6 and 7: the feature cards */
  .features h2 {
    font-size: 1.2rem;
    margin: 24px 0 12px;
  }

  .feature-grid {
    list-style: none;
    padding: 0;
    margin: 0;
    display: grid;
    gap: 16px;
  }

  .card {
    background: var(--paper);
    border: 1px solid var(--line);
    border-radius: 8px;
    padding: 16px;
  }

  .card h3 {
    margin: 0 0 8px;
    font-size: 1.05rem;
  }

  .card p {
    margin: 0 0 8px;
  }

  .card .tags {
    color: var(--muted);
    font-size: 0.9rem;
    margin: 0;
  }

  .badge {
    display: inline-block;
    background: var(--new);
    color: var(--paper);
    font-size: 0.8rem;
    font-weight: bold;
    padding: 2px 8px;
    border-radius: 999px;
  }

  /* Wider screens */
  @media (min-width: 700px) {
    .layout {
      grid-template-columns: 1fr 2fr;
      align-items: start;
    }

    .feature-grid {
      grid-template-columns: 1fr 1fr;
    }
  }

  @media (min-width: 1000px) {
    .feature-grid {
      grid-template-columns: 1fr 1fr 1fr 1fr;
    }
  }
  ```

  `script.js`:

  ```js
  // script.js: Pocket Planner

  // ===== Find elements =====
  const taskForm = document.querySelector("#task-form");
  const taskInput = document.querySelector("#task-input");
  const taskError = document.querySelector("#task-error");
  const taskList = document.querySelector("#task-list");
  const summary = document.querySelector("#summary");
  const featureGrid = document.querySelector("#feature-grid");

  // ===== The data =====
  const features = [
    {
      title: "Add in a second",
      text: "Type a task and press Enter. It goes to the end of your list.",
      tags: ["tasks", "keyboard"]
    },
    {
      title: "Tick it off",
      text: "Check a box to strike a task through. The count keeps up.",
      tags: ["tasks"]
    },
    {
      title: "Any screen",
      text: "One column on a phone, side by side on a laptop.",
      tags: ["layout"]
    },
    {
      title: "No mouse needed",
      text: "Tab, Enter and Space do everything a click can.",
      tags: ["keyboard", "new"]
    }
  ];

  // ===== Define behavior =====

  // updateSummary: shows how many tasks are done, or "No tasks yet."
  function updateSummary() {
    const total = taskList.querySelectorAll("li").length;
    const done = taskList.querySelectorAll("input:checked").length;
    if (total === 0) {
      summary.textContent = "No tasks yet.";
    } else {
      summary.textContent = done + " of " + total + " done";
    }
  }

  // makeTask: takes the task text and returns a new list item with a checkbox.
  function makeTask(text) {
    const item = document.createElement("li");
    const label = document.createElement("label");
    const box = document.createElement("input");
    box.type = "checkbox";
    const words = document.createElement("span");
    words.textContent = text;
    box.addEventListener("change", function () {
      if (box.checked) {
        item.classList.add("is-done");
      } else {
        item.classList.remove("is-done");
      }
      updateSummary();
    });
    label.append(box, words);
    item.append(label);
    return item;
  }

  // addTask: runs on submit; adds the task, or shows a message when it is empty.
  function addTask(event) {
    event.preventDefault();
    const text = taskInput.value.trim();
    if (text === "") {
      taskError.textContent = "Type a task first.";
      taskInput.focus();
      return;
    }
    taskError.textContent = "";
    taskList.append(makeTask(text));
    taskInput.value = "";
    taskInput.focus();
    updateSummary();
  }

  // makeCard: takes one feature object and returns a new card.
  function makeCard(feature) {
    const card = document.createElement("li");
    card.classList.add("card");
    if (feature.tags.includes("new")) {
      const badge = document.createElement("p");
      badge.classList.add("badge");
      badge.textContent = "New";
      card.append(badge);
    }
    const heading = document.createElement("h3");
    heading.textContent = feature.title;
    const text = document.createElement("p");
    text.textContent = feature.text;
    const tagLine = document.createElement("p");
    tagLine.classList.add("tags");
    tagLine.textContent = "Tags: " + feature.tags.join(", ");
    card.append(heading, text, tagLine);
    return card;
  }

  // ===== Connect events, and build the page =====
  taskForm.addEventListener("submit", addTask);
  updateSummary();

  for (const feature of features) {
    featureGrid.append(makeCard(feature));
  }
  ```
