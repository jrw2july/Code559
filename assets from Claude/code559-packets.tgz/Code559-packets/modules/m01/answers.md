# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **The part never sent to the server.** The anchor, `#contact`. MDN says the part after `#` "is never sent to the server with the request." The browser keeps it and uses it to scroll to the element with `id="contact"` once the page arrives. (Core concept 2)
2. **A change does not show.** First, check that you saved: a dot on the VS Code tab instead of an ✕ means unsaved changes. Press Ctrl+S, then F5. Second, check that the browser shows the file you are editing: the address bar should end with the right folder and file name, for example `my-site/about.html`. (Core concept 3)
3. **What would you test with a third page.** Every nav link on every page. Each page now has four links, and there are three pages, so that is four × three = twelve clicks. Before you test, check that the new link was added to the nav on all three pages, not only on the new one, and that the Contact link still says `index.html#contact` on every page. (Core concept 8)

## Common misconception

*"If the page looks right in my browser, the HTML is correct."* It is not that simple. The browser fixes many mistakes quietly and never shows an error. In Exercise step 8, a missing `</h1>` did not stop the page; the browser guessed where the heading ended. A guess can look right in one place and wrong in another. And some readers do not see the page at all: a screen reader reads the headings, the `lang`, and the `alt` text, and a search engine reads the structure. Your page can look fine and still have a missing `alt`, a heading chosen for its size, or a broken link you have not clicked yet. Looking right is a first check, not proof. Read your tags, and test every link. (Exercise step 8; Core concepts 7 and 8)

## Exercise checks

- **Step 6.** Your page shows one large heading, a paragraph, three smaller headings, a bulleted list, a link and your picture. The tab says `Practice Page`.
- **Step 7.** Four bullets after you add the fourth `<li>`. The link opens MDN, and **Back** returns to your page.
- **Step 8.** With `</h1>` missing, the paragraph under the main heading becomes as large and bold as the heading. The rest of the page looks normal, because the browser ends the heading at the next `<h2>`.
- **Step 9.** With `src="imge-one.jpg"`, the picture disappears and your `alt` text shows in its place.
- **Step 10.** The wrong part is the **host**: `developer.mozilla.orgg` is not a server that answers.
- **Steps 13 to 16.** `git log --oneline` shows one commit, `gh repo create` ends with a ✓ line saying your commits were pushed, and your page opens at `https://your-username.github.io/my-site/` with its picture.

## Self-assessment questions

1. **Why Contact worked on one page and failed on the other.** `href="#contact"` has no file name, so the browser looks for `id="contact"` on the page you are already on. The Home page has that id on its Contact section, so the link works there. The About page has no element with that id. So the address ends in `about.html#contact`, you stay on the About page, and nothing moves. There is no error message. `href="index.html#contact"` names the file first, so it works from every page. (The brief; Project steps 10 and 11)
2. **A mistake you made.** There is no single answer. A good answer names the mistake, quotes what the page or the terminal really showed, and says how you found the cause, for example by reading your tags top to bottom, or by checking the end of the address bar.
3. **A third page.** First, create the new file with the full skeleton and its own `<title>`. Second, copy the header and footer from `index.html` into it, and write its `<main>` with sections that each start with an `<h2>`. Third, add a link to the new page in the nav of every page, the two old ones too, so the headers still match letter for letter. Fourth, save, open the new page and press F5. Fifth, compare the headers and footers of all three pages line by line. Sixth, test every nav link on every page: four links on three pages is twelve clicks, and Contact must still end in `index.html#contact`. Last, publish and run the link test again on the live site. (The brief; Project steps 7, 8, 10, 13 and 14)

## Project checks

- **Brief.** Two pages, `index.html` and `about.html`, each with the full skeleton, its own `<title>`, the same header and footer, and a `<main>` made of sections that each start with an `<h2>`. The About page has your picture with `alt` text. (The brief)
- **Step 6.** The Home page shows your site name as the largest heading, the three links on one line, your sections, and the footer line. Without CSS, the header, nav, main, section and footer elements add no boxes or colors of their own. (Step 6; Core concept 8)
- **Step 10.** All six nav clicks go where the checklist says. Contact goes to `index.html#contact` from both pages.
- **Step 11.** With `href="#contact"` on the About page, the address ends in `about.html#contact` and you stay on the About page, because the About page has no element with `id="contact"`. (Step 11; Core concept 8)
- **Step 12.** With `href="abuot.html"`, the browser shows an error page. The path was wrong; the link words were fine.
- **Finishing work.** `git status` says `nothing to commit, working tree clean`, `git log --oneline` shows two commits, and the live address shows your new Home page with working links. (Part 3, steps 6 to 8)
