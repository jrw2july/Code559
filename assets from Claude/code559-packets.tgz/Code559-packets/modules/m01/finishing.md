# Finishing work in Git

Your new pages work on your computer. Now you put them online with the save routine from the lesson's "Save your work" box: `git status`, `git add .`, `git commit`, `git push`, then check the live page. You use this routine at the end of every module from now on.

Items marked **NEW** are new in this part. The others repeat what you did in the Exercise.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **See what changed (NEW: `git status` after a change).** Type:

   ```
   git status
   ```

   Git lists the changes it sees but has not saved yet. You should see `index.html` under **Changes not staged for commit**, marked `modified:`, because you replaced its content. You should see `about.html` under **Untracked files**, because Git has never saved it before. `image-one.jpg` is not listed: it has not changed since your first commit, so Git has nothing new to save. If `git status` lists a file you do not expect, open it and check before you go on.
3. **Stage the changes.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. (A warning that mentions LF and CRLF is harmless.) Run `git status` again. Now both files are under **Changes to be committed**: `new file:   about.html` and `modified:   index.html`.
4. **Commit.** Type:

   ```
   git commit -m "Add Home and About pages"
   ```

   Git prints a short summary. The first line starts with `[main` and a seven-character commit id, then your message. A later line says `create mode 100644 about.html`, which means a new file was saved. Your commit id and numbers will differ. Write messages that say what you changed, so you can find a change again later.
5. **Push (NEW: `git push` on its own).** Type:

   ```
   git push
   ```

   In the Exercise, `gh repo create … --push` uploaded your first commit and connected your folder to GitHub. Now plain `git push` is enough. It prints a few lines; the last one ends in `main -> main`, which means your `main` branch on GitHub now has your new commit.
6. **Check that Git is done.** Type `git status` once more. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. You should see two commits: `Add Home and About pages` on top, and `Add my first page` under it.
7. **Check the live page (NEW: testing the live site).** GitHub Docs says "It can take up to 10 minutes for changes to your site to publish" (*Creating a GitHub Pages site*). Wait a few minutes, then open `https://your-username.github.io/my-site/` and press F5. You should see your new Home page, not the practice page. If you still see the practice page, wait a few more minutes and press F5 again.
8. **Test the live links.** Run the link test from Project step 10 again, on the live site. Click all three nav links on both pages, and check that the picture shows on the About page. A link or picture can work on your computer and fail online, usually because of capital letters in a file name (see *Troubleshooting*).

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows two commits. Your live address shows your Home page, and all six nav clicks work there too.
