# Project: Home and About pages

*Your hands, about 75 minutes (estimate).* In the Exercise you published your practice page as the first page of `my-site`. Now you replace it with the start of the personal website you will build all course: a Home page and an About page. You use only the HTML from this module. The pages will look plain, in black and white with blue links. That is correct. Styling starts in Module 2.

## The brief

When you finish, `my-site` holds two pages and one picture: `index.html` (Home), `about.html` (About) and `image-one.jpg`. Both pages are online at `https://your-username.github.io/my-site/`, and a visitor can click between them.

Each page has the full skeleton from Concept 4: `<!DOCTYPE html>`, `<html lang="en">`, and a `<head>` with `<meta charset="utf-8">`, the viewport line and a `<title>`. Each page has its own title, so the two browser tabs are easy to tell apart. Use `Home - Your Name` and `About - Your Name`, with your own name or the name you want on your site.

Each page's body has four parts, in this order:

- A `<header>` with an `<h1>` that holds your site name, and a `<nav>` with three links. The link words are exactly **Home**, **About** and **Contact**. The header is the same, letter for letter, on both pages.
- One `<main>` with the page's own content in `<section>` elements. Each section starts with an `<h2>`.
- A `<footer>` with one short line, for example `Built by hand by Your Name.` The footer is also the same on both pages.

The Home page's main area has three sections: **Welcome** (a short paragraph about the site), **What you will find here** (a list of three things), and **Contact** (a paragraph with one link, for example to your GitHub profile at `https://github.com/your-username`). The Contact section has `id="contact"`, so the Contact link can jump to it.

The About page's main area has two sections: **About me** (a paragraph about you, and your picture with `alt` text and `width="320"`) and **What I am learning** (a list of three things).

A visitor can do four things: open your address and see the Home page; click **About** to get the About page; click **Home** to come back; and click **Contact** from either page to reach the Contact section of the Home page. All the words are yours. Only the headings, the link words and the file names above need to match.

![The finished Home page: the site name as a large heading, the links Home, About and Contact on one line, then the sections Welcome, What you will find here (three bullets) and Contact (a link to GitHub), and a footer line.](images/p01-home.png)
*One example of a finished Home page. With no CSS, the three nav links sit on one line, and the header, main and footer are invisible: only their content shows. Measured at 800 px wide. (real: rendered in Chromium at 800 px)*

![The finished About page: the same site name and links, then About me with a paragraph and a picture, What I am learning with three bullets, and the same footer line.](images/p01-about.png)
*The About page. The header and footer match the Home page exactly; only the main content changed. (real: rendered in Chromium at 800 px)*

## The steps

Type every line. Do not paste. There is one exception, and it is on purpose: in step 7 you copy the header and footer from one page to the other, because that is how plain HTML pages share navigation (Concept 8).

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder. The Explorer should show `index.html` and `image-one.jpg` from the Exercise. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`. You will need it at the end.
2. **Plan on paper.** Write your site name, the three things for the Home page list, and the three things for the About page list. Then sketch both pages as boxes: header, main with its sections, footer.
3. **Predict.** Next to your sketch, write how many headings each page will show, how many bullets, and how many links. You will check this in step 6.
4. **Start the new Home page.** Open `index.html`. Your practice page is in it. You are replacing it, so select everything (**Ctrl+A**), delete it, and type the skeleton below. Your practice page is not lost: it is still in `practice-01`, and Git kept the published copy in your first commit.

   ```html
   <!DOCTYPE html>
   <html lang="en">
     <head>
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1">
       <title>Home - Your Name</title>
     </head>
     <body>
       <header>
         <h1>Your Name</h1>
         <nav>
           <a href="index.html">Home</a>
           <a href="about.html">About</a>
           <a href="index.html#contact">Contact</a>
         </nav>
       </header>
       <main>
         <section>
           <h2>Welcome</h2>
           <p>One or two sentences about your site.</p>
         </section>
         <!-- Continue alone: a section "What you will find here" with a list of three items,
              then a section with id="contact", an h2 "Contact", and a paragraph with one link. -->
       </main>
       <footer>
         <p>Built by hand by Your Name.</p>
       </footer>
     </body>
   </html>
   ```

   Put your own name in the `<title>`, the `<h1>` and the footer. The HTML comment marks where you continue alone. When you have typed your two sections, delete the comment. A comment never shows on the page, but a leftover one is clutter.
5. **Check your tags.** Before you look at the page, read your code from top to bottom. Every `<section>` needs its `</section>`, every `<li>` sits inside the `<ul>`, and the `id` is written `id="contact"`, all lowercase, with no `#`. The `#` belongs only in the link.
6. **Run.** Save with Ctrl+S. Open `index.html` in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window). After each save, press **F5** to reload. Compare the page with your prediction from step 3. The tab should say `Home - Your Name`.
7. **Make the About page.** In the Explorer, create a new file called `about.html`. Type the skeleton (doctype, `html`, `head` with the two `meta` lines) and give it the title `About - Your Name`. Then copy the whole `<header>…</header>` block from `index.html` and paste it as the first thing inside `<body>`. Do the same with the `<footer>…</footer>` block, at the end of the body. Between them, type the `<main>`:

   ```html
   <main>
     <section>
       <h2>About me</h2>
       <p>Two or three sentences about you.</p>
       <img src="image-one.jpg" alt="Describe your picture in one short sentence" width="320">
     </section>
     <!-- Continue alone: a section with an h2 "What I am learning" and a list of three items. -->
   </main>
   ```

   Write real `alt` text for your picture, as in Concept 7. If your picture is a `.png`, use its real name here, as you did in the Exercise.
8. **Run again.** Save, open `about.html` in the browser, and press F5. You should see the same header and footer as the Home page, your About content, and your picture.
9. **Modify.** Add a fourth item to the About page's list. Save and refresh. Then change only the text inside `<title>` on the About page. Save and refresh, and check that only the tab changed. Put back the title you want.
10. **Test every link.** Start on the Home page. Click each nav link, use the browser's **Back** button, and tick the box. Then do the same from the About page. Each time, look at the end of the address bar as well as the page.

    - [ ] Home page → **Home**: the Home page reloads; the address ends in `index.html`
    - [ ] Home page → **About**: the About page opens; the address ends in `about.html`
    - [ ] Home page → **Contact**: the address ends in `index.html#contact`
    - [ ] About page → **Home**: the Home page opens
    - [ ] About page → **About**: the About page reloads
    - [ ] About page → **Contact**: the Home page opens; the address ends in `index.html#contact`
    - [ ] Home page → the link in the Contact section opens the right website

    That is six nav clicks: three links on two pages (Concept 8). If your Home page is short, the Contact link may not seem to move the page, because there is nowhere to scroll. That is fine when the address ends in `#contact`. To see the jump, make the browser window shorter and click it again.
11. **Break it on purpose.** On the About page only, change the Contact link to `href="#contact"`. Save and refresh. Predict before you click: what will happen? Then click **Contact**.

    The address now ends in `about.html#contact`, and you are still on the About page. Nothing on the screen moves, and there is no error message. The browser looked for `id="contact"` on the About page and found nothing (Concept 8). This is why you test every link on every page: the same nav can work on one page and fail on the other. Put back `href="index.html#contact"`, save, refresh, and click Contact again to check the fix.
12. **Debug.** On the Home page, change the About link to `href="abuot.html"`. Save, refresh and click it. Instead of your About page, the browser shows an error page, because there is no file with that name. Which part was wrong: the link words, or the path? Fix the path and test the link again.
13. **Compare the two headers.** Switch between the `index.html` and `about.html` tabs in VS Code and read the two `<header>` blocks line by line. They must match exactly. Do the same for the footers.
14. **Put it online.** Go to Part 3, *Finishing work in Git*, and publish both pages with the save routine. Then run the link test from step 10 again on the live site.
