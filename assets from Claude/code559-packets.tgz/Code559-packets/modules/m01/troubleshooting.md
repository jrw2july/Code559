# Troubleshooting: five common problems

Each problem has the symptom you see, why it happens, and the fix. Try the fix, then run the link test from Project step 10 again.

### 1. The About link works on your computer but gives a 404 online

**Symptom.** On your computer, clicking **About** opens your About page. On your live site, the same click shows a GitHub "404" page.

**Why.** The name in the link and the name of the file differ only in capital letters, for example `href="about.html"` and a file called `About.html`. Windows treats them as the same file, so the link works on your computer. A web server may not, so online the file is not found. GitHub Docs gives the same warning for the home page: `Index.html` will not work in place of `index.html` (*Troubleshooting 404 errors for GitHub Pages sites*).

**Fix.** Look at the file name in the VS Code Explorer and make every link match it exactly, on both pages. Save, run the save routine, and test again online. As in the lesson's Exercise step 16, fix the link, not the file name: on Windows, Git keeps remembering the old name when only capital letters change. From now on, name every file in lowercase.

### 2. The live site still shows the old practice page

**Symptom.** You pushed, opened your address, and still see the practice page from the Exercise.

**Why.** Usually GitHub Pages has not finished publishing yet. GitHub Docs says "It can take up to 10 minutes for changes to your site to publish" (*Creating a GitHub Pages site*). Less often, the push did not happen.

**Fix.** Wait a few minutes and press F5 on the live page. If it still shows the old page, type `git status` in the `my-site` terminal. If it lists changed files, you skipped `git add .` or `git commit`: finish the routine. Then open `https://github.com/your-username/my-site` in the browser. If `about.html` is not in the file list there, the push did not reach GitHub: read the message from `git push` again, and see problem 3.

### 3. `git push` stops with an error

**Symptom.** `git push` prints a line starting with `fatal:` instead of finishing with `main -> main`.

**Why.** There are two common causes. If the message says `No configured push destination`, this folder was never connected to GitHub: step 14 of the Exercise was run in another folder, or not at all. If the message is about signing in or permission, the GitHub CLI is not logged in.

**Fix.** For a sign-in problem, run `gh auth status` and check that you are logged in (Module 0, step 9). For `No configured push destination`, first open `https://github.com/your-username/my-site`. If no such repository exists, run step 14 of the Exercise again in `my-site`. If the repository does exist, connect the folder to it with these two lines, using your own username:

```
git remote add origin https://github.com/your-username/my-site.git
git push --set-upstream origin main
```

After that, plain `git push` works.

### 4. `about.html` opens as plain text

**Symptom.** You double-click your new About page and see the code, or Windows calls it a "Text Document".

**Why.** With file extensions hidden, the file was saved as `about.html.txt`. A link to `about.html` will not find it either.

**Fix.** This is the same problem as in the Module 0 packet. Turn on **View → Show → File name extensions** in File Explorer, rename the file so it ends in `.html` only, and accept the warning about changing the extension. In VS Code, check the tab name after saving.

### 5. The picture on the About page does not show

**Symptom.** Where your picture should be, you see a small broken-image icon and your `alt` text.

**Why.** The `src` does not match the picture's file name and place. Either the name is spelled differently (`image-one.JPG`, `imageone.jpg`, `.png` instead of `.jpg`), or the picture is not in `my-site` next to `about.html`.

**Fix.** Check that the picture is in the VS Code Explorer under `my-site`, at the same level as `about.html`. If it is missing, copy it from `practice-01`. Then copy its exact name into the `src`, letter for letter. Save and refresh. If it works on your computer but not online, it is the capital-letter problem from problem 1.
