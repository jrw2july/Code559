# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 2. If a line is a 1 or a 2, reread that Core Concept and redo its Exercise or Project step.

## Rubric

- I can explain what the client and the server do when I open a page
- I can name the scheme, host, path and anchor in a URL
- I can type the full HTML skeleton from memory and say what each line is for
- I can use headings, paragraphs and lists for their meaning, not their size
- I can write links to another site, to another page, and to an id on a page
- I can add an image with a correct src and useful alt text
- I can build a page from header, nav, main, section and footer, and share the nav across pages
- I can test every link on every page, and publish a change with the save routine

## Three questions to answer in writing

1. In Project step 11, the Contact link worked on one page and failed on the other. Explain why, in your own words.
2. Pick one mistake you made in this module. What did the page or the terminal show, and how did you find the cause?
3. Your site gets a third page. List everything you must change and test, in order.
