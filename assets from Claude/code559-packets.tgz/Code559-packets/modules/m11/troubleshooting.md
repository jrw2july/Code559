# Troubleshooting: five common problems

Each problem has the symptom you see, why it happens, and the fix. Problems 3 to 5 were made on purpose in the sample and run in Chromium 141, with the files opened from disk. Problems 1 and 2 happen on the live site, which could not be reached when this packet was made. For Problem 1, the sample served its files from a small web server on the same computer, to see what Chromium prints when a file is missing. After each fix, run the failing row again, then the rest of its section.

### 1. A row passes on your computer and fails on the live site

**Symptom.** On the live Interests page, the buttons do nothing, or the photo is a broken picture. On your computer, the same row passes. The live Console has a red line that starts with `Failed to load resource: the server responded with a status of 404`, with a file name beside it. The words in brackets after `404` depend on the server.

**Why.** 404 means the server has no file by that name. Your computer forgave something the live site does not:

| What was wrong | How to see it |
|---|---|
| Capital letters differ, such as `Gallery.js` in the folder and `gallery.js` in the `<script>` line | Windows treats them as the same name; GitHub Pages does not (Module 1, Exercise step 16). In the sample, a server that tells capitals apart gave the 404 above for `gallery.js`. |
| The file was never committed | `git status` lists it under **Untracked files** |
| The file was committed but not pushed | `git status` says `Your branch is ahead of 'origin/main'` |

**Fix.** Read the file name beside the red line and compare it with the Explorer, letter by letter. Change the name in the HTML to match the file, as Module 1 advised, rather than renaming the file. Then run the save routine and wait a few minutes before you test live again.

### 2. The live site still acts like the old version

**Symptom.** You pushed a fix, but the live row still fails the old way.

**Why.** Either GitHub Pages has not published the new version yet (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), or your browser shows a copy it saved earlier (Module 9).

**Fix.** Check that `git status` says your branch is up to date with `origin/main`. Wait a few minutes, then press **Ctrl+Shift+R** on the page to reload it without the saved copy, and run the row again.

### 3. A Console check gives `Cannot read properties of null`

**Symptom.** You type a row's check, such as `document.querySelector("#gallery-photo").alt`, and the Console answers with a red line instead of a value:

```
Uncaught TypeError: Cannot read properties of null (reading 'alt')
```

**Why.** The selector found nothing on the page you are on, so `querySelector` gave `null`, and `null` has no `alt` (Core concept 4). In the sample, this happened in two ways: the check was typed on the About page, which has no gallery, and `document.querySelector("#question2").ariaExpanded` was typed without the dash in `question-2`. That gave the same message, ending in `(reading 'ariaExpanded')`.

**Fix.** Check which page the tab shows. Then type the selector alone, as in Core concept 5. If it gives `null`, compare it with the id in the HTML, letter by letter. The page's own script is not to blame: this error comes from the line you typed.

### 4. A row fails, but the code is right

**Symptom.** A row's Actual does not match, yet the feature seems to work. In the sample, the Rate page's first row expected a ring on number 1 after a mouse click on Send rating. The message showed, but no ring did (Project step 12).

**Why.** The Expected contradicted the brief. The Module 10 brief says focus goes to 1 and the ring shows only with the keyboard. Focus did move to 1. The ring rule uses `:focus-visible`, and Chromium did not show that ring after a mouse click. With Tab and Enter, the ring showed.

**Fix.** Before you change code, read the brief for that feature. If the page does what the brief says, change the Expected, and write why in a few words. If the page does not, change the code. Change only one of the two, then rerun the row.

### 5. The plan does not show as a table

**Symptom.** In the preview (**Ctrl+Shift+V**) or on GitHub, some rows show as a line full of `|` signs instead of a table row.

**Why.** A table has strict rules. In VS Code's preview, which is built on the markdown-it library (VS Code Docs, *Markdown and Visual Studio Code*), the sample broke a table three ways:

| What was wrong | What the preview showed |
|---|---|
| No `\| --- \| --- \| --- \|` line under the column names | No table at all; every line ran together as one paragraph |
| An empty line between two rows | The table stopped at the empty line; the rows after it showed as plain text |
| A `\|` inside a cell, such as an Action with `\|\|` | The cell was cut in two, and the columns shifted |

There is a fourth rule for GitHub: "You must include a blank line before your table in order for it to correctly render" (GitHub Docs, *Organizing information with tables*). The VS Code preview showed a table even without that blank line, so check it by eye.

**Fix.** Give each table its `| --- |` line, no empty lines inside it, and one empty line before it. Write a `|` inside a cell as `\|`, or say it in words.
