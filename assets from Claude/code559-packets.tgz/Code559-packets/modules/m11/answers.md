# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **`null` at line 14.** First check what the message says: the thing before `.addEventListener` on line 14 holds `null`. So the mistake is usually **not** on line 14. Line 14 is only where `null` was used. Find the `querySelector` line that gave that variable its value, usually higher up, in block 1. Compare its selector with the id or class in the HTML, letter by letter, including the `#` or `.`. Then type that `querySelector` call alone in the Console: `null` confirms it. Line 14 itself is wrong only if it uses the wrong variable name for an element that exists. (Core concepts 2, 4 and 5)
2. **A bug with no red line.** A red line appears only when JavaScript cannot go on. A logic error is code that runs from start to end and does the wrong thing, so there is nothing to stop and nothing to print. In the Exercise, the count said **Tip 0 of 3** on the first tip: `index` starts at 0, and the code showed it without adding 1. The class-name mismatch (`visible` against `.is-visible`) and the "Show help" `<div>` that Tab skips also printed nothing. Only a written Expected shows these bugs. (Core concepts 1 and 10)
3. **What would you test? A fourth tip.** Every row whose result depends on how many tips there are, and their Expected changes first: the load row now expects **Tip 1 of 4**, and the two wrap-around rows change most. Previous on the first tip should now land on the fourth tip, **Tip 4 of 4**, and Next on the last tip now starts from tip 4. The two form rows matter too, because the "Added" message counts the tips. The help and Tab rows do not touch the array, but a rerun of the whole table costs two minutes and catches what you did not think of. (Core concepts 10 and 11)

## Common misconception

*"The error is on the line the Console points to."* The Console points to where JavaScript **stopped**, which is where a bad value was used. That is often not where the value was made. In the Exercise, the red line said `script.js:19`, `tipText.textContent = …`, but the mistake was the selector `#tip-txt` on line 8. Line 8 ran without complaint and stored `null`. Line 19 was the first to use it. MDN's troubleshooting page warns that "the error will not necessarily be on that line." So you read the location as a starting point, follow the `at` lines, and trace the bad value back to where it was made. (Core concepts 2 and 4)

## Exercise checks

These are the results with the lesson's code, checked in Chromium 141 with the files opened from disk.

- **Step 5.** Bug 1: `tipText` is `null`, because `#tip-txt` does not match `id="tip-text"`. `document.querySelector("#tip-txt")` gives `null` in the Console, and `document.querySelector("#tip-text")` gives the paragraph. Change the selector to `#tip-text`. After F5 the card shows **Save before you refresh.** and **Tip 0 of 3**, with no red line. (Core concepts 4 and 5)
- **Step 6.** Every row fails at first. Load: **Tip 0 of 3**. Next once: the second tip with **Tip 1 of 3**. Previous on the first tip: the third tip with **Tip 2 of 3**. Next on the last tip: no tip text and **Tip 3 of 3**. Empty submit: **Added. There are now 4 tips.** Spaces only: **Added. There are now 5 tips.** Show help: nothing. Tab: Previous, Next, the text box and Add tip get rings, then focus leaves the page; "Show help" is never reached.
- **Step 7.** One change per bug. Bug 2: `"Tip " + (index + 1) + " of "`. Bug 3: `if (index >= tips.length)`. Bug 4: trim the text and stop on an empty box, as in Module 10:

  ```js
    const text = newTip.value.trim();
    if (text === "") {
      formMessage.textContent = "Please type a tip first.";
      return;
    }
  ```

  With these, rows 1 to 6 pass: **Tip 1 of 3**, **Tip 2 of 3**, **Tip 3 of 3** for Previous on the first tip, **Tip 1 of 3** for Next on the last tip, and **Please type a tip first.** for both bad submits, with the count still **Tip 1 of 3**. (Core concepts 6, 7 and 11)
- **Step 8.** With `>` back in place, row 4 shows no tip text and **Tip 4 of 3**: `index` reached 3, one past the last tip. Put `>=` back and row 4 passes again. (Core concept 11)
- **Step 9.** Bug 5: change `toggle("visible")` to `toggle("is-visible")`. A click on "Show help" then shows the help text, and a second click hides it. (Core concept 6)
- **Step 10.** Bug 6: make "Show help" a real button, keeping its id and class:

  ```html
  <button type="button" class="help-toggle" id="help-toggle">Show help</button>
  ```

  Tab now goes Previous, Next, the text box, Add tip, Show help, each with the dark orange ring, and Enter on Show help opens the help text. (Core concept 9)
- **Step 11.** All eight rows pass. Good extra rows: a real tip, then Next until it shows (**Tip 4 of 4**); a tip with spaces around it, to check it is trimmed; Shift+Tab back through the page.

## Self-assessment questions

1. **One id, six failing rows.** The counter's id changed in the HTML, so line 6 of `gallery.js` stored `null` in `counter`. `showPhoto` sets the photo, the alt text and the caption first, and the counter last. So every call moved the photo and then stopped with a `TypeError` on line 46. That call happens at load and on every click, so every gallery row that checks the counter failed: load, Next once, both wrap-arounds and the keyboard row. The load error is also a red line on the Interests page, so the "No red line on any page" row failed. The alt row passed, because the alt is set on line 44, before the line that fails. You start with the first failing row because it is the simplest: no clicks, one red line, one stack to read. Its cause is often the cause of the rows after it, as here. (Project steps 10 and 11)
2. **Your own failing row.** There is no single answer. A good answer quotes the Expected as you wrote it before the test, gives the Actual in the words you wrote, names the first clue (a red line and its location, a value read in the Console, or what the page showed), and names exactly one change. It also says whether you changed code or the Expected, and why, as in Project step 12.
3. **The "Back to top" rows.** Row 1 has no repeatable Action and an Expected that cannot fail: rewrite as `Scroll to the bottom of the Home page, click Back to top` with `The page is at its top: the site name and Home link show`. Row 2 says "the button" and "goes up": which button, and up to where? It also already says `Pass` though nothing was written to compare it with. Row 3 puts the word `Expected:` into the cell and leaves Actual empty, which is fine, but "the top of the page" should name what you see there. The missing row is the keyboard: `Tab to Back to top, press Enter` with `Ring on the button; the page goes to the top`. An edge case is worth a row too: click it when you are already at the top. (Core concepts 9 to 11)

## Project checks

- **Step 1.** `git status` says `nothing to commit, working tree clean`.
- **Step 3, continue alone.** The sample's other four gallery rows are in the whole plan below, from `Edge case, last item and wrap-around` to the keyboard row.
- **Steps 4 to 7, continue alone.** The sample's rows are in the whole plan below. Your messages, questions and thank-you words make your Expected different.
- **Step 8.** Three rewrites that can fail:

  ```
  | Click Next once on the Interests page | Photo 2 of 5, the second photo and its caption | |
  | On the About page, click question 2 | Its answer shows, the icon is −, the button is navy; questions 1 and 3 do not change | |
  | Contact page: type sam@ as the email, fill the rest correctly, press Send message | "That email looks incomplete. Check the @ and the part after it." under Email; focus in Email | |
  ```

- **Step 10.** 28 rows passed and seven failed: gallery rows 1 to 4 and 6, the Rate page's first row, and "No red line on any page". The sample's Actual for the gallery rows, before the fix: `Fail: Photo 1 of 5 and the first photo, but a red TypeError`, `Fail: second photo and caption, counter still Photo 1 of 5`, `Fail: counter never reaches 5; it stays at Photo 1 of 5`, `Fail: the books photo with Photo 1 of 5`, `Pass: all five match`, `Fail: the photo moves, the counter does not`.
- **Step 11.** `Uncaught TypeError: Cannot set properties of null (setting 'textContent')` at `showPhoto (gallery.js:46:23)` and `gallery.js:68:1` at load. After a click on Next, the second line is `HTMLButtonElement.showNext (gallery.js:54:3)`. `document.querySelector("#photo-count")` gives `null`. The log line prints `counter is null`. After the id is put back, all six rows that depended on it pass.
- **Step 12.** After a mouse click on Send rating, no ring on 1; the right arrow then chooses 2, with a ring. With Tab and Enter, the ring shows on 1. Only the Expected changes.
- **Step 13.** Only the spaces-only row fails: Email and Message messages, no name message, focus in Email.
- **Step 14.** **Photo 3 of 5** at load. Rows 1, 2 and 4 fail (**Photo 3 of 5**, **Photo 4 of 5**, **Photo 2 of 5**); the last-item, alt and keyboard rows pass.
- **Step 16.** If you followed the brief, every box is ticked. The most common misses: an Expected filled in after the test, and a section with no keyboard row.

Here is the sample's whole `test-plan.md`, 63 lines. Its Actual column comes from the run from disk in Chromium, after the fixes in Project steps 11 and 12. Yours comes from your run on the live site (Part 3, step 4).

```
# My site test plan

Action / Expected / Actual for every interactive feature on my site. Rerun it after every change.

## Interests page: gallery

| Action | Expected | Actual |
| --- | --- | --- |
| F5 on the Interests page, Console open | Photo 1 of 5, the first photo and its caption; no red line in the Console | Pass |
| Click Next once | Photo 2 of 5, the second photo and its caption | Pass |
| Edge case, last item and wrap-around: click Next until Photo 5 of 5, then once more | Wraps to Photo 1 of 5, the first photo | Pass |
| Edge case, first item and wrap-around: F5, then click Previous once | Wraps to Photo 5 of 5, the last photo | Pass |
| After each click, type document.querySelector("#gallery-photo").alt in the Console | The alt text describes the photo on screen | Pass: all five match |
| F5, Tab to Next, press Enter, then Space | Each key moves one photo and the counter; Next has a dark orange ring | Pass |

## About page: FAQ

| Action | Expected | Actual |
| --- | --- | --- |
| F5 on the About page, Console open | Three questions, each with +, no answer showing; no red line | Pass |
| Click question 1 | Its answer shows, the icon is −, the button is navy with white text; questions 2 and 3 do not change | Pass |
| Click question 1 again | Answer hidden, icon +, white button again | Pass |
| Edge case, all open: click all three questions | All three answers show at once | Pass |
| Open question 2, then type document.querySelector("#question-2").ariaExpanded in the Console | 'true'; after closing it, 'false' | 'true', then 'false' |
| F5, Tab to each question, press Enter, then Space | Enter opens it, Space closes it, same as a click; ring on each | Pass |

## Contact page: form

| Action | Expected | Actual |
| --- | --- | --- |
| Edge case, empty: F5, press Send message with all three fields empty | Three messages, focus in Your name, no reload | Pass |
| Edge case, empty (spaces only): three spaces as the name, sam@ as the email, hi as the message, Send | Three messages, focus in Your name | Pass |
| Change the name to Sam, Send | Email and Message messages only, focus in Email | Pass |
| Change the email to sam@example.com, Send | Message message only, focus in Message | Pass |
| Edge case, one short: a message of 9 characters (123456789), Send | Message message, focus in Message | Pass |
| Edge case, exactly enough: a message of 10 characters (1234567890), Send | No messages; the form sends | Pass |
| Valid form (Sam, sam@example.com, Hello, I like your site.), Send | Button fades, "One moment...", then after 1 second "Thanks, Sam. Your message passed every check." on pale green; fields empty | Pass |
| During and after the send, type document.querySelector(".contact-form").className in the Console | 'contact-form sending', then 'contact-form sent': one state at a time | 'contact-form sending', then 'contact-form sent' |
| Type pretendFail = true in the Console, then send a valid form | My failed message on pale red; the words stay in the fields; F5 afterwards | Pass |
| Keyboard: Tab from Your name to Send message, Enter with all empty | Ring on each field and the button; three messages, focus in Your name | Pass |
| Keyboard: with a name filled in, type sam@ in Email, press Enter | The form checks; focus stays in Email with its message | Pass |
| Keyboard: in Message, press Enter | A new line in the box, no check | Pass |

## Rate page: rating card

| Action | Expected | Actual |
| --- | --- | --- |
| Edge case, empty (nothing chosen): F5, press Send rating | "Please choose a number from 1 to 5." under the numbers; focus on 1 (no ring after a mouse click; the right arrow then chooses 2) | Pass |
| Then click 3 and press Send rating | The message is gone; the form is replaced by "You chose 3 out of 5" | Pass |
| Edge case, first item: F5, choose 1, Send rating | "You chose 1 out of 5" | Pass |
| Edge case, last item: F5, choose 5, Send rating | "You chose 5 out of 5" | Pass |
| After a send, type document.querySelector("#rating-status").textContent in the Console | 'Thanks for the feedback. You chose 5 out of 5.' (the number chosen) | 'Thanks for the feedback. You chose 5 out of 5.' |
| Keyboard: F5, Tab six times, Tab, Enter; then right arrow three times, Tab, Enter | Ring on 1, then on Send rating; the message and focus on 1; then "You chose 4 out of 5" | Pass |

## Every page: navigation and keyboard

| Action | Expected | Actual |
| --- | --- | --- |
| On each of the five pages, click each nav link | The right page opens, and its own nav link is bold | Pass on all five pages |
| F5 on each page, Console open | No red line on any page | Pass on all five pages |
| On each page, F5, Tab to the last link, button or field, then Shift+Tab back to Home | Five nav links first with a light orange ring, then the page's links, buttons and fields in reading order with a dark orange ring; Shift+Tab goes back the same way | Pass on all five pages |
| Home page: Tab to the GitHub link, press Enter | My GitHub profile opens | Pass |
| Each page at 390 px (F12, then Ctrl+Shift+M) | Nothing scrolls sideways | Pass on all five pages |
```
