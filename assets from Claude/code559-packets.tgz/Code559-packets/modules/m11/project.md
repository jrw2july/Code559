# Project: A test plan for every interactive feature on your site

*Your hands, about 2½ hours (estimate).* In the Exercise you hunted six bugs in `practice-11` with a ready-made test table. Now you write the table yourself, for your real site. Every interactive feature gets its rows: the gallery, the FAQ, the Contact form and its states, the rating card, and the navigation and keyboard on every page. You run the plan on your computer first and fix what fails, one change at a time. In Part 3 you run it again on the live site and save it in your repository, so you can rerun it after every future change. You use only what Modules 1 to 11 taught:

- the Action / Expected / Actual table, with Expected written before you test (Core concept 10)
- the four edge cases: empty input, the first item, the last item and wrap-around (Core concept 11)
- the keyboard test: Tab, Shift+Tab, Enter, Space and the arrow keys, with a visible focus ring on every control (Core concept 9 and Module 4)
- reading a Console error: its type, its message, its file and line, and the `at` lines under it (Core concepts 2 to 4)
- `document.querySelector()` typed in the Console to test a selector, and properties such as `.alt`, `.ariaExpanded`, `.className` and `.textContent` to read a value (Core concept 5 and Module 9)
- one `console.log()` line to see what a variable holds, deleted afterward (Core concept 6)
- changing one thing at a time, and rerunning the same rows after each change (Core concept 7)
- device mode at 390 px (Module 3), and `pretendFail` from the Module 10 project
- one new kind of file, `test-plan.md`: plain text with `#` headings and tables made of `|` lines (Project step 3)

This project starts from the Module 10 packet's site: five pages (Home, About, Interests, Rate, Contact), one shared `styles.css`, and four page scripts: `gallery.js` on the Interests page, `faq.js` on the About page, `contact.js` on the Contact page and `rate.js` on the Rate page. Everything is committed and pushed, and the live site loads.

## The brief

Read the whole brief twice before you type anything.

When you finish, `my-site` holds one new file, `test-plan.md`, next to `index.html`. No other file changes, unless your plan finds a real bug in your site. Then the fix changes that file too.

**The file.** `test-plan.md` starts with a `#` heading, **My site test plan**, and one sentence that says what the file is. Then come five sections, each with a `##` heading and one table, in this order:

1. **Interests page: gallery**
2. **About page: FAQ**
3. **Contact page: form**
4. **Rate page: rating card**
5. **Every page: navigation and keyboard**

Keep the "Every page" section last. In Module 12 you add rows to the end of the file, for a link that sits on every page.

**The tables.** Every table has the same three columns: **Action**, **Expected**, **Actual**. One row is one thing a visitor does.

- **Action** is written so someone else could repeat it without asking you: which page, what to click or press, and how many times.
- **Expected** is written before you test, from the brief of each feature (Modules 9 and 10), with the exact words the page shows.
- **Actual** is written after. A row that matches says `Pass`. A row that does not says what you saw instead, in a few words.

**What the plan must cover.** Every feature gets rows for the mouse **and** for the keyboard. Every one of the four edge cases appears wherever it applies: empty input on the Contact form and the rating card, the first and last item in the gallery and on the rating card, and wrap-around in both directions in the gallery. An edge-case row starts with `Edge case,` and names its edge, so you can find them at a glance. Each of the four feature sections has at least one row that reads a value in the Console, and the "Every page" section checks that no page has a red line.

Your site has no skip link. Module 4 explained the idea, but the packet projects did not add one, so the plan does not test one. If you added one yourself, give it a row in the last section.

**Where the Actual column comes from.** The finished file holds the Actual of your run on the live site, `https://your-username.github.io/my-site/` (Part 3). Before that, you run the whole plan on your computer, from disk, and fix what fails there first.

Here is the top of the sample's file, with its first section:

```
# My site test plan

Action / Expected / Actual for every interactive feature on my site. Rerun it after every change.

## Interests page: gallery

| Action | Expected | Actual |
| --- | --- | --- |
| F5 on the Interests page, Console open | Photo 1 of 5, the first photo and its caption; no red line in the Console | Pass |
| Click Next once | Photo 2 of 5, the second photo and its caption | Pass |
| Edge case, last item and wrap-around: click Next until Photo 5 of 5, then once more | Wraps to Photo 1 of 5, the first photo | Pass |
| Edge case, first item and wrap-around: F5, then click Previous once | Wraps to Photo 5 of 5, the last photo | Pass |
| After each click, type document.querySelector("#gallery-photo").alt in the Console | The alt text describes the photo on screen | Pass: all five match |
| F5, Tab to Next, press Enter, then Space | Each key moves one photo and the counter; Next has a dark orange ring | Pass |
```

The headings, the section order and the three column names must match the brief. The rows are yours: your own questions, messages and photos give you different Expected words. The sample's whole plan has 35 rows, and it is in Part 6, *Answers*.

## The steps

Type every line. Do not paste: typing the rows makes you read each one.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`. Type `git status`. It should say `nothing to commit, working tree clean`: you start from what is already live.
2. **Find every feature, on paper.** Open each of the five pages in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window). After each save, press **F5** to reload. Press **F12** (or **Ctrl+Shift+J**) to open DevTools, then click the **Console** tab. On each page, press Tab from the top to the bottom, and write down everything that responds to a click, a key or a submit.

   The sample's list had six groups: the five nav links on every page, the GitHub link on the Home page, the gallery's two buttons, the three FAQ questions, the Contact form with its four states, and the rating card. Then find your keyboard plan from Module 10, Project step 19. Its nine lines become rows of this plan.
3. **Make the file, then the gallery section.** In the Explorer, create `test-plan.md` next to `index.html`. The `.md` means Markdown: plain text that GitHub shows with formatting. You need four rules today, and Module 12 shows more:

   - A line that starts with `# ` is a heading. `## ` makes a smaller one.
   - A table is a block of lines that start and end with `|`. The `|` separate the columns. On a US keyboard, you type it with **Shift** and the key above **Enter**.
   - The first line holds the column names. The second line, `| --- | --- | --- |`, marks them as headings. Each line after it is one row.
   - Leave one empty line before each table, and none inside it. GitHub Docs (*Organizing information with tables*): "You must include a blank line before your table in order for it to correctly render."

   Type the heading, the sentence, and the gallery section with its first two rows. Leave Actual empty: the last cell is `| |`. **Write each Expected before you look at the page.** That is the whole point of the column.

   ```
   # My site test plan

   Action / Expected / Actual for every interactive feature on my site. Rerun it after every change.

   ## Interests page: gallery

   | Action | Expected | Actual |
   | --- | --- | --- |
   | F5 on the Interests page, Console open | Photo 1 of 5, the first photo and its caption; no red line in the Console | |
   | Click Next once | Photo 2 of 5, the second photo and its caption | |
   ```

   ```
   <!-- Continue alone: four more rows for the gallery. The last item
        (Next on photo 5) and the first item (Previous on photo 1), each
        starting with "Edge case," and naming its edges. One row that reads the alt text in
        the Console after each click. One keyboard row: Tab to Next,
        then Enter and Space. -->
   ```

   To see your table as a table, press **Ctrl+Shift+V** in VS Code. VS Code's *Markdown and Visual Studio Code* page lists it as the preview shortcut. If a row shows as a plain line of `|` signs, see Problem 5 in Part 4, *Troubleshooting*.
4. **The FAQ section.** Under the gallery table, leave one empty line and type:

   ```
   ## About page: FAQ

   | Action | Expected | Actual |
   | --- | --- | --- |
   | F5 on the About page, Console open | Three questions, each with +, no answer showing; no red line | |
   | Click question 1 | Its answer shows, the icon is −, the button is navy with white text; questions 2 and 3 do not change | |
   ```

   ```
   <!-- Continue alone: question 1 clicked again; an edge case with all
        three open at once; aria-expanded read in the Console with
        document.querySelector("#question-2").ariaExpanded, open and
        closed; and a keyboard row with Enter and Space on each question. -->
   ```

   If your keyboard gives a hyphen for the `−`, write "minus sign" instead.
5. **The Contact section.** The five paths from Module 10, Project step 9, are your first rows. Type the section with the first two:

   ```
   ## Contact page: form

   | Action | Expected | Actual |
   | --- | --- | --- |
   | Edge case, empty: F5, press Send message with all three fields empty | Three messages, focus in Your name, no reload | |
   | Edge case, empty (spaces only): three spaces as the name, sam@ as the email, hi as the message, Send | Three messages, focus in Your name | |
   ```

   ```
   <!-- Continue alone: the bad email, the short message and the valid
        send (with your own thank-you words). Two edge cases at the limit:
        a message of 9 characters, and one of exactly 10. The form's class
        read in the Console during and after a send. The failed state with
        pretendFail = true. Then your keyboard lines from Module 10. -->
   ```

   **Think this through:** why test 9 and 10 characters, and not 3 and 50? A rule like "at least 10" breaks at its edge, if it breaks at all: `<` where `<=` was meant changes only what happens at exactly 10.
6. **The Rate section.** Type it alone, the same way: the heading, the two table lines, then your rows. Cover nothing chosen, a choice after the error, the first choice (1), the last choice (5), the hidden status line read in the Console, and the keyboard path from Module 10. The sample's first row was:

   ```
   | Edge case, empty (nothing chosen): F5, press Send rating | "Please choose a number from 1 to 5." under the numbers; focus (ring) on 1 | |
   ```

   This row is wrong on purpose: it promises a ring that the Module 10 brief does not. Keep it as it is, so you can see what a wrong Expected does to a run. Project step 12 comes back to it.
7. **The "Every page" section.** Type it alone, last in the file. It needs five rows: every nav link on every page, no red line on any page, the Tab order and rings on every page (light orange on the navy bar, dark orange elsewhere), the Home page's GitHub link by keyboard, and nothing scrolling sideways at 390 px. One row may cover all five pages; its Actual then says so.
8. **Check the plan before you run it.** Read every row as if a classmate had to run it alone. Could they repeat the Action? Could they say pass or fail from the Expected, without asking you? Here are three rows from a first draft. Rewrite each one in your notebook:

   ```
   | Test the gallery | It works | |
   | Click a question | The answer shows | |
   | Type something wrong in the form and send | An error | |
   ```

   None of the three can fail, so none of them tests anything. The sample's rewrites are in Part 6. Then count your edge-case rows: each of the four edges must be there.
9. **Plant one bug.** Real bugs often arrive this way: you tidy one file and forget the other. Open `interests.html` and change the counter's id from `photo-count` to `photo-counter`. Do not touch `gallery.js`. Save.

   Now try to forget it: the next step shows how much the plan finds alone.
10. **Run the whole plan from disk.** Open each page, press **F5**, keep the Console open, and run every row in order, top to bottom. Fill in Actual for each row as you go. Do not fix anything yet: first you want the whole picture.

    In the sample, 28 rows passed and seven failed. Five were in the gallery: the counter stayed at **Photo 1 of 5** while the photos changed, and the Console had a red line at load and another after every click. Only the alt-text row passed. The Rate page's first row failed: the message showed, but number 1 had no ring. And in the last section, "No red line on any page" failed on the Interests page.
11. **Debug: the gallery.** Seven failures, but how many causes? Start with the first failing row, the one at load, and read its red line:

    ```
    Uncaught TypeError: Cannot set properties of null (setting 'textContent')
        at showPhoto (gallery.js:46:23)
        at gallery.js:68:1
    ```

    Read the `at` lines from the bottom up. Line 68 is `showPhoto();` in block 3, which runs once at load. It called `showPhoto`, and inside it, line 46 tried to set `textContent` on something that holds `null`. Line 46 is `counter.textContent = …`, so `counter` is `null`. A name gets its value in block 1, and `counter` gets it on line 6, from `document.querySelector("#photo-count")`.

    Now ask the page. In the Console, type `document.querySelector("#photo-count")`. The sample gave `null`: nothing on the page has that id. Then type `document.querySelector(".gallery-controls p")`, which finds the counter by where it sits. The sample gave `<p id="photo-counter">Photo 1 of 5</p>`. The selector and the HTML disagree.

    ![Two real captures side by side. Left: the Photo gallery section at 390 pixels wide after one click on Next. The counter between Previous and Next still says Photo 1 of 5, but the photo is interest-two-800.jpg and the caption is Cooking: chemistry I get to eat. Right: a Console with two red errors, Uncaught TypeError: Cannot set properties of null (setting 'textContent'), the first at showPhoto (gallery.js:46:23) and at gallery.js:68:1, the second at showPhoto (gallery.js:46:23) and at HTMLButtonElement.showNext (gallery.js:54:3). Under them, document.querySelector("#photo-count") gives null, and document.querySelector(".gallery-controls p") gives the paragraph with id photo-counter.](images/p11-gallery-bug.png)
    *The planted bug, as the plan found it. The photo and caption moved on; the counter did not. The two lines at the bottom of the Console are the two checks above. Labels added above each capture. (real: rendered in Chromium at 390 px, and real output, rendered; captured in Chromium loading the files from disk. The Console frame is drawn.)*

    Want to see it from inside the function? Add `console.log("counter is", counter);` as the first line of `showPhoto`, save and press F5. The sample printed `counter is null` from `gallery.js:42`, right before the red line. The red line now said `gallery.js:47:23`, because the log line pushed every line below it down by one. Delete the log line.

    Write down the one change you will make, then make it: put `photo-count` back in `interests.html`. The gallery brief from Module 9 names that id, so the HTML was wrong, not the script. Save, press F5, and run the first failing row again. It passed in the sample, with no red line. Then rerun the **whole** gallery section and the "No red line" row in the last section. All of them passed. Six failing rows, one cause, one change. The seventh failure, on the Rate page, has nothing to do with the gallery: it is the next step.
12. **A row that fails while the code is right.** Go back to the Rate row from step 6. The sample's Actual said: the message showed, focus went to 1, but number 1 had no ring. Before you change any code, find out who is wrong.

    Your Expected promised a ring. Reread the Module 10 brief: the card "puts focus on number 1", and "the dark orange ring shows on 1 only when you used the keyboard: after a mouse click, Chromium moves focus but draws no ring." Check both halves. F5, click Send rating with the mouse, then press the right arrow once: in the sample, 2 became the chosen number, so focus **was** on 1. Then run the keyboard row of the same section: with Tab and Enter, 1 got the dark orange ring.

    The code meets the brief; your Expected did not. So the one thing to change is the Expected. The sample's new Expected: `"Please choose a number from 1 to 5." under the numbers; focus on 1 (no ring after a mouse click; the right arrow then chooses 2)`. Rerun the row: it passed. A failing row says only that the page and your Expected disagree. The brief tells you which one is wrong.
13. **Break it on purpose.** In `contact.js`, in `findFirstProblem`, change `const name = nameInput.value.trim();` to `const name = nameInput.value;`. **Predict:** which rows of your Contact section will fail? Write down their numbers. Then save, press F5 and run the whole Contact section.

    In the sample, only the spaces-only edge case failed: no name message, the Email and Message messages, and focus in Email. With a good email and message, three spaces even "sent": **Thanks, . Your message passed every check.** One edge-case row stood between this change and your visitors. Put `.trim()` back and rerun the Contact section.
14. **Modify.** In `gallery.js`, change `let current = 0;` to `let current = 2;`. **Predict:** how many of your gallery rows will fail, and which? Write it down, then save and run the gallery section.

    The sample opened on **Photo 3 of 5**. Three rows failed: the load row, Next once (**Photo 4 of 5**), and Previous on the first item (**Photo 2 of 5**). The last-item row passed: from photo 5, Next still wrapped to photo 1. One change, three failing rows: that is why you rerun the whole section after any change. Change it back to `0` and rerun the section.
15. **Explain it.** Read `gallery.js` to yourself, out loud, from top to bottom. For each function, say which rows of your plan make it run. Do the same for `faq.js`, `contact.js` and `rate.js`; most people miss `finishSending` and its `if (pretendFail)` part. A function with no row is a gap in your plan: add a row.
16. **Test the plan.** Tick each box.

    - [ ] `test-plan.md` has the `#` heading, the sentence, and the five sections in the brief's order, "Every page" last
    - [ ] Every table has the columns Action, Expected and Actual, and shows as a table in the preview (Ctrl+Shift+V)
    - [ ] Every feature has mouse rows and a keyboard row, and each of the four feature sections reads at least one value in the Console
    - [ ] The four edge cases are all there, each row starting with `Edge case,` and naming its edges
    - [ ] A classmate could run every Action without asking you, and say pass or fail from every Expected
    - [ ] Every row has an Actual from your run from disk, and every row now passes
    - [ ] The planted id, the missing `.trim()`, `let current = 2;` and the `console.log` line are all undone
    - [ ] On every page, F5 with the Console open shows no red line

17. **Save it in Git.** Go to Part 3, *Finishing work in Git*. There you run the whole plan on the live site, fix anything that fails only there, and save the plan in your repository.
