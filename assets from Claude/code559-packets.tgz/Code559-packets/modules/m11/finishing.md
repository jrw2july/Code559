# Finishing work in Git

Your plan passes on your computer. Now you run it where your visitors are, on the live site, and save it in your repository with the same save routine as in Modules 1 to 10: `git status`, `git add .`, `git commit`, `git push`, then check the live site. Two things are new. You read `git status` as one more test: it tells you whether the code you are about to test live is the code you tested at home. And for the first time you run a whole written plan on the live site and record what it shows.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 to 10.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **Search for leftover test changes.** This project changed code on purpose three times, and added a log line once. In VS Code, open **Edit → Find in Files** (**Ctrl+Shift+F**) and search for `photo-counter`, then for `counter is`. Neither should be found in an `.html` or `.js` file. Then open `contact.js` and check that the name line in `findFirstProblem` ends in `.trim();`, and open `gallery.js` and check that it says `let current = 0;`.
3. **Read `git status` as a test (NEW).** Type:

   ```
   git status
   ```

   The sample printed:

   ```
   On branch main
   Your branch is up to date with 'origin/main'.

   Untracked files:
     (use "git add <file>..." to include in what will be committed)
   	test-plan.md

   nothing added to commit but untracked files present (use "git add" to track)
   ```

   Read what is **not** there: no `modified:` line. Every page and script is exactly as you pushed it in Module 10, so the live site already runs the code your plan just passed at home. If a page or script shows as `modified:` and you did not fix a real bug in it, a test change is still in it: go back to step 2. If your plan did find a real bug and you fixed it, that file belongs here, and it goes into this commit with the plan.
4. **Run the whole plan on the live site (NEW).** Open `https://your-username.github.io/my-site/` with the Console open (**F12**, then the **Console** tab), and press F5. If a page acts like an old version, press **Ctrl+Shift+R** to reload without the browser's saved copy, as in Module 9. Then run every row, top to bottom, exactly as written. As you run each row, rewrite its Actual with what the live site did. When you are done, every Actual in the file comes from the live run.

   Use a phone too if you have one, for the rows about 390 px and the Contact form. The steps in this packet were tested in Chromium with the files opened from disk. The live run could not be done when this packet was made, so this run is yours, and its Actual column is the record of it.
5. **Fix what fails live, one change at a time (NEW).** A row that passed at home and fails live usually means a file, not the code: a name whose capital letters differ, or a file that was never committed (Problems 1 and 2 in Part 4, *Troubleshooting*). For each failing row:

   - Write down the one change you think will fix it. Make it on your computer, save, and run the row from disk.
   - Run steps 6 to 8 now, with a message that names the fix, such as `Fix capital letters in gallery script name`. The plan goes into that commit as it is so far.
   - Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), press Ctrl+Shift+R, and run the row live again. Rewrite its Actual. Then carry on with the next row.

   If every row passed live, as it should when step 3 showed no `modified:` line, there is nothing to fix.
6. **Stage the plan.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. (A warning that mentions LF and CRLF is harmless.) Run `git status` again. Under **Changes to be committed** the sample showed one line: `new file:   test-plan.md`.
7. **Commit.** Type:

   ```
   git commit -m "Add test plan for every interactive feature"
   ```

   The sample printed `1 file changed, 63 insertions(+)` and `create mode 100644 test-plan.md`. Each line of the file counts as one insertion, the empty lines too. Your commit id and line count will differ.
8. **Push.** Type:

   ```
   git push
   ```

   The last line ends in `main -> main`.
9. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. The new commit is on top, with your Module 10 commit under it.
10. **See the plan on GitHub (NEW).** Open your repository on GitHub, `https://github.com/your-username/my-site`, and click `test-plan.md` in the file list. GitHub shows a Markdown file with its formatting, so your five sections should appear as headings with tables under them. If a section shows as lines full of `|` signs, see Problem 5 in Part 4. This could not be checked on GitHub when the packet was made; the table rules come from GitHub Docs (*Organizing information with tables*).
11. **Run one row again after the push.** The plan is not a page, so the push changed nothing your visitors see. Prove it: on the live site, run the "No red line on any page" row once more. From now on, every change to your site ends this way: rerun the rows that the change could touch, and when in doubt, the whole plan.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`, and `git log --oneline` shows `Add test plan for every interactive feature` on top. `test-plan.md` is in your repository on GitHub, and every Actual in it comes from your run on the live site. Every row passes.
