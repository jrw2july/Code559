# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 12. If a line is a 1 or a 2, reread that Core concept and redo its Exercise or Project step.

## Rubric

- I can write down what I expect before I test, and describe a bug as the gap between expected and actual
- I can read a Console error's type, message, file and line, and follow its at lines from the bottom up
- I can tell SyntaxError, ReferenceError and TypeError apart, and say what each one usually means
- I can trace "of null" back to the querySelector line that made the null, and test that selector in the Console
- I can use console.log() to see what a variable holds when the code runs, delete it afterward, and say when a breakpoint would help more
- I can change one thing at a time, and rerun the same rows after each change
- I can test every page with the keyboard alone, and check that every control shows a focus ring
- I can write an Action / Expected / Actual plan that someone else could run, and decide whether a failing row needs new code or a new Expected
- I can find the edge cases in a feature (empty input, first item, last item, wrap-around) and give each one a row

## Three questions to answer in writing

1. In Project step 10, seven rows failed, and Project step 11 fixed six of them with one change. Explain how one wrong id made five gallery rows and one "Every page" row fail, why the alt-text row still passed, and why you started with the first failing row and not with the last.
2. Pick one row of your own plan that failed at least once: in the run from disk, in a break-it step, or on the live site. What did you write in Expected, what was the Actual, what was your first clue, and what one change made it pass?
3. A classmate's plan for a "Back to top" button has these rows. What is wrong with each one, how would you rewrite it, and what row is missing?

   ```
   | Back to top | Works | |
   | Click the button at the bottom | Page goes up | Pass |
   | Scroll down and click Back to top | Expected: the top of the page shows | |
   ```
