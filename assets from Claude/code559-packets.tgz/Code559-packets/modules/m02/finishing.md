# Finishing work in Git

Your styled pages work on your computer. Now you put them online with the save routine from Module 1: `git status`, `git add .`, `git commit`, `git push`, then check the live page. The routine is the same. What is new this time is a commit that adds a new kind of file and changes two old ones at once, and checking that the live site loads that file.

Items marked **NEW** are new in this part. The others repeat what you did in Module 1.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **See what changed.** Type:

   ```
   git status
   ```

   You should see `about.html` and `index.html` under **Changes not staged for commit**, each marked `modified:`, because you added the `<link>` line and the classes. You should see `styles.css` under **Untracked files**, because Git has never saved it. `image-one.jpg` is not listed. If you do not see `styles.css` at all, check its name in the Explorer (see *Troubleshooting*, problem 1).
3. **Stage the changes.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. Run `git status` again. All three files are now under **Changes to be committed**: `modified:   about.html`, `modified:   index.html` and `new file:   styles.css`.
4. **Commit (NEW: one commit for one change across several files).** Type:

   ```
   git commit -m "Style the site with one shared stylesheet"
   ```

   Git prints a short summary. The first line starts with `[main`, a seven-character commit id and your message. The next line says `3 files changed`, and a later line says `create mode 100644 styles.css`. Your commit id and numbers will differ. The new stylesheet and the two `<link>` lines belong together: one without the other is a broken site. That is why they go into one commit, with a message that names the whole change.
5. **Push.** Type:

   ```
   git push
   ```

   The last line ends in `main -> main`.
6. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. Your newest commit, `Style the site with one shared stylesheet`, is on top, with your Module 1 commits under it.
7. **Check the live page (NEW: checking that the stylesheet arrived).** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/` and press F5. You should see your colors and the nav bar. If the live page shows black serif text on white, the HTML arrived but the stylesheet did not load. Press F12, open the **Console** tab, and look for a red error that names the stylesheet. Online, a missing file is reported as `404 (Not Found)` instead of `ERR_FILE_NOT_FOUND`. See *Troubleshooting*, problems 1 and 5.
8. **Test the live site.** Run the test from Project step 15 again on the live site: both pages styled, the nav in the same spot on both, all six nav clicks working, and no red errors in the Console.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows your new commit on top. Your live address shows both pages with your colors and the Flexbox nav, and the Console has no red errors.
