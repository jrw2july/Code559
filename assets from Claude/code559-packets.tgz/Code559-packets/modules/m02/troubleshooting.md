# Troubleshooting: five common problems

Each problem has the symptom you see, why it happens, and the fix. After each fix, save, press F5, and run the test from Project step 15 again.

### 1. A page has no styles at all

**Symptom.** The page is black serif text on white, with blue underlined links, as if you never wrote any CSS. The other page may still be styled.

**Why.** The browser could not load the stylesheet. The `href` does not match the file's real name or place. The usual causes are `style.css` instead of `styles.css`, a capital letter (`Styles.css`), a file saved as `styles.css.txt`, or `styles.css` saved in another folder. The page itself shows no message, because the HTML is fine (the Console does show one). Only the second request, for the stylesheet, failed.

**Fix.** Press F12 and open the **Console** tab. A red `Failed to load resource` error confirms that the stylesheet did not load. Then compare three things letter by letter: the `href` in this page's `<link>`, the file name in the VS Code Explorer, and its place (it must sit in `my-site`, next to `index.html`). Fix the `href` or move the file, save, and refresh. If only the live site is unstyled, look for a capital letter, as in Module 1's troubleshooting: Windows ignores the difference, a web server may not. If File Explorer shows the file as a "Text Document", turn on **View → Show → File name extensions** and rename it so it ends in `.css` only.

### 2. One rule "does nothing" because another rule wins

**Symptom.** You wrote a rule, saved and refreshed, and the element did not change. Other rules in the same file work.

**Why.** Another rule sets the same property on the same element, and it wins. Either it is more specific (a class beats an element, an id beats a class), or it has the same specificity and comes later in the file. In Project step 12, `p { background-color: yellow; }` came last and still lost to `.note` on the note paragraphs. A missing colon or semicolon in the line above can also break a declaration without any message (Concept 2).

**Fix.** Find every rule that could match the element and sets the same property. Score each selector as in Concept 5 and decide which one wins. Then change the rule that should win, or remove the one that should not. If no other rule matches, read your rule and the line above it for a missing colon, semicolon or brace.

### 3. A class rule does not apply

**Symptom.** Your `.note` box shows on one page but not on the other, or not at all.

**Why.** The class name in the HTML and the name in the CSS differ. CSS needs them to match exactly, including capital letters. Common slips: `class="ntoe"`, `class="Note"`, a dot in the HTML (`class=".note"`), or no dot in the CSS (`note {` instead of `.note {`). The browser gives no error, because a class that matches no rule is allowed.

**Fix.** Copy the class name from the CSS (without the dot) and compare it with the HTML, letter by letter. The dot belongs only in the CSS selector, the same way `#` belongs only in a link and not in an `id` (Module 1).

### 4. The nav links stack in a column, or the gap does nothing

**Symptom.** The nav links sit one under the other, or they stay in a row with only the small spaces of plain text, and your `gap` does nothing.

**Why.** `display: flex` is on the wrong element. If it is in the `nav a` rule, each link becomes its own flex container, which starts on a new line, so the links stack (Project step 13). If it is missing from the `nav` rule, the `nav` has no flex items, so `gap` has nothing to space out. If it is only on `header`, the `<h1>` and the `<nav>` line up, but the links inside the nav do not get the `gap`.

**Fix.** Put `display: flex;` in the `nav` rule, the parent of the links, next to `gap`. Remove it from `nav a`. Keep the second `display: flex;` in the `header` rule: that one lines up the site name and the nav.

### 5. Your change does not show, or the live site shows the old look

**Symptom.** You edited `styles.css`, but the page looks the same as before. Or your computer shows the new look and the live site does not.

**Why.** On your computer, the usual cause is that the change was not saved, or the browser tab shows a different copy of the page. A dot on the VS Code tab instead of an ✕ means unsaved changes. Online, GitHub Pages may not have published your push yet, or the browser may still be using a copy of the stylesheet it saved earlier.

**Fix.** Press Ctrl+S, then F5. Check that the address bar ends in `my-site/index.html` or `my-site/about.html`, not a file in `practice-02`. For the live site, run `git status`: if it lists changed files, finish the save routine. If it is clean, wait a few minutes. Then press **Ctrl+F5**, which reloads the page and its files without the saved copies. Edge and Chrome both have this shortcut.
