# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 3. If a line is a 1 or a 2, reread that Core Concept and redo its Exercise or Project step.

## Rubric

- I can link one stylesheet from several pages and find a wrong href with the Console
- I can name the selector, property, value and declaration in a rule, and spot a missing colon or semicolon
- I can set color, background, font, line height, margin and padding, and say which of them are inherited
- I can choose between an element selector, a class selector and a descendant selector such as nav a
- I can write a reusable class with a name that says what the thing is, and use it on more than one page
- I can predict which of two rules wins, using specificity first and source order only for a tie
- I can tell block boxes from inline boxes and explain why width does nothing on a link
- I can lay out a nav bar with display: flex on the parent, and use gap, justify-content and align-items

## Three questions to answer in writing

1. In Project step 12, the test rule came last in the file but did not turn the `.note` paragraphs yellow. Explain why, in your own words.
2. Pick one mistake you made in this module. What did the page or the Console show, and how did you find the cause?
3. Your site gets a third page. List everything you must add or check so that it looks like the other two, in order.
