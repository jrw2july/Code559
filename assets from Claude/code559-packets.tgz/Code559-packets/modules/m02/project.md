# Project: One stylesheet for the whole site

*Your hands, about 75 minutes (estimate).* In the Exercise you styled a practice page in `practice-02`. Now you style your real site. You write one `styles.css` in `my-site` and link it from the Home and About pages you built in the Module 1 packet. One file sets the color, type and spacing for both pages, and one Flexbox rule turns the nav into a bar that looks the same on every page. You use only the CSS from Modules 1 and 2. Screen sizes and layout grids come in Module 3.

This project starts from the Module 1 packet's Home and About pages. If `my-site` still holds only your first practice page, build those two pages first (Module 1 packet, Part 2), then come back.

## The brief

When you finish, `my-site` holds four files: `index.html` (Home), `about.html` (About), `image-one.jpg` and the new `styles.css`. Both pages link the same stylesheet with `<link rel="stylesheet" href="styles.css">` as the last line inside `<head>`. Nothing else in the `<head>` changes. The restyled site is online at `https://your-username.github.io/my-site/`.

`styles.css` holds rules in four groups, in this order, each with a short comment above it:

- **Site-wide basics.** Element rules for `body` (font, text color, background color, line height, margin, padding), `h1`, `h2` and `a`. Because `color` is inherited, the `body` rule colors almost all the text on both pages.
- **Header and nav.** The `header` gets a dark background and light text. The `nav` gets `display: flex` and a `gap`, and a `nav a` rule makes only the nav links light. The header itself is also a flex container, so the site name sits on the left and the nav on the right.
- **Page areas.** `main` and `footer` get padding, and the footer gets its own background, so the page has three clear bands: header, main, footer.
- **Reusable classes.** At least two class rules, named for what the thing *is*. This project uses `.lead` (a larger opening paragraph) and `.note` (a paragraph in a colored box). Use `.note` on at least one paragraph on *each* page, so you can see one rule reused across pages.

A visitor sees the same header, the same colors and the same fonts on both pages. Only the main content changes. The nav links sit in one row, in the same place, on both pages, and clicking between pages does not make the header jump. All the words, and all the colors, can be yours. The rule names above, the file name `styles.css` and the `<link>` line must match.

If you choose your own colors, keep body text at a contrast of at least 4.5:1 against its background. The sample colors below were checked: the dark text `#2b2d42` on the cream `#fdf6ec` is 12.6:1, white on the navy `#1d3557` is 12.4:1, the rust headings `#9a3412` on cream are 6.8:1, and the dark text on the `.note` box `#fde2b8` is 10.8:1 (computed with the WCAG contrast formula). Pale text on a pale background is the mistake to avoid. For links, `#1d3557` on the cream is 11.5:1; for the footer, `#e9dcc9` behind the dark text is 10.0:1.

![The finished Home page: a navy header band with the white site name on the left and three white links Home, About and Contact on the right, then a cream page with rust-colored headings, a larger first paragraph, a bulleted list, a Contact paragraph in a light orange box, and a beige footer band.](images/p02-home.png)
*One example of the finished Home page. The nav is one row at the right of the header, the Contact paragraph uses `.note`, and the Welcome paragraph uses `.lead`. The sample asks for Segoe UI, a Windows font; this picture was made on a computer without it, so it shows a similar fallback font. Measured at 800 px wide. (real: rendered in Chromium at 800 px)*

![The finished About page: the same navy header with the nav in the same place, an About me heading, a paragraph in the same light orange box, the picture, a What I am learning list, and the same footer band.](images/p02-about.png)
*The About page with the same stylesheet. The header, footer and colors match the Home page, and the nav links sit at exactly the same spots (the browser measured both). The `.note` box is the same rule reused on a second page. (real: rendered in Chromium at 800 px)*

## The steps

Type every line. Do not paste. The `<link>` line is the same on both pages, but type it twice anyway: it is short, and typing it is how you learn to spot a wrong `href`.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. The Explorer should show `about.html`, `image-one.jpg` and `index.html`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`. You will need it at the end.
2. **Plan on paper.** Choose four colors: a page background, a text color, a header background, and a heading color. Write their hex codes. Then choose a font list that ends in a generic family, for example `"Segoe UI", Arial, sans-serif`. If you are not sure about contrast, start with the sample colors from the brief and change them later.
3. **Predict.** Write down what you expect to see on the About page after you link the stylesheet from `index.html` only. You will check this in step 5.
4. **Create the stylesheet and link it from Home.** In the Explorer, create a new file in `my-site` called `styles.css`. Check the name in the Explorer: `styles`, with an `s`, then `.css`. Then open `index.html` and add the link as the last line inside `<head>`:

   ```html
   <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <title>Home - Your Name</title>
     <link rel="stylesheet" href="styles.css">
   </head>
   ```

5. **Write the site-wide basics.** In `styles.css`, type the first group:

   ```css
   /* Site-wide basics */
   body {
     font-family: "Segoe UI", Arial, sans-serif;
     color: #2b2d42;
     background-color: #fdf6ec;
     line-height: 1.5;
     margin: 0;
     padding: 0;
   }

   h1 {
     font-size: 32px;
     margin: 0;
   }

   /* Continue alone: an h2 rule with your heading color and a font-size,
      and an a rule that gives links a color that is easy to read on your background. */
   ```

   A CSS comment starts with `/*` and ends with `*/`. Like an HTML comment, it never shows on the page. Keep the group comments; delete the "Continue alone" comment when you have typed your rules. Save both files. Open `index.html` in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window). After each save, press **F5** to reload. The Home page should show your font and colors. Now click **About** and compare with your prediction from step 3: the About page is still black serif text on white, because it does not link the stylesheet yet.
6. **Link it from About.** Open `about.html` and type the same `<link>` line as the last line inside its `<head>`. Save, go to the About page in the browser, and press F5. Both pages now share every rule you write. From here on, you edit one file and both pages change.
7. **Style the header and nav.** Add the second group:

   ```css
   /* Header and nav */
   header {
     background-color: #1d3557;
     color: white;
     padding: 16px 24px;
     display: flex;
     justify-content: space-between;
     align-items: center;
   }

   nav {
     display: flex;
     gap: 24px;
   }

   /* Continue alone: a nav a rule that makes only the nav links white,
      with a font-size a little larger than the body text. */
   ```

   Read the `header` rule to yourself, line by line. It uses the same Flexbox ideas as the `nav`, one level up. The header's children are the `<h1>` and the `<nav>`, so they become two flex items. `justify-content: space-between` pushes the site name to the left edge and the nav to the right edge. `align-items: center` lines them up across the row, which matters here because the `<h1>` is taller than the links. The `nav` rule makes the three links the flex items of a second, smaller row, with `gap` between them.

   You need `nav a`, not plain `a`. A plain `a` rule set to white would also make the GitHub link in your Contact section white, on a cream background, where nobody could read it. The descendant selector picks only the links inside the `nav` (Concept 4).
8. **Run.** Save and press F5 on both pages. The header should be one dark band: the site name on the left, the three links in a row on the right. Switch between Home and About a few times and watch the header. It should not move at all.
9. **Add the page areas.** Add the third group: a `main` rule with padding (for example `8px 24px 24px`), and a `footer` rule with its own background color, padding and a smaller `font-size`. Write this group alone. Save and refresh. The page now has three bands: header, main, footer. Because `body` has `margin: 0` and `padding: 0`, the header and footer bands reach the edges of the window.
10. **Write the reusable classes.** Add the fourth group:

    ```css
    /* Reusable classes */
    .lead {
      font-size: 20px;
    }

    /* Continue alone: a .note rule with a light background color and padding. */
    ```

    Then use the classes in your HTML. On the Home page, add `class="lead"` to the Welcome paragraph and `class="note"` to the paragraph in the Contact section. On the About page, add `class="note"` to the first paragraph in About me. For example: `<p class="note">You can find me on …</p>`. Save all three files and refresh both pages. One rule now styles a paragraph on each page.
11. **Modify.** Change the header's `background-color` in `styles.css` to another dark color. Save and refresh *both* pages. Both changed, from one edit in one file. Put back the color you want.
12. **Which rule wins?** At the very end of `styles.css`, add this test rule:

    ```css
    p { background-color: yellow; }
    ```

    Before you save, write down which paragraphs will turn yellow. Then save and refresh. Every paragraph turns yellow except the ones with `class="note"`. The `p` rule comes last, but the `.note` rule is more specific (class beats element), and source order decides only a tie (Concept 5). Your `.lead` paragraph does turn yellow: the `.lead` rule sets only `font-size`, so nothing disagrees with the `p` rule about the background. Delete the test rule, save, and refresh.
13. **Break it on purpose: flex on the wrong element.** In the `nav` rule, cut the line `display: flex;` and paste it into the `nav a` rule instead. Save and refresh. Predict first, then look.

    ![The navy header with the site name on the left and the three links Home, About and Contact stacked on top of each other at the right, making the header taller.](images/p02-nav-broken.png)
    *With `display: flex` on `nav a` instead of `nav`, the links stack in a column and the header grows taller. (real: rendered in Chromium at 800 px)*

    The links now stack, one under the other. Each `<a>` became a flex container of its own, which is a block-level box, so each one starts on a new line (Concept 6). The `nav` is a plain block again, so it has no flex items, and its `gap` does nothing. `display: flex` belongs on the *parent* whose children you want in a row (Concept 7). Move the line back into the `nav` rule, save, and refresh.
14. **Debug: a missing stylesheet on one page.** In `about.html` only, change `href="styles.css"` to `href="style.css"`. Save and refresh the About page. All of your styles are gone from that page, but the Home page is still styled. Press **F12** (or **Ctrl+Shift+J**) to open DevTools, then click the **Console** tab. You should see the red error `Failed to load resource: net::ERR_FILE_NOT_FOUND`, as in the lesson's Exercise. Which file is wrong: `styles.css`, or the page that links it? Fix the `href`, save, and refresh.
15. **Test both pages.** Open each page and tick the box.

    - [ ] Home and About both show your font, colors and three bands
    - [ ] On both pages, the nav is one row on the right of the header, in the same spot
    - [ ] On both pages, the nav links are light and every other link is easy to read
    - [ ] A `.note` box shows on both pages
    - [ ] All six nav clicks from Module 1 still work (three links on two pages)
    - [ ] The Console shows no red errors on either page

16. **Put it online.** Go to Part 3, *Finishing work in Git*, and publish your stylesheet with the save routine. Then run the test from step 15 again on the live site.
