# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **No styles at all.** First, the `<link>` line: it must be inside `<head>`, with `rel="stylesheet"`, and its `href` must match the file's name exactly (`styles.css`, not `style.css`). Second, the file itself: is it called exactly that, and is it in the same folder as the page? Press F12 and open the **Console**: a red `Failed to load resource` error confirms that the stylesheet did not load. (Core concept 1; Exercise step 8)
2. **`.note` against a later `p`.** Green. The class selector `.note` is more specific than the element selector `p`, so it wins even though `p` comes later. Source order decides only when specificity ties. (Core concept 5)
3. **`p a { width: 200px; }`.** Nothing changes. The link is an inline box, and MDN says that for an inline box "The `width`, `height`, and top and bottom margins will have no effect." The selector is fine: `p a` does match the link. The box type is the reason. (Core concepts 4 and 6)

## Common misconception

*"The rule lower down in the stylesheet always wins."* Only when the two rules have the same specificity. In the cascade test, line 3 has `class="note"` and `id="special"`. The `.note` rule comes after `#special` in the file, but the line is purple, not green, because an id selector is more specific than a class selector. Order is only the tie-breaker. You saw the same thing in Project step 12: the `p` test rule came last and still lost to `.note`. (Core concept 5; Project step 12)

## Exercise checks

- **Step 6.** Your page shows your background color, font and text color, two heading colors, the highlighted paragraph with its own background, and a nav bar with its own background and white links in a row with space between them.
- **Step 7.** With `justify-content: center`, the nav links move to the middle of the bar. With a second `.highlight` rule below the first, the second one's background wins: the two rules have the same specificity, so the later one wins. (Core concepts 5 and 7)
- **Step 8.** With `href="style.css"`, every style is gone, the page shows no message, and the Console shows `Failed to load resource: net::ERR_FILE_NOT_FOUND`. (Core concept 1)
- **Step 9.** Only the declaration with the missing colon stops working; for example, with `color #d1495b;` the heading keeps the default color while its other declarations still work. If you deleted a semicolon instead, that declaration *and the next one* stop working. (Core concept 2)

## Self-assessment questions

1. **Why the test rule did not turn the `.note` paragraphs yellow.** When two rules disagree, the more specific one wins. `.note` is a class and `p` is an element, and a class beats an element. Source order decides only a tie, so being last did not help the `p` rule. The `.lead` paragraph did turn yellow, because the `.lead` rule sets only `font-size` and does not disagree about the background. (Project steps 10 and 12)
2. **A mistake you made.** There is no single answer. A good answer names the mistake, quotes what the page or the Console really showed, for example a red `ERR_FILE_NOT_FOUND`, and says how you found the cause, for example by checking which page links which file.
3. **A third page that looks like the other two.** First, type `<link rel="stylesheet" href="styles.css">` as the last line inside its `<head>`, and check the spelling of `styles.css`. Second, copy the same header and footer from your other pages. Third, add a link to the new page in the nav of every page. Fourth, use the classes you already have, like `.note` and `.lead`, where they fit. You do not need a new stylesheet. Fifth, save, press F5, and click between the pages: the nav must sit in the same spot and the header must not jump. Sixth, open the Console and check for red errors. Last, publish and run the test again on the live site. (The brief; Project steps 4, 6, 8, 10, 14, 15 and 16)

## Project checks

- **Brief.** `my-site` holds `index.html`, `about.html`, `image-one.jpg` and `styles.css`. Both pages have the same `<link rel="stylesheet" href="styles.css">` as the last line inside `<head>`, and `styles.css` has the four groups: site-wide basics, header and nav, page areas, reusable classes. (The brief)
- **Step 5.** The Home page is styled; the About page is still plain, because only the Home page links the stylesheet so far. (Step 5; Core concept 1)
- **Step 8.** The header is one dark band, with the site name on the left and the nav as one row on the right, in the same place on both pages. (Step 8; Core concept 7)
- **Step 11.** One edit to the header color in `styles.css` changes both pages. (Step 11; Core concept 1)
- **Step 12.** Every paragraph turns yellow except the `.note` paragraphs. The `.lead` paragraph turns yellow too, because `.lead` does not set a background. (Step 12; Core concept 5)
- **Step 13.** With `display: flex` on `nav a`, the links stack in a column and the header grows taller. Each link became a block-level flex container, and the `nav` was no longer a flex container. (Step 13; Core concepts 6 and 7)
- **Step 14.** With `href="style.css"` on the About page only, the About page loses every style while the Home page keeps them, and the Console shows `Failed to load resource: net::ERR_FILE_NOT_FOUND`. The page's link was wrong; `styles.css` was fine. (Step 14; Core concept 1)
- **Finishing work.** `git status` says `nothing to commit, working tree clean`, `git log --oneline` shows `Style the site with one shared stylesheet` on top, and the live address shows both pages styled with no red errors in the Console. (Part 3, steps 6 to 8)
