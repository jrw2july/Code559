# Troubleshooting: five common problems

Each problem has the symptom you see, why it happens, and the fix. Each one was made on purpose in the sample `site-data.js` and run with Node 22. The messages were captured on Linux, with the folder path changed to the course folder; on Windows, Node prints the same words with your own path. The `at` lines under each message are left out here, and your line numbers will differ. After each fix, save, run `node site-data.js` again from the `my-site` folder, and check every line against its `// expect` comment. Problem 4 prints no error at all. Your tests are what catch it.

### 1. TypeError: Cannot read properties of undefined

**Symptom.** Some groups print, then the file stops. With `projects[projects.length].title` in place of `projects[projects.length - 1].title` in the data tests, the sample printed `--- the data ---`, `5` and `Shop flyer`, and then:

```
C:\Users\you\Documents\code559\my-site\site-data.js:135
console.log(projects[projects.length].title);
                                      ^

TypeError: Cannot read properties of undefined (reading 'title')
```

With `tag:` in place of `tags:` in one project, the sample stopped at the first `titlesWithTag` test with `TypeError: Cannot read properties of undefined (reading 'includes')`, pointing at the line `if (item.tags.includes(tag)) {`. Project step 12 shows the same message for `year`.

**Why.** The code asked for a property **of** something that is `undefined`. There are two usual ways to get there. An index past the end gives `undefined` (Core concept 2): with 5 projects, `projects[5]` does not exist. Or a property the object does not have gives `undefined` (Core concept 9): a project with `tag` has no `tags`. Reading `undefined` is allowed. Reading a property of it is not, so Node stops. The name in brackets at the end of the message is the property it tried to read, and the caret points at that name in your line.

**Fix.** Look at what comes just before the property named in the message. If it holds an index, check the index: the last item is at `length - 1`, and a loop checks `i < list.length`, not `<=`. If it is a property such as `item.tags`, check the spelling of that property in every object of your data, capital letters included. `console.log()` the object to see its real property names, as in Project step 13.

### 2. TypeError: x is not a function

**Symptom.** Some groups print, then the file stops. With `.join(", ")` added after `titleLine(projects)` in the summary, the sample printed every group down to `5 projects, 3 live`, and then:

```
C:\Users\you\Documents\code559\my-site\site-data.js:172
console.log("Titles: " + titleLine(projects).join(", "));
                                             ^

TypeError: titleLine(...).join is not a function
```

With `list.length()` in `newestYear`, the message was `TypeError: list.length is not a function` (Project step 12). And with `let titles = "";` in place of `const titles = [];` in `titleLine`, it was `TypeError: titles.push is not a function`.

**Why.** Parentheses mean "run this." Each of these put `()` after something that cannot run. `.length` is a property: a number, not a method (Core concept 8). `titleLine` returns text, already joined, and text has no `.join()` method: `.join()` belongs to arrays. And `""` is empty text, not an empty array, so it has no `.push()`. The `(...)` in the first message stands for the call, `titleLine(projects)`, whose answer was a string.

**Fix.** Find the name just before `is not a function`, and ask what kind of value it holds. A property, such as `.length`, loses its parentheses. A method has to belong to the right type: `.push()` and `.join()` need an array, and `[]` makes an empty one. If a function already returns text, use the text as it is.

### 3. TypeError: Assignment to constant variable.

**Symptom.** Some groups print, then the file stops. With `const count = 0;` in `countLive`, the sample printed the data group and the `--- countLive ---` heading, and then:

```
C:\Users\you\Documents\code559\my-site\site-data.js:74
      count++;
           ^

TypeError: Assignment to constant variable.
```

With `const i = 1` in the `for` line of `newestYear`, the message was the same, and the caret pointed at the `i++` part of the line.

**Why.** A `const` cannot get a new value (Module 6). `count++` and `i++` both give the name a new value, 1 more than before. Notice when the error comes: not at the `const` line, but the first time the code tries to change the value. In `countLive`, that is at the first live project. In the loop, it is right after the first lap, when the step `i++` runs.

**Fix.** Use `let` for a counter, for the `i` of a counting `for` loop, and for a value such as `newest` that changes as the loop runs. Keep `const` for everything else, including the arrays you `.push()` onto and the `item` of a `for...of` loop: each lap makes a new `item`, so it never changes.

### 4. A number or a list that is too small, with no error

**Symptom.** No error, but some answers are smaller than your predictions. Two mistakes gave this in the sample.

- With `return count;` moved up inside the loop, just under the `if` block, the `countLive` group printed `0`, `undefined` and `0` instead of `3`, `0` and `1`. The summary said `5 projects, 0 live`.
- With the year of one milestone typed as `"2026"`, in quotes, the 2026 line of the `milestonesFrom` group printed only `[ 'First page live' ]`, and the last summary line lost a title too.

**Why.** `return` ends the function at once, even in the middle of a loop (Module 7). With `return` inside the loop, the function stops at the end of the first lap and hands back the count so far. The sample's first project is not live, so the answer was `0`. With an empty list there is no lap at all, the function reaches its end with no `return`, and the answer is `undefined`. The year in quotes is text, and `===` treats different types as different (Module 6): `"2026" === 2026` is `false`, so that milestone is never picked.

**Fix.** Put `return` after the loop's closing brace, so it runs once, when every item has been checked. Check the indentation: the `return` lines up with the `for`, not with the `if`. For the year, take the quotes off: every `year` in your data is a number. Both bugs pass some tests and fail others, which is why each function has more than one test.

### 5. SyntaxError messages

**Symptom.** Nothing prints at all, not even the first heading line. Node shows a line of your file, a caret or carets, and a message that starts with `SyntaxError`.

**Why.** Node could not read the file as JavaScript, so it ran none of it. In this file, most of these come from the data: many brackets, braces and commas in a row. Each message below was made on purpose in the sample file.

| Message | Usual cause | Where to look |
|---|---|---|
| `Unexpected token '{'` | A comma missing between two objects (or a `)` missing before `{`; see Module 7, Problem 6) | The `}` just above the named line |
| `Unexpected identifier 'year'` | A comma missing at the end of the property above | The line just above the named line |
| `Invalid shorthand property initializer` | `=` in place of `:` in a property, such as `year = 2025` | The named line |
| `Unexpected token 'const'` | The `]` missing at the end of the `projects` array | The end of the array just above |
| `Unexpected token ']'` | The `}` missing at the end of the last object | The line just above the named `]` |
| `Invalid or unexpected token` | A missing quote, so a string never ends | The string under the carets |

**Fix.** Fix the one thing the row points to, save, and run. If the message changes, read the new one from the top: one missing comma can hide another mistake below it. For messages about the braces of a function or an `if`, Problem 6 in the Module 7 packet has a longer table: the rules are the same.
