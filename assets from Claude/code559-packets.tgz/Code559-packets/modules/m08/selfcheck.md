# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 9. If a line is a 1 or a 2, reread that Core concept and redo its Exercise or Project step.

## Rubric

- I can make an array, read an item by its index counting from 0, and find the last item with length - 1
- I can add an item with .push(), and explain why it works on an array made with const
- I can write a counting for loop, name its start, check and step, and spot an off-by-one error from <=
- I can put an if inside a loop to count or collect items, with the return placed after the loop
- I can choose between for...of and the counting for loop, and say why
- I can use .includes() and .join(), and predict what capital letters and an empty array do to them
- I can tell a property from a method, and fix "is not a function" when parentheses are on a property
- I can write an array of objects, read its properties with a dot, and find a misspelled property from the undefined it gives
- I can combine checks with &&, || and !, and predict the result before I run it

## Three questions to answer in writing

1. In the Exercise, changing `<` to `<=` printed one extra line, `4: undefined`, with no error. In Project step 12, the same change in `newestYear` stopped the file with a `TypeError`. Explain the difference.
2. Pick one test from your project, or one prediction from the Exercise, where your first answer was wrong. What did you write down, what did Node or the Console show, and what do you understand now that you did not before?
3. A friend wrote this from the description *"Write a function that takes a list of projects and returns the titles of the live ones as one line of text."* With Sam's `projects`, what does `console.log(liveLine(projects));` print? What two changes fix it? And if you fix only the line with `return`, what does it print then?

   ```js
   function liveLine(list) {
     const titles = [];
     for (const item of list) {
       if (item.live) {
         titles.push(item.titel);
       }
       return titles.join(", ");
     }
   }
   ```
