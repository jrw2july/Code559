# Project: site-data.js

*Your hands, about 90 minutes (estimate).* In the Exercise you kept a list of interests in an array, visited each item with a loop, and picked places from an array of objects with `&&` and `!`. Now you do the same with data about you. The file is `site-data.js`. It holds your real projects and milestones as two arrays of objects, and five small functions that summarize them. Each function starts as a one-sentence description, and you write its tests **before** its body, as in Module 7. You use only what Modules 5 to 8 taught:

- comments, `console.log()`, `const` and `let`
- joining text with `+`, `-` to subtract, and the comparisons `===`, `>`, `<` and `<=`
- `if`, and functions with parameters, `return` and `null`
- arrays with an index from 0, `.length`, `.push()`, `.includes()` and `.join()`
- the counting `for` loop with `++`, and `for...of`
- objects with dot access, and `&&` and `!`

This project goes in `my-site`, next to `about-me.js`, `plan-my-day.js` and `helpers.js`. Any `my-site` that is a Git repository connected to GitHub works, because no page uses the file yet.

## The brief

Read the whole brief twice before you type anything.

When you finish, `my-site` holds a new file, `site-data.js`, at the top level, next to `index.html`. No page links to it and no page runs it yet: like your other scripts, it runs in the terminal only. It does not use `helpers.js`. Each script in this course stands alone.

**The data.** Two arrays of objects, with your own real items in them.

- **`projects`**: the things you have built. Every packet project you finished counts: your Home and About pages, your Interests page, the rating card, your scripts. Something you made before this course counts too. Each project is an object with five properties, always in this order: `title` (text), `year` (a number, with no quotes), `description` (one short sentence), `tags` (an array of lowercase words such as `"html"`, `"css"` and `"js"`) and `live` (`true` when a visitor can open it as a page on your live site, `false` when not; a script runs in the terminal only, so it is `false`).
- **`milestones`**: things that happened on your way, such as the day your first page went live. Each milestone is an object with three properties: `title`, `year` and `description`. A milestone is not something you built, so it has no tags and nothing to put live.

Use at least four projects and three milestones. To give your tests something to find, include at least one project that is live and one that is not, two projects with the same tag, and two milestones from the same year.

**The five descriptions.** Each function is one sentence. Use the names given here, so your tests and the answers in Part 6 line up.

1. **`countLive`.** Write a function that takes a list of projects and returns how many of them are live.
2. **`titleLine`.** Write a function that takes a list of projects or milestones and returns all the titles as one line of text, with a comma and a space between them.
3. **`titlesWithTag`.** Write a function that takes a list of projects and a tag, and returns an array of the titles of the projects that have that tag.
4. **`milestonesFrom`.** Write a function that takes a list of milestones and a year, and returns an array of the titles of the milestones from that year.
5. **`newestYear`.** Write a function that takes a list of projects or milestones and returns the newest year in it, or `null` when the list is empty.

**What it prints.** Run from the `my-site` folder, `node site-data.js` printed exactly these 31 lines for the sample student, Sam:

```
--- the data ---
5
Shop flyer
Plan my day
4
--- countLive ---
3
0
1
--- titleLine ---
Shop flyer, Home and About, Interests page, Rating card, Plan my day
Joined a bike club, Started to code, First page live, First tested function
Only one
--- titlesWithTag ---
[ 'Plan my day' ]
[ 'Home and About', 'Interests page', 'Rating card' ]
[]
--- milestonesFrom ---
[ 'First page live', 'First tested function' ]
[ 'Started to code' ]
[]
--- newestYear ---
2026
2026
null
--- summary ---
5 projects, 3 live
Titles: Shop flyer, Home and About, Interests page, Rating card, Plan my day
Not live yet: Shop flyer
Not live yet: Plan my day
Latest milestones (2026): First page live, First tested function
```

<img src="images/p08-tests-pass.png" alt="A terminal in the my-site folder running node site-data.js. It prints seven groups: --- the data --- with 5, Shop flyer, Plan my day and 4; --- countLive --- with 3, 0 and 1; --- titleLine --- with the five project titles, the four milestone titles and Only one; --- titlesWithTag --- with [ 'Plan my day' ], [ 'Home and About', 'Interests page', 'Rating card' ] and []; --- milestonesFrom --- with [ 'First page live', 'First tested function' ], [ 'Started to code' ] and []; --- newestYear --- with 2026, 2026 and null; and --- summary --- with 5 projects, 3 live, the titles, two Not live yet lines, and Latest milestones (2026): First page live, First tested function." style="max-height:2.3in"> *The finished file for the sample student, in one run. Each line matches its `// expect` comment. Arrays print with square brackets and single quotes, and an empty array prints as `[]`. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*

Your file prints the same shape with your own data:

- **One group of test lines for the data, then one group per function**, in the order of the descriptions. Each group starts with a heading line, such as `--- countLive ---`.
- **The data group** checks the arrays: the number of projects, the first title, the last title (found with `length - 1`), and the number of milestones.
- **At least three tests per function, and one of them an edge.** For `countLive` and `newestYear`, an empty list, `[]`. For `titleLine`, a list with one item. For `titlesWithTag`, a tag in capital letters. For `milestonesFrom`, a year with no milestones.
- **A summary group at the end** that uses the functions together: how many projects and how many are live, every title, one `Not live yet:` line for each project that is not live, and the titles of the milestones from the newest year.

**What is inside the file.**

- The first two lines are comments: the file name with one sentence about what it does, and how to run it.
- Four parts, each under its own heading comment, in this order: `// ===== The data =====`, `// ===== The functions =====`, `// ===== The tests =====` and `// ===== The summary =====`.
- Above each function, a comment with its name and its description, in your words.
- Above each group of tests, a comment that starts with `// expect` and lists your predictions, in order.
- Every function hands its answer back with `return`. No function has a `console.log()` inside it.
- `const` for every name that keeps its value, and `let` only for a value that changes as a loop runs: a counter, the loop's `i`, or the newest year so far. Never `var`. Comparisons use `===`, never `==`.

## The steps

Type every line. Do not paste. You may copy a test line and change only its argument, once you have typed the first test line of a group yourself.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`.
2. **Plan on paper.** Start from the array of objects you wrote at the end of the lesson. On one page, list your projects. For each one, write its title, its year, one short sentence, its tags and whether it is live. On a second page, list your milestones with a title, a year and a sentence each. Read both lists once more: everything on them will be public, so leave out anything private, such as your full name, your school or where you live. Then, as in Module 7, make a small table for the five functions with three columns: **Name**, **Inputs** (one parameter name for each input) and **Output and its type**. For example, `countLive` takes `list` and returns a number. Do not write any code yet.
3. **Start the file.** In the VS Code Explorer, create `site-data.js` at the top level of `my-site`, next to `index.html`. Type these lines, then save with Ctrl+S:

   ```js
   // site-data.js: my projects and milestones, with functions that summarize them
   // Run it from the my-site folder with: node site-data.js

   // ===== The data =====

   // ===== The functions =====

   // ===== The tests =====
   ```

   The data comes first, so every function and every test can use it. **Predict** before you run: what will `node site-data.js` print? Then type `node site-data.js` and press Enter. The prompt came straight back: only comments, so nothing to run.
4. **The data, and its first tests.** Under `// ===== The data =====`, leave one blank line and type the `projects` array. Put your own first project in place of Sam's:

   ```js
   const projects = [
     {
       title: "Shop flyer",
       year: 2025,
       description: "A flyer page for a friend's bike shop.",
       tags: ["html"],
       live: false
     },
     // Continue alone: one object for each of your other projects,
     // with the same five properties in the same order.
   ];
   ```

   Each object sits inside its own curly braces, one property per line. Commas go **between** properties and **between** objects. Sam's file has no comma after the last property of an object, and none after the last object. The year and `live` have no quotes: one is a number and the other a Boolean, and your functions compare them that way. Add your other projects, then delete the two "Continue alone" lines.

   Below the `projects` array, leave one blank line and type a `milestones` array the same way, with three properties per object: `title`, `year` and `description`. Sam's first milestone was:

   ```js
   const milestones = [
     {
       title: "Joined a bike club",
       year: 2024,
       description: "Weekly rides, and my first long route."
     },
     // Continue alone: your other milestones, oldest first.
   ];
   ```

   Now test the data before you build anything on it. Under `// ===== The tests =====`, leave one blank line and type:

   ```js
   console.log("--- the data ---");
   // expect 5, Shop flyer, Plan my day, 4
   console.log(projects.length);
   console.log(projects[0].title);
   console.log(projects[projects.length - 1].title);
   console.log(milestones.length);
   ```

   Change the `// expect` comment to your own predictions: how many projects you typed, your first title, your last title, and how many milestones. `projects[0].title` reads from left to right: the array, then item 0, then its `title` (Core concept 9). `projects.length - 1` is the index of the last item, because counting starts at 0 (Core concept 2). Save and run. The sample printed `--- the data ---`, `5`, `Shop flyer`, `Plan my day` and `4`. If Node prints a `SyntaxError` and nothing else, a comma or a bracket is missing in the data. See Problem 5 in Part 4, *Troubleshooting*.
5. **`countLive`: the tests first, then the body.** Under the data tests, leave one blank line and type:

   ```js
   console.log("--- countLive ---");
   // expect 3, 0, 1
   console.log(countLive(projects));
   console.log(countLive([]));
   console.log(countLive([{ live: false }, { live: true }]));
   ```

   Change the first prediction to the number of your live projects. `[]` is an array with no items in it: its length is 0. That is the edge: a list with nothing to count. The last test passes a small array of two objects, made right inside the parentheses. Each object has only a `live` property, because that is the only one `countLive` reads. **Think this through:** the function does not exist yet. What will Node do? Save and run. The sample printed the whole data group, the heading line `--- countLive ---`, and then this (the `at` lines below it are left out):

   ```
   C:\Users\you\Documents\code559\my-site\site-data.js:80
   console.log(countLive(projects));
           ^

   ReferenceError: countLive is not defined
   ```

   You saw this message in Module 7. Your line number will differ, because your data has a different number of lines.

   Now the body. Under `// ===== The functions =====`, leave one blank line and type the function with its comment:

   ```js
   // countLive: takes a list of projects and returns how many of them are live.
   function countLive(list) {
     let count = 0;
     for (const item of list) {
       if (item.live) {
         count++;
       }
     }
     return count;
   }
   ```

   This is the counter pattern from Core concept 5: a counter before the loop, a check inside it, and the answer after it. `count` uses `let`, because it changes on every live project. The `for...of` loop puts each object in `item`, one lap at a time (Core concept 6). `item.live` is already `true` or `false`, so it can be the whole condition. The `return` comes **after** the loop's closing brace, so it runs once, when every item has been checked. Save and run. The sample printed `3`, `0` and `1` under the heading.
6. **`titleLine`: push, then join.** Under the `countLive` tests, leave one blank line and type the tests first:

   ```js
   console.log("--- titleLine ---");
   // expect the five project titles, the four milestone titles, Only one
   console.log(titleLine(projects));
   console.log(titleLine(milestones));
   console.log(titleLine([{ title: "Only one" }]));
   ```

   Write your own `// expect` comment. The second test passes the milestones: they have a `title` too, so the same function works for both arrays. The last test is the edge: a list with one item. Run once and see the `ReferenceError` for the new name. Then, under the `countLive` function, leave one blank line and start the function:

   ```js
   // titleLine: takes a list of projects or milestones and returns all the
   // titles as one line of text, with a comma and a space between them.
   function titleLine(list) {
     const titles = [];
     for (const item of list) {
       // Continue alone: push this item's title onto titles.
     }
     // Continue alone: return titles joined with a comma and a space.
   }
   ```

   `titles` starts as an empty array, and the loop fills it with `.push()`. It can be a `const`, because the name always points at the same array. Only the array's contents change (Core concept 3). After the loop, `.join(", ")` turns the array into one line of text (Core concept 7). Write the two missing lines, delete the "Continue alone" comments, save and run. The sample printed its five project titles on one line, its four milestone titles on the next, and `Only one`. With one item, there is nothing to put a comma between, so `.join()` adds none.
7. **`titlesWithTag`: a check inside the loop.** Under the `titleLine` tests, leave one blank line and type the tests first:

   ```js
   console.log("--- titlesWithTag ---");
   // expect [ 'Plan my day' ], the three css titles, []
   console.log(titlesWithTag(projects, "js"));
   console.log(titlesWithTag(projects, "css"));
   console.log(titlesWithTag(projects, "CSS"));
   ```

   Use tags from your own data, and write your predictions. The capital letters in `"CSS"` are the edge: `.includes()` is exact, so `"CSS"` and `"css"` are different. This function returns an array, not text. In Node, `console.log()` shows an array with square brackets, a space inside each bracket, and single quotes around each string, such as `[ 'Plan my day' ]`. An empty array shows as `[]`. Run once and see the `ReferenceError`. Then, under `titleLine`, start the function:

   ```js
   // titlesWithTag: takes a list of projects and a tag, and returns an array
   // of the titles of the projects that have that tag.
   function titlesWithTag(list, tag) {
     const titles = [];
     for (const item of list) {
       // Continue alone: if item.tags includes tag, push item.title onto titles.
     }
     return titles;
   }
   ```

   `item.tags` is an array inside an object, so `item.tags.includes(tag)` reads from left to right: this project, its tags, and then the question "is `tag` in here?" The answer is `true` or `false`, which is exactly what an `if` needs. Write the `if` block, delete the comment, save and run. The sample printed `[ 'Plan my day' ]`, `[ 'Home and About', 'Interests page', 'Rating card' ]` and `[]`.
8. **`milestonesFrom`: create it alone.** This one has no code to copy, only the description from the brief. Do all five steps from Module 7 yourself. Steps 1 to 3 (name, inputs, output) are already in your table from step 2. Then:

   - In the tests part, under the `titlesWithTag` tests, type a heading line `--- milestonesFrom ---`, an `// expect` comment and three test lines: a year with two of your milestones, a year with one, and a year with none. Fill in the `// expect` comment before you run anything.
   - Run once and see the `ReferenceError`, as before.
   - In the functions part, under `titlesWithTag`, type the comment and the function. It has two parameters, the list and the year. Its shape is the same as `titlesWithTag`: an empty array, a loop, a check, a push, and a `return` after the loop. Only the check is different.

   Save and run. The sample tested 2026, 2025 and 2020, and printed `[ 'First page live', 'First tested function' ]`, `[ 'Started to code' ]` and `[]`. If every line prints `[]`, look at the check: it compares a number with a number only when the year in the test line and the year in the data both have no quotes.
9. **`newestYear`: the counting loop, and `null`.** Under the `milestonesFrom` tests, leave one blank line and type the tests first:

   ```js
   console.log("--- newestYear ---");
   // expect 2026, 2026, null
   console.log(newestYear(projects));
   console.log(newestYear([{ year: 2024 }, { year: 2026 }, { year: 2025 }]));
   console.log(newestYear([]));
   ```

   The second test hides the newest year in the middle of the list, so a function that only looks at the first or the last item fails it. The last test is the edge: an empty list has no newest year at all. Run once and see the `ReferenceError`. Then, under `milestonesFrom`, type the whole function:

   ```js
   // newestYear: takes a list of projects or milestones and returns the
   // newest year in it, or null when the list is empty.
   function newestYear(list) {
     if (list.length === 0) {
       return null;
     }
     let newest = list[0].year;
     for (let i = 1; i < list.length; i++) {
       if (list[i].year > newest) {
         newest = list[i].year;
       }
     }
     return newest;
   }
   ```

   Read it in three parts. First, an empty list returns `null` at once, the "no answer" on purpose from Module 7. Second, `newest` starts as the year of item 0, the best answer so far. Third, the loop checks every other item. It uses the counting `for` loop (Core concept 4) because it needs the positions: it starts at index 1, since item 0 is already in `newest`. Each time an item's year is greater, `newest` takes that year. That is why it is a `let`. Save and run. The sample printed `2026`, `2026` and `null`.
10. **The summary: use the functions together.** Under the last test line, leave one blank line and type:

    ```js
    // ===== The summary =====

    console.log("--- summary ---");
    console.log(projects.length + " projects, " + countLive(projects) + " live");
    console.log("Titles: " + titleLine(projects));
    for (const project of projects) {
      if (!project.live) {
        console.log("Not live yet: " + project.title);
      }
    }
    const latest = newestYear(milestones);
    const latestTitles = milestonesFrom(milestones, latest);
    console.log("Latest milestones (" + latest + "): " + latestTitles.join(", "));
    ```

    Read the `if` to yourself, out loud: "not live." `!` flips `false` to `true`, so the line prints for each project that is not live (Core concept 11). The last three lines hand the answer of one function to another: `newestYear` finds the year, and `milestonesFrom` uses it. **Think this through:** how many lines will the summary group print for your data? Write down your answer, then save and run. The sample printed five: `5 projects, 3 live`, the titles, two `Not live yet:` lines, and `Latest milestones (2026): First page live, First tested function`.
11. **Modify.** Make two changes, one at a time. Predict each before you run it, then undo it.

    - **Only live projects.** In `titlesWithTag`, change the condition to `item.tags.includes(tag) && item.live`. Save. Which test lines will change? Write them down, then run. In the sample, only the first `titlesWithTag` line changed, from `[ 'Plan my day' ]` to `[]`: `&&` needs both sides to be `true` (Core concept 11), and Plan my day is not live. The three css projects are all live, so that line stayed the same. Change the condition back, save and run.
    - **One more project.** Under the `milestones` array, leave one blank line and add a project with `.push()`:

      ```js
      projects.push({
        title: "Site data",
        year: 2026,
        description: "My projects and milestones as data.",
        tags: ["js"],
        live: false
      });
      ```

      **Think this through:** which groups will change, and which will not? Write down your answer, then save and run. In the sample, the data group showed `6` and `Site data` as the last title. `countLive(projects)` stayed `3`, because the new project is not live. The first `titleLine` line, the first `titlesWithTag` line and the summary all grew. The summary printed `6 projects, 3 live` and a third `Not live yet:` line. Your `// expect` comments are now out of date, which is what a failing test looks like. Delete the `projects.push(...)` lines, save and run, and check that every line matches again. In Part 3 you add a real item and update the predictions too.
12. **Break it on purpose.** Two mistakes from the lesson. Make each one, run, look, and undo it before the next.

    - **One lap too many.** In `newestYear`, change `i < list.length` to `i <= list.length`. In the Exercise, this mistake printed one extra line with `undefined` and no error. **Think this through:** what will happen here, where each item is an object? Write it down, then save and run.

      The sample printed the groups above `newestYear` as before, then the heading `--- newestYear ---`, and then this (the `at` lines below it are left out):

      ```
      C:\Users\you\Documents\code559\my-site\site-data.js:122
          if (list[i].year > newest) {
                      ^

      TypeError: Cannot read properties of undefined (reading 'year')
      ```

      The same one-character mistake as in the Exercise, but this time it is an error, and Node stops at the first `newestYear` test. On the last lap `i` equals the length, so `list[i]` is `undefined`. In the Exercise, `interests[4]` was `undefined` too, and printing `undefined` is allowed. Here the code reads a property **of** that `undefined`, and that is not allowed: there is no object to read from. The message names the property it tried to read, `year`. Change `<=` back to `<`, save and run.
    - **Parentheses on a property.** In `newestYear`, change `list.length === 0` to `list.length() === 0`. Predict, save and run. The sample printed the groups above `newestYear` and then stopped with `TypeError: list.length is not a function`. `.length` is a property, a number you read. With parentheses, JavaScript tries to run that number, as `tags.length()` did in Core concept 8. Delete the parentheses, save and run.
13. **Debug: `undefined` with no error.** Here is a typing mistake that is easy to make in the data. In the object for your fourth project, change `title` to `titel`. Save. Before you run, write down which lines you expect to change. Then run.

    <img src="images/p08-typo-undefined.png" alt="A terminal in the my-site folder running node site-data.js with the typo. There is no error. In the titleLine group, the first line reads Shop flyer, Home and About, Interests page, , Plan my day, with nothing between two commas. In the titlesWithTag group, the second line reads [ 'Home and About', 'Interests page', undefined ]. The summary's Titles line has the same empty gap. Every other line is the same as before." style="max-height:1.9in"> *One misspelled property name, no error message, and three wrong lines. Rating card is missing from both lines of titles, and the css array shows `undefined` where its title was. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*

    Asking an object for a property it does not have gives `undefined`, quietly (Core concept 9). Every function that reads `item.title` got `undefined` for that one object.

    In the array, `undefined` has no quotes: it is the value, not the text "undefined". In the two lines of titles it does not show at all, because `.join()` turns it into empty text (MDN, *Array.prototype.join()*: "If an element is `undefined` or `null`, it is converted to an empty string"). A gap between two commas is the clue.

    To find the object, count: the gap is where the fourth title should be, so the object is at index 3. Add this line at the end of the data tests, save and run:

    ```js
    console.log(projects[3]);
    ```

    Node printed the whole object, and the misspelled name is right there:

    ```
    {
      titel: 'Rating card',
      year: 2026,
      description: 'A card that asks visitors to rate a lesson.',
      tags: [ 'html', 'css' ],
      live: true
    }
    ```

    Change `titel` back to `title`, delete the `console.log(projects[3]);` line, save and run. Check every line against your comments. In your notebook, write one sentence on why `countLive` still gave the right answer while this bug was in the data.
14. **Explain it.** With every test passing, read the whole file to yourself, out loud, from top to bottom. For each function, say its parameters, what type of value it returns, and which test checks its edge. For each loop, say what is in the loop's variable on the first lap and on the last lap. For `newestYear`, say why the loop starts at 1 and why the check uses `<`, not `<=`. If there is a line you cannot explain, reread the Core concept it comes from.
15. **Looking ahead to Module 9.** No page uses `site-data.js` yet. In Module 9 you learn to build page items from an array of objects: a `for...of` loop visits each object, and for each one, `document.createElement()` makes a new list item and `append()` puts it on the page. It is the same shape as the loops you wrote here, with a page element where your `.push()` was. The habits carry over too: check the data first, read each property with a dot, and test with an empty list.
16. **Check the file.** Tick each box.

    - [ ] `site-data.js` is in `my-site`, next to `index.html`, not in `practice-08`
    - [ ] The prompt ends in `my-site>`, and `node site-data.js` prints seven groups with no error
    - [ ] Every test line matches its `// expect` comment, in order
    - [ ] Each function has at least three tests, one of them an edge: an empty list, one item, a tag in capitals, or a year with no milestones
    - [ ] Every project has the same five properties, every milestone the same three, and no `undefined` appears in the output
    - [ ] Every function hands back its answer with `return`; there is no `console.log()` inside any function
    - [ ] `newestYear` uses `<`, not `<=`, and `.length` has no parentheses
    - [ ] The extra `projects.push(...)` line from step 11 and the `console.log(projects[3]);` line from step 13 are gone
    - [ ] Nothing in the data is private: titles, years and short sentences you are happy for anyone to read

17. **Save it in Git.** Go to Part 3, *Finishing work in Git*, and save the file with the save routine.
