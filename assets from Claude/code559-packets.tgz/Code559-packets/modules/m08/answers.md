# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **`tags.length()` and `tags.push("js")`.** `.length` is a property: a value stored on the array, the number of items. You read it, so it takes no parentheses. Parentheses mean "run this," and a number cannot run, so `tags.length()` stops with `TypeError: tags.length is not a function`. `.push()` is a method: a function that belongs to the array. It needs parentheses to run, and the item to add goes inside them. Without the parentheses, `tags.push` is only a reference to the function, as with `showMessage` in Module 7, and nothing is added. (Core concept 8)
2. **The last of six projects.** It is at index 5, because the first one is at index 0. Write it as `projects[projects.length - 1]`. With six projects, `projects.length - 1` is 5. Push a seventh, and the same code reads index 6 with no change. (Core concept 2)
3. **What value does `n` hold?** `2`. The loop checks each place with `p.visited || p.free`, which is `true` when at least one side is `true`. City library: visited, so `true`, and `n` becomes 1. Art museum: not visited and not free, so `false || false`, which is `false`. River park: not visited, but free, so `true`, and `n` becomes 2. (Core concepts 5 and 11)

## Common misconception

*"An array with 4 items ends at index 4."* It ends at index 3. The index counts steps from the start, so the first item is 0 steps away and the fourth is 3 steps away. The length, 4, is how many items there are, not a position: the last index is always `length - 1`. In the Concept 2 picture, `pages[4]` printed `undefined`, because there is nothing there. The same belief causes the off-by-one error: a loop with `i <= list.length` makes one lap too many. In the Exercise that lap printed `4: undefined`. In Project step 12 it read `.year` from that `undefined` and stopped with a `TypeError`. (Core concepts 1, 2 and 4; Exercise step 7; Project step 12)

## Exercise checks

These are the results with the example data, and with `"cooking"` pushed in step 2, as in the lesson's picture. With your own interests, the shape is the same.

- **Step 1.** `3` and `music`. `interests.length` is 3, and `interests[interests.length - 1]` is `interests[2]`, the last item. (Core concepts 1 and 2)
- **Step 2.** The `.push()` line prints nothing by itself. It adds the item at the end, and the length is now 4. (Core concept 3)
- **Step 3.** Four lines: `0: drawing`, `1: cycling`, `2: music` and `3: cooking`. (Core concept 4)
- **Step 4.** `true` for an item you have and `false` for one you do not, then `drawing | cycling | music | cooking`. (Core concept 7)
- **Steps 5 and 6.** Ten lines in all: `3`, `music`, the four loop lines, `true`, `false`, the joined line, and `Next free trip: River park`. City library is free but already visited, so `!place.visited` is `false`. Art museum is not visited, but it is not free. Only River park makes both sides of `&&` true. (Core concepts 9 and 11)
- **Step 7.** The loop prints a fifth line, `4: undefined`, and the run has 11 lines. There is no error. On the last lap `i` is 4, the same as the length, and `interests[4]` does not exist. (Core concepts 2 and 4)
- **Step 8.** One possible answer:

  ```js
  let freeCount = 0;
  for (const place of places) {
    if (place.free) {
      freeCount++;
    }
  }
  console.log(freeCount);
  ```

  It prints `2`, as the last of 11 lines: City library and River park are free. `freeCount` is a `let`, because it changes on each free place. (Core concept 5)
- **Step 9.** With `||`, all three places print: `Next free trip: City library`, `Next free trip: Art museum` and `Next free trip: River park`. With `||`, one true side is enough. City library is free. Art museum and River park are not visited, so `!place.visited` is already `true` for them. With the step 8 loop below it, the run has 13 lines. (Core concept 11)

## Self-assessment questions

1. **`undefined` in the Exercise, a `TypeError` in the project.** In both, the extra lap reads one index past the end, and that gives `undefined`. In the Exercise, the code only printed that value: `interests[4]` joined to `"4: "` gave the line `4: undefined`. Printing `undefined` is allowed, so there was no error. In `newestYear`, each item is an object, and the code reads a property of it: `list[i].year`. On the extra lap, `list[i]` is `undefined`, and `undefined` has no properties at all. Node cannot read `.year` from nothing, so it stops with `TypeError: Cannot read properties of undefined (reading 'year')`. The cause is the same `<=`; the result depends on what the code does with the missing item. (Core concepts 2, 4 and 9; Project step 12)
2. **A prediction you got wrong.** There is no single answer. A good answer quotes what you wrote down before the run, quotes what Node or the Console really showed, and names the idea you understand now. For example: that `.push()` hands back the new length, not the array, or that `.join()` shows an `undefined` item as nothing at all.
3. **The friend's `liveLine`.** It prints an empty line, with no error. There are two mistakes. First, `return` is inside the loop, so the function ends at the end of the first lap. Sam's first project, Shop flyer, is not live, so nothing was pushed, and `[].join(", ")` is empty text. Second, `item.titel` is misspelled, so every push adds `undefined`. The two changes: move `return titles.join(", ");` below the loop's closing brace, and change `titel` to `title`. With only the `return` moved, it prints `, , ` (two commas and two spaces): three `undefined` items, which `.join()` turns into empty text. With both changes, it prints `Home and About, Interests page, Rating card`. (Core concepts 7 and 9; Project step 13; Problem 4 in Part 4)

## Project checks

- **Step 2.** The sample's plan for the functions:

  | Name | Inputs | Output and its type |
  |---|---|---|
  | `countLive` | `list` | a number, like `3` |
  | `titleLine` | `list` | a string, like `Shop flyer, Home and About` |
  | `titlesWithTag` | `list`, `tag` | an array of strings, like `[ 'Plan my day' ]` |
  | `milestonesFrom` | `list`, `year` | an array of strings, or `[]` when there are none |
  | `newestYear` | `list` | a number, like `2026`, or `null` |

- **Step 3.** Nothing prints, and there is no error.
- **Step 4, continue alone.** The sample's two arrays are at the top of the whole file, at the end of this section. With them, the data group printed `5`, `Shop flyer`, `Plan my day` and `4`.
- **Step 5.** Before the function: the data group, the heading, then `ReferenceError: countLive is not defined`, pointing at the first `countLive` test (line 80 in the sample). After it: `3`, `0` and `1`. The empty list gives `0`, not an error: the loop makes no laps, and `count` is still 0 when the function returns it.
- **Step 6, continue alone.** The sample's `titleLine`:

  ```js
  // titleLine: takes a list of projects or milestones and returns all the
  // titles as one line of text, with a comma and a space between them.
  function titleLine(list) {
    const titles = [];
    for (const item of list) {
      titles.push(item.title);
    }
    return titles.join(", ");
  }
  ```

- **Step 7, continue alone.** The sample's `titlesWithTag`:

  ```js
  // titlesWithTag: takes a list of projects and a tag, and returns an array
  // of the titles of the projects that have that tag.
  function titlesWithTag(list, tag) {
    const titles = [];
    for (const item of list) {
      if (item.tags.includes(tag)) {
        titles.push(item.title);
      }
    }
    return titles;
  }
  ```

- **Step 8, create alone.** The sample's tests and function. The tests go in the tests part, the function in the functions part.

  ```js
  console.log("--- milestonesFrom ---");
  // expect the two 2026 titles, [ 'Started to code' ], []
  console.log(milestonesFrom(milestones, 2026));
  console.log(milestonesFrom(milestones, 2025));
  console.log(milestonesFrom(milestones, 2020));
  ```

  ```js
  // milestonesFrom: takes a list of milestones and a year, and returns an
  // array of the titles of the milestones from that year.
  function milestonesFrom(list, year) {
    const titles = [];
    for (const item of list) {
      if (item.year === year) {
        titles.push(item.title);
      }
    }
    return titles;
  }
  ```

- **Step 9.** `2026`, `2026` and `null`. For `[{ year: 2024 }, { year: 2026 }, { year: 2025 }]`, `newest` starts at 2024, becomes 2026 on the first lap, and stays 2026 on the second, because 2025 is not greater.
- **Step 10.** Five lines: `5 projects, 3 live`, `Titles: Shop flyer, Home and About, Interests page, Rating card, Plan my day`, `Not live yet: Shop flyer`, `Not live yet: Plan my day` and `Latest milestones (2026): First page live, First tested function`.
- **Step 11.** With `&& item.live`, only the first `titlesWithTag` line changes, from `[ 'Plan my day' ]` to `[]`.

  With the extra project pushed, six lines change and one is added. In the data group, `6` and `Site data`. The first `titleLine` line ends in `, Site data`, and the first `titlesWithTag` line is `[ 'Plan my day', 'Site data' ]`.

  The summary starts `6 projects, 3 live`, its titles line ends in `, Site data`, and a third line `Not live yet: Site data` is added. The run has 32 lines.
- **Step 12.** With `<=`: `TypeError: Cannot read properties of undefined (reading 'year')` at the first `newestYear` test. With `list.length()`: `TypeError: list.length is not a function`, at the same test. In both runs, every group above `newestYear` prints as before.
- **Step 13.** Three lines change: the first `titleLine` line and the summary's titles line each show a gap, `Interests page, , Plan my day`, and the css line of `titlesWithTag` shows `undefined` in place of `'Rating card'`. `countLive` still gives `3`, because it reads only `item.live`, and that property was spelled right.
- **Step 16.** If you followed the brief, every box is ticked. The most common misses: a `// expect` comment that still holds the sample's predictions instead of yours, and a leftover line from step 11 or step 13. Here is the whole sample file, 180 lines:

  ```js
  // site-data.js: my projects and milestones, with functions that summarize them
  // Run it from the my-site folder with: node site-data.js

  // ===== The data =====

  const projects = [
    {
      title: "Shop flyer",
      year: 2025,
      description: "A flyer page for a friend's bike shop.",
      tags: ["html"],
      live: false
    },
    {
      title: "Home and About",
      year: 2026,
      description: "My first two pages, with one nav bar.",
      tags: ["html", "css"],
      live: true
    },
    {
      title: "Interests page",
      year: 2026,
      description: "A card grid that fits any screen.",
      tags: ["html", "css"],
      live: true
    },
    {
      title: "Rating card",
      year: 2026,
      description: "A card that asks visitors to rate a lesson.",
      tags: ["html", "css"],
      live: true
    },
    {
      title: "Plan my day",
      year: 2026,
      description: "A script that plans any hour of the day.",
      tags: ["js"],
      live: false
    }
  ];

  const milestones = [
    {
      title: "Joined a bike club",
      year: 2024,
      description: "Weekly rides, and my first long route."
    },
    {
      title: "Started to code",
      year: 2025,
      description: "One hour a day, most days."
    },
    {
      title: "First page live",
      year: 2026,
      description: "My Home page went live on GitHub Pages."
    },
    {
      title: "First tested function",
      year: 2026,
      description: "Tests first, then the body."
    }
  ];

  // ===== The functions =====

  // countLive: takes a list of projects and returns how many of them are live.
  function countLive(list) {
    let count = 0;
    for (const item of list) {
      if (item.live) {
        count++;
      }
    }
    return count;
  }

  // titleLine: takes a list of projects or milestones and returns all the
  // titles as one line of text, with a comma and a space between them.
  function titleLine(list) {
    const titles = [];
    for (const item of list) {
      titles.push(item.title);
    }
    return titles.join(", ");
  }

  // titlesWithTag: takes a list of projects and a tag, and returns an array
  // of the titles of the projects that have that tag.
  function titlesWithTag(list, tag) {
    const titles = [];
    for (const item of list) {
      if (item.tags.includes(tag)) {
        titles.push(item.title);
      }
    }
    return titles;
  }

  // milestonesFrom: takes a list of milestones and a year, and returns an
  // array of the titles of the milestones from that year.
  function milestonesFrom(list, year) {
    const titles = [];
    for (const item of list) {
      if (item.year === year) {
        titles.push(item.title);
      }
    }
    return titles;
  }

  // newestYear: takes a list of projects or milestones and returns the
  // newest year in it, or null when the list is empty.
  function newestYear(list) {
    if (list.length === 0) {
      return null;
    }
    let newest = list[0].year;
    for (let i = 1; i < list.length; i++) {
      if (list[i].year > newest) {
        newest = list[i].year;
      }
    }
    return newest;
  }

  // ===== The tests =====

  console.log("--- the data ---");
  // expect 5, Shop flyer, Plan my day, 4
  console.log(projects.length);
  console.log(projects[0].title);
  console.log(projects[projects.length - 1].title);
  console.log(milestones.length);

  console.log("--- countLive ---");
  // expect 3, 0, 1
  console.log(countLive(projects));
  console.log(countLive([]));
  console.log(countLive([{ live: false }, { live: true }]));

  console.log("--- titleLine ---");
  // expect the five project titles, the four milestone titles, Only one
  console.log(titleLine(projects));
  console.log(titleLine(milestones));
  console.log(titleLine([{ title: "Only one" }]));

  console.log("--- titlesWithTag ---");
  // expect [ 'Plan my day' ], the three css titles, []
  console.log(titlesWithTag(projects, "js"));
  console.log(titlesWithTag(projects, "css"));
  console.log(titlesWithTag(projects, "CSS"));

  console.log("--- milestonesFrom ---");
  // expect the two 2026 titles, [ 'Started to code' ], []
  console.log(milestonesFrom(milestones, 2026));
  console.log(milestonesFrom(milestones, 2025));
  console.log(milestonesFrom(milestones, 2020));

  console.log("--- newestYear ---");
  // expect 2026, 2026, null
  console.log(newestYear(projects));
  console.log(newestYear([{ year: 2024 }, { year: 2026 }, { year: 2025 }]));
  console.log(newestYear([]));

  // ===== The summary =====

  console.log("--- summary ---");
  console.log(projects.length + " projects, " + countLive(projects) + " live");
  console.log("Titles: " + titleLine(projects));
  for (const project of projects) {
    if (!project.live) {
      console.log("Not live yet: " + project.title);
    }
  }
  const latest = newestYear(milestones);
  const latestTitles = milestonesFrom(milestones, latest);
  console.log("Latest milestones (" + latest + "): " + latestTitles.join(", "));
  ```

  This is the file before Part 3. In Part 3 you add one more milestone and update three `// expect` comments.
