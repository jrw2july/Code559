# Finishing work in Git

Every test in `site-data.js` passes. Now you save it to GitHub with the same save routine as in Modules 1 to 7: `git status`, `git add .`, `git commit`, `git push`, then check the live site. Two things are new this time. The file holds real facts about you, so you read it as a stranger would before you publish it. And after the first commit you add one more milestone, which changes what your tests should print, and you save that change as a second commit.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 to 7.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **Run the tests one last time.** Type `node site-data.js` and read every line against its `// expect` comment. Look for the signs of the mistakes from Project steps 11 to 13: an `undefined`, a gap between two commas, an extra project you did not plan, or a `TypeError`. Check that the `projects.push(...)` lines and the `console.log(projects[3]);` line are gone. Commit only a file whose tests you have just run and seen pass.
3. **Read your data as a stranger would (NEW: real data is public).** Your earlier scripts printed made-up plans and page names. This file holds real facts about you. Once you push it, anyone who has the address can read it, the same as your pages. Read every `title` and every `description` once more, slowly. Keep what you would put on your About page. Take out anything you would not tell a stranger, such as your full name, your school, your street, or a year that gives away your age. If you change the data, run `node site-data.js` again and update any `// expect` comment that no longer matches.
4. **See what changed.** Type:

   ```
   git status
   ```

   Under **Untracked files** you should see one line: `site-data.js`. Git has never saved it before. Your `practice-08` folder never shows up here, because it is outside `my-site`.
5. **Stage the change.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. (A warning that mentions LF and CRLF is harmless.) Run `git status` again. Under **Changes to be committed** you should now see `new file:   site-data.js`.
6. **Commit.** Type:

   ```
   git commit -m "Add site-data.js with my projects, milestones and five tested functions"
   ```

   On the sample site, Git printed `1 file changed, 180 insertions(+)` on the second line and `create mode 100644 site-data.js` on the third. The 180 is the number of lines in the sample file, the data, comments, tests and blank lines included. Your commit id and line count will differ.
7. **Push.** Type:

   ```
   git push
   ```

   The last line ends in `main -> main`.
8. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. Your new commit is on top, with your Module 7 commit (or your latest one) under it.
9. **Add a milestone, and save again (NEW: when the data changes, the tests change).** Finishing this project is a milestone too. In the `milestones` array, add one more object at the end. Put a comma after the closing `}` of the object before it. The sample added:

   ```js
     {
       title: "First data file",
       year: 2026,
       description: "My projects and milestones, tested in Node."
     }
   ```

   **Think this through:** which lines of the output will change? Write down your answer before you run anything. In the sample, four lines changed: the number of milestones in the data group (`4` became `5`), the line of milestone titles, the 2026 line in the `milestonesFrom` group, and the last line of the summary.

   Your code did not change, but the right answers did. So update every `// expect` comment that no longer matches. The sample changed three:

   ```js
   // expect 5, Shop flyer, Plan my day, 5
   // expect the five project titles, the five milestone titles, Only one
   // expect the three 2026 titles, [ 'Started to code' ], []
   ```

   Save, run `node site-data.js`, and check every line against its comment. Then type `git status`. This time it lists `modified:   site-data.js` under **Changes not staged for commit**. Run the routine again, with a message that names the change:

   ```
   git add .
   git commit -m "Add a milestone: First data file"
   git push
   ```

   On the sample, the commit printed `1 file changed, 8 insertions(+), 3 deletions(-)`. The three changed `// expect` comments count as three lines deleted and three added, and the new milestone added the other five.

   `git log --oneline` now shows both commits on top, the newest first. From now on, each time you finish a project or reach a milestone, you can add it here the same way: change the data, update the predictions, run the tests, then commit.
10. **Check the live site.** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/` and press F5. Your pages look exactly as before, because no page loads `site-data.js`. Then open `https://your-username.github.io/my-site/site-data.js`. As with your other scripts, the browser shows your code as text or offers to download it, and nothing runs. This is what a stranger sees, so read it once more there.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows your two new commits on top. `node site-data.js` prints every group with no error, and every line matches its `// expect` comment. Your live pages look the same as before, and the live address of `site-data.js` shows your code without running it.
