"""Build the Module 0 learner packet (PDF) from the current blog post plus packet-only sections (v3, 2026-10-12: logo, brand colors, footer, links back to the free lessons)."""
import pathlib, re, markdown, os, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
sys.path.insert(0, ROOT)
import packetkit as pk
from playwright.sync_api import sync_playwright

import shutil
MOD = os.path.dirname(os.path.abspath(__file__))
BLOG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "..", "Code559", "blog")
post = next(f for f in sorted(os.listdir(BLOG)) if f.startswith("module-00-"))
src = open(os.path.join(BLOG, post), encoding="utf-8").read()
# build folder: post pictures + packet-only pictures + logo, next to packet.html
HERE = os.path.join(MOD, "_build"); shutil.rmtree(HERE, ignore_errors=True); os.makedirs(HERE)
shutil.copytree(os.path.join(BLOG, "images"), os.path.join(HERE, "images"))
shutil.copytree(os.path.join(MOD, "images"), os.path.join(HERE, "images"), dirs_exist_ok=True)
shutil.copy(os.path.join(ROOT, "assets", "code559-logo.png"), os.path.join(HERE, "images"))
HTML = os.path.join(HERE, "packet.html")
src, about_md = pk.split_post(src)

# --- lesson: strip front matter, the blog-only Project teaser, and affiliate placeholders
src = re.sub(r"^---\n.*?\n---\n", "", src, flags=re.S)
src = re.sub(r"\n## Project \(in the full packet\)\n.*?(?=\n## )", "\n", src, flags=re.S)
src = re.sub(r"\[([^\]]+)\]\(AFFILIATE_[A-Z0-9_]+\)", r"\1", src)
src = re.sub(r"\n\*Affiliate link: Code559 may earn[^\n]*\n", "\n", src)
src = src.replace("**which step would be hardest to repeat without this post, and why?**",
                  "**which step would be hardest to repeat without this packet, and why?**")
src = re.sub(r"\bthis post\b", "this lesson", src)
src = re.sub(r"\bThis post\b", "This lesson", src)
from markdown_it import MarkdownIt
from mdit_py_plugins.tasklists import tasklists_plugin
from mdit_py_plugins.footnote import footnote_plugin
md = pk.lesson_md()
lesson_html = md.render(src)
# the post's H1 is replaced by the packet's own part header
lesson_html = re.sub(r"<h1>.*?</h1>", "", lesson_html, count=1, flags=re.S)

CHECK = "&#9744;"  # empty checkbox for print

setup_log = f"""
<section class="part" id="setup-log">
<p class="part-label">Part 2</p>
<h1>Setup log</h1>
<p>Fill this in as you finish each step of the Exercise. Write the version number exactly as your terminal prints it. When every row is filled in and ticked, Module 0 is done.</p>
<table class="log">
<thead><tr><th>Tool</th><th>Command that proves it</th><th>What you saw (version or result)</th><th>Done</th></tr></thead>
<tbody>
<tr><td>File extensions</td><td>File Explorer &rarr; View &rarr; Show &rarr; File name extensions</td><td class="write">Ticked? &nbsp; yes / no</td><td>{CHECK}</td></tr>
<tr><td>VS Code</td><td>Help &rarr; About</td><td class="write"></td><td>{CHECK}</td></tr>
<tr><td>AI features off</td><td>Settings &rarr; <code>chat.disableAIFeatures</code></td><td class="write">Ticked? &nbsp; yes / no</td><td>{CHECK}</td></tr>
<tr><td>Live Preview (optional)</td><td>Extensions view, publisher Microsoft</td><td class="write">Installed? &nbsp; yes / skipped</td><td>{CHECK}</td></tr>
<tr><td>Git</td><td><code>git --version</code></td><td class="write"></td><td>{CHECK}</td></tr>
<tr><td>Git identity</td><td><code>git config --global --list</code></td><td class="write">Name, email and <code>init.defaultbranch=main</code> shown? &nbsp; yes / no</td><td>{CHECK}</td></tr>
<tr><td>GitHub CLI</td><td><code>gh --version</code></td><td class="write"></td><td>{CHECK}</td></tr>
<tr><td>GitHub sign-in</td><td><code>gh auth status</code></td><td class="write">Logged in as: </td><td>{CHECK}</td></tr>
<tr><td>Node.js</td><td><code>node --version</code></td><td class="write"></td><td>{CHECK}</td></tr>
<tr><td>npm</td><td><code>npm --version</code></td><td class="write"></td><td>{CHECK}</td></tr>
</tbody></table>
<div class="fill">
<p><b>My course folder:</b> <span class="line"></span></p>
<p><b>My GitHub username:</b> <span class="line"></span></p>
<p><b>Date finished:</b> <span class="line short"></span></p>
</div>

<h2 class="checks-head">Checkpoints: what "done" looks like</h2>
<p class="checks-intro">Compare your screen with these. Your version numbers will be different and newer; what matters is the shape of the result.</p>
<div class="checks">
<figure><img src="images/m00-git-config.png" alt="git config --global --list printing three settings"><figcaption><b>Git is set up</b> when <code>--list</code> prints your default branch, name and email.</figcaption></figure>
<figure><img src="images/m00-node-version.png" alt="node --version and npm --version each printing a version"><figcaption><b>Node is ready</b> when both commands print a version number.</figcaption></figure>
<figure><img src="images/m00-vscode-terminal.png" alt="VS Code with a terminal whose prompt ends in my-site"><figcaption><b>Your terminal is in the right place</b> when the prompt ends in <code>my-site&gt;</code>.</figcaption></figure>
</div>
</section>
"""

trouble = """
<section class="part" id="troubleshooting">
<p class="part-label">Part 3</p>
<h1>Troubleshooting: five problems that can stop you in Modules 0 and 1</h1>
<p>Each problem has the symptom you see, why it happens, and the fix. Try the fix, then rerun the command from your setup log.</p>

<div class="prob">
<h3>1. "not recognized" right after an install</h3>
<p class="sym"><b>Symptom.</b> You installed Git, the GitHub CLI or Node, and typing <code>git --version</code> (or <code>gh</code> or <code>node</code>) gives an error saying the name is not recognized.</p>
<p><b>Why.</b> A terminal reads the list of program locations (the PATH) when it opens, and a terminal inside VS Code gets that list from VS Code. VS Code itself started before the install, so it still has the old list.</p>
<p><b>Fix.</b> Restart VS Code: close it completely with <b>File &rarr; Exit</b>, open it again, then choose <b>Terminal &rarr; New Terminal</b> and rerun the command. A new terminal inside the same VS Code window is not enough. Still not recognized? Restart the computer and try again. If it still fails, run the install command again and read its last lines for an error.</p>
</div>

<div class="prob">
<h3>2. "winget" is not recognized</h3>
<p class="sym"><b>Symptom.</b> The install commands fail because <code>winget</code> itself is not found.</p>
<p><b>Why.</b> Microsoft's documentation says winget is part of the <b>App Installer</b>, delivered through the Microsoft Store, and that it "will not be available until you have logged into Windows as a user for the first time."</p>
<p><b>Fix.</b> Open the Microsoft Store, search for <b>App Installer</b>, and install or update it. Then restart VS Code (<b>File &rarr; Exit</b>, open it again, <b>Terminal &rarr; New Terminal</b>) and type <code>winget --version</code>. If you cannot use the Store, download each tool from its own site instead: code.visualstudio.com, git-scm.com, cli.github.com and nodejs.org (choose LTS).</p>
</div>

<div class="prob">
<h3>3. Git says "Author identity unknown"</h3>
<p class="sym"><b>Symptom.</b> Your first <code>git commit</code> (in Module 1) stops with this message:</p>
<figure class="wide"><img src="images/p00-identity-error.png" alt="git commit failing with Author identity unknown and instructions to run git config"><figcaption>Git tells you exactly which two commands to run. The last line differs from computer to computer; often it starts <code>fatal: unable to auto-detect email address</code>. This picture was made with a setting that prints a shorter last line. <span class="tag">real output, rendered; captured on Linux, with the folder path changed to the course folder</span></figcaption></figure>
<p><b>Why.</b> Step 8 of the Exercise was skipped, or the email or name line had a typo.</p>
<p><b>Fix.</b> Run all three lines of Exercise step 8 (default branch, name, email), and check them with <code>git config --global --list</code>. Then type <code>git status</code>. If it says <code>On branch master</code>, type <code>git branch -m main</code>: the repository was made before the default-branch line, and Module 1 step 15 looks for <code>main</code>. Commit again, then check that <code>git log --oneline</code> shows <code>HEAD -&gt; main</code>.</p>
</div>

<div class="prob">
<h3>4. The browser did not open during <code>gh auth login</code></h3>
<p class="sym"><b>Symptom.</b> The terminal shows a one-time code, but no browser window appears, or you closed it by mistake.</p>
<p><b>First check.</b> <code>gh</code> waits for you: it says "Press Enter to open" a github.com address in your browser. If you have not pressed Enter yet, press it now.</p>
<p><b>Why.</b> The sign-in happens on GitHub's website; the terminal only waits for it.</p>
<p><b>Fix.</b> Open your browser yourself and go to <b>github.com/login/device</b>, the address GitHub Docs gives for entering device codes. Type the code from the terminal. GitHub Docs says these codes last 15 minutes, so if it has been longer, press Ctrl+C and run <code>gh auth login</code> again for a fresh code. Finish with <code>gh auth status</code>.</p>
</div>

<div class="prob">
<h3>5. A file named <code>index.html</code> opens as plain text</h3>
<p class="sym"><b>Symptom.</b> You double-click your page and see the code itself, or Windows calls it a "Text Document."</p>
<p><b>Why.</b> Either you double-clicked it inside VS Code, which opens the code for editing, or, with file extensions hidden, the file was saved as <code>index.html.txt</code>.</p>
<p><b>Fix.</b> Open the page from File Explorer (double-click it there, or drag it onto a browser window). If Windows still calls it a text document, turn on <b>View &rarr; Show &rarr; File name extensions</b> (Exercise step 1), rename the file so it ends in <code>.html</code> only, and accept the warning about changing the extension. In VS Code, always check the tab name after saving.</p>
</div>
</section>
"""

rubric_rows = [
    "I can say what each of the five tools is for",
    "I can explain why file extensions should be visible",
    "I can explain why AI features are off in this course",
    "I can configure Git's name, email and default branch",
    "I can sign in to GitHub from the terminal and prove it",
    "I can prove a tool is installed with a version command",
    "I can read an error message and find the hint in it",
]
rows = "".join(f"<tr><td>{r}</td>" + "".join(f"<td class='c'>{CHECK}</td>" for _ in range(4)) + "</tr>" for r in rubric_rows)
selfcheck = f"""
<section class="part" id="self-assessment">
<p class="part-label">Part 4</p>
<h1>Self-assessment</h1>
<p>Rate yourself on each line. Aim for at least <b>3 (Proficient)</b> on every line before you start Module 1. If a line is a 1 or a 2, reread that Core Concept and redo its Exercise step.</p>
<table class="rubric">
<thead><tr><th>Skill</th><th>1<br><small>Beginning</small></th><th>2<br><small>Developing</small></th><th>3<br><small>Proficient</small></th><th>4<br><small>Ready to advance</small></th></tr></thead>
<tbody>{rows}</tbody></table>
<h2>Three questions to answer in writing</h2>
<ol class="write-qs">
<li>Which step took you the longest, and what was the cause?<div class="lines"></div></li>
<li>Pick one error message you saw. What did it tell you, and what did you do?<div class="lines"></div></li>
<li>Explain to a friend, in two sentences, the difference between Git and GitHub.<div class="lines"></div></li>
</ol>
</section>
"""

cover = """
<section class="cover">
<img class="logo" src="images/code559-logo.png" alt="Code559">
<p class="sub">Front-End Developer Course</p>
<div class="cover-title">
<p class="mod">Module 0</p>
<h1>Setup</h1>
<p class="tag-line">Install every tool once, so no later module stops for an install.</p>
<p class="free-link">Free lesson: <a href="https://559solutions.com/code559/module-00-setup/">559solutions.com/code559/module-00-setup/</a></p>
</div>
<div class="contents">
<p class="c-head">In this packet</p>
<ol>
<li><b>The lesson</b>: the complete Module 0 lesson, ready to print</li>
<li><b>Setup log</b>: fill it in as you go, with checkpoint pictures</li>
<li><b>Troubleshooting</b>: five problems that can stop you in Modules 0 and 1, and their fixes</li>
<li><b>Self-assessment</b>: check you are ready for Module 1</li>
<li><b>Answers</b>: to the lesson's questions, to check your own</li>
</ol>
</div>
<p class="parent">Powered by <a href="https://559solutions.com">559 Solutions</a></p>
</section>
"""


answers = """
<section class="part" id="answers">
<p class="part-label">Part 5</p>
<h1>Answers</h1>
<p>Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson explains it.</p>
<h2>Check your understanding</h2>
<ol class="answers">
<li><b>"Not recognized" after installing Git.</b> Restart VS Code: close it completely with <b>File &rarr; Exit</b>, open it again, choose <b>Terminal &rarr; New Terminal</b>, and run <code>git --version</code> again. A new terminal in the same VS Code window still has the settings VS Code had before the install. Still "not recognized"? Restart the computer. (Exercise step 7)</li>
<li><b>Why <code>init.defaultBranch</code> is <code>main</code>.</b> Git still names the first branch <code>master</code> unless you tell it otherwise, and GitHub uses <code>main</code>. Setting it to <code>main</code> keeps the two in agreement, so in Module 1 your branch has the name GitHub Pages looks for. (Core concept 5)</li>
<li><b>What to test for the GitHub CLI.</b> Run <code>gh auth status</code>. It should say you are logged in to github.com. That is your proof. If it does not, run <code>gh auth login</code> again. (Core concept 6)</li>
</ol>
<h2>Common misconception</h2>
<p><i>"Git and GitHub are the same thing."</i> They are not. Git is a program on your computer that keeps a history of your project as commits; it works with no internet connection at all. GitHub is a website that stores a copy of that history online and can publish your site. (Core concept 1)</p>
<div class="next"><p class="next-label">Next</p><p><b>Module 1: HTML Foundations.</b><br>Free lesson: <a href="https://559solutions.com/code559/module-01-html-foundations/">559solutions.com/code559/module-01-html-foundations/</a></p></div>
</section>
"""

lesson = f"""<section class="part lesson" id="lesson"><p class="part-label">Part 1</p><h1>The lesson</h1>{lesson_html}</section>"""

CSS = """
@page { size: Letter; margin: 0.75in 0.7in 0.85in 0.7in; }
* { box-sizing: border-box; }
body { font: 10.5pt/1.5 "Segoe UI", "DejaVu Sans", Arial, sans-serif; color: #1f2328; margin: 0; }
h1 { font-size: 20pt; margin: 0 0 10pt; color: #0F2849; }
h2 { font-size: 13.5pt; margin: 16pt 0 6pt; color: #0F2849; break-after: avoid; }
h3 { font-size: 11.5pt; margin: 12pt 0 4pt; break-after: avoid; }
p, li { orphans: 3; widows: 3; }
code { font-family: Consolas, "DejaVu Sans Mono", monospace; font-size: 9.5pt; background: #f2f4f7; padding: 0 3px; border-radius: 3px; }
pre { background: #f2f4f7; padding: 8pt 10pt; border-radius: 5px; font-size: 9.5pt; white-space: pre-wrap; break-inside: avoid; }
pre code { background: none; padding: 0; }
img { max-width: 100%; max-height: 3.0in; object-fit: contain; display: block; margin: 6pt auto; break-inside: avoid; }
img[src*="brand/marker-"] { display: inline-block; width: 15pt; height: 15pt; margin: 0 3pt 0 0; vertical-align: -0.3em; }
div[role="separator"] { break-after: avoid; }
div[role="separator"] img { display: block; margin: 0; max-height: none; object-fit: fill; }
blockquote { margin: 8pt 0; padding: 6pt 12pt; border-left: 4px solid #1A52BB; background: #eef3fc; }
table { border-collapse: collapse; width: 100%; font-size: 9.5pt; break-inside: avoid; }
th, td { border: 1px solid #c9d1da; padding: 5pt 6pt; vertical-align: top; text-align: left; }
th { background: #eef2f7; }
.part { break-before: page; }
.part-label { text-transform: uppercase; letter-spacing: 0.12em; font-size: 9pt; color: #6b7280; margin: 0 0 2pt; }
.task-list-item { list-style: none; margin-left: -1.2em; padding-left: 1.5em; text-indent: -1.5em; }
.task-list-item input { margin-right: 6pt; }
.lesson h2 { border-top: 1px solid #e5e7eb; padding-top: 8pt; }
/* cover */
.cover { height: 9.0in; display: flex; flex-direction: column; padding-top: 0.4in; }
.brand { font-size: 30pt; font-weight: 800; color: #0F2849; margin: 0; letter-spacing: -0.5px; }
.sub { font-size: 12pt; color: #4b5563; margin: 0 0 1.1in; }
.cover-title .mod { font-size: 13pt; color: #1A52BB; font-weight: 700; margin: 0; text-transform: uppercase; letter-spacing: 0.1em; }
.cover-title h1 { font-size: 46pt; margin: 0; line-height: 1.05; }
.tag-line { font-size: 13pt; color: #374151; margin-top: 8pt; }
.contents { margin-top: 0.8in; border-top: 2px solid #0F2849; padding-top: 10pt; }
.c-head { font-weight: 700; margin: 0 0 4pt; }
.contents li { margin: 3pt 0; }
.parent { color: #6b7280; margin: auto 0 0; }
.free-link { font-size: 10.5pt; color: #374151; margin-top: 10pt; }
.cover img.logo { width: 3in; max-height: none; margin: 0 0 4pt; }
.next { margin-top: 24pt; border-top: 2px solid #0F2849; padding-top: 8pt; }
.next-label { text-transform: uppercase; letter-spacing: 0.12em; font-size: 9pt; color: #1A52BB; font-weight: 700; margin: 0; }
a { color: #1A52BB; }
/* setup log */
.log td.write { height: 26pt; min-width: 1.8in; }
.log td:last-child, .log th:last-child { text-align: center; width: 0.55in; } .log td:last-child { font-size: 14pt; }
.fill p { margin: 10pt 0; }
.line { display: inline-block; border-bottom: 1px solid #555; width: 4.2in; height: 12pt; vertical-align: bottom; }
.line.short { width: 2in; }
.checks { display: grid; grid-template-columns: 1fr; gap: 10pt; }
.checks-intro { break-after: avoid; } h2.checks-head { break-before: page; }
.checks figure { margin: 0; break-inside: avoid; }
.checks img { max-height: 2.6in; }
figcaption { font-size: 9pt; color: #374151; break-before: avoid; }
figure { break-inside: avoid; }
p:has(> img:not([src*="brand/"])) { break-after: avoid; break-inside: avoid; }
.tag { font-size: 8pt; color: #6b7280; white-space: nowrap; }
/* troubleshooting */
.prob { border: 1px solid #d6dbe1; border-radius: 6px; padding: 4pt 12pt 6pt; margin: 0 0 10pt; break-inside: avoid; }
.prob h3 { margin-top: 6pt; color: #0F2849; }
.prob p { margin: 4pt 0; }
.prob .sym { background: #f6f8fa; padding: 4pt 6pt; border-radius: 4px; }
figure.wide { margin: 4pt 0; }
figure.wide img { max-width: 85%; }
/* self-assessment */
.rubric td.c { text-align: center; font-size: 14pt; width: 0.75in; }
.rubric th:not(:first-child) { text-align: center; }
.write-qs { margin-bottom: 0; } .write-qs li { margin-bottom: 4pt; } .write-qs li:last-child { margin-bottom: 0; }
.answers li { margin-bottom: 8pt; }
.lines { height: 58pt; background: repeating-linear-gradient(to bottom, transparent 0 19pt, #9aa3ad 19pt 20pt); margin-top: 4pt; }
"""

html = f"<!doctype html><html lang='en'><head><meta charset='utf-8'><title>Code559 Module 0 Packet: Setup</title><style>{CSS}{pk.TOC_CSS}</style></head><body>{cover}__ABOUT__{lesson}{setup_log}{trouble}{selfcheck}{answers}{pk.ABOUT_559}</body></html>"
about = pk.about_page(about_md, 0) if about_md else ""
entries = pk.toc_entries(about + html)
def page_html(pages=None):
    return html.replace("__ABOUT__", about + pk.toc_page(entries, pages))

footer = pk.footer("Module 0: Setup")
credit = ""
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    MARGIN = {"top": "0.7in", "bottom": "0.8in", "left": "0.7in", "right": "0.7in"}
    full = os.path.join(HERE, "_full.pdf"); cover_only = os.path.join(HERE, "_cover.pdf")
    # pass 1: placeholder page numbers; read where each linked heading landed; pass 2: real numbers
    pages = None
    for _ in range(2):
        open(HTML, "w", encoding="utf-8").write(page_html(pages))
        pg.goto(pathlib.Path(HTML).as_uri()); pg.wait_for_timeout(500)
        pg.pdf(path=full, format="Letter", print_background=True, margin=MARGIN)
        found = pk.dest_pages(full)
        missing = [e[1] for e in entries if e[1] not in found]
        assert not missing, missing
        if pages == {e[1]: found[e[1]] for e in entries}:
            break
        pages = {e[1]: found[e[1]] for e in entries}
    open(HTML, "w", encoding="utf-8").write(page_html(pages))
    pg.goto(pathlib.Path(HTML).as_uri()); pg.wait_for_timeout(500)
    pg.pdf(path=full, format="Letter", print_background=True,
           display_header_footer=True, header_template="<span></span>", footer_template=footer, margin=MARGIN)
    # the cover gets no footer: print page 1 again without header/footer, same margins, and swap it in
    pg.pdf(path=cover_only, format="Letter", print_background=True, page_ranges="1", margin=MARGIN)
    b.close()
from pypdf import PdfReader, PdfWriter
body, cov = PdfReader(full), PdfReader(cover_only)
w = PdfWriter(clone_from=full)  # keeps the named destinations and internal links
w.insert_page(cov.pages[0], 0)
w.remove_page(1)  # the first print of the cover, with its footer
FINAL = os.path.join(MOD, "Code559-Module-0-Setup.pdf")
w.write(FINAL)
final = pk.dest_pages(FINAL)
assert all(final.get(k) == v for k, v in pages.items()), "page numbers moved"
os.remove(full); os.remove(cover_only)
print("built", FINAL)
