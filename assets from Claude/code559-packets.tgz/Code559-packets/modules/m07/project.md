# Project: A tested helpers.js

*Your hands, about 75 minutes (estimate).* In the Exercise you wrote `toMinutes` and `isNarrow` in `practice-07`, tested them in Node, and broke one on purpose. Now you write four small functions for your own site, in a file called `helpers.js`. Each one starts as a one-sentence description, the kind of task the lesson called the hardest step. You take each description through the five steps from Core concept 7, and you write its test calls **before** the function exists. Then you write the body, run the file with Node, and compare every line with your predictions. You use only what Modules 5 to 7 taught: comments, `console.log()`, `const`, joining text with `+`, `===`, `<` and `<=`, `if` and `else`, and functions with parameters, `return` and `null`.

This project goes in `my-site`, next to `about-me.js` and `plan-my-day.js`. Any `my-site` that is a Git repository connected to GitHub works, because no page uses the file yet.

## The brief

Read the whole brief twice before you type anything.

When you finish, `my-site` holds a new file, `helpers.js`, at the top level, next to `index.html`. It is a new file. It has the same name as the Exercise file in `practice-07`, but it is not a copy of it. No page links to it and no page runs it yet: like your other scripts, it runs in the terminal only.

**The four descriptions.** Each helper is one sentence. Use the names given here, so your tests and the answers in Part 6 line up.

1. **`toFileName`.** Write a function that takes a page name in lowercase and returns its file name: the name followed by `.html`, except `home`, which returns `index.html`.
2. **`makePageTitle`.** Write a function that takes a page name and your name and returns the text for the browser tab: the page name, a space, a dash, a space, then your name. This is the `Home - Your Name` pattern your pages have used since Module 1.
3. **`isNarrowScreen`.** Write a function that takes a screen width in pixels and returns `true` when it is narrower than 700, the width where your site's wider layout starts (the `@media (min-width: 700px)` block from Module 3).
4. **`navLabel`.** Write a function that takes a file name and returns the words on its link in your nav, or `null` when your site has no page with that file name.

**What it prints.** Run from the `my-site` folder, `node helpers.js` printed exactly these 21 lines for the sample student, Sam:

```
--- toFileName ---
index.html
about.html
contact.html
--- makePageTitle ---
Home - Sam
About - Sam
Rate this lesson - Sam
--- isNarrowScreen ---
true
false
false
true
--- navLabel ---
Home
Contact
null
null
true
false
blog.html is not a page on this site
```

Your file prints the same shape with your own name and your own pages:

- **One group of test lines per helper**, in the order of the descriptions. Each group starts with a heading line, such as `--- toFileName ---`, so you can tell the groups apart.
- **At least three tests per helper, and one of them an edge.** For `toFileName` the edge is `home`, the one name that breaks the pattern. For `isNarrowScreen` it is 700 and 699, one on each side of the limit. For `navLabel` it is a file name your site does not have.
- **Two `=== null` checks** in the `navLabel` group: one that gives `true` and one that gives `false`.
- **A last line that uses two helpers together**, and checks for `null` before it uses an answer.

**What is inside the file.**

- The first two lines are comments: the file name with one sentence about what it does, and how to run it.
- Three parts, each under its own heading comment, in this order: `// ===== The helpers =====`, `// ===== The tests =====` and `// ===== Using two helpers together =====`.
- Above each function, a comment with its name and its description, in your words.
- Above each group of tests, a comment that starts with `// expect` and lists your predictions, in order.
- Every function hands its answer back with `return`. No function has a `console.log()` inside it: only the test lines print.
- Only `const`, never `let` and never `var`. Comparisons use `===`, never `==`.

![A terminal in the my-site folder running node helpers.js. It prints four groups of test results: --- toFileName --- then index.html, about.html, contact.html; --- makePageTitle --- then Home - Sam, About - Sam, Rate this lesson - Sam; --- isNarrowScreen --- then true, false, false, true; --- navLabel --- then Home, Contact, null, null, true, false; and a last line, blog.html is not a page on this site.](images/p07-tests-pass.png)
*The finished file for the sample student, in one run. Each line matches its `// expect` comment. The `null` lines are answers too: `navLabel` handed back "no answer" on purpose. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*

## The steps

Type every line. Do not paste. You may copy a test line and change only its argument, once you have typed the first test line of a group yourself.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`.
2. **Plan on paper.** For each of the four descriptions, do steps 1 to 3 of the five-step method from Core concept 7. Make a small table with four rows and three columns: **Name**, **Inputs** (one parameter name for each input) and **Output and its type**. The names are given in the brief, so step 1 is done. For the inputs, choose names that say what the value is, such as `pageName` or `width`. For the output, write the type as well as an example, such as "a string, like `about.html`". Do not write any code yet. This page is your plan.
3. **Start the file.** In the VS Code Explorer, create `helpers.js` at the top level of `my-site`, next to `index.html`. Type these lines, then save with Ctrl+S:

   ```js
   // helpers.js: four small helper functions for my site, with their tests
   // Run it from the my-site folder with: node helpers.js

   // ===== The helpers =====

   // ===== The tests =====
   ```

   Functions go under the first heading and test lines under the second, so the tests always run after every function is defined. **Predict** before you run: what will `node helpers.js` print? Write it down. Then type `node helpers.js` and press Enter. The prompt came straight back. Only comments, so nothing to run.
4. **`toFileName`: the tests first, then the body.** This is step 4 of the five-step method. Under `// ===== The tests =====`, leave one blank line and type:

   ```js
   console.log("--- toFileName ---");
   // expect index.html, about.html, contact.html
   console.log(toFileName("home"));
   console.log(toFileName("about"));
   console.log(toFileName("contact"));
   ```

   The `// expect` comment holds your predictions, in the same order as the test lines. Each test line calls the function inside `console.log()`, so its answer prints. **Think this through:** the function does not exist yet. What will Node do? Write down your answer. Save and run. The sample printed the heading line, and then this (the `at` lines below it are left out):

   ```
   C:\Users\you\Documents\code559\my-site\helpers.js:10
   console.log(toFileName("home"));
           ^

   ReferenceError: toFileName is not defined
   ```

   This is the Module 5 error: JavaScript does not know the name yet. The caret sits under `log`, not under the missing name, so read the message: it names `toFileName`. Your line number may differ. A test that fails before the function exists is a good start. You now know exactly what "working" means: three lines that match your comment.

   Now step 5: the body. Under `// ===== The helpers =====`, leave one blank line and type the function with its comment:

   ```js
   // toFileName: takes a page name in lowercase and returns its file name,
   // the name followed by .html, except home, which is index.html.
   function toFileName(pageName) {
     if (pageName === "home") {
       return "index.html";
     }
     return pageName + ".html";
   }
   ```

   Leave one blank line after the closing `}`. Read the body and say what happens for `"home"`: the condition is true, so `return "index.html"` hands back the answer and ends the function right there (Core concept 4). The last line never runs for `"home"`. For any other name, the condition is false, so the last line joins the name and `".html"` and returns that. Save and run. Compare each line with your comment: the sample printed `--- toFileName ---`, `index.html`, `about.html` and `contact.html`.
5. **`makePageTitle`: two parameters.** Under the `toFileName` tests, leave one blank line and type the tests first, with your own name in place of Sam's:

   ```js
   console.log("--- makePageTitle ---");
   // expect Home - Sam, About - Sam, Rate this lesson - Sam
   console.log(makePageTitle("Home", "Sam"));
   console.log(makePageTitle("About", "Sam"));
   console.log(makePageTitle("Rate this lesson", "Sam"));
   ```

   The last test is the long one: a page name with spaces in it, like the title of the Module 4 rate page. Save and run once before you write the function. The whole `toFileName` group prints, then the new heading line, then `ReferenceError: makePageTitle is not defined`. The tests above the bad line ran and passed. Node stopped only where it met the name it did not know.

   Then, under the `toFileName` function, leave one blank line and start the function:

   ```js
   // makePageTitle: takes a page name and your name and returns the text
   // for the browser tab: the page name, a dash, then your name.
   function makePageTitle(pageName, ownerName) {
     // Continue alone: one line that returns the page name,
     // the text " - " and the owner's name, joined with +.
   }
   ```

   Two parameters, separated by a comma. In a call, the arguments are matched to the parameters **by position**: the first argument goes into `pageName` and the second into `ownerName` (Core concept 3). Write the body alone. Mind the spaces inside `" - "`: without them, the output reads `Home-Sam`. Delete the two "Continue alone" comment lines, save and run. The sample printed `Home - Sam`, `About - Sam` and `Rate this lesson - Sam` under the heading.
6. **`isNarrowScreen`: create it alone.** This one has no code to copy, only the description from the brief. Do all five steps yourself:

   - In the tests part, under the `makePageTitle` tests, type a heading line `--- isNarrowScreen ---`, an `// expect` comment and at least four test lines. Use a phone width, a laptop width, and the two edge widths: exactly 700 and 699. Fill in the `// expect` comment before you run anything.
   - Run once and see the `ReferenceError` for the new name, as before.
   - In the helpers part, under `makePageTitle`, type the comment and the function. The answer is a Boolean, so the body can be a single `return` with a comparison, like `isNarrow` in the lesson.

   Save and run. The sample tested 390, 1200, 700 and 699, and printed `true`, `false`, `false` and `true`. The `false` for 700 is the edge test: 700 is not narrower than 700, and at exactly 700 your wider layout already applies, because `min-width` includes the number itself. If your 700 line prints `true`, compare your comparison sign with the description.
7. **`navLabel`: a function that can say "no answer."** In the tests part, under the `isNarrowScreen` tests, type the tests first:

   ```js
   console.log("--- navLabel ---");
   // expect Home, Contact, null, null, true, false
   console.log(navLabel("index.html"));
   console.log(navLabel("contact.html"));
   console.log(navLabel("blog.html"));
   console.log(navLabel("About.html"));
   console.log(navLabel("blog.html") === null);
   console.log(navLabel("about.html") === null);
   ```

   Use the file names of your own site. The sample site has five pages from the Modules 1 to 4 packets: `index.html`, `about.html`, `interests.html`, `rate.html` and `contact.html`. If your site has no `contact.html`, test one of your own pages instead and change the `// expect` comment to match. `blog.html` is the page the site does not have. `About.html`, with a capital A, is the edge: `===` compares letter for letter, so it is not the same as `about.html`. The last two lines turn the answer into a plain `true` or `false`, as in Core concept 9. Run once and see the `ReferenceError`. Then, in the helpers part, under `isNarrowScreen`, start the function:

   ```js
   // navLabel: takes a file name and returns the words for its nav link,
   // or null when the site has no page with that file name.
   function navLabel(fileName) {
     if (fileName === "index.html") {
       return "Home";
     }
     // Continue alone: one if for each other page your site has,
     // in the same order as your nav.
     return null;
   }
   ```

   Each `if` returns at once when its file name matches, and the function ends there. Only a file name that matches none of them reaches the last line, `return null;`. That is the "no answer" on purpose from Core concept 9. Write one `if` block for each of your other pages, with the nav words exactly as they are on your links. Delete the two "Continue alone" lines, save and run. The sample printed `Home`, `Contact`, `null`, `null`, `true` and `false` under the heading.

   This function has more braces than any you have written. If Node prints a `SyntaxError`, nothing at all prints, not even the first heading line, because Node could not read the file. Read the message, the line it names, and the lines just above it. The two most likely messages here:

   - `SyntaxError: Unexpected token '}'`: there is a `}` too many, or a `{` is missing after an `if (...)` line. Either way, a `}` closes the function too early, and Node complains at a later `}`. The line it names can be several lines below the real mistake, often the function's last line. Check every `if` line ends in `{`, and count: every `{` needs its own `}`.
   - `SyntaxError: Unexpected end of input`, pointing at the end of the file (the empty line after the last `}`): a `}` is missing, or there is an extra `{`. Node reached the end of the file with a block still open.

   For any other `SyntaxError` message, see Problem 6 in Part 4, *Troubleshooting*.
8. **Use two helpers together, and check for `null` first.** Under the last test line, leave one blank line and type:

   ```js
   // ===== Using two helpers together =====

   console.log(makePageTitle(navLabel("blog.html"), "Sam"));
   ```

   The answer of `navLabel` goes straight into `makePageTitle` as its first argument. **Think this through:** what does `navLabel("blog.html")` give, and what will `makePageTitle` do with it? Write down your answer, then save and run. The sample's last line was `null - Sam`. No error, but a wrong answer: `+` joined `null` into the text as the word `null`. A visitor would see a tab called `null - Sam`. This is why the lesson says to check with `=== null` before you use the answer. Replace the line with this:

   ```js
   const label = navLabel("blog.html");
   if (label === null) {
     console.log("blog.html is not a page on this site");
   } else {
     console.log(makePageTitle(label, "Sam"));
   }
   ```

   Save and run. The last line is now `blog.html is not a page on this site`. Then change `"blog.html"` to `"about.html"` on the `const label` line, and only there. Predict the last line, save and run. The sample printed `About - Sam`: the answer was not `null`, so the `else` block used it. The message in the `if` block still says `blog.html`, so change the file name back to `"blog.html"`, save and run once more.
9. **Modify.** Make two changes, one at a time. Predict each before you run it, then undo it.

   - **Change `<` to `<=`.** In `isNarrowScreen`, change `width < 700` to `width <= 700`. Save. Which test line would show this change? Write it down, then run. In the sample, only the third `isNarrowScreen` line changed, from `false` to `true`: the test for 700. The tests for 390, 1200 and 699 gave the same answers as before. This is why the edge test is there. Change it back, save and run.
   - **Swap two arguments.** In the second `makePageTitle` test, swap the two arguments, so the line reads `console.log(makePageTitle("Sam", "About"));`. Predict, save and run. The sample printed `Sam - About`. JavaScript does not read the parameter names to decide where a value goes. It goes by position: the first argument always becomes `pageName`. Swap them back, save and run.
10. **Break it on purpose.** Two classic mistakes from the lesson. Make each one, run, look, and undo it before the next.

    - **`console.log()` instead of `return`.** In `makePageTitle`, change the word `return` to `console.log(`, and add a `)` before the semicolon, so the body is `console.log(pageName + " - " + ownerName);`. **Think this through:** what will the `makePageTitle` group print now? Write it down, then save and run.

      ![A terminal in the my-site folder running node helpers.js after the change. The makePageTitle group now prints Home - Sam, undefined, About - Sam, undefined, Rate this lesson - Sam, undefined. Every other group prints the same as before.](images/p07-log-not-return.png)
      *Six lines where there were three, and no error message. Each title prints from inside the function, and then the test line prints what the function handed back: `undefined`. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*

      Each call now does two things. The `console.log()` inside the function shows the title. Then the function ends with no `return`, so it hands back `undefined`, and the test line prints that. The titles on the screen look right, but the code that called the function received nothing. This is the misconception at the end of the lesson. Put `return` back, save and run, and check that the group shows three titles and no `undefined`.
    - **No parentheses.** In the `toFileName` tests, delete the parentheses and the argument from the second test, so it reads `console.log(toFileName);`. Predict, save and run. The sample printed `[Function: toFileName]` where `about.html` had been. Without parentheses, the name is a reference to the function itself, so Node printed the function, not an answer (Core concept 8). Nothing ran. Put back `("about")`, save and run.
11. **Debug: a test that fails with no error.** Here is a mistake that is easy to make in `navLabel`. Change the first `if` block so it has an `else`:

    ```js
    if (fileName === "index.html") {
      return "Home";
    } else {
      return null;
    }
    ```

    Leave the other `if` blocks and the last `return null;` as they are. Save. Before you run, write down which lines of the `navLabel` group you expect to change. Then run. The sample printed `Home`, `null`, `null`, `null`, `true` and `true`. Compare with the `// expect` comment, one line at a time: the second line should be `Contact`, and the last line should be `false`. Two tests failed, and Node showed no error.

    When a test fails, first ask which one is wrong: your prediction or your code. Here the prediction is right, because `contact.html` is a page on the site. So the code is wrong. Follow the call `navLabel("contact.html")` line by line, as JavaScript does. `"contact.html" === "index.html"` is false, so the `else` block runs: `return null`. `return` ends the function right there, so the `if` blocks for the other pages are never reached. With this `else`, every file name except `index.html` gets `null`. Delete the `else` part, from `} else {` to its closing `}`, and put back the single `}` that closes the first `if`. Save, run, and check all six lines against your comment. In your notebook, write one sentence on why a test with only `index.html` could not catch this bug.
12. **Explain it.** With every test passing, read the whole file to yourself, out loud, from top to bottom. For each function, say its parameters, what type of value it returns, and which test line checks its edge. For each `return`, say when it runs and what it ends. For `navLabel`, say why `return null;` must be the last line and not the first. If there is a line you cannot explain, reread the Core concept it comes from.
13. **Looking ahead to Module 9.** No page uses `helpers.js` yet. In Module 9 you learn how a page loads a script file with a `<script>` tag, and how a click runs a function. The functions there are built from the same parts as these: a name, a body, and sometimes parameters. Two habits from this project carry over. First, test a function by itself, in Node, where a wrong answer is easy to see, before any page depends on it. Second, when a click should run a function, hand over the function itself, not its answer: `showMessage`, not `showMessage()`, as Core concept 8 showed. The test lines are for you, not for visitors. You run them with Node, after every change, to prove the helpers still work.
14. **Check the file.** Tick each box.

    - [ ] `helpers.js` is in `my-site`, next to `index.html`, not in `practice-07`
    - [ ] The prompt ends in `my-site>`, and `node helpers.js` prints four groups and the last line, with no error
    - [ ] Every test line matches its `// expect` comment, in order
    - [ ] Each helper has at least three tests, one of them an edge: `home`, 700 and 699, and a file your site does not have
    - [ ] `navLabel` returns `null` for a page your site does not have, and the file checks it with `=== null` before using it
    - [ ] Every function hands back its answer with `return`; there is no `console.log()` inside any function
    - [ ] Each function has a comment above it with its description
    - [ ] The `else` from step 11 is gone, and the parentheses from step 10 are back
    - [ ] Nothing in the file is private: your first name or a nickname is enough

15. **Save it in Git.** Go to Part 3, *Finishing work in Git*, and save the file with the save routine.
