# Troubleshooting: six common problems

Each problem has the symptom you see, why it happens, and the fix. Each one was made on purpose with the sample `helpers.js` and run with Node 22. The messages were captured on Linux, with the folder path changed to the course folder; on Windows, Node prints the same words with your own path. The `at` lines under each message are left out here. After each fix, save, and run `node helpers.js` again from the `my-site` folder, and check every test line against its `// expect` comment. Three of the six problems print no error at all. Your tests are what catch them.

### 1. undefined where an answer should be

**Symptom.** No error, but a test line prints `undefined`. With the word `return` deleted from `makePageTitle`, so the body was only `pageName + " - " + ownerName;`, the sample printed:

```
--- makePageTitle ---
undefined
undefined
undefined
```

With `console.log(` in place of `return`, as in Project step 10, each title printed and was followed by an `undefined` line.

**Why.** A function with no `return` still hands something back: `undefined` (Core concept 4). The work in the body happens, the text is joined, and then it is thrown away. A `console.log()` inside the function shows the text, but showing is not handing back, so the test line still receives `undefined`.

**Fix.** Put `return` at the start of the line that makes the answer: `return pageName + " - " + ownerName;`. Then remove any `console.log()` from inside the function. In this file, only the test lines print.

### 2. ReferenceError for a parameter used outside its function

**Symptom.** Some test groups print, then the file stops. With the line `console.log(pageName);` added under the `toFileName` tests, the sample printed the `toFileName` group and then:

```
C:\Users\you\Documents\code559\my-site\helpers.js:55
console.log(pageName);
            ^

ReferenceError: pageName is not defined
```

**Why.** A parameter belongs to its function, like a `const` made inside the body (Core concept 5). `pageName` exists only while `toFileName` or `makePageTitle` is running, and only inside it. The test lines are outside every function, so for them the name does not exist. Each call fills the parameter with a new argument, so there is no single `pageName` to look at anyway.

**Fix.** Delete the line. To see a value from inside a function, get it the way the lesson does: call the function and use what it returns, such as `console.log(toFileName("about"));`. If you need the answer twice, store it first: `const fileName = toFileName("about");`.

### 3. A missing argument: NaN, undefined in the text, or a quiet false

**Symptom.** No error, but a strange answer. With the second argument left out, `makePageTitle("About")` printed `About - undefined`. In the Exercise file in `practice-07`, `toMinutes()` with no argument printed `NaN`, which means "not a number." And with the argument left out of one `isNarrowScreen` test, `isNarrowScreen()` printed `false`, the same answer the sample expected from `isNarrowScreen(1200)`, so the test seemed to pass.

**Why.** A parameter with no argument holds `undefined` (Core concept 3). Then the body does its normal work with `undefined`. `+` joins it into text as the word `undefined`. `*` cannot do math with it, so the answer is `NaN`. And `undefined < 700` is `false`, which looks like a real answer. That last one is the hardest to spot.

**Fix.** Compare the call with the definition: one argument for each parameter, in the same order, separated by commas. Read every test line, not only its result: a test that passes for the wrong reason proves nothing. When an answer contains the word `undefined` or `NaN`, look first for a missing argument.

### 4. [Function: toFileName] instead of an answer

**Symptom.** No error, but one test line prints the function's name in square brackets. With `console.log(toFileName);` as a test line, the sample printed `[Function: toFileName]` where `about.html` should have been.

**Why.** The name without parentheses is a reference to the function itself, the stored instructions (Core concept 8). Nothing runs. `console.log()` shows you what it was given: a function, named `toFileName`. The browser Console shows a function differently, as the lesson's picture does, but the cause is the same.

**Fix.** Add the parentheses and the argument: `console.log(toFileName("about"));`. Every call needs `()`, even a function with no parameters, such as `showMessage()`. Keep the habit from the other side too: in Module 9, an event listener gets the name with **no** parentheses, because there you hand over the function itself.

### 5. TypeError: x is not a function

**Symptom.** Some test groups print, then the file stops. With these two lines added under the `toFileName` tests, the sample printed the `toFileName` group and then:

```js
const fileName = toFileName("about");
console.log(fileName());
```

```
C:\Users\you\Documents\code559\my-site\helpers.js:56
console.log(fileName());
            ^

TypeError: fileName is not a function
```

**Why.** Parentheses mean "run this function." `fileName` is not a function: it holds the string `"about.html"`, the answer that `toFileName` returned. A string cannot run, so Node stops with a `TypeError`, the error for a value of the wrong type. You get the same kind of message whenever `()` goes after something that is not a function. With an extra `()` after a call, as in `console.log(toFileName("about")());`, the sample printed `TypeError: toFileName(...) is not a function`: the `(...)` stands for the call, whose answer was a string.

**Fix.** Look at the name in the message, then find where that name got its value. If it holds an answer, use it without parentheses: `console.log(fileName);`. If you meant to call a function, check the spelling against its `function` line, capital letters included.

### 6. SyntaxError messages

**Symptom.** Nothing prints at all, not even the first heading line. Node shows a line of your file, a caret or carets, and a message that starts with `SyntaxError`.

**Why.** Node could not read the file as JavaScript, so it ran none of it. Each message below was made on purpose in the sample file.

| Message | Usual cause | Where to look |
|---|---|---|
| `Unexpected token '}'` | A `}` too many, or a `{` missing after `if (...)` | Lines above the one named, often several; the named line is often the function's last `}` |
| `Unexpected end of input` | A `}` missing, or an extra `{` | Every block; Node points at the end of the file |
| `Unexpected token 'if'` | The `{` missing at the end of a `function` line | The `function` line just above |
| `Unexpected token '{'` | The `)` missing before `{`, on a `function` or `if` line | The named line, just before the caret |
| `Unexpected token ';'` | A semicolon between `)` and `{` on a `function` line | The named line |
| `Invalid or unexpected token` | A missing quote, so a string never ends | The string under the carets |
| `Unexpected string` | A misspelled `return`, such as `retrun` | The word before the carets |
| `Unexpected identifier` | A missing `+` between two parts, a missing comma between two parameters, or missing parentheses around an `if` condition | The named line, just before the carets |
| `missing ) after argument list` | One `)` missing from `))` on a test line, or a missing comma between two arguments | The named test line |

**Fix.** Fix the one thing the row points to, save, and run. If the message changes, read the new one from the top: one missing brace can hide another mistake below it.
