# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **Why `x` holds `undefined`.** `logGreeting` has no `return`. Its body shows `Hello, Ana!` with `console.log()`, and showing is all it does. When the body ends, the function hands back the value it always hands back without a `return`: `undefined`. So `x` stores `undefined`. The text on the screen came from inside the function, not from the value it gave back. `makeGreeting("Ana")` would show nothing and give `x` the text `"Hello, Ana!"`. (Core concept 4)
2. **`isNarrow` and `isNarrow(390)`.** `isNarrow`, with no parentheses, is a reference to the function itself: the stored instructions. Nothing runs. `typeof isNarrow` gives `"function"`, and in Node, `console.log(isNarrow)` prints `[Function: isNarrow]`. `isNarrow(390)` is a call: the body runs with `width` set to 390, and you get its answer, `true`. (Core concept 8)
3. **Testing the boundary.** Test `isNarrow(600)` and expect `false`, because 600 is not less than 600. Then test the number just below it, `isNarrow(599)`, and expect `true`. The pair checks the comparison sign: with `<=` by mistake, 600 would give `true`, and every test away from the edge would still pass. (Core concepts 6 and 7)

## Common misconception

*"My function works. I can see the right answer in the Console. Adding `return` is extra work."* Seeing the answer is not the same as getting it back. Store the result in a variable, as in Core concept 4: `const a = logGreeting("Sam");` shows `Hello, Sam!`, but `a` holds `undefined`. Any code that wants to use the answer, to join it to more text, compare it, or pass it to another function, gets nothing. Project step 10 shows the same thing in a file: with `console.log()` in place of `return`, the titles printed, and every test line printed `undefined`. In Module 9 the code that calls your functions is not you reading the screen. It is your page's script, and it can only use what the function hands back. (Core concept 4; Project step 10)

## Exercise checks

- **Steps 2 and 3.** `120`, `90` and `0`, one per line, matching `// expect 120, 90, 0`. `toMinutes(1.5)` is `1.5 * 60`, which is 90. (Core concepts 2 and 6)
- **Step 4.** Name: `isNarrow`. Input: one width, so one parameter, `width`. Output: `true` or `false`, a Boolean. The three new lines are `true`, `false` and `false`. The last one is the edge: 600 is not less than 600. (Core concept 7)
- **Step 5.** The two new lines are `[Function: showMessage]` and `Thanks for visiting!`. The whole run prints eight lines: `120`, `90`, `0`, `true`, `false`, `false`, `[Function: showMessage]` and `Thanks for visiting!`. The first of the two new lines is the function itself, because there are no parentheses. The second is its answer. (Core concept 8)
- **Step 6.** The first three lines become `undefined`, and the other five lines do not change. There is no error. `hours * 60` is still worked out, but with no `return`, the answer is thrown away and each call hands back `undefined`. (Core concept 4)
- **Step 7.** The Console shows `Uncaught ReferenceError: total is not defined`. The words that tell you the problem are `not defined`, with the name `total` just before them: outside the function, the name does not exist. (Core concept 5)
- **Step 8.** One possible answer, with its tests first:

  ```js
  // expect isHourOrMore(90) true, isHourOrMore(30) false, isHourOrMore(60) true
  function isHourOrMore(minutes) {
    return minutes >= 60;
  }
  console.log(isHourOrMore(90));
  console.log(isHourOrMore(30));
  console.log(isHourOrMore(60));
  ```

  In Node it printed `true`, `false` and `true`. The edge is 60: "an hour or more" includes exactly one hour, so the comparison is `>=`. With `>`, the test for 60 prints `false` and fails, and the other two still pass. Any name that asks a question works, such as `isAtLeastAnHour`. (Core concepts 6 and 7)

## Self-assessment questions

1. **Two lines for each title.** The first line came from inside the function: `console.log()` showed the joined text while the function ran. The second came from the test line: the function then ended with no `return`, so it handed back `undefined`, and `console.log(makePageTitle(...))` printed that. The screen showed the right titles, but no code received them. If a page used `makePageTitle` to set a tab's text, it would get `undefined`. A function is right only when its answer comes back, and the test lines check exactly that. (Core concept 4; Project step 10)
2. **A prediction you got wrong.** There is no single answer. A good answer quotes what you wrote down before the run, quotes what Node or the Console really showed, and names the idea you understand now, for example that the function returns `undefined` with no `return`, or that `return` ends a function, so an `else` with `return null` hides every `if` after it.
3. **The friend's reading time.** The file prints `undefined`, then stops with `ReferenceError: text is not defined` on the last line. There are two mistakes. First, `readingTime` has no `return`, so the joined text is thrown away and the call gives `undefined`. Second, `text` was made inside the function, so it does not exist outside it. The two changes: add `return text;` as the last line of the body, and replace `console.log(text);` with a line that stores the answer and prints it, such as `const label = readingTime(5);` and then `console.log(label);`. Then the file prints `5 min read` twice. (Core concepts 4 and 5)

## Project checks

- **Step 2.** The sample's plan:

  | Name | Inputs | Output and its type |
  |---|---|---|
  | `toFileName` | `pageName` | a string, like `about.html` |
  | `makePageTitle` | `pageName`, `ownerName` | a string, like `About - Sam` |
  | `isNarrowScreen` | `width` | a Boolean, `true` or `false` |
  | `navLabel` | `fileName` | a string, like `About`, or `null` |

- **Step 3.** Nothing prints, and there is no error.
- **Step 4.** Before the function: the heading line, then `ReferenceError: toFileName is not defined`, pointing at the first test line (line 10 in the sample). After it: `--- toFileName ---`, `index.html`, `about.html` and `contact.html`.
- **Step 5, continue alone.** The sample's `makePageTitle`:

  ```js
  // makePageTitle: takes a page name and your name and returns the text
  // for the browser tab: the page name, a dash, then your name.
  function makePageTitle(pageName, ownerName) {
    return pageName + " - " + ownerName;
  }
  ```

- **Step 6, create alone.** The sample's tests and function. The tests go in the tests part, the function in the helpers part.

  ```js
  console.log("--- isNarrowScreen ---");
  // expect true, false, false, true
  console.log(isNarrowScreen(390));
  console.log(isNarrowScreen(1200));
  console.log(isNarrowScreen(700));
  console.log(isNarrowScreen(699));
  ```

  ```js
  // isNarrowScreen: takes a screen width in pixels and returns true
  // when it is narrower than 700, where the wider layout starts.
  function isNarrowScreen(width) {
    return width < 700;
  }
  ```

- **Step 7, continue alone.** The sample's whole `navLabel`, with one `if` for each of its five pages:

  ```js
  // navLabel: takes a file name and returns the words for its nav link,
  // or null when the site has no page with that file name.
  function navLabel(fileName) {
    if (fileName === "index.html") {
      return "Home";
    }
    if (fileName === "about.html") {
      return "About";
    }
    if (fileName === "interests.html") {
      return "Interests";
    }
    if (fileName === "rate.html") {
      return "Rate";
    }
    if (fileName === "contact.html") {
      return "Contact";
    }
    return null;
  }
  ```

- **Step 8.** Without the check, the last line is `null - Sam`. With the check, it is `blog.html is not a page on this site`. With `"about.html"` on the `const label` line, it is `About - Sam`.
- **Step 9.** With `<=`, only the test for 700 changes, from `false` to `true`. With the arguments swapped, the second title is `Sam - About`.
- **Step 10.** With `console.log()` in place of `return`, the `makePageTitle` group prints six lines: each title, then `undefined`. With no parentheses, the second `toFileName` line is `[Function: toFileName]`.
- **Step 11.** The `navLabel` group prints `Home`, `null`, `null`, `null`, `true` and `true`. The second and the last lines fail. A test with only `index.html` passes either way, because `"index.html"` matches the first `if` and returns `Home` before the `else` can matter. Only a file name that should reach a later `if` shows the bug.
- **Step 14.** If you followed the brief, every box is ticked. The most common misses: a `console.log()` left inside a function from step 10, and a test whose `// expect` comment was never filled in. Here is the whole sample file, 85 lines:

  ```js
  // helpers.js: four small helper functions for my site, with their tests
  // Run it from the my-site folder with: node helpers.js

  // ===== The helpers =====

  // toFileName: takes a page name in lowercase and returns its file name,
  // the name followed by .html, except home, which is index.html.
  function toFileName(pageName) {
    if (pageName === "home") {
      return "index.html";
    }
    return pageName + ".html";
  }

  // makePageTitle: takes a page name and your name and returns the text
  // for the browser tab: the page name, a dash, then your name.
  function makePageTitle(pageName, ownerName) {
    return pageName + " - " + ownerName;
  }

  // isNarrowScreen: takes a screen width in pixels and returns true
  // when it is narrower than 700, where the wider layout starts.
  function isNarrowScreen(width) {
    return width < 700;
  }

  // navLabel: takes a file name and returns the words for its nav link,
  // or null when the site has no page with that file name.
  function navLabel(fileName) {
    if (fileName === "index.html") {
      return "Home";
    }
    if (fileName === "about.html") {
      return "About";
    }
    if (fileName === "interests.html") {
      return "Interests";
    }
    if (fileName === "rate.html") {
      return "Rate";
    }
    if (fileName === "contact.html") {
      return "Contact";
    }
    return null;
  }

  // ===== The tests =====

  console.log("--- toFileName ---");
  // expect index.html, about.html, contact.html
  console.log(toFileName("home"));
  console.log(toFileName("about"));
  console.log(toFileName("contact"));

  console.log("--- makePageTitle ---");
  // expect Home - Sam, About - Sam, Rate this lesson - Sam
  console.log(makePageTitle("Home", "Sam"));
  console.log(makePageTitle("About", "Sam"));
  console.log(makePageTitle("Rate this lesson", "Sam"));

  console.log("--- isNarrowScreen ---");
  // expect true, false, false, true
  console.log(isNarrowScreen(390));
  console.log(isNarrowScreen(1200));
  console.log(isNarrowScreen(700));
  console.log(isNarrowScreen(699));

  console.log("--- navLabel ---");
  // expect Home, Contact, null, null, true, false
  console.log(navLabel("index.html"));
  console.log(navLabel("contact.html"));
  console.log(navLabel("blog.html"));
  console.log(navLabel("About.html"));
  console.log(navLabel("blog.html") === null);
  console.log(navLabel("about.html") === null);

  // ===== Using two helpers together =====

  const label = navLabel("blog.html");
  if (label === null) {
    console.log("blog.html is not a page on this site");
  } else {
    console.log(makePageTitle(label, "Sam"));
  }
  ```
