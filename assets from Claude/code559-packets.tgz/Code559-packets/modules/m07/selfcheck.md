# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 8. If a line is a 1 or a 2, reread that Core concept and redo its Exercise or Project step.

## Rubric

- I can name the parts of a function definition, and explain why defining a function runs nothing until it is called
- I can tell a parameter from an argument, match arguments to parameters by position, and predict what a missing argument gives
- I can use return to hand back a value, and spot a function that only logs by the undefined it hands back
- I can explain local scope, and fix a ReferenceError for a name made inside a function by returning the value and storing it
- I can test a function with several inputs, an edge included, writing the expected answers before I run anything
- I can write a function from a one-sentence description with the five steps: name, inputs, output, tests, body
- I can tell a function reference from a call, read [Function: name] and "is not a function", and say why a listener gets the reference
- I can return null on purpose when there is no answer, and check it with === null before using the answer
- I can read a failing test, decide whether my prediction or my code is wrong, and follow the call line by line to find the bug

## Three questions to answer in writing

1. In Project step 10, the `console.log()` version of `makePageTitle` printed every title and also an `undefined` line after each one. Explain where each of the two lines came from, and why the screen looking right did not mean the function was right.
2. Pick one test from your project, or one prediction from the Exercise, where your first answer was wrong. What did you write down, what did Node or the Console show, and what do you understand now that you did not before?
3. A friend wrote this from the description *"Write a function that takes a number of minutes and returns the text for a reading time, like 5 min read."* What does this file print when it runs, and what two changes fix it?

   ```js
   function readingTime(minutes) {
     const text = minutes + " min read";
   }
   console.log(readingTime(5));
   console.log(text);
   ```
