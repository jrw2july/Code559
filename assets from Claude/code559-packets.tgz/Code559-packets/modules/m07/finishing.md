# Finishing work in Git

Every test in `helpers.js` passes. Now you save it to GitHub with the same save routine as in Modules 1 to 6: `git status`, `git add .`, `git commit`, `git push`, then check the live site. What is new this time: the tests are part of the file you save, so you run them as the last thing before every commit. And you add one more test after the first commit, then save again, to see how a small change looks to Git.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 to 6.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **Run the tests one last time (NEW: the tests decide when you commit).** Type `node helpers.js` and read every line against its `// expect` comment. Look for the three signs of the mistakes from Project steps 10 and 11: an `undefined` where an answer should be, a `[Function: …]` line, or a `null` your comment did not predict. Check one more thing in the file: the `const label` line uses `"blog.html"` again, as in Project step 8. Commit only a file whose tests you have just run and seen pass. The test lines stay in the file: they are your proof, and you can run them again after any change.
3. **See what changed.** Type:

   ```
   git status
   ```

   Under **Untracked files** you should see one line: `helpers.js`. Git has never saved it before.

   **NEW: two files with the same name.** You now have two files called `helpers.js`: the Exercise file in `practice-07`, and the project file in `my-site`. Git sees only the one inside `my-site`, because the repository is `my-site`. The `practice-07` folder never shows up here. Before you go on, check that the right file is open: in the VS Code Explorer, `helpers.js` should sit at the top level of `my-site`, next to `index.html`.
4. **Stage the change.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. (A warning that mentions LF and CRLF is harmless.) Run `git status` again. Under **Changes to be committed** you should now see `new file:   helpers.js`.
5. **Commit.** Type:

   ```
   git commit -m "Add helpers.js with four helper functions, each tested in Node"
   ```

   On the sample site, Git printed `1 file changed, 85 insertions(+)` on the second line and `create mode 100644 helpers.js` on the third. The 85 is the number of lines in the sample file, comments, tests and blank lines included. Your commit id and line count will differ.
6. **Push.** Type:

   ```
   git push
   ```

   The last line ends in `main -> main`.
7. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. Your new commit is on top, with your Module 6 commit (or your latest one) under it.
8. **Add one more test, and save again (NEW: a small second commit).** Tests grow as a site grows. Add a fourth test to the `toFileName` group, for one of your other pages, and add its prediction to the `// expect` comment. The sample's group became:

   ```js
   // expect index.html, about.html, contact.html, interests.html
   console.log(toFileName("home"));
   console.log(toFileName("about"));
   console.log(toFileName("contact"));
   console.log(toFileName("interests"));
   ```

   Save, run `node helpers.js`, and check that the new line matches the comment. Then type `git status`. This time it lists `modified:   helpers.js` under **Changes not staged for commit**. Run the routine again, with a message that names the change:

   ```
   git add .
   git commit -m "Add a toFileName test for the Interests page"
   git push
   ```

   On the sample, the commit printed `1 file changed, 2 insertions(+), 1 deletion(-)`. Git counts a changed line as one line deleted and one line added: the `// expect` comment changed, and one test line is new. `git log --oneline` now shows both commits on top, the newest first. One small change, tested, then saved with a message that says what it was: that is a commit you can find again later.
9. **Check the live site.** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/` and press F5. Your pages look exactly as before, because no page loads `helpers.js`. Then open `https://your-username.github.io/my-site/helpers.js`. As with your scripts in Modules 5 and 6, the browser shows your code as text or offers to download it, and nothing runs. Anyone with the address can read it, your tests included, so check once more that it holds nothing private.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows your two new commits on top. `node helpers.js` still prints every group with no error, your live pages look the same as before, and the live address of `helpers.js` shows your code without running it.
