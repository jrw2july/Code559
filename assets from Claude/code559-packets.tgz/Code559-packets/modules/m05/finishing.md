# Finishing work in Git

Your script works on your computer. Now you save it to GitHub with the same save routine as in Modules 1 to 4: `git status`, `git add .`, `git commit`, `git push`, then check the live site. What is new this time is the kind of file. `about-me.js` is not a page, and no page uses it. Git saves it all the same, and GitHub Pages publishes it as it is. Opening its address shows the code in the browser, and nothing runs it.

Items marked **NEW** are new in this part. The others repeat what you did in Modules 1 to 4.

1. **Check the terminal.** In VS Code, with `my-site` open, look at the terminal prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal.
2. **See what changed.** Type:

   ```
   git status
   ```

   Under **Untracked files** you should see one line: `about-me.js`. Git has never saved it before. No page is listed, because no page changed. If you see a page or `styles.css` under **Changes not staged for commit**, you changed it by accident or left work from an earlier module unsaved: open it and check before you go on. Your `practice-05` folder never shows up here, because it is outside `my-site`.
3. **Stage the change.** Type:

   ```
   git add .
   ```

   It prints nothing when it works. (A warning that mentions LF and CRLF is harmless.) Run `git status` again. Under **Changes to be committed** you should now see `new file:   about-me.js`.
4. **Commit (NEW: a file that is not a page).** Type:

   ```
   git commit -m "Add an about-me script that Node runs"
   ```

   On the sample site, Git printed `1 file changed, 26 insertions(+)` on the second line and `create mode 100644 about-me.js` on the third. The 26 is the number of lines in the sample file: comments and blank lines count too. Your commit id and line count will differ. Git saves any file you give it, a page, a stylesheet, a picture or a script. It does not check whether a page uses it.
5. **Push.** Type:

   ```
   git push
   ```

   The last line ends in `main -> main`.
6. **Check that Git is done.** Type `git status`. It should say `nothing to commit, working tree clean`. Then type `git log --oneline`. Your new commit is on top, with your Module 4 commit (or your latest one) under it.
7. **Check the live site (NEW: nothing changes).** Wait a few minutes (GitHub Docs: "It can take up to 10 minutes for changes to your site to publish"), then open `https://your-username.github.io/my-site/` and press F5. Your Home page looks exactly as before, and so does every other page. That is correct. No page loads `about-me.js`, so adding it changed nothing a visitor sees.
8. **Open the script's own address (NEW: a published file that is not a page).** Open `https://your-username.github.io/my-site/about-me.js`. The browser shows your code as text, comments and all. Your browser may show it as text or offer to download it; either way nothing runs. If it shows the text, press **F12** (or **Ctrl+Shift+J**) to open DevTools, then click the **Console** tab: it is empty, because none of your `console.log()` lines ran. (This check was made on a local test server, not on GitHub Pages: Chromium showed the file's text and an empty Console.) Nobody runs this script except you, with Node. This is also why the brief said to keep the script free of private details: anyone with this address can read it.
9. **Run the saved copy.** Back in VS Code, type `node about-me.js` one more time. The script runs from the file on your computer. The copy on GitHub is your saved history and a backup. Node never reads it.

> **Checkpoint.** `git status` says `nothing to commit, working tree clean`. `git log --oneline` shows your new commit on top. Your live pages look the same as before, and the live address of `about-me.js` shows your code as text (or downloads it) without running it.
