# Troubleshooting: five common problems

Each problem has the symptom you see, why it happens, and the fix. Each error below was made on purpose with the sample script and run with Node 22. The messages were captured on Linux, with the folder path changed to the course folder; on Windows, Node prints the same words with your own path. After each fix, save, and run `node about-me.js` again from the `my-site` folder.

### 1. "node" is not recognized

**Symptom.** You type `node about-me.js` (or `node --version`) and the terminal answers with a red error saying the term `node` is not recognized. Nothing from your script prints.

**Why.** The terminal cannot find the Node program. Either Node is not installed, or it was installed after VS Code was opened. A terminal inside VS Code gets its list of program locations from VS Code, and VS Code still has the list from before the install.

**Fix.** This is problem 1 of the Module 0 troubleshooting page. Close VS Code completely with **File → Exit**, open it again, choose **Terminal → New Terminal**, and type `node --version`. A new terminal in the same VS Code window is not enough. Still not recognized? Restart the computer. If it still fails, install Node again as in Module 0.

### 2. "Cannot find module" from the wrong folder

**Symptom.** Node prints an error that starts like this, and nothing from your script prints:

```
node:internal/modules/cjs/loader:1386
  throw err;
  ^

Error: Cannot find module 'C:\Users\you\Documents\code559\about-me.js'
```

Under it are some `at` lines and `code: 'MODULE_NOT_FOUND'`. The numbers in the first line depend on your Node version.

**Why.** `node about-me.js` looks for the file in the folder the terminal is in. Read the path in the message: it is the place Node looked. Here the terminal was in the course folder, `code559`, one level above `my-site`, so Node looked for `code559\about-me.js`, and there is no such file.

**Fix.** Check the prompt. It must end in `my-site>`. If it does not, use **File → Open Folder…**, choose `my-site`, and open a new terminal. Then run the command again. The error is the same if you type the file name wrong, for example `node aboutme.js`, so compare the name in the message with the name in the VS Code Explorer letter by letter.

### 3. "Cannot find module" from the right folder

**Symptom.** The prompt ends in `my-site>`, but Node still prints `Error: Cannot find module 'C:\Users\you\Documents\code559\my-site\about-me.js'`. The file is right there: you can see your code.

**Why.** The file's real name is not `about-me.js`. The usual cause is a file created outside VS Code, for example in File Explorer with **New → Text Document**, while file extensions were hidden. You typed `about-me.js`, and Windows kept its own ending: the file is really `about-me.js.txt`. On the sample, a file named `about-me.js.txt` in `my-site` gave exactly this error. A file saved in another folder, such as `practice-05`, gives it too.

**Fix.** Look at the name in the VS Code Explorer, which shows the whole name. If it ends in `.txt`, click it, press F2, and rename it so it ends in `.js` only. Then turn on **View → Show → File name extensions** in File Explorer, as in Module 0, so this cannot hide again. If the file is in the wrong folder, drag it in the Explorer onto `my-site`, or create it again at the top level of `my-site`.

### 4. A SyntaxError, and nothing prints

**Symptom.** Not a single line of your card prints. Node shows a line of your code with a row of carets under it, then `SyntaxError:` and a message. With a missing closing quote on line 16 of the sample, it printed:

```
C:\Users\you\Documents\code559\my-site\about-me.js:16
console.log("Course: Code559 Front-End Developer Course);
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

SyntaxError: Invalid or unexpected token
```

With a missing `)` instead, the message was `SyntaxError: missing ) after argument list` (Project step 9).

**Why.** Before Node runs anything, it reads the whole file to check that it is valid JavaScript. One missing quote or parenthesis makes the file invalid, so Node runs none of it, not even the lines above the mistake. A missing closing quote is the most common cause: Node keeps reading the rest of the line as text, looking for the end of it.

**Fix.** Go to the line number in the first line of the error. Look where the carets start: on that line, every `"` needs a partner, and every `(` needs a `)` before the semicolon.

### 5. A ReferenceError partway through

**Symptom.** Some of your card prints, then it stops, and Node prints a line of your code with one caret under it and `ReferenceError: consol is not defined` (or another word in place of `consol`).

**Why.** Every line above the mistake was fine, so Node ran those lines and printed them. Then it reached a name it does not know and stopped. In the sample, `consol.log` on line 23 printed 14 lines first (Project step 8). Capital letters count: `Console.log("b");` gave `ReferenceError: Console is not defined`, because JavaScript treats `Console` and `console` as two different names.

**Fix.** The last line that printed tells you where to look: the mistake is in the statement right after it. The first line of the error gives the same line number. Check the spelling of `console`, all lowercase, and fix it.
