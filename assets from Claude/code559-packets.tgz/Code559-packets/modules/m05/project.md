# Project: About me in the Console

*Your hands, about 60 minutes (estimate).* In the Exercise you ran, changed and broke `hello.js` in `practice-05`. Now you write a script of your own and keep it in your real site. The script is `about-me.js`. When you run it with Node, it prints a short introduction in labeled lines, like a small card in the terminal: who you are, what you are learning, and one thing you want to build. When Node runs the file, `console.log()` prints in the terminal, which is Node's console. You plan it with comments first and predict the output before every run. You use only what Module 5 taught: comments, statements, semicolons, text in quotes and `console.log()`.

This project goes in `my-site`, the folder you have built since Module 1. Any `my-site` that is a Git repository connected to GitHub works, because the script does not touch your pages. If you did the Module 4 packet, your site has five pages; this project adds a file that is not a page.

## The brief

Read the whole brief twice before you type anything.

When you finish, `my-site` holds a new file, `about-me.js`, next to `index.html` and your other pages. Not inside `practice-05`, and not in a sub-folder. No page links to it and no page runs it. In Modules 5 to 8 your JavaScript runs in the terminal only. Module 9 shows how a page loads a script.

**What it prints.** Run from the `my-site` folder, `node about-me.js` printed exactly these 18 lines for the sample student, Sam:

```
==============================
ABOUT ME
==============================
Name: Sam
Likes: drawing, soccer and old maps

------------------------------
WHAT I AM LEARNING
------------------------------
Course: Code559 Front-End Developer Course
So far: HTML, CSS and JavaScript
This week: running scripts with Node

------------------------------
ONE THING I WANT TO BUILD
------------------------------
Goal: a page where my family shares recipes
==============================
```

Your script prints the same shape with your own words:

- **Three sections, in this order:** `ABOUT ME`, `WHAT I AM LEARNING`, `ONE THING I WANT TO BUILD`. Each heading is in capital letters, with a divider line above it and below it.
- **The dividers.** The top of the card and the line under `ABOUT ME` are `=` signs. The dividers in the two later sections are `-` signs. The very last line is `=` signs again: the bottom of the card. Every divider has the same length. The sample uses 30 characters.
- **Labeled lines.** Every fact is one line: a short label, a colon, a space, then your words, such as `Name: Sam`. `ABOUT ME` has your name and at least one more fact. `WHAT I AM LEARNING` has at least two lines. `ONE THING I WANT TO BUILD` has one `Goal:` line.
- **One blank line between sections**, before each section's first divider.

**What is inside the file.**

- The first two lines are comments: the file name with one sentence about what it does, and how to run it.
- Each section starts with a comment that names it, such as `// Section 1: who I am`.
- Every printed line, the blank ones too, comes from its own `console.log()` statement, and every statement ends with a semicolon.
- Only text in quotes. You learn to store values in Module 6.

The script will be public: GitHub Pages publishes every file in `my-site`, so anyone with the address can read it (Part 3 shows you). Write only what you are happy to share. Your first name or a nickname is enough. No address, no phone number, no school.

![A terminal in the my-site folder running node about-me.js. It prints a line of equals signs, ABOUT ME, another line of equals signs, Name: Sam, Likes: drawing, soccer and old maps, a blank line, then the WHAT I AM LEARNING section between dashed lines with three labeled lines, a blank line, the ONE THING I WANT TO BUILD section with one Goal line, and a closing line of equals signs.](images/p05-about-me.png)
*The finished script for the sample student. Eighteen statements, eighteen lines of output, in the same order as the code. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*

## The steps

Type every line. Do not paste. The one exception is the divider lines: once you have typed one divider and checked its length, you may copy that whole line for the others.

1. **Open `my-site`.** In VS Code, **File → Open Folder…** and choose `my-site` in your course folder, `C:\Users\you\Documents\code559`. Open a terminal with **Terminal → New Terminal** and check that the prompt ends in `my-site>`. Type `node --version`. It should print a version starting with `v`, as in Module 0.
2. **Plan on paper.** Read the brief again. On paper, write the 18 or so lines you want your script to print, in order, with your own words. Mark where each blank line goes. This is your plan, and later it is your prediction: when you run the finished script, the terminal should match this page line for line.
3. **Plan with comments first.** In the VS Code Explorer, create `about-me.js` at the top level of `my-site`, next to `index.html`. Type only these comments, then save with Ctrl+S:

   ```js
   // about-me.js: a short introduction that Node prints in the terminal
   // Run it from the my-site folder with: node about-me.js

   // Section 1: who I am

   // Section 2: what I am learning

   // Section 3: one thing I want to build
   ```

   The comments are the outline of the script. Each section's code goes under its own comment. **Predict** before you run it: what will `node about-me.js` print? Write down your answer. Then type `node about-me.js` and press Enter.

   Nothing printed. The prompt came straight back, with no error. Node read every line, and every line was a comment, so there was nothing to do.
4. **Section 1.** Under `// Section 1: who I am`, type the five statements below, with your own name and your own fact in place of Sam's:

   ```js
   // Section 1: who I am
   console.log("==============================");
   console.log("ABOUT ME");
   console.log("==============================");
   console.log("Name: Sam");
   console.log("Likes: drawing, soccer and old maps");
   ```

   Read the five statements to yourself, out loud. For each one, say what it will print. Then write the five lines down as your prediction. Save, run `node about-me.js` again, and compare.

   Save before every run. Node runs the file as it is saved on the disk, not what you see in the editor. A white dot on the file's tab in VS Code means the file has changes that are not saved yet.
5. **Section 2, with a blank line.** Under `// Section 2: what I am learning`, start with these two statements:

   ```js
   // Section 2: what I am learning
   console.log("");
   console.log("------------------------------");
   // Continue alone: the heading WHAT I AM LEARNING, a second divider,
   // then at least two labeled lines of your own.
   ```

   `""` is text with nothing in it: two quotes and no characters between them. `console.log("")` prints that empty text, so the terminal shows an empty line. That is your blank line between sections.

   Write the rest of the section alone. Then delete the two "Continue alone" comment lines, because they described work that is now done. Before you run, count your statements in Sections 1 and 2, and write down how many lines will print. Save and run. The sample printed 12 lines: 5 from Section 1 and 7 from Section 2, the empty one included.
6. **Create Section 3 alone.** This section has no code to copy, only this description from the brief: a blank line, a `-` divider, the heading `ONE THING I WANT TO BUILD`, a second `-` divider, one `Goal:` line, then the bottom of the card, a line of `=` signs. Type it under `// Section 3: one thing I want to build`. Count all your statements and write down the number of lines you expect. Save and run. Compare the result with your plan from step 2 and with the picture in the brief. If a line is missing, in the wrong place or spelled differently, fix the statement that prints it and run again.
7. **Modify.** Make two changes, one at a time. Predict each before you run it.

   - **Remove the first blank line.** Put the cursor on the `console.log("");` line in Section 2 and press Ctrl+X to cut the whole line. Save. Predict what changes, then run. In the sample, the dashed divider now sat right under `Likes: drawing, soccer and old maps`, with no space between the sections. Put the cursor back at the start of the line under `// Section 2: what I am learning`, press Ctrl+V, save, and run again to check that the blank line is back.
   - **Swap two sections.** Select all of Section 3, from its comment to the last line of the file, and cut it with Ctrl+X. Paste it on the empty line above `// Section 2: what I am learning`. Save. Before you run, write down the order of the 18 lines. Then run. In the sample, the building section came second, and so did the closing line of `=` signs, because that statement was cut together with Section 3. The bottom of the card now sat in the middle of the output, and the card had no bottom at all. The computer did exactly what the file said, top to bottom. Move Section 3 back to the end, save, and run once more to check that the output matches the brief again.
8. **Break it on purpose: a misspelled name.** In Section 3, on the heading line, delete the `e` from `console`, so it reads `consol.log("ONE THING I WANT TO BUILD");`. Save. Before you run, think this through: in the Exercise, a typo on line 2 stopped everything, so nothing printed. This typo is near the end of the file. What will print this time? Write it down, then run.

   ![A terminal in the my-site folder running node about-me.js. Sections 1 and 2 print normally, then a blank line and a dashed divider. Then comes the error: the path to about-me.js with :23, the line consol.log("ONE THING I WANT TO BUILD");, a caret under the c, a blank line, ReferenceError: consol is not defined, and the stack lines starting with at, ending with Node.js v22.22.0.](images/p05-reference-error.png)
   *The first 14 lines printed: Node ran lines 5 to 22 before it reached the typo on line 23. Then it stopped, and the heading, the Goal line and the bottom of the card never printed. Your line number may differ if your sections have more or fewer lines. The `node:internal` lines and the last line depend on your Node version. (real output, rendered; captured on Linux, with the folder path changed to the course folder)*

   Find the five parts from the lesson's Core Concept 7: where (the file and line), the line, the caret, the name and message, and the `file:line:column` in the first `at` line. Fix the spelling, save, and run again to prove that all 18 lines are back.
9. **Debug: a message to read before you look.** Now a different mistake. On the `Goal:` line, delete the closing parenthesis `)`, the one just before the semicolon. Save. Before you run, write down one prediction: will the first 17 lines print this time, or none of them? Then run. Here are the top lines of what Node printed for the sample, with the folder path changed to the course folder (captured on Linux):

   ```
   C:\Users\you\Documents\code559\my-site\about-me.js:25
   console.log("Goal: a page where my family shares recipes";
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

   SyntaxError: missing ) after argument list
   ```

   Nothing printed before the error, not even `ABOUT ME`. A `SyntaxError` means Node could not read the file as JavaScript, so it ran none of it, even the lines that were fine. Use the error, not your memory of what you deleted: the line number says line 25, the carets underline the quoted text, and the message says a `)` is missing after it. Put the `)` back, save, and run. Then write two lines in your notebook: the name and message of each error from steps 8 and 9, and the difference in what printed before each one.
10. **Explain it.** With the script working, read the whole file to yourself, out loud, from top to bottom. For each comment, say why it is there. For each statement, say what it prints and why it prints at that point and not earlier. If there is a line you cannot explain, reread the Core Concept it comes from.
11. **Check the script.** Tick each box.

    - [ ] `about-me.js` is in `my-site`, next to `index.html`, not in `practice-05`
    - [ ] The prompt ends in `my-site>`, and `node about-me.js` prints three sections in the order from the brief
    - [ ] Every heading is in capital letters with a divider above and below; the top and bottom of the card are `=` signs
    - [ ] There is exactly one blank line before each of the two later sections, and nowhere else
    - [ ] Every fact line has a label, a colon and a space
    - [ ] The file starts with two comments, and each section starts with its own comment
    - [ ] Every statement ends with a semicolon
    - [ ] The output matches the plan you wrote in step 2, or you know why it changed
    - [ ] Nothing in the script is private

12. **Save it in Git.** Go to Part 3, *Finishing work in Git*, and save the script with the save routine.
