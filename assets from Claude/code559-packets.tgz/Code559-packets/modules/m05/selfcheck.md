# Self-assessment

Rate yourself on each line: 1 Beginning, 2 Developing, 3 Proficient, 4 Ready to advance. Aim for at least **3 (Proficient)** on every line before you start Module 6. If a line is a 1 or a 2, reread that Core Concept and redo its Exercise or Project step.

## Rubric

- I can explain that a program runs top to bottom, and predict the order of a script's output before I run it
- I can say where JavaScript runs in this course, the browser's Console and Node, and choose the right one for a task
- I can write statements that end in a semicolon, and comments that say what a part of the code is for
- I can print text, numbers and blank lines with console.log(), and predict the difference between console.log(10 - 4) and console.log("10 - 4")
- I can run a file with node from the right folder, and fix "Cannot find module" by reading the path in the message
- I can open the DevTools Console with F12 or Ctrl+Shift+J, type an expression and read the answer
- I can read a Node error from the top: the file and line, the code line, the caret, the name and message, and the file:line:column
- I can tell a SyntaxError from a ReferenceError by what printed before it, and fix each one
- I can plan a script with comments first and take it through Predict, Run, Modify, Create and Debug

## Three questions to answer in writing

1. In Project step 8, 14 lines printed before the ReferenceError. In step 9, nothing printed before the SyntaxError. Explain the difference in your own words, and say what each error tells you about where to look.
2. Pick one prediction you got wrong in this module. What did you write down, what did the terminal or the Console show, and what did you not understand before that you understand now?
3. A friend's `about-me.js` prints the `WHAT I AM LEARNING` section before `ABOUT ME`, and has no blank line between the last two sections. Without seeing the file, describe the two changes they need to make, and the statement each change is about.
