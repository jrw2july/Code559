# Answers

Try each question on your own first, in writing. Then compare. The section in brackets is where the lesson or the project explains it.

## Check your understanding

1. **Why nothing printed in step 6.** A program runs from the top down, and Node stops at the first error. The typo was on line 2, the first statement in the file, so Node stopped before it had printed anything. The lines after line 2 were fine, but Node never reached them. Compare Project step 8: the same typo near the end of the file let 14 lines print first. (Core concepts 1 and 7; Exercise step 6; Project step 8)
2. **`console.log(10 - 4);` and `console.log("10 - 4");`.** Without quotes, `10 - 4` is a sum: JavaScript works it out first and prints `6`. With quotes, `"10 - 4"` is text, and `console.log()` prints its characters exactly as typed: `10 - 4`. (Core concept 4; Exercise step 5)
3. **Why `undefined` appears.** The Console does two things for each line you type. It runs the line, and then it shows the value the line hands back. `console.log("Hello from the Console")` prints its text while it runs. Then the Console shows what `console.log()` handed back, and it hands back no value, which JavaScript calls `undefined`. It is not an error: an error is shown in red and starts with `Uncaught`, as in Core concept 7. (Core concepts 6 and 7)

## Common misconception

*"An error message means I did something badly wrong. I should delete the line and start over."* An error is a report, and it is free help. The ReferenceError in Exercise step 6 gave you, without any searching: the file, the line number (2), the line itself, a caret at the exact spot, the kind of problem (`ReferenceError`, a name JavaScript does not know) and the problem in words (`consol is not defined`). That is enough to fix a one-letter typo in seconds. Deleting the line throws all of that away, and if you retype it with the same mistake, you are back where you started. Read the message from the top, fix the one thing it points to, and run again. (Core concept 7; Exercise steps 6 and 7)

## Exercise checks

- **Steps 2 and 3.** Three lines, in this order: `Hello, world!`, `This line runs second.` and `5`. The comment on line 1 prints nothing, and neither does the comment at the end of line 4. (Core concepts 3 to 5)
- **Step 4.** Four lines: the three from step 3, then `I added this line.`, last, because it is the last statement in the file. (Core concept 1)
- **Step 5.** The hours in a week, `console.log(7 * 24);`, prints `168`. `console.log(10 - 4);` prints `6`, and `console.log("10 - 4");` prints `10 - 4`. (Core concept 4)
- **Step 6.** Nothing prints. Name: `ReferenceError`. Message: `consol is not defined`. The first line of the error and the first `at` line both point to line 2 of `hello.js`. (Core concept 7)
- **Step 7.** Nothing prints, not even line 2. Name: `SyntaxError`. Message: `Invalid or unexpected token`. The error points to line 3, with carets from the open quote to the end of the line. (Core concept 7)
- **Step 8.** `2 + 3` gives `5`. `"Hello, " + "world"` gives `"Hello, world"` (your Console may show single quotes). `consol.log("hi")` gives `Uncaught ReferenceError: consol is not defined`. (Core concepts 6 and 7)

## Self-assessment questions

1. **Why 14 lines printed in step 8 but none in step 9.** A ReferenceError happens while the script runs. Node had already run every line above the typo, so those 14 lines printed, and it stopped only when it reached `consol` on line 23. A SyntaxError happens before the script runs: Node reads the whole file first, finds that it is not valid JavaScript, and runs none of it. Where to look: for a ReferenceError, the statement right after the last line that printed, which is also the line number in the error; for a SyntaxError, the line number and the carets, because the output gives no clue. (Core concept 7; Project steps 8 and 9)
2. **A prediction you got wrong.** There is no single answer. A good answer quotes what you wrote down before the run, quotes what the terminal or the Console really showed, and names the idea you understand now, for example that a SyntaxError stops the whole file, or that `""` prints an empty line.
3. **Fixing the friend's script.** First, move the whole `WHAT I AM LEARNING` section, from its comment to its last statement, below the `ABOUT ME` section, because statements run top to bottom. Second, add `console.log("");` as the first statement of the last section, before its first dashed divider, so the blank line prints between the two sections. (Core concept 1; Project steps 5 and 7)

## Project checks

- **Step 3.** Nothing prints, and there is no error: the prompt comes straight back. A file with only comments has nothing to run.
- **Step 4.** Five lines: the `=` divider, `ABOUT ME`, the `=` divider, your name line and your fact line.
- **Step 5, continue alone.** The sample's Section 2. Seven statements, so the sample printed 12 lines in all.

  ```js
  // Section 2: what I am learning
  console.log("");
  console.log("------------------------------");
  console.log("WHAT I AM LEARNING");
  console.log("------------------------------");
  console.log("Course: Code559 Front-End Developer Course");
  console.log("So far: HTML, CSS and JavaScript");
  console.log("This week: running scripts with Node");
  ```

- **Step 6, create alone.** The sample's Section 3. The whole file now has 18 statements, so 18 lines print, as in the brief.

  ```js
  // Section 3: one thing I want to build
  console.log("");
  console.log("------------------------------");
  console.log("ONE THING I WANT TO BUILD");
  console.log("------------------------------");
  console.log("Goal: a page where my family shares recipes");
  console.log("==============================");
  ```

- **Step 7.** Without the first blank line, the dashed divider prints right under the last line of `ABOUT ME`. With the sections swapped, the building section and the closing `=` line print second, and the output ends with `This week: running scripts with Node`: the card has no bottom line. The statements ran in the order they sat in the file.
- **Step 8.** Sections 1 and 2 print, then the blank line and the first dashed divider of Section 3: 14 lines. Then `ReferenceError: consol is not defined`, pointing at line 23 in the sample.
- **Step 9.** None of the lines print. `SyntaxError: missing ) after argument list`, pointing at line 25 in the sample. A SyntaxError stops the whole file before it starts; a ReferenceError stops it only when Node reaches the bad line.
- **Step 11.** If you followed the brief, every box is ticked. The most common miss is a blank line in the wrong place: count the `console.log("");` statements. There should be exactly two, one at the start of Section 2 and one at the start of Section 3.
