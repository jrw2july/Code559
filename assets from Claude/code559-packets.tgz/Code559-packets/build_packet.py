"""Build one Code559 module packet (Modules 1-13) as a PDF.
Usage: python build_packet.py N [--blog PATH] [--out PATH]   (default blog: ../Code559/blog, beside this folder)
Inputs, in modules/mNN/:
  project.md        Part 2: the full Project (the brief, then the steps)          required
  finishing.md      Part 3: finishing work in Git                                   required
  troubleshooting.md  optional part, only where the module has common failures
  selfcheck.md      Self-assessment (rubric rows as a "- " list under "## Rubric", then anything else)  required
  answers.md        Answers to Check your understanding, the misconception, and Exercise checks       required
  images/           packet-only pictures (pNN-*.png); post pictures come from the blog's images folder
Each .md starts with "# Part title". Page order: cover, About this module, Contents, Part 1 the lesson, the parts, About 559 Solutions.
"""
import pathlib, re, os, sys, shutil, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import packetkit as pk
from markdown_it import MarkdownIt
from playwright.sync_api import sync_playwright
from pypdf import PdfWriter, PdfReader

ap = argparse.ArgumentParser(); ap.add_argument("n", type=int)
HERE = os.path.dirname(os.path.abspath(__file__))
ap.add_argument("--blog", default=os.path.join(HERE, "..", "Code559", "blog")); ap.add_argument("--out", default=None)
ap.add_argument("--modules", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "modules"))
a = ap.parse_args(); N = a.n
MOD = os.path.join(a.modules, f"m{N:02d}"); OUT = a.out or MOD
post_path = next(p for p in sorted(os.listdir(a.blog)) if p.startswith(f"module-{N:02d}-"))
slug = post_path[:-3]
src = open(os.path.join(a.blog, post_path), encoding="utf-8").read()
fm = dict(re.findall(r'^(\w+):\s*"?(.*?)"?\s*$', re.search(r"\A---\n(.*?)\n---\n", src, re.S).group(1), re.M))
title = fm["title"].split(": ", 1)[1]; tagline = fm["subtitle"]
nxt = sorted(p for p in os.listdir(a.blog) if p.startswith(f"module-{N+1:02d}-"))
SITE = "https://559solutions.com/code559/"

# --- Part 1: the lesson (post without front matter, About/Contents blocks, Project teaser, H1)
src = re.sub(r"\A---\n.*?\n---\n", "", src, flags=re.S)
src, about_md = pk.split_post(src)
src = re.sub(r"\n## Project \(in the full packet\)\n.*?(?=\n## )", "\n", src, flags=re.S)
src = src.replace("without this post, and why?", "without this packet, and why?")
src = re.sub(r"\bthis post\b", "this lesson", src)
src = re.sub(r"\bThis post\b", "This lesson", src)
lesson_html = re.sub(r"<h1>.*?</h1>", "", pk.lesson_md().render(src), count=1, flags=re.S)
parts = [("lesson", "The lesson", f'<section class="part lesson" id="lesson"><p class="part-label">Part 1</p><h1>The lesson</h1>{lesson_html}</section>')]

plain = MarkdownIt("commonmark", {"html": True}).enable("table")
from mdit_py_plugins.tasklists import tasklists_plugin; plain.use(tasklists_plugin)
for key in ["project", "finishing", "troubleshooting", "selfcheck", "answers"]:
    f = os.path.join(MOD, key + ".md")
    if not os.path.exists(f):
        if key == "troubleshooting": continue
        sys.exit(f"missing {f}")
    md_src = open(f, encoding="utf-8").read()
    h1 = re.match(r"# (.+)\n", md_src).group(1); body = md_src[md_src.index("\n") + 1:]
    if key == "selfcheck":
        rows = re.findall(r"^- (.+)$", re.search(r"## Rubric\n(.*?)(?=\n## |\Z)", body, re.S).group(1), re.M)
        body = re.sub(r"## Rubric\n.*?(?=\n## |\Z)", "RUBRICTABLE", body, flags=re.S)
        CHECK = "&#9744;"
        table = ('<table class="rubric"><thead><tr><th>Skill</th><th>1<br><small>Beginning</small></th><th>2<br><small>Developing</small></th>'
                 '<th>3<br><small>Proficient</small></th><th>4<br><small>Ready to advance</small></th></tr></thead><tbody>'
                 + "".join(f"<tr><td>{r}</td>" + "".join(f"<td class='c'>{CHECK}</td>" for _ in range(4)) + "</tr>" for r in rows) + "</tbody></table>")
        html = plain.render(body).replace("<p>RUBRICTABLE</p>", table)
    else:
        html = plain.render(body)
    if key == "answers" and nxt:
        nslug = nxt[0][:-3]; ntitle = re.search(r'^title:\s*"Module \d+: (.*)"', open(os.path.join(a.blog, nxt[0]), encoding="utf-8").read(), re.M).group(1)
        html += (f'<div class="next"><p class="next-label">Next</p><p><b>Module {N+1}: {ntitle}.</b><br>Free lesson: '
                 f'<a href="{SITE}{nslug}/">559solutions.com/code559/{nslug}/</a></p></div>')
    parts.append((key, h1, f'<section class="part" id="{key}"><p class="part-label">Part {len(parts)+1}</p><h1>{h1}</h1>{html}</section>'))

cover_items = "".join(f"<li><b>{h1}</b></li>" for _, h1, _ in parts)
cover = f"""<section class="cover"><img class="logo" src="images/code559-logo.png" alt="Code559">
<p class="sub">Front-End Developer Course</p>
<div class="cover-title"><p class="mod">Module {N}</p><h1>{title}</h1><p class="tag-line">{tagline}</p>
<p class="free-link">Free lesson: <a href="{SITE}{slug}/">559solutions.com/code559/{slug}/</a></p></div>
<div class="contents"><p class="c-head">In this packet</p><ol>{cover_items}</ol></div>
<p class="parent">Powered by <a href="https://559solutions.com">559 Solutions</a></p></section>"""

about = pk.about_page(about_md, N)
body_html = "".join(h for _, _, h in parts) + pk.ABOUT_559
html = (f"<!doctype html><html lang='en'><head><meta charset='utf-8'><title>Code559 Module {N} Packet: {title}</title>"
        f"<style>{pk.PACKET_CSS}{pk.TOC_CSS}</style></head><body>{cover}__ABOUT__{body_html}</body></html>")
entries = pk.toc_entries(about + body_html)
def page_html(pages=None): return html.replace("__ABOUT__", about + pk.toc_page(entries, pages))

# images: logo + brand + post images + packet-only images, next to the HTML
BUILD = os.path.join(OUT, "_build"); img_out = os.path.join(BUILD, "images")
shutil.rmtree(BUILD, ignore_errors=True); os.makedirs(BUILD)
shutil.copytree(os.path.join(a.blog, "images"), img_out)
if os.path.isdir(os.path.join(MOD, "images")):
    shutil.copytree(os.path.join(MOD, "images"), img_out, dirs_exist_ok=True)
shutil.copy(os.path.join(HERE, "assets", "code559-logo.png"), img_out)

HTML = os.path.join(BUILD, "packet.html"); full = os.path.join(BUILD, "_full.pdf"); cov = os.path.join(BUILD, "_cover.pdf")
MARGIN = {"top": "0.7in", "bottom": "0.8in", "left": "0.7in", "right": "0.7in"}
footer = pk.footer(f"Module {N}: {title}")
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(); pages = None
    for _ in range(3):
        open(HTML, "w", encoding="utf-8").write(page_html(pages))
        pg.goto(pathlib.Path(HTML).as_uri()); pg.wait_for_timeout(500)
        pg.pdf(path=full, format="Letter", print_background=True, margin=MARGIN)
        found = pk.dest_pages(full); missing = [e[1] for e in entries if e[1] not in found]
        assert not missing, missing
        new = {e[1]: found[e[1]] for e in entries}
        if new == pages: break
        pages = new
    open(HTML, "w", encoding="utf-8").write(page_html(pages)); pg.goto(pathlib.Path(HTML).as_uri()); pg.wait_for_timeout(500)
    pg.pdf(path=full, format="Letter", print_background=True, display_header_footer=True,
           header_template="<span></span>", footer_template=footer, margin=MARGIN)
    pg.pdf(path=cov, format="Letter", print_background=True, page_ranges="1", margin=MARGIN)
    broken = pg.evaluate("[...document.images].filter(i=>!(i.complete&&i.naturalWidth>0)).map(i=>i.getAttribute('src'))")
    b.close()
assert not broken, f"broken images: {broken}"
w = PdfWriter(clone_from=full); w.insert_page(PdfReader(cov).pages[0], 0); w.remove_page(1)
name = f"Code559-Module-{N}-{re.sub(r'[^A-Za-z0-9]+', '-', title).strip('-')}.pdf"
final = os.path.join(OUT, name); w.write(final); os.remove(full); os.remove(cov)
assert all(pk.dest_pages(final).get(k) == v for k, v in pages.items()), "page numbers moved"
print("built", final, len(PdfReader(final).pages), "pages")
