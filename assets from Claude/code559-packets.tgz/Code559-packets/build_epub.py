"""Make an EPUB 3 edition of a Code559 packet from its built print HTML (2026-10-12).
Usage: python build_epub.py N        (N = 0..13; build the PDF first so packet.html is current)
Changes from print: no printed Contents page (the reader's own table of contents replaces it), the cover
becomes the cover image, page-only layout (writing lines, flex dividers, inline styles) becomes reflowable."""
import os, re, sys, shutil, subprocess, tempfile
from bs4 import BeautifulSoup

HERE = os.path.dirname(os.path.abspath(__file__))
N = int(sys.argv[1])
if N == 0:
    MOD = os.path.join(HERE, "modules", "m00"); SRC = os.path.join(MOD, "_build"); HTML = os.path.join(SRC, "packet.html"); PDF = os.path.join(MOD, "Code559-Module-0-Setup.pdf")
else:
    MOD = os.path.join(HERE, "modules", f"m{N:02d}"); SRC = os.path.join(MOD, "_build"); HTML = os.path.join(SRC, "packet.html")
    PDF = next(os.path.join(MOD, f) for f in os.listdir(MOD) if f.startswith(f"Code559-Module-{N}-") and f.endswith(".pdf"))
OUT = PDF[:-4] + ".epub"

soup = BeautifulSoup(open(HTML, encoding="utf-8").read(), "html.parser")
title_full = soup.title.get_text().replace("Packet: ", "Packet: ")          # "Code559 Module 7 Packet: Functions"
mod_title = title_full.split(": ", 1)[1]

# 1. Cover: drop the HTML cover (it becomes the cover image) and the printed Contents page.
for sel in ["section.cover", "section.toc-page"]:
    for el in soup.select(sel):
        el.decompose()

# 2. Part labels join their heading, so the book's table of contents reads "Part 2: Project: ...".
for sec in soup.select("section.part"):
    lab = sec.select_one("p.part-label"); h1 = sec.find("h1")
    if lab and h1:
        h1.insert(0, lab.get_text() + ": "); lab.decompose()

# 3. Floor-plan dividers: one combined picture (readers handle flex layouts poorly).
for d in soup.select('div[role="separator"]'):
    new = soup.new_tag("p", attrs={"class": "divider"})
    new.append(soup.new_tag("img", src="images/brand/divider-floorplan.svg", alt=""))
    d.replace_with(new)

# 4. Writing lines and fill-in lines: on an e-reader, write in your notebook instead.
for d in soup.select("div.lines"):
    p = soup.new_tag("p", attrs={"class": "write-note"}); p.string = "Write your answer in your course notebook."
    d.replace_with(p)
for s in soup.select("span.line"):
    s.replace_with("________________")

# 5. No inline styles (e-readers and EPUB checks prefer classes); badges get a class.
for el in soup.select("[style]"):
    if el.name == "img" and "brand/marker-" in el.get("src", ""):
        el["class"] = el.get("class", []) + ["badge"]
    del el["style"]

# 6. Flatten <section> wrappers (pandoc splits chapters at h1); keep each section's id on its heading.
for sec in soup.find_all("section"):
    h = sec.find(["h1", "h2"])
    if sec.get("id") and h is not None and not h.get("id"):
        h["id"] = sec["id"]
    sec.unwrap()

body = soup.body.decode_contents()
CSS = """
body { font-family: serif; line-height: 1.5; }
h1 { color: #0F2849; font-size: 1.6em; margin-top: 0.4em; }
h2 { color: #0F2849; font-size: 1.25em; }
h3 { font-size: 1.05em; }
code, pre { font-family: monospace; font-size: 0.9em; }
pre { white-space: pre-wrap; background: #f2f4f7; padding: 0.6em; border-radius: 4px; }
code { background: #f2f4f7; }
pre code { background: none; }
img { max-width: 100%; height: auto; }
img.badge { height: 1.2em; width: auto; vertical-align: -0.25em; margin-right: 0.2em; }
p.divider img { width: 100%; height: auto; }
blockquote { border-left: 4px solid #1A52BB; background: #eef3fc; margin: 0.8em 0; padding: 0.4em 0.8em; }
table { border-collapse: collapse; width: 100%; font-size: 0.9em; }
th, td { border: 1px solid #c9d1da; padding: 0.3em 0.4em; vertical-align: top; text-align: left; }
th { background: #eef2f7; }
figcaption, .tag { font-size: 0.85em; color: #374151; }
.write-note { font-style: italic; color: #4b5563; }
.task-list-item { list-style: none; }
.next { border-top: 2px solid #0F2849; margin-top: 1.5em; padding-top: 0.5em; }
.next-label { text-transform: uppercase; letter-spacing: 0.1em; color: #1A52BB; font-weight: bold; }
.rights { font-size: 0.9em; color: #374151; }
.sign-off { font-weight: bold; color: #0F2849; }
"""

work = tempfile.mkdtemp(prefix="epub-")
shutil.copytree(os.path.join(SRC, "images"), os.path.join(work, "images"))
# the combined divider: wall (1 part), window, wall (3 parts), door, as in the course pages
open(os.path.join(work, "images", "brand", "divider-floorplan.svg"), "w", encoding="utf-8").write(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 34" width="600" height="34">'
    '<g stroke="#1951BC" stroke-width="2" fill="none">'
    '<line x1="0" y1="22" x2="121" y2="22"/><line x1="0" y1="29" x2="121" y2="29"/>'
    '<rect x="122" y="22" width="68" height="7"/><line x1="122" y1="25.5" x2="190" y2="25.5" stroke-width="1.2"/>'
    '<line x1="191" y1="22" x2="554" y2="22"/><line x1="191" y1="29" x2="554" y2="29"/>'
    '<line x1="554" y1="22" x2="554" y2="29"/><path d="M554 22 A 20 20 0 0 1 574 2" stroke-width="1.4"/>'
    '<line x1="574" y1="2" x2="574" y2="29"/><line x1="574" y1="22" x2="600" y2="22"/><line x1="574" y1="29" x2="600" y2="29"/>'
    '</g></svg>')
# cover image: the PDF's own cover page
subprocess.run(["pdftoppm", "-f", "1", "-l", "1", "-r", "150", "-png", "-singlefile", PDF, os.path.join(work, "cover")], check=True)
open(os.path.join(work, "book.html"), "w", encoding="utf-8").write(
    f"<!doctype html><html lang='en'><head><meta charset='utf-8'><title>{title_full}</title></head><body>{body}</body></html>")
open(os.path.join(work, "epub.css"), "w", encoding="utf-8").write(CSS)
meta = os.path.join(work, "meta.yaml")
open(meta, "w", encoding="utf-8").write(f"""---
title: "Code559 Module {N}: {mod_title}"
subtitle: "Front-End Developer Course packet"
creator:
  - role: author
    text: "J. R. Wells"
publisher: "559 Solutions LLC"
rights: "© 2026 559 Solutions LLC. {'All rights reserved.' if N == 0 else 'Licensed to the purchaser for personal use. Do not share, resell or post it.'}"
lang: en-US
date: "2026"
identifier:
  - scheme: URN
    text: "urn:code559:packet:module-{N:02d}:2026-10-12"
...
""")
subprocess.run(["pandoc", "book.html", "meta.yaml", "-f", "html", "-t", "epub3", "-o", OUT,
                "--toc", "--toc-depth=3", "--split-level=1", "--css=epub.css",
                "--epub-cover-image=cover.png", "--resource-path=.", "--metadata", "toc-title=Contents"],
               cwd=work, check=True)
shutil.rmtree(work)
print("built", OUT)
