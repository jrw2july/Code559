"""Drawn illustrations (NOT screenshots). Every image made here must be captioned
'(illustration, not a screenshot)'. Each carries a small 'ILLUSTRATION' tag in the corner."""
import html
F = "font-family='Segoe UI,Arial,sans-serif'"
M = "font-family='Consolas,Menlo,monospace'"

def esc(s): return html.escape(s, quote=True)

def tag(w, h):
    return f"<g><rect x='{w-118}' y='{h-24}' width='112' height='18' rx='9' fill='#fff3cd' stroke='#e0c36a'/><text x='{w-62}' y='{h-11}' {F} font-size='10.5' text-anchor='middle' fill='#7a5d00'>ILLUSTRATION</text></g>"

def _code(lines, x, y, lh=20, size=13):
    out = ""
    for i, ln in enumerate(lines):
        out += f"<text x='{x}' y='{y+i*lh}' {M} font-size='{size}' fill='#1f2328' xml:space='preserve'>{esc(ln)}</text>"
        out += f"<text x='{x-34}' y='{y+i*lh}' {M} font-size='{size}' fill='#9aa0a6' text-anchor='end'>{i+1}</text>"
    return out

def vscode(files, active, code_lines, w=900, h=420, terminal=None, status="main", panel_title="EXPLORER", folder="MY-SITE", extra=""):
    """files: list of (name, indent). active: file name shown in tab."""
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'>"
    s += f"<rect width='{w}' height='{h}' rx='8' fill='#fff' stroke='#c9d1da'/>"
    s += f"<rect width='{w}' height='30' rx='8' fill='#dddddd'/><rect y='22' width='{w}' height='8' fill='#dddddd'/>"
    s += f"<text x='14' y='20' {F} font-size='12' fill='#333'>File&#160;&#160; Edit&#160;&#160; Selection&#160;&#160; View&#160;&#160; Go&#160;&#160; Run&#160;&#160; Terminal&#160;&#160; Help</text>"
    s += f"<rect y='30' width='44' height='{h-52}' fill='#2c2c2c'/>"
    for i in range(4):
        s += f"<rect x='13' y='{46+i*38}' width='18' height='18' rx='3' fill='{'#fff' if i==0 else '#8a8a8a'}'/>"
    s += f"<rect x='44' y='30' width='190' height='{h-52}' fill='#f3f3f3'/>"
    s += f"<text x='58' y='52' {F} font-size='11' fill='#555'>{esc(panel_title)}</text>"
    s += f"<text x='58' y='76' {F} font-size='12' font-weight='bold' fill='#333'>&#8964; {esc(folder)}</text>"
    for i, (n, ind) in enumerate(files):
        y = 98 + i * 22
        if n == active: s += f"<rect x='44' y='{y-15}' width='190' height='21' fill='#e4e6f1'/>"
        s += f"<text x='{66+ind*14}' y='{y}' {F} font-size='12.5' fill='#222'>{esc(n)}</text>"
    s += f"<rect x='234' y='30' width='{w-234}' height='32' fill='#ececec'/>"
    s += f"<rect x='234' y='30' width='150' height='32' fill='#fff'/><text x='250' y='51' {F} font-size='12.5' fill='#222'>{esc(active)}</text>"
    s += _code(code_lines, 290, 90)
    if terminal:
        ty = h - 22 - 24 - len(terminal) * 18 - 14
        s += f"<rect x='234' y='{ty}' width='{w-234}' height='{h-22-ty}' fill='#fff' stroke='#d9d9d9'/>"
        s += f"<text x='248' y='{ty+16}' {F} font-size='11' fill='#555'>TERMINAL</text>"
        for i, t in enumerate(terminal):
            s += f"<text x='248' y='{ty+38+i*18}' {M} font-size='12.5' fill='#1f2328' xml:space='preserve'>{esc(t)}</text>"
    s += f"<rect y='{h-22}' width='{w}' height='22' rx='0' fill='#007acc'/>"
    s += f"<text x='12' y='{h-7}' {F} font-size='11.5' fill='#fff'>&#9095; {esc(status)}</text>"
    s += extra + tag(w, h) + "</svg>"
    return s

def github_repo(repo, files, w=900, h=400, banner=None, user="your-username"):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'>"
    s += f"<rect width='{w}' height='{h}' rx='8' fill='#fff' stroke='#d0d7de'/>"
    s += f"<rect width='{w}' height='52' rx='8' fill='#f6f8fa'/><rect y='44' width='{w}' height='8' fill='#f6f8fa'/>"
    s += f"<circle cx='30' cy='26' r='12' fill='#24292f'/><text x='54' y='31' {F} font-size='14' fill='#24292f'>{esc(user)} / <tspan font-weight='bold'>{esc(repo)}</tspan></text>"
    tabs = ["Code", "Issues", "Pull requests", "Actions", "Settings"]
    x = 30
    for i, t in enumerate(tabs):
        s += f"<text x='{x}' y='82' {F} font-size='13' fill='{'#24292f' if i==0 else '#57606a'}' font-weight='{'bold' if i==0 else 'normal'}'>{t}</text>"
        if i == 0: s += f"<rect x='{x}' y='90' width='34' height='2' fill='#fd8c73'/>"
        x += len(t) * 8 + 26
    s += f"<line x1='0' y1='92' x2='{w}' y2='92' stroke='#d8dee4'/>"
    y0 = 112
    if banner:
        s += f"<rect x='30' y='{y0}' width='{w-60}' height='34' rx='6' fill='#ddf4ff' stroke='#54aeff'/><text x='44' y='{y0+22}' {F} font-size='13' fill='#0969da'>{esc(banner)}</text>"
        y0 += 48
    s += f"<rect x='30' y='{y0}' width='{w-60}' height='{26+len(files)*30}' rx='6' fill='#fff' stroke='#d0d7de'/>"
    s += f"<rect x='30' y='{y0}' width='{w-60}' height='30' rx='6' fill='#f6f8fa' stroke='#d0d7de'/>"
    s += f"<text x='44' y='{y0+20}' {F} font-size='12.5' fill='#57606a'>main</text>"
    for i, (n, msg) in enumerate(files):
        y = y0 + 52 + i * 30
        s += f"<text x='44' y='{y}' {F} font-size='13' fill='#0969da'>&#128196; {esc(n)}</text><text x='330' y='{y}' {F} font-size='12.5' fill='#57606a'>{esc(msg)}</text>"
        s += f"<line x1='30' y1='{y+9}' x2='{w-30}' y2='{y+9}' stroke='#eaeef2'/>"
    s += tag(w, h) + "</svg>"
    return s

def explorer(path, files, w=760, h=300, shown_ext=True):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'>"
    s += f"<rect width='{w}' height='{h}' rx='8' fill='#fff' stroke='#c9d1da'/>"
    s += f"<rect width='{w}' height='36' rx='8' fill='#f3f3f3'/><text x='16' y='23' {F} font-size='12.5' fill='#333'>&#128193; {esc(path)}</text>"
    s += f"<rect y='36' width='{w}' height='30' fill='#fafafa' stroke='#eee'/><text x='16' y='56' {F} font-size='12' fill='#555'>New&#160;&#160;&#160;Sort&#160;&#160;&#160;View&#160;&#160;&#160;&#8943;</text>"
    s += f"<text x='40' y='88' {F} font-size='11.5' fill='#666'>Name</text><text x='430' y='88' {F} font-size='11.5' fill='#666'>Type</text>"
    for i, (n, t) in enumerate(files):
        y = 112 + i * 28
        s += f"<text x='16' y='{y}' font-size='14'>{'&#128193;' if t=='File folder' else '&#128196;'}</text><text x='40' y='{y}' {F} font-size='13' fill='#222'>{esc(n)}</text><text x='430' y='{y}' {F} font-size='12.5' fill='#555'>{esc(t)}</text>"
    s += tag(w, h) + "</svg>"
    return s

def flow(steps, w=900, h=150, title=None, fill="#dbe8ff", stroke="#7aa7e8"):
    """Horizontal flow of boxes with arrows. steps: list of (label, sublabel)."""
    n = len(steps); pad = 20; gap = 28
    bw = (w - 2 * pad - gap * (n - 1)) / n
    top = 46 if title else 24
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'>"
    s += f"<defs><marker id='ar' viewBox='0 0 10 10' refX='8' refY='5' markerWidth='7' markerHeight='7' orient='auto'><path d='M0 0L10 5L0 10z' fill='#4a6fa5'/></marker></defs>"
    s += f"<rect width='{w}' height='{h}' fill='#fff'/>"
    if title: s += f"<text x='{w/2}' y='28' {F} font-size='15' font-weight='bold' text-anchor='middle' fill='#1b2b44'>{esc(title)}</text>"
    for i, (a, b) in enumerate(steps):
        x = pad + i * (bw + gap)
        s += f"<rect x='{x}' y='{top}' width='{bw}' height='{h-top-34}' rx='8' fill='{fill}' stroke='{stroke}'/>"
        s += f"<text x='{x+bw/2}' y='{top+28}' {F} font-size='14' font-weight='bold' text-anchor='middle' fill='#1b2b44'>{esc(a)}</text>"
        if b:
            for j, ln in enumerate(b.split("|")):
                s += f"<text x='{x+bw/2}' y='{top+50+j*17}' {F} font-size='11.5' text-anchor='middle' fill='#37474f'>{esc(ln)}</text>"
        if i < n - 1:
            ax = x + bw + 3
            s += f"<line x1='{ax}' y1='{top+(h-top-34)/2}' x2='{ax+gap-8}' y2='{top+(h-top-34)/2}' stroke='#4a6fa5' stroke-width='2' marker-end='url(#ar)'/>"
    s += tag(w, h) + "</svg>"
    return s

def layers(w=900, h=220):
    cols = [("HTML", "Structure", "What is on the page|headings, text, links, forms", "#fde2e2", "#e08a8a"),
            ("CSS", "Appearance", "How it looks|color, spacing, layout", "#e0f0ff", "#7aa7e8"),
            ("JavaScript", "Behavior", "What it does|clicks, checks, updates", "#e2f6e2", "#7bbf7b")]
    bw = (w - 80) / 3
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    s += f"<text x='{w/2}' y='28' {F} font-size='15' font-weight='bold' text-anchor='middle' fill='#1b2b44'>The three layers of a web page</text>"
    for i, (a, b, c, f, st) in enumerate(cols):
        x = 20 + i * (bw + 20)
        s += f"<rect x='{x}' y='48' width='{bw}' height='{h-90}' rx='10' fill='{f}' stroke='{st}'/>"
        s += f"<text x='{x+bw/2}' y='84' {F} font-size='20' font-weight='bold' text-anchor='middle' fill='#222'>{a}</text>"
        s += f"<text x='{x+bw/2}' y='108' {F} font-size='14' text-anchor='middle' fill='#333'>= {b}</text>"
        for j, ln in enumerate(c.split("|")):
            s += f"<text x='{x+bw/2}' y='{136+j*18}' {F} font-size='12' text-anchor='middle' fill='#444'>{esc(ln)}</text>"
    s += tag(w, h) + "</svg>"
    return s
