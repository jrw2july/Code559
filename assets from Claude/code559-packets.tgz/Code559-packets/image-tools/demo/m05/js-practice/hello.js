// hello.js: my first script
console.log("Hello, world!");
console.log("This line runs second.");
console.log(2 + 3); // a number, not text
