# My Portfolio

## What it does
A small personal website with a Home page and an About page.

## Built with
HTML and CSS.

## What I learned
How to keep a project's history with Git: one change per commit,
branches for new pages, and a .gitignore for files that do not belong.

## Live site
https://your-username.github.io/portfolio/
