function toMinutes(hours) {
  return hours * 60;
}

function isNarrow(width) {
  return width < 600;
}

function showMessage() {
  return "Thanks for visiting!";
}

console.log(toMinutes(2));
console.log(toMinutes(1.5));
console.log(toMinutes(0));
console.log(isNarrow(390));
console.log(isNarrow(800));
console.log(isNarrow(600));
console.log(showMessage);
console.log(showMessage());
