const messageButton = document.querySelector("#mesage-button");
messageButton.addEventListener("click", showMessage);

function showMessage() {
  document.querySelector("#message").textContent = "Hello!";
}
