const messageButton = document.querySelector("#message-button");
messageButton.addEventListener("click", showMesage);

function showMessage() {
  document.querySelector("#message").textContent = "Hello!";
}
