const tips = [
  "Save before you refresh.",
  "Read the whole error message.",
  "Change one thing at a time."
];
let index = 0;

const tipText = document.querySelector("#tip-text");
const tipCount = document.querySelector("#tip-count");
const prevButton = document.querySelector("#prev-button");
const nextButton = document.querySelector("#next-button");
const tipForm = document.querySelector("#tip-form");
const newTip = document.querySelector("#new-tip");
const formMessage = document.querySelector("#form-message");
const helpToggle = document.querySelector("#help-toggle");
const help = document.querySelector("#help");

function showTip() {
  tipText.textContent = tips[index];
  tipCount.textContent = "Tip " + index + " of " + tips.length;
}

nextButton.addEventListener("click", function () {
  index = index + 1;
  if (index > tips.length) {
    index = 0;
  }
  showTip();
});

prevButton.addEventListener("click", function () {
  index = index - 1;
  if (index < 0) {
    index = tips.length - 1;
  }
  showTip();
});

tipForm.addEventListener("submit", function (event) {
  event.preventDefault();
  const text = newTip.value;
  tips.push(text);
  formMessage.textContent = "Added. There are now " + tips.length + " tips.";
  newTip.value = "";
  showTip();
});

helpToggle.addEventListener("click", function () {
  help.classList.toggle("visible");
});

showTip();
