const messageButton = document.querySelector("#message-button");
messageButton.addEventListener("click", showMessage;

function showMessage() {
  document.querySelector("#message").textContent = "Hello!";
}
