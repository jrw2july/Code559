const interests = ["drawing", "cycling", "music"];
console.log(interests.length);
console.log(interests[interests.length - 1]);

interests.push("cooking");

for (let i = 0; i < interests.length; i++) {
  console.log(i + ": " + interests[i]);
}

console.log(interests.includes("music"));
console.log(interests.includes("hiking"));
console.log(interests.join(" | "));

const places = [
  { name: "City library", visited: true, free: true },
  { name: "Art museum", visited: false, free: false },
  { name: "River park", visited: false, free: true }
];

for (const place of places) {
  if (!place.visited && place.free) {
    console.log("Next free trip: " + place.name);
  }
}
