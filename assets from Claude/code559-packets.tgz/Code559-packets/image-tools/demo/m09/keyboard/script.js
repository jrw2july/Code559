const realButton = document.querySelector("#real-btn");
const fakeButton = document.querySelector("#fake-btn");

function reportReal() {
  console.log("click on the real button");
}
function reportFake() {
  console.log("click on the div");
}

realButton.addEventListener("click", reportReal);
fakeButton.addEventListener("click", reportFake);
