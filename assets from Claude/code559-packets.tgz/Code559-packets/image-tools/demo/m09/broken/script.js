// 1. Find elements
const toggleButton = document.querySelector("#toggle-btn");
const details = document.querySelector("#details");
const list = document.querySelector("#interest-list");

const interests = [
  { name: "Interest one", note: "a sentence about it", favorite: true },
  { name: "Interest two", note: "a sentence about it", favorite: false },
  { name: "Interest three", note: "a sentence about it", favorite: true }
];

// 2. Define behavior
function toggleDetails() {
  console.log("toggleDetails ran");
  details.hidden = !details.hidden;
  if (details.hidden) {
    toggleButton.textContent = "Show details";
  } else {
    toggleButton.textContent = "Hide details";
  }
  toggleButton.classList.toggle("is-open");
}

function buildList() {
  for (const interest of interests) {
    const item = document.createElement("li");
    item.textContent = interest.name + ": " + interest.note;
    if (interest.favorite) {
      item.classList.add("favorite");
      const star = document.createElement("img");
      star.src = "icon-star.svg";
      star.alt = "favorite";
      item.append(star);
    }
    list.append(item);
  }
}

// 3. Connect events
toggleButton.addEventListener("click", toggleDetails());
buildList();
