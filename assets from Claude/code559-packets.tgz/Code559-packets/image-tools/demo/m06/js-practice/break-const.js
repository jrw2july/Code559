const city = "Fresno";
city = "Chicago";
console.log(city);
