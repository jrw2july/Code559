// weather.js: suggest what to wear from the temperature (degrees F)
const temp = 40;

if (temp < 50) {
  console.log("Wear a coat");
} else if (temp < 70) {
  console.log("Bring a jacket");
} else {
  console.log("T-shirt weather");
}

console.log("Checked " + temp + " degrees");
