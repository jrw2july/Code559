// 1. Find elements
const form = document.querySelector("#contact-form");
const nameInput = document.querySelector("#name");
const emailInput = document.querySelector("#email");
const messageInput = document.querySelector("#message");
const nameError = document.querySelector("#name-error");
const emailError = document.querySelector("#email-error");
const messageError = document.querySelector("#message-error");
const pretendFail = document.querySelector("#pretend-fail");
const sendButton = document.querySelector("#send-btn");
const statusMessage = document.querySelector("#status");

// 2. Define behavior
function setState(stateName) {
  form.classList.remove("idle", "sending", "sent", "failed");
  form.classList.add(stateName);
}

function showError(input, errorElement, text) {
  errorElement.textContent = text;
  input.classList.add("invalid");
}

function clearError(input, errorElement) {
  errorElement.textContent = "";
  input.classList.remove("invalid");
}

// Checks every field. Returns the first field with a problem, or null.
function findFirstProblem() {
  let firstProblem = null;
  clearError(nameInput, nameError);
  clearError(emailInput, emailError);
  clearError(messageInput, messageError);

  const name = nameInput.value.trim();
  if (name === "") {
    showError(nameInput, nameError, "Please enter your name.");
    firstProblem = nameInput;
  }

  const email = emailInput.value.trim();
  if (email === "") {
    showError(emailInput, emailError, "Please enter your email address.");
    if (firstProblem === null) { firstProblem = emailInput; }
  } else if (!emailInput.checkValidity()) {
    showError(emailInput, emailError, "That email address looks incomplete. Check the @ and the part after it.");
    if (firstProblem === null) { firstProblem = emailInput; }
  }

  const message = messageInput.value.trim();
  if (message.length < 10) {
    showError(messageInput, messageError, "Please write at least 10 characters.");
    if (firstProblem === null) { firstProblem = messageInput; }
  }

  return firstProblem;
}

function finishSending() {
  if (pretendFail.checked) {
    setState("failed");
    statusMessage.textContent = "Sorry, your message did not go through. Please try again.";
  } else {
    setState("sent");
    statusMessage.textContent = "Thanks, " + nameInput.value.trim() + ". Your message was sent.";
    form.reset();
  }
  sendButton.disabled = false;
}

function handleSubmit(event) {
  event.preventDefault();
  statusMessage.textContent = "";
  const firstProblem = findFirstProblem();
  if (firstProblem !== null) {
    setState("idle");
    firstProblem.focus();
    return;
  }
  setState("sending");
  statusMessage.textContent = "Sending...";
  sendButton.disabled = true;
  // Stand-in for a real server: wait one second, then finish.
  setTimeout(finishSending, 1000);
}

// 3. Connect events
form.addEventListener("submit", handleSubmit);
