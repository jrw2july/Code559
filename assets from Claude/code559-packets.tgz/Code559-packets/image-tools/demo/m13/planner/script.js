const taskForm = document.querySelector("#task-form");
const taskInput = document.querySelector("#task-input");
const formMessage = document.querySelector("#form-message");
const taskList = document.querySelector("#task-list");
const summary = document.querySelector("#summary");

function updateSummary() {
  const total = taskList.querySelectorAll("li").length;
  const done = taskList.querySelectorAll("input:checked").length;
  if (total === 0) {
    summary.textContent = "No tasks yet.";
  } else {
    summary.textContent = done + " of " + total + " done";
  }
}

function makeTask(text) {
  const item = document.createElement("li");
  const label = document.createElement("label");
  const box = document.createElement("input");
  box.type = "checkbox";
  const words = document.createElement("span");
  words.textContent = text;
  box.addEventListener("change", function () {
    if (box.checked) {
      item.classList.add("is-done");
    } else {
      item.classList.remove("is-done");
    }
    updateSummary();
  });
  label.append(box, words);
  item.append(label);
  return item;
}

taskForm.addEventListener("submit", function (event) {
  event.preventDefault();
  const text = taskInput.value.trim();
  if (text === "") {
    formMessage.textContent = "Type a task first.";
    return;
  }
  formMessage.textContent = "";
  taskList.append(makeTask(text));
  taskInput.value = "";
  updateSummary();
});

updateSummary();
