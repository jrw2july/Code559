const countText = document.querySelector("#count");
const addButton = document.querySelector("#add-button");
let count = 0;

function addOne() {
  count = count + 1;
  countText.textContent = count;
}

addButton.addEventListener("click", addOne);
