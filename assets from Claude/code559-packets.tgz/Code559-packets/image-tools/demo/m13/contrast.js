// WCAG 2 contrast ratio: (lighter + 0.05) / (darker + 0.05), using relative luminance.
function channel(hex, start) {
  const c = parseInt(hex.slice(start, start + 2), 16) / 255;
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}
function luminance(hex) {
  return 0.2126 * channel(hex, 1) + 0.7152 * channel(hex, 3) + 0.0722 * channel(hex, 5);
}
function ratio(a, b) {
  const la = luminance(a);
  const lb = luminance(b);
  return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
}
const pairs = [
  ["body text", "#1d2733", "#ffffff"],
  ["summary text", "#4f5a66", "#ffffff"],
  ["button text", "#ffffff", "#2f5d8a"],
  ["error message", "#b3261e", "#ffffff"],
  ["a light gray", "#9aa3ad", "#ffffff"]
];
for (const [name, fg, bg] of pairs) {
  const r = ratio(fg, bg);
  console.log(name.padEnd(14), fg, "on", bg, r.toFixed(2) + ":1", r >= 4.5 ? "pass AA" : "FAIL AA");
}
