"""Image helpers for the Code559 blog build.

Every terminal/console image is rendered from REAL captured output:
use run() / node_eval() / browser_eval() to get the text, never type it by hand.
Page renders are real Chromium screenshots. SVG illustrations are drawn and
must be captioned as illustrations.
"""
import html, json, os, subprocess, tempfile
from playwright.sync_api import sync_playwright

OUT = "/home/claude/blog/images"
os.makedirs(OUT, exist_ok=True)

_pw = None
_browser = None

def _b():
    global _pw, _browser
    if _browser is None:
        _pw = sync_playwright().start()
        _browser = _pw.chromium.launch()
    return _browser

def close():
    global _pw, _browser
    if _browser:
        _browser.close(); _pw.stop(); _browser = None; _pw = None

# ---------- real runs ----------
def run(cmd, cwd=None, env=None):
    """Run a shell command for real; return combined stdout+stderr text."""
    e = dict(os.environ)
    e.update({"GIT_PAGER": "cat", "PAGER": "cat", "LANG": "C.UTF-8", "TERM": "dumb"})
    if env: e.update(env)
    p = subprocess.run(cmd, shell=True, cwd=cwd, env=e, capture_output=True, text=True)
    return (p.stdout + p.stderr).rstrip("\n")

def node_eval(js):
    """Run JS in Node for real; return combined output."""
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False) as f:
        f.write(js); path = f.name
    try:
        return run(f"node {path}")
    finally:
        os.unlink(path)

def browser_eval(html_text, js_lines):
    """Load html in Chromium; evaluate each JS line like a DevTools Console.
    Returns list of (kind, text): ('input', line), ('result', repr) or ('error', msg),
    plus ('log', text) for console.log output in order."""
    page = _b().new_page()
    entries = []
    page.on("console", lambda m: entries.append(("log" if m.type == "log" else m.type, m.text)))
    page.on("pageerror", lambda e: entries.append(("error", str(e))))
    page.set_content(html_text)
    page.wait_for_timeout(100)
    for line in js_lines:
        entries.append(("input", line))
        try:
            r = page.evaluate("""(src) => {
                try {
                    const v = (0, eval)(src);
                    const show = (x) => {
                      if (x === undefined) return 'undefined';
                      if (x === null) return 'null';
                      if (typeof x === 'string') return JSON.stringify(x);
                      if (typeof x === 'function') return x.toString();
                      if (x instanceof Element) return x.outerHTML.split('>')[0] + '>';
                      if (x instanceof NodeList) return 'NodeList(' + x.length + ') [' + Array.from(x).map(e => e.outerHTML.split('>')[0] + '>').join(', ') + ']';
                      if (Array.isArray(x)) return '(' + x.length + ') ' + JSON.stringify(x);
                      if (typeof x === 'object') return JSON.stringify(x);
                      return String(x);
                    };
                    return {ok: true, v: show(v)};
                } catch (e) { return {ok: false, v: 'Uncaught ' + e.name + ': ' + e.message}; }
            }""", line)
            page.wait_for_timeout(30)
            entries.append(("result" if r["ok"] else "error", r["v"]))
        except Exception as ex:
            entries.append(("error", str(ex)))
    page.close()
    return entries

# ---------- renderers ----------
def _shot(html_text, out_png, width, height=None, full_page=True, scale=2):
    page = _b().new_page(viewport={"width": width, "height": height or 600}, device_scale_factor=scale)
    page.set_content("<div id='__wrap' style='display:inline-block;min-width:100%;background:#e9eef3'>" + html_text + "</div>")
    page.wait_for_timeout(150)
    page.locator("#__wrap").screenshot(path=out_png)
    page.close()
    return out_png

def render_page(html_path, out_png, width=1200, height=None, full_page=True, actions=None, scale=2, clip=None):
    """Real Chromium render of a lesson page (file:// so relative css/js/images work)."""
    page = _b().new_page(viewport={"width": width, "height": height or 700}, device_scale_factor=scale)
    page.goto("file://" + os.path.abspath(html_path))
    page.wait_for_timeout(150)
    for kind, arg in (actions or []):
        if kind == "click": page.click(arg)
        elif kind == "press": page.keyboard.press(arg)
        elif kind == "fill": page.fill(arg[0], arg[1])
        elif kind == "check": page.check(arg)
        elif kind == "focus": page.focus(arg)
        elif kind == "wait": page.wait_for_timeout(arg)
        elif kind == "eval": page.evaluate(arg)
        page.wait_for_timeout(80)
    page.screenshot(path=out_png, full_page=full_page, clip=clip)
    page.close()
    return out_png

TERM_CSS = """
body{margin:0;background:#e9eef3;font-family:Segoe UI,Arial,sans-serif}
.win{margin:16px;border-radius:8px;overflow:hidden;box-shadow:0 6px 24px rgba(0,0,0,.18);background:#fff;border:1px solid #c9d1da}
.tb{background:#f3f3f3;border-bottom:1px solid #d9d9d9;height:34px;display:flex;align-items:center;padding:0 12px;font-size:12px;color:#444}
.tab{background:#fff;border:1px solid #d9d9d9;border-bottom:none;padding:5px 12px;border-radius:6px 6px 0 0;margin-top:8px}
.dots{margin-left:auto;letter-spacing:12px;color:#666}
pre{margin:0;padding:14px 16px;font:14.5px/1.45 Consolas,'Cascadia Mono',Menlo,monospace;color:#1f2328;white-space:pre-wrap;background:#fff}
.p{color:#0b57d0}.c{color:#1f2328;font-weight:600}.o{color:#333}
"""

def render_terminal(blocks, out_png, title="Windows Terminal — PowerShell", prompt="PS C:\\Users\\you\\my-site>", width=820):
    """blocks: list of (command, real_output). Draws a light-theme terminal frame."""
    body = ""
    for cmd, out in blocks:
        body += f'<span class="p">{html.escape(prompt)}</span> <span class="c">{html.escape(cmd)}</span>\n'
        if out: body += f'<span class="o">{html.escape(out)}</span>\n'
    body += f'<span class="p">{html.escape(prompt)}</span> <span style="background:#1f2328">&nbsp;</span>'
    doc = f"<style>{TERM_CSS}</style><div class='win'><div class='tb'><span class='tab'>{html.escape(title)}</span><span class='dots'>— ☐ ✕</span></div><pre>{body}</pre></div>"
    return _shot(doc, out_png, width)

CONSOLE_CSS = """
body{margin:0;background:#e9eef3;font-family:Segoe UI,Arial,sans-serif}
.win{margin:16px;border-radius:8px;overflow:hidden;box-shadow:0 6px 24px rgba(0,0,0,.18);background:#fff;border:1px solid #c9d1da}
.tb{background:#f1f3f4;border-bottom:1px solid #dadce0;height:32px;display:flex;align-items:center;padding:0 10px;font-size:12px;color:#5f6368;gap:14px}
.tb b{color:#202124;border-bottom:2px solid #1a73e8;padding:8px 2px}
.row{display:flex;gap:8px;padding:3px 10px;border-bottom:1px solid #f0f0f0;font:13.5px/1.4 Consolas,Menlo,monospace;color:#202124}
.row.input{color:#202124}.row.input .g{color:#1a73e8}
.row.result .g{color:#8a8a8a}.row.result{color:#1c1c1c}
.row.error{background:#fff0f0;color:#d93025}.row.error .g{color:#d93025}
.row.log .g{color:#bbb}
.g{width:14px;flex:none}.t{white-space:pre-wrap;word-break:break-word}
"""

def render_console(entries, out_png, width=820):
    """entries: list of (kind, text) with kind in input|result|error|log|warning."""
    glyph = {"input": "›", "result": "‹", "error": "⊗", "log": " ", "warning": "⚠"}
    rows = "".join(f'<div class="row {k}"><span class="g">{glyph.get(k," ")}</span><span class="t">{html.escape(t)}</span></div>' for k, t in entries)
    doc = f"<style>{CONSOLE_CSS}</style><div class='win'><div class='tb'><span>Elements</span><b>Console</b><span>Sources</span><span>Network</span></div>{rows}<div class='row input'><span class='g'>›</span><span class='t'>&nbsp;</span></div></div>"
    return _shot(doc, out_png, width)

def render_svg(svg_text, out_png, width=900, scale=2):
    doc = f"<style>body{{margin:0;background:#fff}} svg{{display:block}}</style>{svg_text}"
    return _shot(doc, out_png, width, scale=scale)

def browser_frame(html_path, out_png, url_text, width=1000, height=640, actions=None, scale=2):
    """Real page inside a drawn browser chrome. Uses an iframe so the page is a real render."""
    page = _b().new_page(viewport={"width": width, "height": height}, device_scale_factor=scale)
    src = "file://" + os.path.abspath(html_path)
    doc = f"""<style>body{{margin:0;background:#e9eef3;font-family:Segoe UI,Arial,sans-serif}}
    .win{{margin:16px;border-radius:8px;overflow:hidden;box-shadow:0 6px 24px rgba(0,0,0,.18);background:#fff;border:1px solid #c9d1da;height:{height-32}px;display:flex;flex-direction:column}}
    .tb{{background:#dfe3e8;height:38px;display:flex;align-items:center;padding:0 10px;gap:8px;font-size:13px}}
    .tab{{background:#fff;padding:6px 14px;border-radius:8px 8px 0 0;margin-top:10px;font-size:12px;color:#333}}
    .ab{{background:#fff;height:36px;display:flex;align-items:center;padding:0 10px;gap:10px;border-bottom:1px solid #d5d9de;font-size:13px;color:#333}}
    .url{{flex:1;background:#f1f3f4;border-radius:14px;padding:5px 12px;font-size:13px;color:#202124}}
    .url b{{color:#1a73e8;font-weight:600}}
    iframe{{border:0;flex:1;width:100%}}</style>
    <div class='win'><div class='tb'><span class='tab'>{html.escape(url_text.split('/')[-1] or 'index.html')}</span></div>
    <div class='ab'><span>‹ › ⟳</span><span class='url'>{html.escape(url_text)}</span></div>
    <iframe src='{src}'></iframe></div>"""
    page.set_content(doc)
    page.wait_for_timeout(300)
    fr = page.frames[1] if len(page.frames) > 1 else None
    for kind, arg in (actions or []):
        if fr is None: break
        if kind == "click": fr.click(arg)
        elif kind == "fill": fr.fill(arg[0], arg[1])
        elif kind == "check": fr.check(arg)
        elif kind == "press": page.keyboard.press(arg)
        elif kind == "wait": page.wait_for_timeout(arg)
        page.wait_for_timeout(80)
    page.screenshot(path=out_png)
    page.close()
    return out_png
