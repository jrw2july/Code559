"""Module 13 images: Capstone. Regenerate with: python3 /home/claude/build/mods/m13.py"""
import sys, os, shutil, tempfile, json
sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I

O = k.OUT
D = "/home/claude/build/demo/m13"
P = f"{D}/planner/index.html"
LOG = {}

add = lambda t: [("fill", ("#task-input", t)), ("press", "Enter")]
three = add("Read chapter 4") + add("Practice Flexbox for 20 minutes") + add("Push today's work") + [("click", "#task-list li:first-child input")]

# ---------- real renders of the planner ----------
k.render_page(P, f"{O}/m13-planner-390.png", width=390, height=640, full_page=False, actions=three)
k.render_page(P, f"{O}/m13-planner-1200.png", width=1200, height=520, full_page=False, actions=three)
k.render_page(P, f"{O}/m13-planner-empty.png", width=390, height=470, full_page=False,
              actions=[("fill", ("#task-input", "   ")), ("click", "button[type=submit]")])
# keyboard: Tab from top -> input, button, first checkbox; Space checks it
k.render_page(P, f"{O}/m13-planner-focus.png", width=390, height=640, full_page=False,
              actions=add("Read chapter 4") + add("Practice Flexbox for 20 minutes") +
                      [("press", "Tab"), ("press", "Tab"), ("press", "Space")])

# measured facts for the post (recorded, not drawn)
def probe(width, actions, js):
    page = k._b().new_page(viewport={"width": width, "height": 700})
    page.goto("file://" + P); page.wait_for_timeout(120)
    for kind, arg in actions:
        if kind == "fill": page.fill(*arg)
        elif kind == "press": page.keyboard.press(arg)
        elif kind == "click": page.click(arg)
        elif kind == "eval": page.evaluate(arg)
        page.wait_for_timeout(40)
    r = page.evaluate(js); page.close(); return r
cols = "getComputedStyle(document.querySelector('.layout')).gridTemplateColumns"
LOG["columns"] = {w: probe(w, [], cols) for w in (390, 699, 700, 1200)}
LOG["after_three"] = probe(390, three, "({summary: document.querySelector('#summary').textContent, items: document.querySelectorAll('#task-list li').length, done: document.querySelector('#task-list li').className})")
LOG["empty"] = probe(390, [("fill", ("#task-input", "   ")), ("click", "button[type=submit]")], "({msg: document.querySelector('#form-message').textContent, items: document.querySelectorAll('#task-list li').length})")
LOG["load"] = probe(390, [], "document.querySelector('#summary').textContent")
LOG["focus_after_tab2_space"] = probe(390, add("Read chapter 4") + add("Practice Flexbox for 20 minutes") + [("press", "Tab"), ("press", "Tab"), ("press", "Space")],
    "({active: document.activeElement.type, checked: document.activeElement.checked, summary: document.querySelector('#summary').textContent})")

# ---------- exercise: row 1 works, and the break-it version ----------
def ex(path, clicks):
    page = k._b().new_page(); errs = []
    page.on("pageerror", lambda e: errs.append(str(e)))
    page.goto("file://" + path); page.wait_for_timeout(100)
    before = page.text_content("#count")
    for _ in range(clicks): page.click("#add-button"); page.wait_for_timeout(30)
    after = page.text_content("#count"); page.close()
    return {"on_load": before, "after_clicks": after, "errors": errs}
LOG["exercise_ok"] = ex(f"{D}/exercise/index.html", 3)
LOG["exercise_broken"] = ex(f"{D}/exercise-broken/index.html", 3)

# ---------- contrast check, real Node run ----------
out = k.run("node contrast.js", cwd=D)
LOG["contrast"] = out
k.render_terminal([("node contrast.js", out)], f"{O}/m13-contrast.png",
                  prompt="PS C:\\Users\\you\\Documents\\code559\\m13-practice>", width=760)

# ---------- git: commit row 1 of the exercise, real, throwaway HOME ----------
home = tempfile.mkdtemp(); env = {"HOME": home, "XDG_CONFIG_HOME": home}
repo = os.path.join(home, "goal-counter"); shutil.copytree(f"{D}/exercise", repo)
g = lambda c: k.run(c, cwd=repo, env=env)
g("git config --global init.defaultBranch main"); g('git config --global user.name "Your Name"'); g('git config --global user.email "you@example.com"')
blocks = [("git init", g("git init")), ("git status --short", None), ("git add .", None), ('git commit -m "Row 1: +1 button raises the count"', None), ("git log --oneline", None)]
blocks[1] = ("git status --short", g("git status --short"))
blocks[2] = ("git add .", g("git add ."))
blocks[3] = (blocks[3][0], g(blocks[3][0]))
blocks[4] = ("git log --oneline", g("git log --oneline"))
# hide the throwaway path in the init line
blocks[0] = ("git init", blocks[0][1].replace(repo, "C:/Users/you/Documents/code559/goal-counter"))
LOG["git"] = blocks
k.render_terminal(blocks, f"{O}/m13-git-row1.png", prompt="PS C:\\Users\\you\\Documents\\code559\\goal-counter>")

# ---------- illustrations ----------
def nine_steps(w=900, h=330):
    steps = [("1 Predict", "say what will happen"), ("2 Run", "do it once"), ("3 Explain", "say why, line by line"),
             ("4 Modify", "change one thing"), ("5 Debug", "find and fix the gap"), ("6 Retest", "same test again"),
             ("7 Commit", "one change, clear message"), ("8 Push", "send it to GitHub"), ("9 Verify live", "check the real site")]
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    s += f"<text x='{w/2}' y='28' {I.F} font-size='15' font-weight='bold' text-anchor='middle' fill='#1b2b44'>The Code559 completion standard: a feature is done after all nine</text>"
    bw, bh, gx, gy, x0, y0 = 260, 70, 30, 22, 30, 48
    fills = ["#dbe8ff", "#fde2e2", "#e2f6e2"]; strokes = ["#7aa7e8", "#e08a8a", "#7bbf7b"]
    for i, (a, b) in enumerate(steps):
        r, c = divmod(i, 3); x = x0 + c * (bw + gx); y = y0 + r * (bh + gy)
        s += f"<rect x='{x}' y='{y}' width='{bw}' height='{bh}' rx='8' fill='{fills[r]}' stroke='{strokes[r]}'/>"
        s += f"<text x='{x+bw/2}' y='{y+30}' {I.F} font-size='15' font-weight='bold' text-anchor='middle' fill='#1b2b44'>{I.esc(a)}</text>"
        s += f"<text x='{x+bw/2}' y='{y+52}' {I.F} font-size='12' text-anchor='middle' fill='#37474f'>{I.esc(b)}</text>"
        if c < 2: s += f"<text x='{x+bw+gx/2}' y='{y+bh/2+6}' {I.F} font-size='18' text-anchor='middle' fill='#4a6fa5'>&#8594;</text>"
    for r, lab in enumerate(["understand it", "make it right", "ship it"]):
        pass
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(nine_steps(), f"{O}/m13-nine-steps.png", 900)

def req_to_tasks(w=900, h=300):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    s += f"<defs><marker id='ar' viewBox='0 0 10 10' refX='8' refY='5' markerWidth='7' markerHeight='7' orient='auto'><path d='M0 0L10 5L0 10z' fill='#4a6fa5'/></marker></defs>"
    s += f"<rect x='20' y='30' width='270' height='230' rx='8' fill='#f6f8fa' stroke='#d0d7de'/>"
    s += f"<text x='36' y='56' {I.F} font-size='13' font-weight='bold' fill='#1b2b44'>Requirement row 2</text>"
    for j, ln in enumerate(["An empty or spaces-only task", "is not added. A message", "says why.", "", "Done when: the list does not", "change and the message", "appears under the form."]):
        s += f"<text x='36' y='{84+j*20}' {I.F} font-size='12.5' fill='#24292f'>{I.esc(ln)}</text>"
    rows = [("Structure (HTML)", "a <p> under the form for the message,|with role=\"status\"", "#fde2e2", "#e08a8a"),
            ("Look (CSS)", "message color passes contrast;|space kept so the form does not jump", "#e0f0ff", "#7aa7e8"),
            ("Behavior (JS)", "trim the value; if it is \"\", show|the message and stop (return)", "#e2f6e2", "#7bbf7b"),
            ("Test row", "submit \"   \" → list unchanged,|message shown", "#fff3cd", "#e0c36a")]
    for i, (a, b, f, st) in enumerate(rows):
        y = 22 + i * 64
        s += f"<line x1='292' y1='145' x2='372' y2='{y+28}' stroke='#4a6fa5' stroke-width='1.6' marker-end='url(#ar)'/>"
        s += f"<rect x='380' y='{y}' width='{w-400}' height='56' rx='8' fill='{f}' stroke='{st}'/>"
        s += f"<text x='396' y='{y+22}' {I.F} font-size='13.5' font-weight='bold' fill='#1b2b44'>{I.esc(a)}</text>"
        for j, ln in enumerate(b.split("|")):
            s += f"<text x='560' y='{y+22+j*18}' {I.M} font-size='12' fill='#24292f'>{I.esc(ln)}</text>"
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(req_to_tasks(), f"{O}/m13-req-to-tasks.png", 900)

k.close()
with open("/tmp/claude-0/-home-claude/e333ed89-abd5-5ce0-9f36-c634f9ea9b6d/scratchpad/m13-log.json", "w") as f: json.dump(LOG, f, indent=1)
print(json.dumps(LOG, indent=1))
