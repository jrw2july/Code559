"""Module 8 (Arrays, Loops, Objects) image build. Console images: real Chromium evaluation via
CDP Runtime.evaluate(replMode) in m78kit. Terminal images: real `node` runs. SVGs: illustrations."""
import sys, os, shutil; sys.path.insert(0, "/home/claude/build"); sys.path.insert(0, "/home/claude/build/mods")
import imgkit as k, illus as I, m78kit as M
O = k.OUT; D = "/home/claude/build/demo/m08"; P = f"{D}/m08-practice"
PROMPT = "PS C:\\Users\\you\\Documents\\code559\\m08-practice>"
F, MONO, esc = I.F, I.M, I.esc
PAGES = 'const pages = ["Home", "About", "Interests", "Projects"];'

# 1. Index diagram (illustration)
def indexes(w=900, h=250):
    items = ["Home", "About", "Interests", "Projects"]
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    s += f"<text x='30' y='32' {MONO} font-size='14' fill='#1f2328'>{esc(PAGES)}</text>"
    bw = 150
    for i, it in enumerate(items):
        x = 60 + i * (bw + 10)
        s += f"<rect x='{x}' y='60' width='{bw}' height='60' rx='6' fill='#dbe8ff' stroke='#7aa7e8'/>"
        s += f"<text x='{x+bw/2}' y='96' {MONO} font-size='15' text-anchor='middle' fill='#1b2b44'>\"{esc(it)}\"</text>"
        s += f"<text x='{x+bw/2}' y='145' {F} font-size='13' text-anchor='middle' fill='#37474f'>index {i}</text>"
        s += f"<text x='{x+bw/2}' y='165' {MONO} font-size='12.5' text-anchor='middle' fill='#0b57d0'>pages[{i}]</text>"
    x4 = 60 + 4 * (bw + 10)
    s += f"<rect x='{x4}' y='60' width='70' height='60' rx='6' fill='#fff' stroke='#c0c0c0' stroke-dasharray='5 4'/>"
    s += f"<text x='{x4+35}' y='145' {F} font-size='13' text-anchor='middle' fill='#9a9a9a'>index 4</text>"
    s += f"<text x='{x4+35}' y='165' {F} font-size='12' text-anchor='middle' fill='#9a9a9a'>nothing here</text>"
    s += f"<text x='60' y='205' {F} font-size='14' fill='#263238'>Counting starts at 0. pages.length is 4, so the last index is pages.length - 1, which is 3.</text>"
    s += f"<text x='60' y='227' {F} font-size='14' fill='#263238'>pages[4] reads past the end and gives undefined.</text>"
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(indexes(), f"{O}/m08-indexes.png", 900)

# 2. Array basics + push (real console)
k.render_console(M.console([PAGES, "pages[0]", "pages[3]", "pages.length", "pages[pages.length - 1]", "pages[4]", 'pages.push("Contact")', "pages"]), f"{O}/m08-array-basics.png")

# 3. Loop anatomy (illustration)
def loop_anatomy(w=900, h=272):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    s += f"<rect x='24' y='20' width='{w-48}' height='90' rx='8' fill='#f6f8fa' stroke='#d0d7de'/>"
    code = ["for (let i = 0; i < pages.length; i++) {", "  console.log(i + \": \" + pages[i]);", "}"]
    for j, ln in enumerate(code):
        s += f"<text x='44' y='{50+j*24}' {MONO} font-size='16' fill='#1f2328' xml:space='preserve'>{esc(ln)}</text>"
    parts = [("let i = 0", "1. Start", "runs once, before|the first lap", "#e2f6e2", "#7bbf7b"),
             ("i < pages.length", "2. Check", "before every lap:|true → run the body|false → stop", "#dbe8ff", "#7aa7e8"),
             ("{ … }", "3. Body", "the work for this lap;|pages[i] is this item", "#fff3cd", "#e0c36a"),
             ("i++", "4. Step", "after every lap:|add 1 to i,|then back to Check", "#fde2e2", "#e08a8a")]
    bw = (w - 48 - 30) / 4
    for j, (c, a, b, f, st) in enumerate(parts):
        x = 24 + j * (bw + 10)
        s += f"<rect x='{x}' y='124' width='{bw}' height='112' rx='8' fill='{f}' stroke='{st}'/>"
        s += f"<text x='{x+bw/2}' y='146' {F} font-size='14' font-weight='bold' text-anchor='middle' fill='#1b2b44'>{esc(a)}</text>"
        s += f"<text x='{x+bw/2}' y='166' {MONO} font-size='12.5' text-anchor='middle' fill='#0b57d0'>{esc(c)}</text>"
        for q, ln in enumerate(b.split("|")):
            s += f"<text x='{x+bw/2}' y='{188+q*16}' {F} font-size='12' text-anchor='middle' fill='#37474f'>{esc(ln)}</text>"
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(loop_anatomy(), f"{O}/m08-loop-anatomy.png", 900)

# 4. for loop + ++ (real console)
loop = "for (let i = 0; i < pages.length; i++) {\n  console.log(i + \": \" + pages[i]);\n}"
k.render_console(M.console([PAGES, loop, "let count = 0;", "count++", "count"]), f"{O}/m08-for-loop.png")

# 5. Conditions inside loops + for...of (real console)
mins = "const minutes = [30, 0, 45, 20, 0];"
cond = "let restDays = 0;\nfor (let i = 0; i < minutes.length; i++) {\n  if (minutes[i] === 0) {\n    restDays++;\n  }\n}"
forof = "for (const amount of minutes) {\n  console.log(amount + \" min\");\n}"
k.render_console(M.console([mins, cond, "restDays", forof]), f"{O}/m08-loop-if-forof.png")

# 6. includes + join (real console)
ints = 'const interests = ["drawing", "cycling", "music"];'
k.render_console(M.console([ints, 'interests.includes("music")', 'interests.includes("Music")', '"front-end developer".includes("end")', 'interests.join(", ")', "interests.join()"]), f"{O}/m08-includes-join.png")

# 7. Properties vs methods (real console)
k.render_console(M.console(['const tags = ["html", "css"];', "tags.length", 'tags.push("js")', "tags.length", "tags.length()", '"  hello  ".length', '"  hello  ".trim()', '"  hello  ".trim().length', '"hello".trim']), f"{O}/m08-props-methods.png")

# 8. Parallel arrays vs array of objects (illustration)
def parallel(w=900, h=290):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    s += f"<text x='24' y='30' {F} font-size='15' font-weight='bold' fill='#1b2b44'>Parallel arrays: related only by position</text>"
    left = ['const titles = ["Feedback card", "FAQ card"];', 'const years  = [2026, 2026];', 'const live   = [true, false];']
    for j, ln in enumerate(left):
        s += f"<text x='24' y='{62+j*22}' {MONO} font-size='13.5' fill='#1f2328' xml:space='preserve'>{esc(ln)}</text>"
    s += f"<text x='24' y='140' {F} font-size='13' fill='#8a1c1c'>Delete a title but forget to delete its year, and every title after it now pairs with the wrong year.</text>"
    s += f"<text x='24' y='180' {F} font-size='15' font-weight='bold' fill='#1b2b44'>Array of objects: each item carries its own facts</text>"
    right = ['const projects = [', '  { title: "Feedback card", year: 2026, live: true },', '  { title: "FAQ card", year: 2026, live: false }', '];']
    for j, ln in enumerate(right):
        s += f"<text x='24' y='{208+j*20}' {MONO} font-size='13.5' fill='#1f2328' xml:space='preserve'>{esc(ln)}</text>"
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(parallel(), f"{O}/m08-parallel-vs-objects.png", 900)

# 9. Objects and arrays of objects (real console)
obj = 'const project = { title: "Feedback card", year: 2026, live: true, tags: ["html", "css"] };'
arr = 'const projects = [\n  { title: "Feedback card", year: 2026, live: true },\n  { title: "FAQ card", year: 2026, live: false }\n];'
lp = 'for (const p of projects) {\n  console.log(p.title + " (" + p.year + ")");\n}'
k.render_console(M.console([obj, "project.title", "project.tags.length", "project.status", arr, "projects[1].title", lp]), f"{O}/m08-objects.png")

# 10. Logical operators (real console)
k.render_console(M.console(["[true && true, true && false, false && true, false && false]",
                            "[true || true, true || false, false || true, false || false]",
                            "[!true, !false]",
                            "const live = true;", "const year = 2025;",
                            "live && year === 2026", "live || year === 2026", "!live"]), f"{O}/m08-logic.png")

# 11. Break-it (real terminal)
B = f"{D}/m08-break"; shutil.rmtree(B, ignore_errors=True); shutil.copytree(P, B)
src = open(f"{B}/practice.js").read().replace("i < interests.length", "i <= interests.length")
open(f"{B}/practice.js", "w").write(src)
k.render_terminal([("node practice.js", k.run("node practice.js", cwd=B))], f"{O}/m08-break-it.png", prompt=PROMPT)
k.close()
