"""Module 5 images: JavaScript Primer. Run: python3 /home/claude/build/mods/m05.py"""
import sys, os, json, html as H
sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I
O = k.OUT
D = "/home/claude/build/demo/m05/js-practice"
os.makedirs(D, exist_ok=True)
P = "PS C:\\Users\\you\\Documents\\code559\\js-practice>"
log = {}

def write(name, text):
    with open(os.path.join(D, name), "w") as f: f.write(text)

# ---- 1. the three layers (illustration)
k.render_svg(I.layers(), f"{O}/m05-layers.png", 900)

# ---- 2. hello.js run with node (real)
HELLO = '''// hello.js: my first script
console.log("Hello, world!");
console.log("This line runs second.");
console.log(2 + 3); // a number, not text
'''
write("hello.js", HELLO)
out = k.run("node hello.js", cwd=D); log["hello"] = out
k.render_terminal([("node hello.js", out)], f"{O}/m05-node-hello.png", prompt=P)

# modify step: add a line
write("hello.js", HELLO + 'console.log("I added this line.");\n')
out = k.run("node hello.js", cwd=D); log["hello_mod"] = out
k.render_terminal([("node hello.js", out)], f"{O}/m05-node-hello-modified.png", prompt=P)

# ---- 3. break it: misspell console (real)
write("hello.js", HELLO.replace('console.log("Hello, world!")', 'consol.log("Hello, world!")'))
ref = k.run("node hello.js", cwd=D); log["ref_error"] = ref
k.render_terminal([("node hello.js", ref)], f"{O}/m05-node-reference-error.png", prompt=P, width=900)

# ---- 4. break it: drop a quote (real)
write("hello.js", HELLO.replace('console.log("This line runs second.")', 'console.log("This line runs second.)'))
syn = k.run("node hello.js", cwd=D); log["syn_error"] = syn
k.render_terminal([("node hello.js", syn)], f"{O}/m05-node-syntax-error.png", prompt=P, width=900)
write("hello.js", HELLO)  # restore

# ---- 5. Console: typing expressions (real Chromium evaluation)
entries = k.browser_eval("<p>blank page</p>", ['2 + 3', '"Hello, " + "world"', '60 * 24', 'console.log("Hello from the Console")'])
log["console_basic"] = entries
k.render_console(entries, f"{O}/m05-console-expressions.png")

# ---- 6. Console error (real Chromium evaluation)
entries = k.browser_eval("<p>blank page</p>", ['consol.log("hi")', 'console.log("hi)'])
log["console_errors"] = entries
k.render_console(entries, f"{O}/m05-console-error.png")

# ---- 7. error anatomy (illustration built from the real ReferenceError text)
lines = ref.splitlines()[:6]
W, Hh = 900, 300
F, M = I.F, I.M
s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{W}' height='{Hh}' viewBox='0 0 {W} {Hh}'><rect width='{W}' height='{Hh}' fill='#fff'/>"
s += f"<text x='{W/2}' y='28' {F} font-size='15' font-weight='bold' text-anchor='middle' fill='#1b2b44'>Reading a Node error from the top</text>"
s += f"<rect x='20' y='44' width='470' height='{24*len(lines)+16}' rx='8' fill='#f6f8fa' stroke='#d0d7de'/>"
folder = os.path.dirname(lines[0].split(":")[0])
for i, ln in enumerate(lines):
    shown = ln.replace(folder + "/", ".../") if i == 5 else ln  # shorten the long path only in the stack line
    s += f"<text x='34' y='{68+i*24}' {M} font-size='13' fill='#1f2328' xml:space='preserve'>{I.esc(shown)}</text>"
notes = [(0, 0, "1  Where: file name and line number"),
         (1, 0, "2  The line Node was running"),
         (2, 0, "3  The caret points at the spot"),
         (4, -8, "4  Name (before the colon): the kind of error"),
         (4, 10, "    Message (after it): what went wrong"),
         (5, 18, "5  file:line:column, inside the stack")]
cols = {0: "#0b57d0", 1: "#37474f", 2: "#37474f", 4: "#c5221f", 5: "#0b57d0"}
for row, dy, text in notes:
    col = cols[row]; y = 68 + row * 24 + dy
    s += f"<line x1='494' y1='{63+row*24}' x2='514' y2='{y-4}' stroke='{col}' stroke-width='1.5'/>"
    s += f"<text x='520' y='{y}' {F} font-size='12.5' fill='{col}'>{I.esc(text)}</text>"
s += f"<text x='34' y='{Hh-44}' {F} font-size='12.5' fill='#444'>Read the top of the message first. The other \"at ...\" lines are Node's own files; you can usually skip them.</text>"
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m05-error-anatomy.png", 900)

# ---- 8. where JavaScript runs (illustration)
W, Hh = 900, 250
s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{W}' height='{Hh}' viewBox='0 0 {W} {Hh}'><rect width='{W}' height='{Hh}' fill='#fff'/>"
s += "<defs><marker id='ar' viewBox='0 0 10 10' refX='8' refY='5' markerWidth='7' markerHeight='7' orient='auto'><path d='M0 0L10 5L0 10z' fill='#4a6fa5'/></marker></defs>"
s += f"<text x='{W/2}' y='28' {I.F} font-size='15' font-weight='bold' text-anchor='middle' fill='#1b2b44'>Same language, two places to run it</text>"
def box(x, y, w, h, a, b, fill):
    out = f"<rect x='{x}' y='{y}' width='{w}' height='{h}' rx='8' fill='{fill}' stroke='#7aa7e8'/>"
    out += f"<text x='{x+w/2}' y='{y+26}' {I.F} font-size='14' font-weight='bold' text-anchor='middle' fill='#1b2b44'>{a}</text>"
    for j, ln in enumerate(b.split('|')):
        out += f"<text x='{x+w/2}' y='{y+46+j*17}' {I.F} font-size='12' text-anchor='middle' fill='#37474f'>{I.esc(ln)}</text>"
    return out
s += box(40, 90, 240, 84, "Your JavaScript", "typed in a .js file|or straight into the Console", "#fff8e1")
s += box(520, 48, 340, 76, "In the browser (Edge or Chrome)", "runs inside a web page|try it in the DevTools Console", "#dbe8ff")
s += box(520, 140, 340, 76, "In Node (the terminal)", "runs with no web page at all|node hello.js", "#e2f6e2")
s += "<line x1='284' y1='122' x2='512' y2='88' stroke='#4a6fa5' stroke-width='2' marker-end='url(#ar)'/>"
s += "<line x1='284' y1='142' x2='512' y2='176' stroke='#4a6fa5' stroke-width='2' marker-end='url(#ar)'/>"
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m05-where-js-runs.png", 900)

# ---- 9. DevTools docked with Console (illustration)
W, Hh = 900, 420
s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{W}' height='{Hh}' viewBox='0 0 {W} {Hh}'><rect width='{W}' height='{Hh}' rx='8' fill='#fff' stroke='#c9d1da'/>"
s += f"<rect width='{W}' height='40' rx='8' fill='#dfe3e8'/><rect y='32' width='{W}' height='8' fill='#dfe3e8'/>"
s += f"<rect x='12' y='10' width='160' height='30' rx='6' fill='#fff'/><text x='24' y='30' {F} font-size='12' fill='#333'>New tab</text>"
s += f"<rect y='40' width='{W}' height='36' fill='#fff' stroke='#d5d9de'/><rect x='70' y='47' width='{W-90}' height='22' rx='11' fill='#f1f3f4'/>"
s += f"<text x='16' y='63' {F} font-size='13' fill='#555'>&#8249; &#8250; &#10227;</text>"
s += f"<text x='{W/2}' y='150' {F} font-size='14' text-anchor='middle' fill='#888'>(the web page area)</text>"
s += f"<rect y='200' width='{W}' height='{Hh-200}' fill='#fff' stroke='#c9d1da'/>"
s += f"<rect y='200' width='{W}' height='30' fill='#f1f3f4'/>"
x = 14
for t in ["Elements", "Console", "Sources", "Network"]:
    bold = t == "Console"
    s += f"<text x='{x}' y='220' {F} font-size='12.5' fill='{'#202124' if bold else '#5f6368'}' font-weight='{'bold' if bold else 'normal'}'>{t}</text>"
    if bold: s += f"<rect x='{x}' y='226' width='52' height='3' fill='#1a73e8'/>"
    x += len(t) * 8 + 22
s += f"<text x='18' y='262' {M} font-size='14' fill='#1a73e8'>&#8250;</text><rect x='34' y='249' width='2' height='17' fill='#202124'/>"
s += f"<text x='60' y='262' {F} font-size='12.5' fill='#5f6368'>&#8592; click here and type an expression, then press Enter</text>"
s += f"<rect x='{W-330}' y='96' width='300' height='76' rx='8' fill='#fff8e1' stroke='#e0c36a'/>"
s += f"<text x='{W-316}' y='120' {F} font-size='13' font-weight='bold' fill='#5d4300'>Open it (Edge or Chrome on Windows)</text>"
s += f"<text x='{W-316}' y='142' {F} font-size='12.5' fill='#5d4300'>Ctrl + Shift + J: straight to Console</text>"
s += f"<text x='{W-316}' y='162' {F} font-size='12.5' fill='#5d4300'>F12: DevTools, last panel you used</text>"
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m05-devtools-console.png", 900)

# ---- 10. the habit (illustration)
k.render_svg(I.flow([("Predict", "say what will|happen"), ("Run", "run it and|compare"), ("Modify", "change one|thing"), ("Create", "write your|own line"), ("Debug", "break it, read|the message")],
                    h=160, title="The habit for every piece of code"), f"{O}/m05-habit.png", 900)

k.close()
print(json.dumps(log, indent=1))
