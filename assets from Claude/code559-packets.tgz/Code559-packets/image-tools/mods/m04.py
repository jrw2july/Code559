"""Module 4 (Forms and Accessibility) images. Run: python3 /home/claude/build/mods/m04.py
Real Chromium renders, real form submissions (served over local HTTP), real Console values.
Illustrations are tagged."""
import sys, os, json, html, threading, functools, http.server, socketserver
sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I
from PIL import Image, ImageDraw, ImageFont, ImageOps

O = k.OUT
D = "/home/claude/build/demo/m04"
FL = f"{D}/form-lab"
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
results = {}

class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
socketserver.TCPServer.allow_reuse_address = True
try:
    srv = socketserver.TCPServer(("127.0.0.1", 3000), functools.partial(Q, directory=D))
except OSError:
    srv = socketserver.TCPServer(("127.0.0.1", 0), functools.partial(Q, directory=D))
PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{PORT}"
b = k._b()

def new(width=800, height=600, dpr=2):
    ctx = b.new_context(viewport={"width": width, "height": height}, device_scale_factor=dpr)
    return ctx, ctx.new_page()

def frame_with_url(url, out, width=900, height=520):
    """Draw browser chrome around a real page; the address text is the real URL Chromium reported."""
    doc = f"""<style>body{{margin:0;background:#e9eef3;font-family:Segoe UI,Arial,sans-serif}}
    .win{{margin:16px;border-radius:8px;overflow:hidden;box-shadow:0 6px 24px rgba(0,0,0,.18);background:#fff;border:1px solid #c9d1da;height:{height-32}px;display:flex;flex-direction:column}}
    .ab{{background:#fff;height:40px;display:flex;align-items:center;padding:0 10px;gap:10px;border-bottom:1px solid #d5d9de;font-size:14px;color:#333}}
    .url{{flex:1;background:#f1f3f4;border-radius:14px;padding:6px 12px;font-size:14px;color:#202124;white-space:nowrap;overflow:hidden}}
    .url b{{color:#b23c17}} iframe{{border:0;flex:1;width:100%}}</style>"""
    path, _, query = url.partition("?")
    doc += f"<div class='win'><div class='ab'><span>&#8249; &#8250; &#10227;</span><span class='url'>{html.escape(path)}<b>?{html.escape(query)}</b></span></div><iframe src='{html.escape(url)}'></iframe></div>"
    ctx, pg = new(width, height)
    pg.set_content(doc); pg.wait_for_timeout(500); pg.screenshot(path=out); ctx.close()

# ---------- 1. contact form at 390 ----------
ctx, pg = new(390, 700)
pg.goto(f"{BASE}/form-lab/contact.html"); pg.wait_for_timeout(200)
pg.screenshot(path=f"{O}/m04-contact-390.png", full_page=True)
# submit it for real
pg.fill("#visitor-name", "Sam"); pg.fill("#visitor-email", "sam@example.com"); pg.fill("#nickname", "Ace"); pg.fill("#message", "Hello there")
with pg.expect_navigation(): pg.click("button[type=submit]")
results["contact_url"] = pg.url; ctx.close()
frame_with_url(results["contact_url"], f"{O}/m04-contact-url.png", width=1000, height=420)

# ---------- 2. radio group: submit 3-5 ----------
ctx, pg = new(800, 300)
pg.goto(f"{BASE}/form-lab/radio-practice.html"); pg.click("label[for=hours-mid]")
# (no screenshot here; the keyboard image shows the group)
with pg.expect_navigation(): pg.click("button[type=submit]")
results["radio_url"] = pg.url; ctx.close()
frame_with_url(results["radio_url"], f"{O}/m04-radio-url.png", width=900, height=300)

# also: does a file:// page do the same? (what a learner sees if they double-click the file)
ctx, pg = new(800, 300)
pg.goto(f"file://{FL}/radio-practice.html"); pg.click("label[for=hours-mid]")
with pg.expect_navigation(): pg.click("button[type=submit]")
results["radio_url_file"] = pg.url; ctx.close()

# ---------- 3. required on one radio applies to the group (Console) ----------
src = open(f"{FL}/radio-practice.html").read()
entries = k.browser_eval(src, [
    "document.querySelector('form').checkValidity()",
    "document.querySelector('#hours-high').hasAttribute('required')",
    "document.querySelector('#hours-high').validity.valueMissing",
    "document.querySelector('#hours-low').validationMessage",
    "document.querySelector('#hours-high').click()",
    "document.querySelector('form').checkValidity()",
])
results["required_console"] = entries
k.render_console(entries, f"{O}/m04-required-console.png", width=860)

# submit attempt with nothing selected: does the page navigate?
ctx, pg = new(800, 300)
pg.goto(f"{BASE}/form-lab/radio-practice.html"); before = pg.url
pg.click("button[type=submit]"); pg.wait_for_timeout(600)
results["empty_submit"] = {"before": before, "after": pg.url, "active": pg.evaluate("document.activeElement.id")}
ctx.close()

# ---------- 4. keyboard: Tab vs arrow keys ----------
ctx, pg = new(800, 200)
pg.goto(f"{BASE}/form-lab/radio-practice.html"); pg.wait_for_timeout(200)
state = "() => ({focused: document.activeElement.id || document.activeElement.tagName, checked: (document.querySelector('input:checked')||{}).value || null})"
seq, shots = [], []
for i, key in enumerate(["Tab", "ArrowRight", "ArrowRight", "Tab"]):
    pg.keyboard.press(key); pg.wait_for_timeout(120)
    st = pg.evaluate(state); seq.append({"key": key, **st})
    p = f"/tmp/m04-key-{i}.png"; pg.screenshot(path=p, clip={"x": 0, "y": 0, "width": 640, "height": 110}); shots.append((key, st, p))
results["keyboard"] = seq; ctx.close()
ims = [ImageOps.expand(Image.open(p), border=2, fill=(160, 170, 182)) for _, _, p in shots]
f = ImageFont.truetype(FONT, 22)
W = ims[0].width + 360; H = sum(i.height + 24 for i in ims) + 24
can = Image.new("RGB", (W, H), (233, 238, 243)); d = ImageDraw.Draw(can); y = 24
for (key, st, _), im in zip(shots, ims):
    can.paste(im, (24, y)); tx = im.width + 48
    d.text((tx, y + 40), f"pressed: {key}", font=f, fill=(29, 39, 51))
    d.text((tx, y + 80), f"focus: {st['focused']}", font=ImageFont.truetype(FONT, 18), fill=(70, 80, 95))
    d.text((tx, y + 110), f"checked: {st['checked'] or 'nothing yet'}", font=ImageFont.truetype(FONT, 18), fill=(70, 80, 95))
    y += im.height + 24
can.save(f"{O}/m04-keyboard.png")

# ---------- 5. break it: hourz ----------
broken = open(f"{FL}/radio-broken.html").read()
entries = k.browser_eval(broken, [
    "document.querySelector('label[for=hours-low]').click()",
    "document.querySelector('label[for=hours-mid]').click()",
    "document.querySelector('label[for=hours-high]').click()",
    "document.querySelectorAll('input:checked').length",
    "[...document.querySelectorAll('input:checked')].map(r => r.name + '=' + r.value)",
])
results["hourz_console"] = entries
ctx, pg = new(800, 200)
pg.goto(f"{BASE}/form-lab/radio-broken.html")
for l in ("hours-low", "hours-mid", "hours-high"): pg.click(f"label[for={l}]")
results["hourz_checked"] = pg.evaluate("[...document.querySelectorAll('input:checked')].map(r => r.id)")
pg.screenshot(path="/tmp/m04-hourz-page.png", clip={"x": 0, "y": 0, "width": 640, "height": 110})
ctx.close()
k.render_console(entries, "/tmp/m04-hourz-console.png", width=640)
a, c = Image.open("/tmp/m04-hourz-page.png"), Image.open("/tmp/m04-hourz-console.png")
can = Image.new("RGB", (max(a.width + 64, c.width), a.height + c.height + 40), (233, 238, 243))
can.paste(ImageOps.expand(a, border=2, fill=(160, 170, 182)), (32, 24)); can.paste(c, (0, a.height + 40))
can.save(f"{O}/m04-hourz-break.png")

# ---------- 6. skip link, aria-current, focus-visible, hidden ----------
ctx, pg = new(600, 300)
pg.goto(f"{BASE}/form-lab/a11y.html"); pg.wait_for_timeout(200)
order = []
for i in range(8):
    pg.keyboard.press("Tab"); pg.wait_for_timeout(60)
    order.append(pg.evaluate("document.activeElement === document.body ? 'BODY' : (document.activeElement.textContent.trim() || document.activeElement.tagName)"))
    if i == 0: pg.screenshot(path=f"{O}/m04-skip-link.png")
results["tab_order"] = order
results["hidden_section"] = pg.evaluate("() => { const s = document.querySelector('.later'); return {hidden: s.hidden, offsetHeight: s.offsetHeight, display: getComputedStyle(s).display}; }")
ctx.close()
ctx, pg = new(600, 300)
pg.goto(f"{BASE}/form-lab/a11y.html"); pg.keyboard.press("Tab"); pg.keyboard.press("Enter"); pg.wait_for_timeout(150)
results["skip_enter"] = {"url": pg.url, "active": pg.evaluate("document.activeElement.id || document.activeElement.tagName")}
pg.keyboard.press("Tab"); pg.wait_for_timeout(100)
results["after_skip_tab"] = pg.evaluate("document.activeElement.textContent.trim()")
ctx.close()
ctx, pg = new(600, 300)
pg.goto(f"{BASE}/form-lab/a11y.html"); pg.keyboard.press("Tab"); pg.keyboard.press("Tab"); pg.keyboard.press("Tab"); pg.wait_for_timeout(120)
pg.screenshot(path=f"{O}/m04-focus-visible.png", clip={"x": 0, "y": 0, "width": 600, "height": 200})
# mouse click on a link: does :focus-visible match?
pg.mouse.click(5, 290)
pg.click("text=Interests"); pg.wait_for_timeout(100)
results["focus_visible_after_mouse_click"] = pg.evaluate("document.activeElement.matches(':focus-visible')")
pg.keyboard.press("Tab"); pg.wait_for_timeout(100)
results["focus_visible_after_tab"] = pg.evaluate("[document.activeElement.textContent.trim(), document.activeElement.matches(':focus-visible')]")
ctx.close()

# ---------- 7. state selectors with visually-hidden radios ----------
ctx, pg = new(420, 200)
pg.goto(f"{BASE}/form-lab/states.html"); pg.wait_for_timeout(150)
pg.click("label[for=pick-2]")
pg.mouse.click(400, 190)  # click empty space so focus leaves
pg.keyboard.press("Tab"); pg.wait_for_timeout(100)   # Tab into the group lands on the checked radio
results["states_focus"] = pg.evaluate("[document.activeElement.id, document.activeElement.matches(':focus-visible'), document.activeElement.checked]")
pg.hover("label[for=pick-3]"); pg.wait_for_timeout(100)
pg.screenshot(path=f"{O}/m04-state-selectors.png")
results["states_value_still_sent"] = None
with pg.expect_navigation(): pg.click("button[type=submit]")
results["states_value_still_sent"] = pg.url
ctx.close()
# break: display:none instead of visually-hidden
ctx, pg = new(420, 200)
pg.goto(f"{BASE}/form-lab/states.html"); pg.add_style_tag(content=".choices input { display: none; }")
pg.mouse.click(400, 190); pg.keyboard.press("Tab"); pg.wait_for_timeout(100)
results["display_none_first_tab"] = pg.evaluate("document.activeElement.id || document.activeElement.tagName")
ctx.close()

# ---------- 8. rating card teaser (original design) ----------
RC = f"{BASE}/rating-card/index.html"
ctx, pg = new(390, 540)
pg.goto(RC); pg.wait_for_timeout(200); pg.click("label[for=rating-4]"); pg.mouse.click(5, 5)
pg.screenshot(path="/tmp/m04-card-a.png")
results["card_tab_order"] = []
pg.keyboard.press("Tab"); pg.wait_for_timeout(60)
results["card_tab_order"].append(pg.evaluate("document.activeElement.id || document.activeElement.tagName"))
pg.keyboard.press("Tab"); pg.wait_for_timeout(60)
results["card_tab_order"].append(pg.evaluate("document.activeElement.id || document.activeElement.tagName"))
pg.keyboard.press("Tab"); pg.wait_for_timeout(60)
results["card_tab_order"].append(pg.evaluate("document.activeElement === document.body ? 'BODY' : (document.activeElement.id || document.activeElement.tagName)"))
# show the thank-you state by editing the live page (the card's own JavaScript is Module 9)
pg.evaluate("""() => { document.querySelector('.rating-state').hidden = true;
  const t = document.querySelector('.thanks-state'); t.hidden = false;
  document.querySelector('#chosen-rating').textContent = '4'; }""")
pg.wait_for_timeout(100); pg.screenshot(path="/tmp/m04-card-b.png"); ctx.close()
a, c = Image.open("/tmp/m04-card-a.png"), Image.open("/tmp/m04-card-b.png")
f = ImageFont.truetype(FONT, 24)
can = Image.new("RGB", (a.width + c.width + 72, a.height + 70), (233, 238, 243)); d = ImageDraw.Draw(can)
d.text((24, 18), "Rating state (4 chosen)", font=f, fill=(29, 39, 51)); can.paste(ImageOps.expand(a, border=2, fill=(160, 170, 182)), (24, 56))
d.text((a.width + 52, 18), "Thank-you state", font=f, fill=(29, 39, 51)); can.paste(ImageOps.expand(c, border=2, fill=(160, 170, 182)), (a.width + 52, 56))
can.save(f"{O}/m04-rating-card.png")

# ---------- 9. reading a brief (illustration) ----------
F, M = I.F, I.M
def brief_svg(w=980, h=430):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    s += f"<text x='24' y='34' {F} font-size='17' font-weight='bold' fill='#1b2b44'>A design brief, read as HTML first</text>"
    # sketch card
    s += f"<rect x='24' y='56' width='300' height='330' rx='4' fill='#fffdf8' stroke='#1f2a2e' stroke-width='2' stroke-dasharray='5 4'/>"
    s += f"<circle cx='54' cy='90' r='16' fill='#e6f2f0' stroke='#0f766e'/>"
    s += f"<rect x='40' y='122' width='170' height='16' fill='#c9d1da'/><rect x='40' y='150' width='260' height='9' fill='#e3e8ee'/><rect x='40' y='166' width='220' height='9' fill='#e3e8ee'/>"
    for i in range(5): s += f"<circle cx='{62+i*55}' cy='218' r='20' fill='#fff' stroke='#1f2a2e' stroke-width='2'/><text x='{62+i*55}' y='223' {F} font-size='13' text-anchor='middle'>{i+1}</text>"
    s += f"<rect x='40' y='262' width='268' height='38' rx='3' fill='#1f2a2e'/><text x='174' y='286' {F} font-size='13' fill='#fff' text-anchor='middle'>button</text>"
    notes = [(122, "heading", "<h1>"), (158, "short paragraph", "<p>"), (218, "pick one of five", "<fieldset>, <legend>, 5 radios"), (281, "send it", "<button type=\"submit\">"), (340, "after sending: a thank-you", "<section hidden>")]
    for y, a1, b1 in notes:
        s += f"<line x1='326' y1='{y}' x2='392' y2='{y}' stroke='#e76f51' stroke-width='1.5'/>"
        s += f"<text x='400' y='{y-3}' {F} font-size='13.5' font-weight='bold' fill='#1b2b44'>{I.esc(a1)}</text><text x='400' y='{y+15}' {M} font-size='12.5' fill='#0f5b55'>{I.esc(b1)}</text>"
    s += f"<text x='40' y='346' {F} font-size='12' fill='#5b6b70'>(not shown until sent)</text>"
    s += f"<text x='740' y='80' {F} font-size='13.5' font-weight='bold' fill='#1b2b44'>The visitor can:</text>"
    for i, t in enumerate(["choose 1 to 5 with a mouse", "or with the keyboard", "send the rating", "see a thank-you"]):
        s += f"<text x='740' y='{104+i*20}' {F} font-size='12.5' fill='#37474f'>&#8226; {I.esc(t)}</text>"
    s += f"<text x='740' y='210' {F} font-size='13.5' font-weight='bold' fill='#1b2b44'>Colors (CSS later):</text>"
    for i, (n, c) in enumerate([("--page", "#f6f1e9"), ("--ink", "#1f2a2e"), ("--accent", "#0f766e")]):
        s += f"<rect x='740' y='{222+i*24}' width='16' height='16' fill='{c}' stroke='#999'/><text x='764' y='{235+i*24}' {M} font-size='12.5' fill='#37474f'>{n}</text>"
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(brief_svg(), f"{O}/m04-brief.png", 980)

srv.shutdown(); k.close()
print(json.dumps(results, indent=1))
