"""Module 6 images: JavaScript Language Foundations. Run: python3 /home/claude/build/mods/m06.py

Console sessions that declare a variable on one line and use it on the next cannot go through
k.browser_eval (it evaluates each line with indirect eval, so const/let do not survive to the
next line). console_repl() below evaluates each line in real Chromium through the DevTools
protocol with replMode, which is the mode the DevTools Console itself uses, so declarations
persist line to line exactly as they do for a learner typing in the Console.
"""
import sys, os, json
sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I
O = k.OUT
D = "/home/claude/build/demo/m06/js-practice"
os.makedirs(D, exist_ok=True)
P = "PS C:\\Users\\you\\Documents\\code559\\js-practice>"
log = {}

def _show(r):
    t = r.get("type")
    if t == "undefined": return "undefined"
    if t == "string": return json.dumps(r["value"])
    if r.get("subtype") == "null": return "null"
    if "description" in r: return r["description"]
    return str(r.get("value")).lower() if t == "boolean" else str(r.get("value"))

def console_repl(lines):
    page = k._b().new_page()
    page.set_content("<p>blank page</p>")
    cdp = page.context.new_cdp_session(page)
    out = []
    cdp.on("Runtime.consoleAPICalled", lambda e: out.append(("log", " ".join(_show(a) if a.get("type") != "string" else a["value"] for a in e["args"]))))
    cdp.send("Runtime.enable")
    page.wait_for_timeout(100)
    out.clear()  # drop console messages Playwright's own set_content left behind (replayed on enable)
    for line in lines:
        out.append(("input", line))
        r = cdp.send("Runtime.evaluate", {"expression": line, "replMode": True})
        page.wait_for_timeout(30)
        if "exceptionDetails" in r:
            ex = r["exceptionDetails"].get("exception", {})
            out.append(("error", "Uncaught " + ex.get("description", r["exceptionDetails"].get("text", ""))))
        else:
            out.append(("result", _show(r["result"])))
    page.close()
    return out

def session(name, lines, width=820):
    e = console_repl(lines); log[name] = e
    k.render_console(e, f"{O}/m06-{name}.png", width=width)
    return e

# 1. types and typeof (no declarations, so the shared k.browser_eval works here)
e = k.browser_eval("<p>blank page</p>", ['typeof "hello"', 'typeof 42', 'typeof 3.5', 'typeof true',
                                          'typeof undefined', 'typeof null', 'typeof "42"'])
log["typeof"] = e; k.render_console(e, f"{O}/m06-typeof.png")

# 2. const and let
session("const-let", ['let visits = 1', 'visits = visits + 1', 'visits',
                      'const siteName = "My Site"', 'siteName', 'let note', 'note'])

# 3. assignment vs comparison
session("assign-compare", ['let mood = "calm"', 'mood === "busy"', 'mood = "busy"', 'mood === "busy"'])

# 4. arithmetic and + with strings
e = k.browser_eval("<p>blank page</p>", ['7 + 2', '7 - 2', '7 * 2', '7 / 2', '7 % 2',
                                          '"5" + 3', '"5" - 3', '"5" * 2', '"Total: " + 2 + 3', '"Total: " + (2 + 3)'])
log["arithmetic"] = e; k.render_console(e, f"{O}/m06-arithmetic.png")

# 5. comparison and === vs ==
e = k.browser_eval("<p>blank page</p>", ['10 > 9', '10 >= 10', '3 !== 4', '5 === 5', '5 === "5"', '5 == "5"',
                                          '0 == false', '0 === false', 'null == undefined', 'null === undefined'])
log["equality"] = e; k.render_console(e, f"{O}/m06-equality.png")

# 6. booleans as results
session("boolean-results", ['const temp = 62', 'temp < 50', 'const needsJacket = temp < 70', 'needsJacket', 'typeof needsJacket'])

# 7. if / else if / else in a Node file, run twice with two values (real)
GREET = '''// weather.js: suggest what to wear from the temperature (degrees F)
const temp = {H};

if (temp < 50) {{
  console.log("Wear a coat");
}} else if (temp < 70) {{
  console.log("Bring a jacket");
}} else {{
  console.log("T-shirt weather");
}}

console.log("Checked " + temp + " degrees");
'''
runs = []
for h in (40, 62, 85):
    open(os.path.join(D, "weather.js"), "w").write(GREET.format(H=h))
    runs.append((f"node weather.js", k.run("node weather.js", cwd=D)))
log["weather"] = runs
open(os.path.join(D, "weather.js"), "w").write(GREET.format(H=40))
k.render_terminal(runs, f"{O}/m06-if-else-node.png", prompt=P)

# 8. if / else if / else decision diagram (illustration)
W, Hh = 900, 300
F = I.F
s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{W}' height='{Hh}' viewBox='0 0 {W} {Hh}'><rect width='{W}' height='{Hh}' fill='#fff'/>"
s += "<defs><marker id='ar' viewBox='0 0 10 10' refX='8' refY='5' markerWidth='7' markerHeight='7' orient='auto'><path d='M0 0L10 5L0 10z' fill='#4a6fa5'/></marker></defs>"
s += f"<text x='{W/2}' y='26' {F} font-size='15' font-weight='bold' text-anchor='middle' fill='#1b2b44'>if / else if / else: checked top to bottom, first true wins, only one block runs</text>"
def dia(cx, cy, label):
    return (f"<polygon points='{cx},{cy-34} {cx+110},{cy} {cx},{cy+34} {cx-110},{cy}' fill='#dbe8ff' stroke='#7aa7e8'/>"
            f"<text x='{cx}' y='{cy+5}' {I.M} font-size='14' text-anchor='middle' fill='#1b2b44'>{I.esc(label)}</text>")
def out(x, y, label, fill="#e2f6e2", st="#7bbf7b"):
    return (f"<rect x='{x}' y='{y-20}' width='190' height='40' rx='8' fill='{fill}' stroke='{st}'/>"
            f"<text x='{x+95}' y='{y+5}' {F} font-size='13.5' text-anchor='middle' fill='#1b2b44'>{I.esc(label)}</text>")
def arrow(x1, y1, x2, y2, label=None, lx=0, ly=0):
    a = f"<line x1='{x1}' y1='{y1}' x2='{x2}' y2='{y2}' stroke='#4a6fa5' stroke-width='2' marker-end='url(#ar)'/>"
    if label: a += f"<text x='{(x1+x2)/2+lx}' y='{(y1+y2)/2+ly}' {F} font-size='12' fill='#4a6fa5' font-weight='bold'>{label}</text>"
    return a
s += dia(150, 90, "temp < 50"); s += dia(450, 90, "temp < 70")
s += arrow(260, 90, 336, 90, "false", -18, -8)
s += arrow(560, 90, 668, 90, "false", -18, -8)
s += out(670, 90, "else: \"T-shirt weather\"", "#fde2e2", "#e08a8a")
s += arrow(150, 124, 150, 196, "true", 8, 0); s += out(55, 216, "\"Wear a coat\"")
s += arrow(450, 124, 450, 196, "true", 8, 0); s += out(355, 216, "\"Bring a jacket\"")
s += f"<text x='{W/2}' y='{Hh-34}' {F} font-size='12.5' text-anchor='middle' fill='#444'>After whichever block ran, the program carries on with the next line after the closing brace.</text>"
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m06-if-flow.png", 900)

# 9. break it: reassign a const, in the Console and in Node (both real)
session("const-error", ['const city = "Fresno"', 'city = "Chicago"', 'city'])
open(os.path.join(D, "break-const.js"), "w").write('const city = "Fresno";\ncity = "Chicago";\nconsole.log(city);\n')
nodeout = k.run("node break-const.js", cwd=D); log["const_error_node"] = nodeout
k.render_terminal([("node break-const.js", nodeout)], f"{O}/m06-const-error-node.png", prompt=P, width=900)

# 10. exercise drill answers (real), printed for the post's answer table
drill = ['typeof "7"', 'typeof 7', '"7" + 7', '"7" - 7', '7 + 7 + "7"', '"7" + 7 + 7',
         '10 / 4', '10 % 4', '7 == "7"', '7 === "7"', 'typeof (7 > 3)', 'typeof undefined', 'typeof null']
log["drill"] = k.browser_eval("<p>blank page</p>", drill)

k.close()
print(json.dumps(log, indent=1))
