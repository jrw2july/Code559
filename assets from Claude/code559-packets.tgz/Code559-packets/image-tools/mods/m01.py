"""Module 1 images. Run: python3 /home/claude/build/mods/m01.py"""
import sys, os, shutil, tempfile
sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I
from illus import F, M, esc

O = k.OUT
D = "/home/claude/build/demo/m01"
WIN = "file:///C:/Users/you/Documents/code559"


def frame(html_path, out_png, url_text, width=800, height=360, actions=None, scale=2):
    """Real Chromium screenshot of the page (loaded by file://, so links and images work),
    placed inside a DRAWN browser chrome. Caption: (page real: rendered in Chromium; browser frame drawn).
    Written here because imgkit.browser_frame's iframe does not load file:// pages from about:blank."""
    import base64, html as H
    page = k._b().new_page(viewport={"width": width, "height": height}, device_scale_factor=scale)
    page.goto("file://" + os.path.abspath(html_path))
    page.wait_for_timeout(150)
    for kind, arg in (actions or []):
        if kind == "click": page.click(arg)
        elif kind == "fill": page.fill(arg[0], arg[1])
        elif kind == "press": page.keyboard.press(arg)
        elif kind == "eval": page.evaluate(arg)
        elif kind == "wait": page.wait_for_timeout(arg)
        page.wait_for_timeout(80)
    title = page.title()
    png = page.screenshot(full_page=False)
    page.close()
    b64 = base64.b64encode(png).decode()
    doc = f"""<style>body{{margin:0;background:#e9eef3;font-family:Segoe UI,Arial,sans-serif}}
    .win{{margin:16px;border-radius:8px;overflow:hidden;box-shadow:0 6px 24px rgba(0,0,0,.18);background:#fff;border:1px solid #c9d1da;width:{width}px}}
    .tb{{background:#dfe3e8;height:38px;display:flex;align-items:center;padding:0 10px;font-size:13px}}
    .tab{{background:#fff;padding:6px 14px;border-radius:8px 8px 0 0;margin-top:10px;font-size:12px;color:#333}}
    .ab{{background:#fff;height:36px;display:flex;align-items:center;padding:0 10px;gap:10px;border-bottom:1px solid #d5d9de;font-size:13px;color:#333}}
    .url{{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;background:#f1f3f4;border-radius:14px;padding:5px 12px;font-size:13px;color:#202124}}
    img{{display:block;width:{width}px;height:{height}px}}</style>
    <div class='win'><div class='tb'><span class='tab'>{H.escape(title)}</span></div>
    <div class='ab'><span>&#8249; &#8250; &#10227;</span><span class='url'>{H.escape(url_text)}</span></div>
    <img src='data:image/png;base64,{b64}'></div>"""
    return k._shot(doc, out_png, width + 40, scale=scale)


def svg_open(w, h):
    return (f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'>"
            f"<defs><marker id='ar' viewBox='0 0 10 10' refX='8' refY='5' markerWidth='7' markerHeight='7' orient='auto'>"
            f"<path d='M0 0L10 5L0 10z' fill='#4a6fa5'/></marker></defs><rect width='{w}' height='{h}' fill='#fff'/>")


def txt(x, y, s, size=13, fill="#1b2b44", bold=False, anchor="start", mono=False):
    fam = M if mono else F
    return (f"<text x='{x}' y='{y}' {fam} font-size='{size}' fill='{fill}' text-anchor='{anchor}'"
            f"{' font-weight=\"bold\"' if bold else ''} xml:space='preserve'>{esc(s)}</text>")


# 1. Request / response diagram (illustration)
def request_response():
    w, h = 900, 300
    s = svg_open(w, h)
    s += txt(w / 2, 30, "What happens when you visit a page", 16, bold=True, anchor="middle")
    # client
    s += "<rect x='30' y='60' width='250' height='190' rx='10' fill='#dbe8ff' stroke='#7aa7e8'/>"
    s += txt(155, 90, "Client", 17, bold=True, anchor="middle")
    s += txt(155, 112, "your browser (Edge or Chrome)", 12, "#37474f", anchor="middle")
    s += "<rect x='55' y='130' width='200' height='95' rx='6' fill='#fff' stroke='#7aa7e8'/>"
    s += txt(155, 160, "shows the page:", 12, "#37474f", anchor="middle")
    s += txt(155, 185, "reads the HTML and", 12, "#37474f", anchor="middle")
    s += txt(155, 203, "draws it on screen", 12, "#37474f", anchor="middle")
    # server
    s += "<rect x='620' y='60' width='250' height='190' rx='10' fill='#e2f6e2' stroke='#7bbf7b'/>"
    s += txt(745, 90, "Server", 17, bold=True, anchor="middle")
    s += txt(745, 112, "a computer that stores the site", 12, "#37474f", anchor="middle")
    for i, f in enumerate(["index.html", "about.html", "styles.css", "image-one.jpg"]):
        s += txt(680, 145 + i * 22, "\U0001F4C4 " + f, 12.5, "#222", mono=True)
    # arrows
    s += "<line x1='290' y1='120' x2='608' y2='120' stroke='#4a6fa5' stroke-width='2.5' marker-end='url(#ar)'/>"
    s += txt(450, 108, "1. Request: \u201cplease send /about.html\u201d", 13, anchor="middle")
    s += "<line x1='610' y1='190' x2='292' y2='190' stroke='#4a6fa5' stroke-width='2.5' marker-end='url(#ar)'/>"
    s += txt(450, 178, "2. Response: the file's contents", 13, anchor="middle")
    s += txt(450, 214, "(HTML text, then CSS and images as the", 11.5, "#555", anchor="middle")
    s += txt(450, 230, "browser asks for them)", 11.5, "#555", anchor="middle")
    s += I.tag(w, h) + "</svg>"
    k.render_svg(s, f"{O}/m01-request-response.png", w)


# 2. URL parts (illustration)
def url_parts():
    w, h = 900, 230
    s = svg_open(w, h)
    s += txt(w / 2, 30, "The parts of a URL", 16, bold=True, anchor="middle")
    parts = [("https", "scheme", "how to ask (the protocol)", "#fde2e2", "#e08a8a"),
             ("://", None, None, None, None),
             ("www.example.com", "host (domain)", "which server to ask", "#dbe8ff", "#7aa7e8"),
             ("/about.html", "path", "which file on that server", "#e2f6e2", "#7bbf7b"),
             ("#contact", "anchor (fragment)", "a spot inside the page", "#fff3cd", "#e0c36a")]
    cw = 15.6  # px per char at 26px mono (approx)
    gap = 10
    total = sum(len(p[0]) for p in parts) * cw + gap * (len(parts) - 1)
    x = (w - total) / 2
    y = 92
    for t, name, desc, fill, st in parts:
        pw = len(t) * cw
        if fill:
            s += f"<rect x='{x-2}' y='{y-30}' width='{pw+4}' height='42' rx='6' fill='{fill}' stroke='{st}'/>"
        s += txt(x, y, t, 26, "#1f2328", mono=True)
        if name:
            cx = x + pw / 2
            s += f"<line x1='{cx}' y1='{y+14}' x2='{cx}' y2='{y+44}' stroke='{st}' stroke-width='2'/>"
            s += txt(cx, y + 64, name, 13.5, bold=True, anchor="middle")
            s += txt(cx, y + 84, desc, 11.5, "#37474f", anchor="middle")
        x += pw + gap
    s += txt(w / 2, 205, "The anchor is never sent to the server; the browser uses it to scroll (MDN, What is a URL?).", 12, "#555", anchor="middle")
    s += I.tag(w, h) + "</svg>"
    k.render_svg(s, f"{O}/m01-url-parts.png", w)


# 10. GitHub Pages settings (illustration; labels from GitHub Docs)
def pages_settings():
    w, h = 900, 380
    s = svg_open(w, h)
    s += f"<rect width='{w}' height='{h}' rx='8' fill='#fff' stroke='#d0d7de'/>"
    s += f"<rect width='{w}' height='48' rx='8' fill='#f6f8fa'/><rect y='40' width='{w}' height='8' fill='#f6f8fa'/>"
    s += "<circle cx='28' cy='24' r='11' fill='#24292f'/>"
    s += txt(50, 29, "your-username / ", 14, "#24292f") + txt(163, 29, "my-site", 14, "#24292f", bold=True)
    tabs = ["Code", "Issues", "Pull requests", "Actions", "Settings"]
    x = 28
    for t in tabs:
        s += txt(x, 76, t, 13, "#24292f" if t == "Settings" else "#57606a", bold=(t == "Settings"))
        if t == "Settings":
            s += f"<rect x='{x}' y='84' width='56' height='2' fill='#fd8c73'/>"
        x += len(t) * 8 + 26
    s += f"<line x1='0' y1='86' x2='{w}' y2='86' stroke='#d8dee4'/>"
    # sidebar
    s += txt(28, 118, "General", 13, "#57606a")
    s += txt(28, 148, "Code, planning, and automation", 11.5, "#57606a", bold=True)
    for i, t in enumerate(["Branches", "Actions", "Pages"]):
        y = 174 + i * 28
        if t == "Pages":
            s += f"<rect x='20' y='{y-18}' width='220' height='26' rx='6' fill='#eaeef2'/><rect x='20' y='{y-18}' width='3' height='26' fill='#0969da'/>"
        s += txt(32, y, t, 13, "#24292f", bold=(t == "Pages"))
    # main
    s += txt(280, 122, "GitHub Pages", 20, "#24292f", bold=True)
    s += f"<line x1='280' y1='136' x2='{w-30}' y2='136' stroke='#d8dee4'/>"
    s += txt(280, 166, "Build and deployment", 15, "#24292f", bold=True)
    s += txt(280, 194, "Source", 13, "#24292f", bold=True)
    s += "<rect x='280' y='204' width='210' height='32' rx='6' fill='#f6f8fa' stroke='#d0d7de'/>"
    s += txt(292, 225, "Deploy from a branch  \u25BE", 13, "#24292f")
    s += txt(280, 266, "Branch", 13, "#24292f", bold=True)
    s += "<rect x='280' y='276' width='110' height='32' rx='6' fill='#f6f8fa' stroke='#d0d7de'/>"
    s += txt(292, 297, "\u2442 main  \u25BE", 13, "#24292f")
    s += "<rect x='400' y='276' width='110' height='32' rx='6' fill='#f6f8fa' stroke='#d0d7de'/>"
    s += txt(412, 297, "/ (root)  \u25BE", 13, "#24292f")
    s += "<rect x='520' y='276' width='70' height='32' rx='6' fill='#f6f8fa' stroke='#d0d7de'/>"
    s += txt(555, 297, "Save", 13, "#24292f", anchor="middle")
    s += txt(280, 340, "Layout simplified. Labels follow GitHub Docs; the real page has more text and options.", 11.5, "#57606a")
    s += I.tag(w, h) + "</svg>"
    k.render_svg(s, f"{O}/m01-pages-settings.png", w)


def git_first_commit():
    home = tempfile.mkdtemp()
    env = {"HOME": home, "XDG_CONFIG_HOME": home,
           "GIT_AUTHOR_DATE": "2026-10-09T12:00:00", "GIT_COMMITTER_DATE": "2026-10-09T12:00:00"}
    for c in ["git config --global init.defaultBranch main", 'git config --global user.name "Your Name"',
              'git config --global user.email "you@example.com"']:
        k.run(c, cwd=home, env=env)
    site = f"{D}/git-run/my-site"
    shutil.rmtree(site, ignore_errors=True)
    os.makedirs(site)
    for f in ["index.html", "about.html", "image-one.jpg"]:
        shutil.copy(f"{D}/pages-demo/{f}", site)
    r = lambda c: k.run(c, cwd=site, env=env)
    blocks = [(c, r(c)) for c in ["git init", "git add .", "git status",
                                  'git commit -m "Add Home and About pages"', "git log --oneline"]]
    k.render_terminal(blocks, f"{O}/m01-git-first-commit.png", prompt="PS C:\\Users\\you\\Documents\\code559\\my-site>")
    shutil.rmtree(home)
    return blocks


OUTLINE = """(() => { const s = document.createElement('style'); s.textContent = `
header,nav,main,section,footer{outline:2px dashed #d0457a;outline-offset:3px;position:relative;margin:14px 6px;padding:4px}
header::before,nav::before,main::before,section::before,footer::before{position:absolute;top:-9px;right:6px;background:#d0457a;color:#fff;font:bold 11px monospace;padding:1px 5px}
header::before{content:'<header>'} nav::before{content:'<nav>'} main::before{content:'<main>'} section::before{content:'<section>'} footer::before{content:'<footer>'}`;
document.head.appendChild(s); })()"""

if __name__ == "__main__":
    request_response()
    url_parts()
    pages_settings()
    frame(f"{D}/first-page/index.html", f"{O}/m01-first-page.png", f"{WIN}/first-page/index.html", width=800, height=190)
    k.render_page(f"{D}/alt-demo/index.html", f"{O}/m01-alt-text.png", width=800, height=330)
    k.render_page(f"{D}/pages-demo/index.html", f"{O}/m01-semantic-outline.png", width=800, height=300, actions=[("eval", OUTLINE)])
    frame(f"{D}/pages-demo/index.html", f"{O}/m01-about-after-click.png", f"{WIN}/pages-demo/about.html",
                    width=800, height=380, actions=[("click", "a[href='about.html']"), ("wait", 300)])
    k.render_page(f"{D}/practice/index.html", f"{O}/m01-exercise-page.png", width=800, height=300)
    k.render_page(f"{D}/practice-broken/index.html", f"{O}/m01-break-h1.png", width=800, full_page=False,
                  clip={"x": 0, "y": 0, "width": 800, "height": 300})
    blocks = git_first_commit()
    k.close()
    print("\n\n".join(f"$ {c}\n{o}" for c, o in blocks))
