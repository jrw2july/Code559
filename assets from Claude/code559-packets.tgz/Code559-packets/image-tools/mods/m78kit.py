"""Console helper for Modules 7 and 8 (own helper; does not modify shared files).
Evaluates each line through Chrome DevTools Protocol Runtime.evaluate with replMode=True,
the same mode the DevTools Console uses, so const/let persist between lines.
Returns (kind, text) entries for imgkit.render_console. All values are real."""
import sys; sys.path.insert(0, "/home/claude/build")
import imgkit as k

def _prev_val(p):
    t = p.get("type"); v = p.get("value", "")
    if t == "boolean": return v
    if t == "string": return "'" + v + "'"
    if t == "object" and p.get("subtype") == "array": return v  # e.g. Array(2)
    if t == "object": return v if v not in ("Object",) else "{…}"
    return v

def _fmt(o):
    t = o.get("type"); st = o.get("subtype")
    if t == "undefined": return "undefined"
    if st == "null": return "null"
    if t == "string": return "'" + o["value"] + "'"
    if t == "boolean": return "true" if o.get("value") else "false"
    if t == "number": return o.get("description", str(o.get("value")))
    if t == "function": return "ƒ " + o.get("description", "").replace("function ", "", 1) if o.get("description","").startswith("function ") else o.get("description", "")
    pv = o.get("preview")
    if st == "array":
        n = o.get("description", "Array(0)").split("(")[1].rstrip(")")
        items = ", ".join(_prev_val(p) for p in (pv or {}).get("properties", []) if p["name"].isdigit())
        if pv and pv.get("overflow"): items += ", …"
        return f"({n}) [{items}]"
    if t == "object" and pv:
        items = ", ".join(f"{p['name']}: {_prev_val(p)}" for p in pv.get("properties", []))
        if pv.get("overflow"): items += ", …"
        return "{" + items + "}"
    return o.get("description", str(o))

def console(lines, html="<!doctype html><title>Console</title>"):
    page = k._b().new_page()
    page.set_content(html)
    cdp = page.context.new_cdp_session(page)
    logs = []
    def on_log(ev):
        logs.append(("log" if ev["type"] == "log" else ev["type"], " ".join(_fmt_log(a) for a in ev["args"])))
    cdp.on("Runtime.consoleAPICalled", on_log)
    cdp.send("Runtime.enable")
    page.wait_for_timeout(100); logs.clear()
    out = []
    for line in lines:
        out.append(("input", line))
        r = cdp.send("Runtime.evaluate", {"expression": line, "replMode": True, "generatePreview": True, "awaitPromise": False})
        page.wait_for_timeout(60)
        out += logs; logs.clear()
        if "exceptionDetails" in r:
            d = r["exceptionDetails"].get("exception", {}).get("description", r["exceptionDetails"].get("text", ""))
            out.append(("error", "Uncaught " + d.split("\n")[0]))
        else:
            out.append(("result", _fmt(r["result"])))
    page.close()
    return out

def _fmt_log(a):
    if a.get("type") == "string": return a["value"]
    return _fmt(a)
