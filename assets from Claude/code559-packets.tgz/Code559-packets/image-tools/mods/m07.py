"""Module 7 (Functions) image build. Console images: real Chromium evaluation via CDP
Runtime.evaluate(replMode) in m78kit. Terminal images: real `node` runs. SVGs: illustrations."""
import sys, os, shutil; sys.path.insert(0, "/home/claude/build"); sys.path.insert(0, "/home/claude/build/mods")
import imgkit as k, illus as I, m78kit as M
O = k.OUT; D = "/home/claude/build/demo/m07"; P = f"{D}/m07-practice"
PROMPT = "PS C:\\Users\\you\\Documents\\code559\\m07-practice>"
F, MONO, esc = I.F, I.M, I.esc

# 1. Anatomy of a function (illustration)
def anatomy(w=900, h=330):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    s += f"<text x='24' y='30' {F} font-size='15' font-weight='bold' fill='#1b2b44'>Defining a function (nothing runs yet)</text>"
    s += f"<rect x='24' y='44' width='330' height='92' rx='8' fill='#f6f8fa' stroke='#d0d7de'/>"
    lines = ["function toMinutes(hours) {", "  return hours * 60;", "}"]
    for i, ln in enumerate(lines):
        s += f"<text x='40' y='{74+i*24}' {MONO} font-size='16' fill='#1f2328' xml:space='preserve'>{esc(ln)}</text>"
    notes = [(40, 'keyword', 'function'), (128, 'name', 'toMinutes'), (225, 'parameter', 'hours'), (62, 'hands a value back', 'return')]
    # labels to the right
    lab = [("function", "keyword: \"here comes a definition\""), ("toMinutes", "name: how you call it later"), ("(hours)", "parameter: a name for the input"), ("return hours * 60;", "body: the work, then the value handed back")]
    for i, (a, b) in enumerate(lab):
        y = 62 + i * 20
        s += f"<text x='380' y='{y}' {MONO} font-size='12.5' fill='#0b57d0'>{esc(a)}</text><text x='380' y='{y+0}' dx='{len(a)*7.6+8}' {F} font-size='12.5' fill='#37474f'>{esc(b)}</text>"
    s += f"<text x='24' y='182' {F} font-size='15' font-weight='bold' fill='#1b2b44'>Calling it (now it runs)</text>"
    s += f"<rect x='24' y='196' width='330' height='50' rx='8' fill='#eaf6ea' stroke='#9fd39f'/>"
    s += f"<text x='40' y='227' {MONO} font-size='16' fill='#1f2328' xml:space='preserve'>{esc('const total = toMinutes(2);')}</text>"
    s += f"<text x='380' y='216' {MONO} font-size='12.5' fill='#0b57d0'>2</text><text x='398' y='216' {F} font-size='12.5' fill='#37474f'>argument: the real value sent in</text>"
    s += f"<text x='380' y='238' {MONO} font-size='12.5' fill='#0b57d0'>()</text><text x='404' y='238' {F} font-size='12.5' fill='#37474f'>the parentheses are what make it run</text>"
    s += f"<text x='24' y='282' {F} font-size='13.5' fill='#37474f'>Inside the call, hours holds 2. The function hands back 120, and the call is replaced by that value,</text>"
    s += f"<text x='24' y='302' {F} font-size='13.5' fill='#37474f'>so total holds 120.</text>"
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(anatomy(), f"{O}/m07-anatomy.png", 900)

# 2. Define vs call (real console)
fn_toMin = "function toMinutes(hours) {\n  return hours * 60;\n}"
k.render_console(M.console([fn_toMin, "toMinutes(2)", "toMinutes(1.5)", "toMinutes(0)"]), f"{O}/m07-define-call.png")

# 3. return vs console.log (real console)
logG = "function logGreeting(name) {\n  console.log(\"Hello, \" + name + \"!\");\n}"
makeG = "function makeGreeting(name) {\n  return \"Hello, \" + name + \"!\";\n}"
k.render_console(M.console([logG, makeG, "const a = logGreeting(\"Sam\");", "a", "const b = makeGreeting(\"Sam\");", "b"]), f"{O}/m07-return-vs-log.png")

# 4. Scope (real console)
cnt = "function countLetters(word) {\n  const total = word.length;\n  return total;\n}"
k.render_console(M.console([cnt, "countLetters(\"website\")", "total"]), f"{O}/m07-scope.png")

# 5. Test calls in Node (real terminal)
os.makedirs(P, exist_ok=True)
helpers = open(f"{P}/helpers.js").read()
k.render_terminal([("node helpers.js", k.run("node helpers.js", cwd=P))], f"{O}/m07-node-tests.png", prompt=PROMPT)

# 6. Description method (illustration)
k.render_svg(I.flow([("1. Name it", "a verb that says|what it does"), ("2. List inputs", "the parameters"), ("3. State output", "what it hands back|and its type"), ("4. Write tests", "three calls with|expected answers"), ("5. Write body", "then run the tests")],
                    h=170, title="Writing a function from a one-sentence description"), f"{O}/m07-description-method.png", 900)

# 7. Reference vs call (real console)
show = "function showMessage() {\n  return \"Thanks for visiting!\";\n}"
k.render_console(M.console([show, "showMessage", "showMessage()", "typeof showMessage", "typeof showMessage()", "const later = showMessage;", "later()"]), f"{O}/m07-reference-call.png")

# 8. Listener bridge (illustration)
def bridge(w=900, h=230):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    s += f"<text x='{w/2}' y='28' {F} font-size='15' font-weight='bold' text-anchor='middle' fill='#1b2b44'>Module 9 preview: what you hand to an event listener</text>"
    boxes = [(20, "#e2f6e2", "#7bbf7b", "button.addEventListener(\"click\", showMessage);", ["You hand over the function itself.", "The browser keeps it and calls it", "each time the button is clicked."]),
             (460, "#fde2e2", "#e08a8a", "button.addEventListener(\"click\", showMessage());", ["showMessage() runs right now, once.", "You hand over its result, a string,", "not something the browser can call."])]
    for x, f, st, code, txt in boxes:
        s += f"<rect x='{x}' y='46' width='420' height='150' rx='10' fill='{f}' stroke='{st}'/>"
        s += f"<text x='{x+14}' y='78' {MONO} font-size='12.6' fill='#1f2328'>{esc(code)}</text>"
        for i, t in enumerate(txt):
            s += f"<text x='{x+14}' y='{112+i*22}' {F} font-size='14' fill='#263238'>{esc(t)}</text>"
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(bridge(), f"{O}/m07-listener-bridge.png", 900)

# 9. null for "no answer" (real console)
pick = "function pickColor(mode) {\n  if (mode === \"dark\") {\n    return \"#222222\";\n  }\n  if (mode === \"light\") {\n    return \"#ffffff\";\n  }\n  return null;\n}"
k.render_console(M.console([pick, "pickColor(\"dark\")", "pickColor(\"blue\")", "pickColor(\"blue\") === null", "pickColor(\"light\") === null"]), f"{O}/m07-null.png")

# 10. Break it: forget the return (real terminal)
B = f"{D}/m07-break"; shutil.rmtree(B, ignore_errors=True); shutil.copytree(P, B)
src = open(f"{B}/helpers.js").read().replace("  return hours * 60;", "  hours * 60;")
open(f"{B}/helpers.js", "w").write(src)
k.render_terminal([("node helpers.js", k.run("node helpers.js", cwd=B))], f"{O}/m07-break-it.png", prompt=PROMPT)
k.close()
