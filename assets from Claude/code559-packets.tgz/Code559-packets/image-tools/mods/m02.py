"""Module 2 images. Run: python3 /home/claude/build/mods/m02.py"""
import sys, os, io
sys.path.insert(0, "/home/claude/build")
sys.path.insert(0, "/home/claude/build/mods")
import imgkit as k, illus as I
from m01 import svg_open, txt, frame
from PIL import Image, ImageDraw, ImageFont

O = k.OUT
D = "/home/claude/build/demo/m02"
WIN = "file:///C:/Users/you/Documents/code559"


def file_eval(html_path, js_lines):
    """Like imgkit.browser_eval, but loads the real file (file://) so its <link> stylesheet applies.
    Returns console-style entries from a real Chromium run, including load-time console errors."""
    page = k._b().new_page()
    entries = []
    page.on("console", lambda m: entries.append(("error" if m.type == "error" else "log", m.text)))
    page.on("pageerror", lambda e: entries.append(("error", str(e))))
    page.goto("file://" + os.path.abspath(html_path))
    page.wait_for_timeout(200)
    for line in js_lines:
        entries.append(("input", line))
        r = page.evaluate("(src) => { try { const v = (0, eval)(src); return {ok:true, v: typeof v === 'string' ? JSON.stringify(v) : String(v)}; } catch (e) { return {ok:false, v:'Uncaught ' + e.name + ': ' + e.message}; } }", line)
        entries.append(("result" if r["ok"] else "error", r["v"]))
    page.close()
    return entries


def rule_anatomy():
    w, h = 900, 260
    s = svg_open(w, h)
    s += txt(w / 2, 30, "The parts of a CSS rule", 16, bold=True, anchor="middle")
    x0, y0 = 250, 90
    s += "<rect x='240' y='60' width='420' height='120' rx='8' fill='#f6f8fa' stroke='#d0d7de'/>"
    s += txt(x0, y0, "h1 {", 22, "#1f2328", mono=True)
    s += txt(x0 + 30, y0 + 32, "color: #d1495b;", 22, "#1f2328", mono=True)
    s += txt(x0 + 30, y0 + 64, "font-size: 36px;", 22, "#1f2328", mono=True)
    s += txt(x0, y0 + 84, "}", 22, "#1f2328", mono=True)
    # labels
    s += "<line x1='238' y1='83' x2='150' y2='83' stroke='#e08a8a' stroke-width='2'/>"
    s += txt(140, 80, "selector", 14, bold=True, anchor="end") + txt(140, 98, "which elements", 12, "#37474f", anchor="end")
    s += "<line x1='340' y1='184' x2='340' y2='205' stroke='#7aa7e8' stroke-width='2'/>"
    s += txt(340, 222, "property", 14, bold=True, anchor="middle") + txt(340, 240, "what to change", 12, "#37474f", anchor="middle")
    s += "<line x1='452' y1='184' x2='452' y2='205' stroke='#7bbf7b' stroke-width='2'/>"
    s += txt(452, 222, "value", 14, bold=True, anchor="middle") + txt(452, 240, "what to change it to", 12, "#37474f", anchor="middle")
    s += "<line x1='662' y1='120' x2='700' y2='120' stroke='#e0c36a' stroke-width='2'/>"
    s += txt(710, 112, "declaration", 14, bold=True) + txt(710, 130, "property: value;", 12, "#37474f", mono=True)
    s += txt(710, 148, "colon between, semicolon after", 12, "#37474f")
    s += I.tag(w, h) + "</svg>"
    k.render_svg(s, f"{O}/m02-rule-anatomy.png", w)


def specificity():
    w, h = 900, 270
    s = svg_open(w, h)
    s += txt(w / 2, 28, "Specificity: compare the columns from left to right", 16, bold=True, anchor="middle")
    cols = [("ID", 380), ("Class", 470), ("Element", 560)]
    for name, x in cols:
        s += txt(x, 64, name, 13.5, bold=True, anchor="middle")
    rows = [("p", (0, 0, 1), "weakest"), (".note", (0, 1, 0), "beats any element-only selector"),
            ("#special", (1, 0, 0), "beats any number of classes"), (".tag  (twice)", (0, 1, 0), "a tie: the later rule wins")]
    for i, (sel, sc, note) in enumerate(rows):
        y = 100 + i * 40
        s += f"<rect x='40' y='{y-24}' width='{w-80}' height='34' rx='6' fill='{'#f6f8fa' if i % 2 == 0 else '#fff'}'/>"
        s += txt(60, y, sel, 16, "#1f2328", mono=True)
        for (name, x), v in zip(cols, sc):
            s += txt(x, y, str(v), 17, "#d0457a" if v else "#9aa0a6", bold=bool(v), anchor="middle", mono=True)
        s += txt(630, y, note, 12, "#37474f")
    s += txt(w / 2, 262, "Based on MDN, Handling conflicts. Only when every column ties does source order decide.", 11.5, "#555", anchor="middle")
    s += I.tag(w, h) + "</svg>"
    k.render_svg(s, f"{O}/m02-specificity.png", w)


def before_after():
    a = f"{D}/_before.png"; b = f"{D}/_after.png"
    k.render_page(f"{D}/link-demo/no-css.html", a, width=560, height=420, full_page=False)
    k.render_page(f"{D}/link-demo/index.html", b, width=560, height=420, full_page=False)
    A, B = Image.open(a), Image.open(b)
    pad, top = 40, 80
    W = A.width + B.width + pad * 3
    H = max(A.height, B.height) + top + pad
    im = Image.new("RGB", (W, H), (233, 238, 243))
    d = ImageDraw.Draw(im)
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 30)
    d.text((pad, 26), "Without the <link> line", fill=(30, 40, 60), font=f)
    d.text((pad * 2 + A.width, 26), "With <link rel=\"stylesheet\" href=\"styles.css\">", fill=(30, 40, 60), font=f)
    for x, img in [(pad, A), (pad * 2 + A.width, B)]:
        d.rectangle([x - 2, top - 2, x + img.width + 1, top + img.height + 1], outline=(180, 190, 200), width=2)
        im.paste(img, (x, top))
    im.save(f"{O}/m02-before-after-link.png")
    os.unlink(a); os.unlink(b)


if __name__ == "__main__":
    rule_anatomy()
    specificity()
    before_after()
    k.render_page(f"{D}/cascade/index.html", f"{O}/m02-cascade-winners.png", width=800, height=240)
    ent = file_eval(f"{D}/cascade/index.html", [
        "getComputedStyle(document.querySelector('#one')).color",
        "getComputedStyle(document.querySelector('#two')).color",
        "getComputedStyle(document.querySelector('#special')).color",
        "getComputedStyle(document.querySelector('#four')).color",
    ])
    k.render_console(ent, f"{O}/m02-cascade-console.png")
    print(ent)
    k.render_page(f"{D}/block-inline/index.html", f"{O}/m02-block-inline.png", width=800, height=300)
    k.render_page(f"{D}/flex-nav/index.html", f"{O}/m02-flex-nav.png", width=800, height=400)
    frame(f"{D}/practice/index.html", f"{O}/m02-exercise-phone.png", "file:///C:/Users/you/.../practice-02/index.html", width=390, height=640)
    frame(f"{D}/practice-broken/index.html", f"{O}/m02-break-href.png", "file:///C:/Users/you/.../practice-02/index.html", width=390, height=640)
    ent2 = file_eval(f"{D}/practice-broken/index.html", [])
    print(ent2)
    k.render_console(ent2, f"{O}/m02-break-console.png")
    k.close()
