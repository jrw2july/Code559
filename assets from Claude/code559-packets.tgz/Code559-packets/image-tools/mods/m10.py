"""Module 10 (Forms and Validation with JavaScript) image build.
Real Chromium renders served from a local test server on 127.0.0.1:3000 (Live Preview's default port),
plus drawn diagrams. No network beyond localhost."""
import sys, os, base64, html, json, subprocess, tempfile, time; sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I
O = k.OUT; D = "/home/claude/build/demo/m10"; TMP = tempfile.mkdtemp(); facts = {}
F = I.F

def b64(p): return "data:image/png;base64," + base64.b64encode(open(p, "rb").read()).decode()

def grid(cells, out_png, cols=2, width=860):
    items = "".join(f"<div><div style='font:600 14px Segoe UI,Arial;color:#1b2b44;margin:0 0 6px'>{html.escape(l)}</div>"
                    f"<img src='{b64(p)}' style='width:100%;border:1px solid #c9d1da;border-radius:6px;display:block'></div>" for p, l in cells)
    doc = f"<div style='padding:16px;background:#fff;display:grid;grid-template-columns:repeat({cols},1fr);gap:16px;align-items:start'>{items}</div>"
    return k._shot(doc, out_png, width)

def frame(png, url, out_png, width=600):
    doc = f"""<div style='padding:16px;background:#e9eef3'><div style='border-radius:8px;overflow:hidden;border:1px solid #c9d1da;box-shadow:0 6px 24px rgba(0,0,0,.18);background:#fff'>
    <div style='background:#dfe3e8;height:30px'></div>
    <div style='display:flex;gap:10px;align-items:center;padding:6px 10px;border-bottom:1px solid #d5d9de;font:13px Segoe UI,Arial'>
    <span>&#8249; &#8250; &#10227;</span><span style='flex:1;background:#f1f3f4;border-radius:14px;padding:5px 12px;font-size:12px;white-space:nowrap'>{html.escape(url)}</span></div>
    <img src='{b64(png)}' style='width:100%;display:block'></div></div>"""
    return k._shot(doc, out_png, width)

def serve(root):
    p = subprocess.Popen(["python3", "-m", "http.server", "3000", "--bind", "127.0.0.1", "-d", root],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1); return p

B = "http://127.0.0.1:3000"
srv = serve(f"{D}/exercise")
try:
    br = k._b()
    def newpage(h=620):
        pg = br.new_page(viewport={"width": 390, "height": h}, device_scale_factor=2)
        pg.goto(B + "/index.html"); pg.wait_for_timeout(250); return pg

    # 1. Idle
    pg = newpage(); pg.screenshot(path=f"{TMP}/idle.png")
    # 2. Errors: name ok, email incomplete, message too short -> focus jumps to email
    pg.fill("#name", "Your Name"); pg.fill("#email", "you@"); pg.fill("#message", "hi")
    pg.click("#send-btn"); pg.wait_for_timeout(150)
    facts["errors_focus"] = pg.evaluate("document.activeElement.id")
    facts["errors_text"] = pg.evaluate("[nameError.textContent, emailError.textContent, messageError.textContent]")
    pg.screenshot(path=f"{TMP}/errors.png")
    cdp = pg.context.new_cdp_session(pg)
    root = cdp.send("DOM.getDocument")["root"]["nodeId"]
    nid = cdp.send("DOM.querySelector", {"nodeId": root, "selector": "#email"})["nodeId"]
    n = cdp.send("Accessibility.getPartialAXTree", {"nodeId": nid, "fetchRelatives": False})["nodes"][0]
    facts["ax_email"] = {"role": n["role"]["value"], "name": n["name"]["value"], "description": n.get("description", {}).get("value")}
    # 3. Fixed -> sending -> sent
    pg.fill("#email", "you@example.com"); pg.fill("#message", "Hello, this is a practice message.")
    pg.click("#send-btn"); pg.wait_for_timeout(150)
    facts["sending"] = pg.evaluate("[form.className, statusMessage.textContent, sendButton.disabled]")
    pg.screenshot(path=f"{TMP}/sending.png")
    pg.wait_for_timeout(1200)
    facts["sent"] = pg.evaluate("[form.className, statusMessage.textContent, nameInput.value, emailInput.value, messageInput.value]")
    pg.screenshot(path=f"{TMP}/sent.png")
    # 4. Failed
    pg.fill("#name", "Your Name"); pg.fill("#email", "you@example.com"); pg.fill("#message", "Hello, this is a practice message.")
    pg.check("#pretend-fail"); pg.click("#send-btn"); pg.wait_for_timeout(1300)
    facts["failed"] = pg.evaluate("[form.className, statusMessage.textContent, nameInput.value]")
    pg.screenshot(path=f"{TMP}/failed.png"); pg.close()

    grid([(f"{TMP}/idle.png", "Before: empty form"), (f"{TMP}/errors.png", "After Send: two problems found")], f"{O}/m10-form-errors.png")
    grid([(f"{TMP}/sending.png", "Fixed and sent: sending"), (f"{TMP}/sent.png", "One second later: sent")], f"{O}/m10-form-sent.png")
    grid([(f"{TMP}/idle.png", "idle"), (f"{TMP}/sending.png", "sending"), (f"{TMP}/sent.png", "sent"), (f"{TMP}/failed.png", "failed")], f"{O}/m10-states.png", cols=4, width=1200)

    # 5. Built-in validation, read from the Console (real)
    pg = newpage()
    lines = ['document.querySelector("#name").validity.valueMissing',
             'document.querySelector("#name").validationMessage',
             'document.querySelector("#email").value = "you@"',
             'document.querySelector("#email").checkValidity()',
             'document.querySelector("#email").validationMessage']
    ent = []
    for ln in lines:
        ent.append(("input", ln)); v = pg.evaluate("(s) => JSON.stringify((0, eval)(s))", ln); ent.append(("result", v))
    pg.close(); facts["builtin"] = ent
    k.render_console(ent, f"{O}/m10-builtin-console.png")

    # 6. Without novalidate: the browser blocks submit; the submit event never fires
    pg = newpage()
    pg.evaluate("form.removeAttribute('novalidate'); window.__n = 0; form.addEventListener('submit', () => window.__n++)")
    pg.click("#send-btn"); pg.wait_for_timeout(200)
    facts["builtin_block"] = pg.evaluate("[window.__n, document.activeElement.id]"); pg.close()

    # 7. Client-side checks can be switched off from the Console (real)
    pg = newpage()
    lines = ['document.querySelector("#contact-form").checkValidity()',
             'for (const field of document.querySelectorAll("[required]")) { field.removeAttribute("required"); }',
             'document.querySelector("#contact-form").checkValidity()']
    ent = []
    for ln in lines:
        ent.append(("input", ln)); v = pg.evaluate("(s) => { const r = (0, eval)(s); return r === undefined ? 'undefined' : JSON.stringify(r); }", ln); ent.append(("result", v))
    pg.close(); facts["bypass"] = ent
    k.render_console(ent, f"{O}/m10-bypass-console.png")

    # 8. type="email" strips spaces; type="text" does not (real)
    pg = newpage()
    facts["sanitize"] = pg.evaluate("""() => { nameInput.value = "  Your Name  "; emailInput.value = "  you@example.com  ";
        return [JSON.stringify(nameInput.value), JSON.stringify(emailInput.value)]; }"""); pg.close()
finally:
    srv.terminate(); srv.wait()

# 9. trim (real Chromium evaluation)
ent = k.browser_eval("<p>trim</p>", ['"   " === ""', '"   ".length', '"   ".trim() === ""', '"  Your Name  ".trim()'])
facts["trim"] = ent
k.render_console(ent, f"{O}/m10-trim-console.png")

# 10. Break-it: no preventDefault -> page navigates, message lost (real)
srv = serve(f"{D}/no-prevent")
try:
    pg = k._b().new_page(viewport={"width": 390, "height": 500}, device_scale_factor=2)
    pg.goto(B + "/index.html"); pg.wait_for_timeout(250)
    pg.fill("#name", "Your Name"); pg.click("#send-btn"); pg.wait_for_timeout(800)
    facts["noprevent_url"] = pg.url
    facts["noprevent_after"] = pg.evaluate("[document.querySelector('#name').value, document.querySelector('#email-error').textContent, document.querySelector('#status').textContent]")
    pg.screenshot(path=f"{TMP}/np.png"); pg.close()
    frame(f"{TMP}/np.png", facts["noprevent_url"], f"{O}/m10-no-prevent.png")
finally:
    srv.terminate(); srv.wait()

# 11. Form-state diagram (illustration)
w, h = 900, 230
s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
s += "<defs><marker id='a' viewBox='0 0 10 10' refX='8' refY='5' markerWidth='7' markerHeight='7' orient='auto'><path d='M0 0L10 5L0 10z' fill='#4a6fa5'/></marker></defs>"
s += f"<text x='{w/2}' y='28' {F} font-size='15' font-weight='bold' text-anchor='middle' fill='#1b2b44'>One class on the form at a time</text>"
def box(x, y, label, sub, fill, st):
    return (f"<rect x='{x}' y='{y}' width='170' height='62' rx='10' fill='{fill}' stroke='{st}'/>"
            f"<text x='{x+85}' y='{y+27}' {F} font-size='16' font-weight='bold' text-anchor='middle' fill='#1b2b44'>{label}</text>"
            f"<text x='{x+85}' y='{y+47}' {F} font-size='11.5' text-anchor='middle' fill='#37474f'>{sub}</text>")
s += box(30, 90, "idle", "waiting for the visitor", "#eef1f6", "#9aa7bd")
s += box(330, 90, "sending", "button disabled", "#dbe8ff", "#7aa7e8")
s += box(660, 40, "sent", "thank-you, form reset", "#e3f4e5", "#7bbf7b")
s += box(660, 140, "failed", "error, values kept", "#fbe4e2", "#e08a8a")
s += "<line x1='202' y1='121' x2='326' y2='121' stroke='#4a6fa5' stroke-width='2' marker-end='url(#a)'/>"
s += f"<text x='264' y='112' {F} font-size='11.5' text-anchor='middle' fill='#37474f'>valid submit</text>"
s += "<line x1='502' y1='112' x2='656' y2='75' stroke='#4a6fa5' stroke-width='2' marker-end='url(#a)'/>"
s += "<line x1='502' y1='130' x2='656' y2='166' stroke='#4a6fa5' stroke-width='2' marker-end='url(#a)'/>"
s += f"<text x='575' y='82' {F} font-size='11.5' text-anchor='middle' fill='#37474f'>it worked</text>"
s += f"<text x='575' y='172' {F} font-size='11.5' text-anchor='middle' fill='#37474f'>it did not</text>"
s += f"<text x='115' y='178' {F} font-size='11.5' text-anchor='middle' fill='#37474f'>a problem found:</text>"
s += f"<text x='115' y='194' {F} font-size='11.5' text-anchor='middle' fill='#37474f'>stay idle, show errors</text>"
s += I.tag(w, h) + "</svg>"
k.render_svg(s, f"{O}/m10-state-diagram.png", 900)

# 12. Client check vs server check (illustration)
k.render_svg(I.flow([("Browser checks", "required, type, your JS|fast feedback = UX"),
                     ("Request travels", "anyone can change it|or send their own"),
                     ("Server checks", "checks again, every time|this is the security")],
                    title="Client-side validation is user experience, not security", h=160), f"{O}/m10-client-server.png", 900)

# 13. Optional break: no trim on the name -> three spaces pass (real)
k.render_page(f"{D}/no-trim/index.html", f"{O}/m10-no-trim.png", width=390, height=620, full_page=False,
              actions=[("fill", ("#name", "   ")), ("fill", ("#email", "you@example.com")),
                       ("fill", ("#message", "Hello, this is a practice message.")), ("click", "#send-btn"), ("wait", 1300)])
k.close()
print(json.dumps(facts, indent=1))
