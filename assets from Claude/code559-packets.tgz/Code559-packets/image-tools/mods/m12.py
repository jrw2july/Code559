"""Module 12 (Git/GitHub and Publishing) image build.
Every terminal image comes from a real git run in a throwaway repo with a throwaway HOME.
GitHub.com, VS Code and GitHub Desktop images are drawn illustrations.
Run: python3 /home/claude/build/mods/m12.py
"""
import sys, os, shutil, tempfile, html as H
sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I

O = k.OUT
DEMO = "/home/claude/build/demo/m12"
REPO = f"{DEMO}/portfolio"
COPY = f"{DEMO}/portfolio-copy"
PRAC = f"{DEMO}/git-practice"
LOG = f"{DEMO}/m12-run-log.txt"
for d in (REPO, COPY, PRAC):
    if os.path.exists(d):
        shutil.rmtree(d)
os.makedirs(REPO); os.makedirs(PRAC)

home = tempfile.mkdtemp(prefix="m12home-")
env = {"HOME": home, "XDG_CONFIG_HOME": home,
       "GIT_AUTHOR_DATE": "2026-10-09T09:00:00+0000",
       "GIT_COMMITTER_DATE": "2026-10-09T09:00:00+0000"}
for c in ("git config --global init.defaultBranch main",
          'git config --global user.name "Your Name"',
          'git config --global user.email "you@example.com"'):
    k.run(c, cwd=home, env=env)

log = []
def g(cmd, cwd=REPO):
    out = k.run(cmd, cwd=cwd, env=env)
    log.append(f"[{os.path.basename(cwd)}] $ {cmd}\n{out}\n")
    return (cmd, out)

def w(path, text, base=REPO):
    p = os.path.join(base, path)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", newline="\n") as f:
        f.write(text)
    log.append(f"[write] {path}\n{text}\n")

P = lambda folder: f"PS C:\\Users\\you\\Documents\\code559\\{folder}>"
term = lambda blocks, name, folder="portfolio", width=860: k.render_terminal(blocks, f"{O}/{name}", prompt=P(folder), width=width)

INDEX1 = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>My Portfolio</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>My Portfolio</h1>
</body>
</html>
"""
CSS1 = """body {
  font-family: system-ui, sans-serif;
  margin: 2rem;
}

h1 {
  color: #335;
}
"""
# ---------- 1. init, status, status --short, add, commit ----------
b1 = [g("git init")]
w("index.html", INDEX1); w("style.css", CSS1)
b1 += [g("git status"), g("git status --short")]
term(b1, "m12-init-status.png")

b2 = [g("git add index.html"), g("git status --short"),
      g('git commit -m "Add home page structure"'),
      g("git add style.css"), g('git commit -m "Add base styles"'),
      g("git status")]
term(b2, "m12-add-commit.png")

# ---------- 2. diff, diff --stat, diff --staged ----------
w("index.html", INDEX1.replace("  <h1>My Portfolio</h1>\n",
    "  <h1>My Portfolio</h1>\n  <p>Small projects I built while learning front-end development.</p>\n"))
w("style.css", CSS1.replace("color: #335;", "color: #1b2b44;"))
b3 = [g("git diff --stat"), g("git diff")]
term(b3, "m12-diff.png")
b4 = [g("git add index.html"), g("git diff --staged"),
      g('git commit -m "Add tagline to home page"'),
      g("git add style.css"), g('git commit -m "Darken heading color"')]
term(b4, "m12-diff-staged.png")

# ---------- 3. log ----------
b5 = [g("git log --oneline")]

# ---------- 4. branch, prove separation, merge, delete ----------
ABOUT = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>About | My Portfolio</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>About me</h1>
  <p>A short paragraph about you goes here.</p>
</body>
</html>
"""
b6 = b5 + [g("git switch -c add-about-page")]
w("about.html", ABOUT)
b6 += [g("git add about.html"), g('git commit -m "Add About page"'),
       g("git ls-files"), g("git switch main"), g("git ls-files"), g("git branch")]
term(b6, "m12-branch.png")
b7 = [g("git merge add-about-page"), g("git ls-files"), g("git log --oneline"),
      g("git branch -d add-about-page"), g("git branch")]
term(b7, "m12-merge.png")

# ---------- 5. restore ----------
w("index.html", "oops\n")
b8 = [g("git status --short"), g("git restore index.html"), g("git status --short")]
w("style.css", CSS1.replace("color: #335;", "color: red;"))
b8 += [g("git add style.css"), g("git status --short"), g("git restore --staged style.css"),
       g("git status --short"), g("git restore style.css"), g("git status")]
term(b8, "m12-restore.png")

# ---------- 6. .gitignore ----------
w(".vscode/settings.json", '{\n  "editor.wordWrap": "on"\n}\n')
w("Thumbs.db", "x")
w("debug.log", "test run\n")
b9 = [g("git status --short")]
w(".gitignore", ".vscode/\nThumbs.db\n*.log\n")
b9 += [g("git status --short"), g("git add .gitignore"), g('git commit -m "Add .gitignore"'),
       g("git status")]
term(b9, "m12-gitignore.png")

# ---------- 7. README, tag ----------
README = """# My Portfolio

## What it does
A small personal website with a Home page and an About page.

## Built with
HTML and CSS.

## What I learned
How to keep a project's history with Git: one change per commit,
branches for new pages, and a .gitignore for files that do not belong.

## Live site
https://your-username.github.io/portfolio/
"""
w("README.md", README)
b10 = [g("git add README.md"), g('git commit -m "Add README"'),
       g("git tag v1.0"), g("git tag"), g("git log --oneline --decorate")]
term(b10, "m12-tag.png")
g("git show --stat v1.0")

# ---------- 8. dubious ownership (real: copy owned by another uid) ----------
shutil.copytree(REPO, COPY, symlinks=True)
k.run(f"chown -R 1000:1000 {COPY}")
b11 = [g("git status", COPY)]
fix = f"git config --global --add safe.directory {COPY}"
b11 += [g(fix, COPY), g("git status", COPY)]
term(b11, "m12-dubious.png", folder="portfolio-copy", width=900)

# ---------- 9. Exercise: git-practice with a fast-forward, then a real conflict ----------
X = PRAC
e = [g("git init", X)]
w("notes.txt", "Favorite color: blue\n", X)
e += [g("git status --short", X), g("git add notes.txt", X), g('git commit -m "Add notes"', X),
      g("git switch -c add-hobby", X)]
w("notes.txt", "Favorite color: blue\nHobby: drawing\n", X)
e += [g("git diff", X), g("git add notes.txt", X), g("git diff --staged", X),
      g('git commit -m "Add hobby line"', X), g("git switch main", X), g("cat notes.txt", X),
      g("git merge add-hobby", X), g("git branch -d add-hobby", X), g("git log --oneline", X)]
# break it: same line changed on two branches
e += [g("git switch -c change-color", X)]
w("notes.txt", "Favorite color: green\nHobby: drawing\n", X)
e += [g("git add notes.txt", X), g('git commit -m "Change color to green"', X), g("git switch main", X)]
w("notes.txt", "Favorite color: orange\nHobby: drawing\n", X)
e += [g("git add notes.txt", X), g('git commit -m "Change color to orange"', X)]
conf = [g("git merge change-color", X), g("git status --short", X), g("cat notes.txt", X)]
term(conf, "m12-conflict.png", folder="git-practice")
w("notes.txt", "Favorite color: green\nHobby: drawing\n", X)
fixb = [g("git add notes.txt", X), g('git commit -m "Merge change-color, keep green"', X),
        g("git log --oneline --graph", X), g("git branch -d change-color", X)]
term(fixb, "m12-conflict-fixed.png", folder="git-practice")
e += [g("git status", X), g("git tag v0.1", X), g("git log --oneline --decorate -1", X)]
open(f"{DEMO}/m12-exercise-blocks.txt", "w").write("\n".join(f"$ {c}\n{o}" for c, o in e))

open(LOG, "w").write("\n".join(log))

# ======================= Illustrations =======================
F, M = I.F, I.M
esc = I.esc

def svg_open(w_, h_):
    return (f"<svg xmlns='http://www.w3.org/2000/svg' width='{w_}' height='{h_}' viewBox='0 0 {w_} {h_}'>"
            f"<defs><marker id='ar' viewBox='0 0 10 10' refX='8' refY='5' markerWidth='7' markerHeight='7' orient='auto'><path d='M0 0L10 5L0 10z' fill='#4a6fa5'/></marker>"
            f"<marker id='ag' viewBox='0 0 10 10' refX='8' refY='5' markerWidth='7' markerHeight='7' orient='auto'><path d='M0 0L10 5L0 10z' fill='#8a5a00'/></marker></defs>"
            f"<rect width='{w_}' height='{h_}' fill='#fff'/>")

def txt(x, y, s, size=13, fill="#1b2b44", anchor="start", bold=False, mono=False):
    fam = M if mono else F
    return f"<text x='{x}' y='{y}' {fam} font-size='{size}' fill='{fill}' text-anchor='{anchor}' font-weight='{'bold' if bold else 'normal'}' xml:space='preserve'>{esc(s)}</text>"

# --- mental model ---
W, Hh = 1000, 330
s = svg_open(W, Hh)
s += txt(W/2, 30, "Where your work lives in Git", 16, anchor="middle", bold=True)
boxes = [("Working folder", "the files you edit|in VS Code", "#fde2e2", "#e08a8a"),
         ("Staging area", "what goes into|the next commit", "#fff1d6", "#e0b060"),
         ("Commits", "saved snapshots|on your computer", "#e2f6e2", "#7bbf7b"),
         ("Remote (GitHub)", "a copy of your commits|online", "#e0f0ff", "#7aa7e8")]
bw, gap, top, bh = 180, 80, 60, 110
for i, (a, b_, f, st) in enumerate(boxes):
    x = 20 + i * (bw + gap)
    s += f"<rect x='{x}' y='{top}' width='{bw}' height='{bh}' rx='10' fill='{f}' stroke='{st}' stroke-width='1.5'/>"
    s += txt(x + bw/2, top + 34, a, 15, anchor="middle", bold=True)
    for j, ln in enumerate(b_.split("|")):
        s += txt(x + bw/2, top + 60 + j * 18, ln, 12.5, "#37474f", "middle")
    if i < 3:
        ax = x + bw + 4
        cmd = ["git add", "git commit", "git push"][i]
        s += f"<line x1='{ax}' y1='{top+bh/2}' x2='{ax+gap-10}' y2='{top+bh/2}' stroke='#4a6fa5' stroke-width='2.2' marker-end='url(#ar)'/>"
        s += txt(ax + (gap-6)/2, top + bh/2 - 12, cmd, 11.5, "#0b57d0", "middle", mono=True)
# looks-at brackets
y2 = top + bh + 30
def bracket(x1, x2, y, label, color):
    out = f"<path d='M{x1} {y} v10 H{x2} v-10' fill='none' stroke='{color}' stroke-width='1.6'/>"
    out += txt((x1+x2)/2, y + 30, label, 12.5, color, "middle", mono=True)
    return out
s += bracket(20 + 20, 20 + bw + gap + bw - 20, y2, "git diff  (folder vs staging)", "#8a5a00")
s += bracket(20 + bw + gap + 20, 20 + 2*(bw+gap) + bw - 20, y2 + 50, "git diff --staged  (staging vs last commit)", "#8a5a00")
s += txt(20 + 2*(bw+gap) + bw/2, y2 + 108, "git log --oneline  lists the commits", 12.5, "#2e6b2e", "middle", mono=True)
s += txt(40, y2 + 108, "git status  reports on all of them", 12.5, "#0b57d0", "start", mono=True)
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m12-mental-model.png", W)

# --- VS Code Source Control: three moments ---
W, Hh = 1000, 420
s = svg_open(W, Hh)
s += f"<rect x='0.5' y='0.5' width='{W-1}' height='{Hh-1}' rx='8' fill='#fff' stroke='#c9d1da'/>"
s += txt(W/2, 30, "VS Code Source Control view: three moments", 15, anchor="middle", bold=True)
pw, ph, py = 300, 300, 52
def panel(x, title, body):
    out = f"<rect x='{x}' y='{py}' width='{pw}' height='{ph}' rx='6' fill='#f3f3f3' stroke='#d0d0d0'/>"
    out += f"<rect x='{x}' y='{py}' width='{pw}' height='30' rx='6' fill='#e8e8e8'/>"
    out += txt(x + 12, py + 20, "SOURCE CONTROL", 11, "#555")
    out += txt(x + pw/2, py + ph + 26, title, 13, "#1b2b44", "middle", bold=True)
    return out + body
def btn(x, y, wid, label, primary=True):
    fill = "#0078d4" if primary else "#e5e5e5"; col = "#fff" if primary else "#222"
    return f"<rect x='{x}' y='{y}' width='{wid}' height='28' rx='3' fill='{fill}'/>" + txt(x + wid/2, y + 19, label, 12.5, col, "middle")
x1, x2, x3 = 30, 350, 670
b = txt(x1 + 14, py + 62, "The folder that is open does not", 12, "#333")
b += txt(x1 + 14, py + 80, "have a Git repository yet.", 12, "#333")
b += btn(x1 + 14, py + 100, pw - 28, "Initialize Repository")
b += txt(x1 + 14, py + 160, "Same job as: git init", 12, "#0b57d0", mono=True)
s += panel(x1, "1. Start: Initialize Repository", b)
b = f"<rect x='{x2+12}' y='{py+42}' width='{pw-24}' height='28' rx='3' fill='#fff' stroke='#c8c8c8'/>" + txt(x2 + 20, py + 61, "Add tagline to home page", 12, "#333")
b += btn(x2 + 12, py + 78, pw - 24, "Commit")
b += txt(x2 + 14, py + 130, "Staged Changes", 11.5, "#555", bold=True)
b += txt(x2 + 26, py + 152, "index.html", 12.5, "#222") + txt(x2 + pw - 22, py + 152, "M", 12, "#9a6700", "end", bold=True)
b += txt(x2 + 14, py + 184, "Changes", 11.5, "#555", bold=True)
b += txt(x2 + 26, py + 206, "style.css", 12.5, "#222") + txt(x2 + pw - 22, py + 206, "M", 12, "#9a6700", "end", bold=True)
b += f"<rect x='{x2+pw-60}' y='{py+192}' width='20' height='20' rx='3' fill='#fff' stroke='#0078d4'/>" + txt(x2 + pw - 50, py + 207, "+", 15, "#0078d4", "middle", bold=True)
b += txt(x2 + pw - 22, py + 236, "+ = Stage Changes", 11.5, "#0078d4", "end")
b += txt(x2 + 14, py + 268, "Same jobs as: git add, git commit", 12, "#0b57d0", mono=True)
s += panel(x2, "2. Stage Changes, then Commit", b)
b = txt(x3 + 14, py + 62, "First time, no GitHub copy yet:", 12, "#333")
b += txt(x3 + 14, py + 80, "Command Palette (Ctrl+Shift+P) →", 12, "#333")
b += btn(x3 + 14, py + 92, pw - 28, "Publish to GitHub", False)
b += txt(x3 + 14, py + 150, "Already on GitHub:", 12, "#333")
b += btn(x3 + 14, py + 162, pw - 28, "Sync Changes")
b += txt(x3 + 14, py + 214, "Sync Changes pulls first,", 12, "#333")
b += txt(x3 + 14, py + 232, "then pushes your commits.", 12, "#333")
b += txt(x3 + 14, py + 268, "Same jobs as: git pull, git push", 12, "#0b57d0", mono=True)
s += panel(x3, "3. Publish to GitHub / Sync Changes", b)
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m12-vscode-source-control.png", W)

# --- GitHub pages: common chrome ---
def gh_chrome(w_, h_, active_tab, repo="portfolio"):
    out = svg_open(w_, h_)
    out += f"<rect x='0.5' y='0.5' width='{w_-1}' height='{h_-1}' rx='8' fill='#fff' stroke='#d0d7de'/>"
    out += f"<rect x='1' y='1' width='{w_-2}' height='50' rx='8' fill='#f6f8fa'/>"
    out += f"<circle cx='30' cy='26' r='12' fill='#24292f'/>" + txt(54, 31, f"your-username / ", 14, "#24292f") + txt(54 + 118, 31, repo, 14, "#24292f", bold=True)
    x = 30
    for t in ["Code", "Issues", "Pull requests", "Actions", "Settings"]:
        act = t == active_tab
        out += txt(x, 80, t, 13, "#24292f" if act else "#57606a", bold=act)
        if act: out += f"<rect x='{x}' y='89' width='{len(t)*7.6}' height='2' fill='#fd8c73'/>"
        x += len(t) * 8 + 26
    out += f"<line x1='0' y1='92' x2='{w_}' y2='92' stroke='#d8dee4'/>"
    return out

# --- Issue + PR with Closes #1 ---
W, Hh = 1000, 470
s = gh_chrome(W, Hh, "Pull requests")
# issue card (left)
s += f"<rect x='30' y='110' width='330' height='150' rx='6' fill='#fff' stroke='#d0d7de'/>"
s += txt(46, 136, "Issue #1", 12, "#57606a")
s += txt(46, 160, "Add a Contact page", 16, "#24292f", bold=True)
s += f"<rect x='46' y='174' width='64' height='22' rx='11' fill='#1f883d'/>" + txt(78, 189, "Open", 12, "#fff", "middle")
s += txt(46, 222, "The site needs a way for visitors", 12.5, "#24292f")
s += txt(46, 240, "to reach me.", 12.5, "#24292f")
# arrow
s += f"<line x1='366' y1='185' x2='404' y2='185' stroke='#8a5a00' stroke-width='2' marker-end='url(#ag)'/>"
s += txt(385, 176, "linked", 11, "#8a5a00", "middle")
# PR card (right)
s += f"<rect x='410' y='110' width='560' height='330' rx='6' fill='#fff' stroke='#d0d7de'/>"
s += txt(426, 136, "Pull request #2", 12, "#57606a")
s += txt(426, 160, "Add Contact page", 16, "#24292f", bold=True)
s += f"<rect x='426' y='174' width='64' height='22' rx='11' fill='#1f883d'/>" + txt(458, 189, "Open", 12, "#fff", "middle")
s += txt(500, 189, "wants to merge add-contact-page into main", 12.5, "#57606a")
s += f"<rect x='426' y='208' width='528' height='92' rx='6' fill='#f6f8fa' stroke='#d0d7de'/>"
s += txt(440, 230, "Description", 11.5, "#57606a", bold=True)
s += txt(440, 254, "Adds contact.html with a short form and a link", 12.5, "#24292f")
s += txt(440, 272, "from the Home page.", 12.5, "#24292f")
s += f"<rect x='438' y='279' width='80' height='18' rx='3' fill='#fff8c5'/>" + txt(442, 292, "Closes #1", 12.5, "#24292f", mono=True, bold=True)
s += txt(530, 292, "← keyword + issue number", 11.5, "#8a5a00")
s += txt(426, 330, "Tabs on this page:  Conversation   Commits   Files changed", 12.5, "#57606a")
s += f"<rect x='426' y='350' width='528' height='70' rx='6' fill='#fff' stroke='#1f883d'/>"
s += txt(442, 374, "When this pull request is merged into main,", 12.5, "#24292f")
s += txt(442, 394, "issue #1 closes automatically.", 12.5, "#24292f", bold=True)
s += f"<rect x='800' y='366' width='140' height='30' rx='6' fill='#1f883d'/>" + txt(870, 386, "Merge", 13, "#fff", "middle", bold=True)
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m12-issue-pr.png", W)

# --- line comment on Files changed ---
W, Hh = 1000, 400
s = gh_chrome(W, Hh, "Pull requests")
s += txt(30, 120, "Pull request #2  ›  Files changed", 13, "#24292f", bold=True)
s += f"<rect x='30' y='134' width='940' height='240' rx='6' fill='#fff' stroke='#d0d7de'/>"
s += f"<rect x='30' y='134' width='940' height='30' rx='6' fill='#f6f8fa'/>" + txt(44, 154, "contact.html", 12.5, "#24292f", mono=True)
rows = [("+", "9", '  <h1>Contact</h1>'), ("+", "10", '  <form>'), ("+", "11", '    <label>Email <input type="email"></label>')]
for i, (sg, n, code) in enumerate(rows):
    y = 172 + i * 24
    s += f"<rect x='31' y='{y}' width='938' height='24' fill='#e6ffec'/>"
    s += txt(70, y + 17, n, 12, "#57606a", "end", mono=True) + txt(84, y + 17, sg + " " + code, 12.5, "#24292f", mono=True)
s += f"<rect x='36' y='{172+2*24+3}' width='18' height='18' rx='4' fill='#0969da'/>" + txt(45, 172 + 2*24 + 16, "+", 14, "#fff", "middle", bold=True)
s += txt(40, 172 + 2*24 + 44, "↑ hover a line number, click the blue icon", 11.5, "#0969da")
s += f"<rect x='84' y='272' width='870' height='88' rx='6' fill='#fff' stroke='#d0d7de'/>"
s += txt(98, 296, "Note to self: add a name field before the email field,", 12.5, "#24292f")
s += txt(98, 314, "and give the input an id so the label can use for=.", 12.5, "#24292f")
s += btn(700, 324, 110, "Start a review", False) if False else ""
s += f"<rect x='690' y='324' width='120' height='28' rx='6' fill='#f6f8fa' stroke='#d0d7de'/>" + txt(750, 343, "Start a review", 12.5, "#24292f", "middle")
s += f"<rect x='820' y='324' width='120' height='28' rx='6' fill='#1f883d'/>" + txt(880, 343, "Comment", 12.5, "#fff", "middle", bold=True)
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m12-line-comment.png", W)

# --- release page ---
W, Hh = 1000, 360
s = gh_chrome(W, Hh, "Code")
s += txt(30, 124, "Releases  ›  v1.0", 13, "#24292f", bold=True)
s += f"<rect x='30' y='138' width='940' height='190' rx='6' fill='#fff' stroke='#d0d7de'/>"
s += txt(50, 172, "Portfolio v1.0", 20, "#24292f", bold=True)
s += f"<rect x='220' y='156' width='54' height='22' rx='11' fill='#fff' stroke='#1f883d'/>" + txt(247, 171, "Latest", 11.5, "#1a7f37", "middle")
s += txt(50, 200, "tag: v1.0   ·   branch: main", 12.5, "#57606a", mono=True)
s += txt(50, 232, "First complete version: Home, About and Contact pages,", 13, "#24292f")
s += txt(50, 252, "a README, and a .gitignore.", 13, "#24292f")
s += txt(50, 288, "Assets:  Source code (zip)   Source code (tar.gz)", 12.5, "#0969da")
s += txt(50, 312, "A release is built on a Git tag: it points at one exact commit.", 12, "#8a5a00")
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m12-release.png", W)

# --- GitHub Desktop (awareness only) ---
W, Hh = 1000, 360
s = svg_open(W, Hh)
s += f"<rect x='0.5' y='0.5' width='{W-1}' height='{Hh-1}' rx='8' fill='#fff' stroke='#c9d1da'/>"
s += f"<rect x='1' y='1' width='{W-2}' height='28' rx='8' fill='#24292f'/>" + txt(14, 19, "File   Edit   View   Repository   Branch   Help", 12, "#fff")
s += f"<rect x='1' y='29' width='{W-2}' height='46' fill='#2f363d'/>"
for i, (a, b_) in enumerate([("Current repository", "portfolio"), ("Current branch", "main"), ("Fetch origin", "")]):
    x = 14 + i * 250
    s += txt(x, 47, a, 10.5, "#9aa4ad") + txt(x, 65, b_, 13, "#fff", bold=True)
s += f"<rect x='1' y='75' width='300' height='{Hh-76}' fill='#f6f8fa'/>"
s += txt(40, 100, "Changes", 13, "#24292f", bold=True) + txt(170, 100, "History", 13, "#57606a")
s += f"<rect x='20' y='106' width='110' height='2' fill='#0969da'/>"
s += txt(24, 136, "☑ index.html", 12.5, "#24292f") + txt(280, 136, "M", 12, "#9a6700", "end", bold=True)
s += f"<rect x='14' y='{Hh-110}' width='274' height='28' rx='4' fill='#fff' stroke='#d0d7de'/>" + txt(24, Hh - 91, "Summary", 12, "#8c959f")
s += f"<rect x='14' y='{Hh-72}' width='274' height='30' rx='4' fill='#0969da'/>" + txt(151, Hh - 52, "Commit to main", 12.5, "#fff", "middle", bold=True)
s += txt(330, 110, "index.html", 12.5, "#24292f", mono=True)
s += txt(330, 138, "   <h1>My Portfolio</h1>", 12.5, "#24292f", mono=True)
s += f"<rect x='320' y='144' width='660' height='22' fill='#e6ffec'/>" + txt(330, 160, "+  <p>Small projects I built while learning…</p>", 12.5, "#24292f", mono=True)
s += txt(330, 214, "GitHub Desktop shows the same ideas as the terminal:", 13, "#1b2b44", bold=True)
s += txt(330, 238, "Changes = git status + git diff,  History = git log,", 12.5, "#37474f")
s += txt(330, 258, "the commit box = git commit,  Fetch / Push origin = talk to GitHub.", 12.5, "#37474f")
s += txt(330, 290, "Awareness only in this course. You keep using the terminal.", 12.5, "#8a5a00")
s += I.tag(W, Hh) + "</svg>"
k.render_svg(s, f"{O}/m12-github-desktop.png", W)

k.close()
print("\n".join(log))
