"""Module 3 (Responsive Layout) images. Run: python3 /home/claude/build/mods/m03.py
Real Chromium renders + measurements; illustrations are tagged."""
import sys, os, json, threading, functools, http.server, socketserver
sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I
from PIL import Image, ImageDraw, ImageFont, ImageOps

O = k.OUT
D = "/home/claude/build/demo/m03"
LAB = f"{D}/layout-lab"
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_R = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

# ---------- demo images for srcset (each image shows its own file name) ----------
os.makedirs(f"{LAB}/images", exist_ok=True)
for w in (400, 800, 1600):
    h = w * 5 // 8
    im = Image.new("RGB", (w, h), (54, 98, 140))
    d = ImageDraw.Draw(im)
    for i in range(0, w, w // 10):
        d.line([(i, 0), (i + h, h)], fill=(70, 118, 163), width=max(2, w // 80))
    f = ImageFont.truetype(FONT, w // 13)
    t = f"photo-one-{w}.jpg"
    bb = d.textbbox((0, 0), t, font=f)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    d.rectangle([(w - tw) // 2 - w // 40, (h - th) // 2 - w // 40, (w + tw) // 2 + w // 40, (h + th) // 2 + w // 30], fill=(255, 255, 255))
    d.text(((w - tw) // 2, (h - th) // 2 - bb[1]), t, font=f, fill=(30, 40, 60))
    im.save(f"{LAB}/images/photo-one-{w}.jpg", quality=85)

# break-it variants
src = open(f"{LAB}/index.html").read()
open(f"{LAB}/no-viewport.html", "w").write(src.replace('  <meta name="viewport" content="width=device-width, initial-scale=1">\n', ""))
css = open(f"{LAB}/style.css").read()
mq_start = css.index("/* Wider screens")
mq = css[mq_start:]
base_start = css.index("/* Base rules")
swapped = css[:base_start] + mq + "\n" + css[base_start:mq_start]
open(f"{LAB}/style-swapped.css", "w").write(swapped)
open(f"{LAB}/swapped.html", "w").write(src.replace('href="style.css"', 'href="style-swapped.css"'))

MEASURE = """() => { const g=document.querySelector('.card-grid'); const h=document.querySelector('.site-header');
 const img=document.querySelector('.featured img'); const cs=getComputedStyle(g).gridTemplateColumns;
 return {innerWidth: innerWidth, gridTemplateColumns: cs, columns: cs.split(' ').length,
   headerDirection: getComputedStyle(h).flexDirection, featuredSpan: getComputedStyle(document.querySelector(".featured")).gridColumnStart,
   currentSrc: img.currentSrc.split('/').pop(), scrollWidth: document.documentElement.scrollWidth}}"""

b = k._b()
results = {}

def shot(path, out, width, height=800, dpr=2, mobile=False, full=True, clip=None):
    ctx = b.new_context(viewport={"width": width, "height": height}, device_scale_factor=dpr, is_mobile=mobile, has_touch=mobile)
    pg = ctx.new_page(); pg.goto("file://" + path); pg.wait_for_timeout(400)
    pg.evaluate("() => { for (const i of document.images) i.loading = 'eager'; }"); pg.wait_for_timeout(300)
    m = pg.evaluate(MEASURE) if "layout-lab" in path else None
    if out: pg.screenshot(path=out, full_page=full, clip=clip)
    ctx.close(); return m

# ---------- measurements: columns and chosen image at three widths, DPR 1 and 2 ----------
for dpr in (1, 2):
    for w in (390, 800, 1200):
        ctx = b.new_context(viewport={"width": w, "height": 800}, device_scale_factor=dpr)
        pg = ctx.new_page(); pg.goto(f"file://{LAB}/index.html"); pg.wait_for_timeout(400)
        results[f"dpr{dpr}-{w}"] = pg.evaluate(MEASURE); ctx.close()

# ---------- real renders at 390 / 800 / 1200 ----------
results["r390"] = shot(f"{LAB}/index.html", f"{O}/m03-grid-390.png", 390)
results["r800"] = shot(f"{LAB}/index.html", f"{O}/m03-grid-800.png", 800)
results["r1200"] = shot(f"{LAB}/index.html", f"{O}/m03-grid-1200.png", 1200, dpr=1)

# ---------- break it: no viewport meta, phone emulation ----------
tmp1, tmp2 = "/tmp/m03-vp-yes.png", "/tmp/m03-vp-no.png"
results["phone-with-meta"] = shot(f"{LAB}/index.html", tmp1, 390, 700, dpr=2, mobile=True, full=False)
results["phone-no-meta"] = shot(f"{LAB}/no-viewport.html", tmp2, 390, 700, dpr=2, mobile=True, full=False)

def side_by_side(paths, labels, out, pad=24, top=54):
    ims = [ImageOps.expand(Image.open(p), border=2, fill=(160, 170, 182)) for p in paths]
    W = sum(i.width for i in ims) + pad * (len(ims) + 1); H = max(i.height for i in ims) + top + pad
    can = Image.new("RGB", (W, H), (233, 238, 243)); d = ImageDraw.Draw(can); f = ImageFont.truetype(FONT, 26)
    x = pad
    for im, lab in zip(ims, labels):
        d.text((x, 14), lab, font=f, fill=(29, 39, 51)); can.paste(im, (x, top)); x += im.width + pad
    can.save(out)

side_by_side([tmp1, tmp2], ["With the viewport tag", "Viewport tag removed"], f"{O}/m03-viewport-break.png")

# ---------- break it: media query above the base rules, at 1200 ----------
tmp3, tmp4 = "/tmp/m03-order-ok.png", "/tmp/m03-order-bad.png"
results["order-ok-1200"] = shot(f"{LAB}/index.html", tmp3, 1200, 800, dpr=1, full=False, clip={"x": 0, "y": 0, "width": 1200, "height": 260})
results["order-swapped-1200"] = shot(f"{LAB}/swapped.html", tmp4, 1200, 800, dpr=1, full=False, clip={"x": 0, "y": 0, "width": 1200, "height": 260})
a, c = Image.open(tmp3), Image.open(tmp4)
can = Image.new("RGB", (a.width + 40, a.height + c.height + 130), (233, 238, 243)); d = ImageDraw.Draw(can); f = ImageFont.truetype(FONT, 22)
d.text((20, 14), "Media query AFTER the base rules (correct)", font=f, fill=(29, 39, 51)); can.paste(ImageOps.expand(a, border=1, fill=(160, 170, 182)), (20, 48))
d.text((20, a.height + 72), "Media query moved ABOVE the base rules", font=f, fill=(150, 40, 30)); can.paste(ImageOps.expand(c, border=1, fill=(160, 170, 182)), (20, a.height + 106))
can.save(f"{O}/m03-rule-order.png")

# ---------- span 2 without a media query, at 390 (measured, no image) ----------
ctx = b.new_context(viewport={"width": 390, "height": 800})
pg = ctx.new_page(); pg.goto(f"file://{LAB}/index.html")
pg.add_style_tag(content=".featured{grid-column: span 2}")
results["span2-always-390"] = pg.evaluate(MEASURE); ctx.close()

# ---------- box-sizing ----------
results["box"] = None
ctx = b.new_context(viewport={"width": 520, "height": 300}, device_scale_factor=2)
pg = ctx.new_page(); pg.goto(f"file://{D}/box-lab/index.html"); pg.wait_for_timeout(200)
results["box"] = pg.evaluate("() => [...document.querySelectorAll('.box')].map(b => ({cls: b.className, offsetWidth: b.offsetWidth, contentWidth: getComputedStyle(b).width}))")
pg.screenshot(path=f"{O}/m03-box-sizing.png", full_page=True); ctx.close()

# ---------- layout shift: images that never arrive (served over local HTTP) ----------
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = socketserver.TCPServer(("127.0.0.1", 0), functools.partial(Q, directory=D)); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
ctx = b.new_context(viewport={"width": 800, "height": 420}, device_scale_factor=2)
pg = ctx.new_page(); pg.route("**/never/**", lambda route: None)
pg.goto(f"http://127.0.0.1:{port}/shift-lab/index.html", wait_until="domcontentloaded"); pg.wait_for_timeout(500)
results["shift"] = pg.evaluate("() => [...document.images].map(i => ({complete: i.complete, height: Math.round(i.getBoundingClientRect().height)}))")
import base64
cdp = ctx.new_cdp_session(pg)  # Playwright's screenshot waits for the hanging images; CDP captures the page as it is now
open(f"{O}/m03-layout-shift.png", "wb").write(base64.b64decode(cdp.send("Page.captureScreenshot", {"format": "png"})["data"]))
ctx.close()
srv.shutdown()

# ---------- illustrations ----------
F, M = I.F, I.M
def box_model_svg(w=900, h=380):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' fill='#fff'/>"
    layers = [("margin", "#fdf0d5", "#e0b25c", 30, 20), ("border", "#1d3557", "#1d3557", 110, 70), ("padding", "#cfe3d4", "#6aa57a", 130, 90), ("content", "#dbe8ff", "#7aa7e8", 200, 140)]
    cx = 330
    for name, fill, stroke, inset_x, inset_y in layers:
        x = inset_x; y = inset_y - 0; ww = 2 * (cx - inset_x); hh = h - 2 * inset_y
        s += f"<rect x='{x}' y='{y}' width='{ww}' height='{hh}' fill='{fill}' stroke='{stroke}' stroke-width='{2 if name!='border' else 0}' {'stroke-dasharray=\"6 4\"' if name=='margin' else ''}/>"
    s += f"<rect x='130' y='90' width='400' height='200' fill='#cfe3d4'/>"
    s += f"<rect x='200' y='140' width='260' height='100' fill='#dbe8ff' stroke='#7aa7e8'/>"
    s += f"<text x='330' y='186' {F} font-size='16' font-weight='bold' text-anchor='middle' fill='#1b2b44'>content</text><text x='330' y='208' {F} font-size='12.5' text-anchor='middle' fill='#37474f'>your text and images</text>"
    s += f"<text x='145' y='115' {F} font-size='14' font-weight='bold' fill='#2f6b40'>padding</text>"
    s += f"<text x='122' y='86' {F} font-size='14' font-weight='bold' fill='#fff'>border</text>"
    s += f"<text x='44' y='46' {F} font-size='14' font-weight='bold' fill='#8a5a00'>margin</text>"
    notes = [("content", "width and height set this", "(in the default content-box model)"), ("padding", "space inside the border;", "takes the background color"),
             ("border", "the visible edge", ""), ("margin", "space outside the border;", "pushes other boxes away")]
    y = 70
    for a, b1, b2 in notes:
        s += f"<text x='660' y='{y}' {F} font-size='15' font-weight='bold' fill='#1b2b44'>{a}</text><text x='660' y='{y+19}' {F} font-size='12.5' fill='#37474f'>{I.esc(b1)}</text><text x='660' y='{y+36}' {F} font-size='12.5' fill='#37474f'>{I.esc(b2)}</text>"
        y += 72
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(box_model_svg(), f"{O}/m03-box-model.png", 900)

def devtools_svg(w=980, h=520):
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'><rect width='{w}' height='{h}' rx='8' fill='#fff' stroke='#c9d1da'/>"
    s += f"<rect width='{w}' height='40' rx='8' fill='#dfe3e8'/><rect y='32' width='{w}' height='8' fill='#dfe3e8'/>"
    s += f"<rect x='14' y='8' width='520' height='24' rx='12' fill='#f1f3f4'/><text x='28' y='25' {F} font-size='12.5' fill='#202124'>file:///C:/Users/you/Documents/code559/layout-lab/index.html</text>"
    # page area with device toolbar
    s += f"<rect x='0' y='40' width='620' height='{h-40}' fill='#f1f3f4'/>"
    s += f"<rect x='0' y='40' width='620' height='34' fill='#fafafa' stroke='#dadce0'/>"
    s += f"<text x='16' y='62' {F} font-size='12.5' fill='#202124'>Dimensions: Responsive &#9662;</text>"
    s += f"<rect x='200' y='48' width='54' height='20' rx='3' fill='#fff' stroke='#9aa0a6'/><text x='227' y='63' {M} font-size='12.5' text-anchor='middle' fill='#202124'>390</text>"
    s += f"<text x='262' y='63' {F} font-size='12.5' fill='#5f6368'>&#215;</text>"
    s += f"<rect x='276' y='48' width='54' height='20' rx='3' fill='#fff' stroke='#9aa0a6'/><text x='303' y='63' {M} font-size='12.5' text-anchor='middle' fill='#202124'>844</text>"
    s += f"<text x='345' y='62' {F} font-size='12.5' fill='#5f6368'>100% &#9662;</text>"
    s += f"<rect x='215' y='92' width='190' height='{h-112}' fill='#fff' stroke='#9aa0a6'/>"
    s += f"<rect x='215' y='92' width='190' height='54' fill='#1d3557'/><text x='226' y='112' {F} font-size='11' fill='#fff' font-weight='bold'>Layout lab</text>"
    for i in range(4): s += f"<rect x='{226+i*44}' y='122' width='38' height='16' rx='3' fill='none' stroke='#a8c0dc'/>"
    for i in range(3): s += f"<rect x='225' y='{160+i*92}' width='170' height='80' rx='5' fill='#fff' stroke='#ccd5df'/>"
    s += f"<rect x='405' y='{h/2}' width='8' height='40' rx='3' fill='#9aa0a6'/>"
    s += f"<text x='420' y='{h/2+24}' {F} font-size='11.5' fill='#5f6368'>drag to resize</text>"
    # devtools panel
    s += f"<rect x='620' y='40' width='{w-620}' height='{h-40}' fill='#fff' stroke='#dadce0'/>"
    s += f"<rect x='620' y='40' width='{w-620}' height='30' fill='#f1f3f4'/>"
    s += f"<rect x='630' y='47' width='18' height='16' rx='2' fill='none' stroke='#5f6368'/><rect x='656' y='45' width='14' height='20' rx='3' fill='#d2e3fc' stroke='#1a73e8' stroke-width='2'/>"
    s += f"<text x='682' y='60' {F} font-size='12' fill='#5f6368'>Elements&#160;&#160;&#160;Console&#160;&#160;&#160;Sources</text>"
    s += f"<line x1='663' y1='76' x2='663' y2='120' stroke='#e76f51' stroke-width='2'/><text x='640' y='140' {F} font-size='12.5' fill='#b23c17' font-weight='bold'>The device toolbar toggle</text>"
    s += f"<text x='640' y='158' {F} font-size='12' fill='#37474f'>Ctrl+Shift+M with DevTools open</text>"
    s += f"<text x='640' y='210' {F} font-size='13' font-weight='bold' fill='#1b2b44'>Try these widths</text>"
    for i, (a, b1) in enumerate([("390", "a phone"), ("800", "a tablet"), ("1200", "a laptop")]):
        s += f"<text x='640' y='{236+i*22}' {M} font-size='12.5' fill='#202124'>{a}</text><text x='690' y='{236+i*22}' {F} font-size='12.5' fill='#37474f'>{b1}</text>"
    s += f"<text x='640' y='330' {F} font-size='12' fill='#5f6368'>Device mode is a simulation.</text><text x='640' y='348' {F} font-size='12' fill='#5f6368'>Check on a real phone too.</text>"
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(devtools_svg(), f"{O}/m03-devtools-device.png", 980)

k.close()
print(json.dumps(results, indent=1))
