"""Module 11 images: Debugging and Testing. Regenerate with: python3 /home/claude/build/mods/m11.py"""
import sys, os, html, shutil, json
sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I

O = k.OUT
D = "/home/claude/build/demo/m11"
LOG = {}

# ---------- own helpers (do not edit shared files) ----------
def capture(html_path, actions=None):
    """Load a page from a FILE (so file names and line numbers are real) and collect
    uncaught exceptions (via the DevTools protocol) and console messages, in order.
    Returns list of (kind, text, location)."""
    page = k._b().new_page(viewport={"width": 800, "height": 600})
    out = []
    cdp = page.context.new_cdp_session(page)
    cdp.send("Runtime.enable")
    def on_exc(p):
        d = p["exceptionDetails"]
        desc = d.get("exception", {}).get("description") or d.get("text")
        first = desc.split("\n")[0]
        url = d.get("url") or (d.get("stackTrace", {}).get("callFrames") or [{}])[0].get("url", "")
        line = d.get("lineNumber", 0) + 1
        if not first.startswith("Uncaught"): first = "Uncaught " + first
        frames = (d.get("stackTrace") or {}).get("callFrames") or []
        stack = [(f"at {fr['functionName']} ({os.path.basename(fr['url'])}:{fr['lineNumber']+1}:{fr['columnNumber']+1})" if fr['functionName']
                  else f"at {os.path.basename(fr['url'])}:{fr['lineNumber']+1}:{fr['columnNumber']+1}") for fr in frames]
        if frames:
            url = frames[0]["url"]; line = frames[0]["lineNumber"] + 1
        out.append(("error", first, f"{os.path.basename(url)}:{line}", stack))
    cdp.on("Runtime.exceptionThrown", on_exc)
    def on_console(m):
        loc = m.location or {}
        out.append(("log", m.text, f"{os.path.basename(loc.get('url',''))}:{loc.get('lineNumber',0)+1}", []))
    page.on("console", on_console)
    page.goto("file://" + os.path.abspath(html_path))
    page.wait_for_timeout(200)
    for kind, arg in (actions or []):
        if kind == "click": page.click(arg)
        elif kind == "fill": page.fill(arg[0], arg[1])
        elif kind == "press": page.keyboard.press(arg)
        page.wait_for_timeout(60)
    page.wait_for_timeout(100)
    page.close()
    return out

CCSS = k.CONSOLE_CSS + """
.row .loc{margin-left:auto;padding-left:16px;color:#1a0dab;text-decoration:underline;white-space:nowrap;flex:none}
.row.error .loc{color:#1a0dab}
.row .st{display:block;color:#b3261e;padding-left:18px}
"""

def console_img(entries, out_png, width=820):
    """entries: (kind, text, location, stack_lines). Draws a Console-styled frame with
    the file:line link on the right, as DevTools places it."""
    glyph = {"input": "›", "result": "‹", "error": "⊗", "log": " ", "warning": "⚠"}
    rows = ""
    for kind, text, loc, stack in entries:
        st = "".join(f"<span class='st'>{html.escape(s)}</span>" for s in stack)
        locs = f"<span class='loc'>{html.escape(loc)}</span>" if loc else ""
        rows += f"<div class='row {kind}'><span class='g'>{glyph.get(kind,' ')}</span><span class='t'>{html.escape(text)}{st}</span>{locs}</div>"
    doc = f"<style>{CCSS}</style><div class='win'><div class='tb'><span>Elements</span><b>Console</b><span>Sources</span><span>Network</span></div>{rows}<div class='row input'><span class='g'>›</span><span class='t'>&nbsp;</span></div></div>"
    return k._shot(doc, out_png, width)

def rel_stack(stack):
    """Turn file:///long/path/script.js:19:11 into script.js:19:11 so no build path shows."""
    res = []
    for s in stack:
        if "file://" in s:
            pre, post = s.split("file://", 1)
            post = post.rstrip(")")
            res.append(pre + os.path.basename(post) + (")" if s.endswith(")") else ""))
        else:
            res.append(s)
    return res

# ---------- 1. three real errors from files ----------
errs = []
for name in ["error-syntax", "error-ref", "error-type"]:
    got = capture(f"{D}/{name}/index.html")
    LOG[name] = got
    for kind, text, loc, stack in got:
        errs.append((kind, text, loc, rel_stack(stack)))
console_img([e for e in errs if e[0] == "error"][2:], f"{O}/m11-console-typeerror.png")
console_img([e for e in errs if e[0] == "error"][:2], f"{O}/m11-console-syntax-reference.png")

# ---------- 2. debugging a selector in the Console (real evaluation) ----------
page_html = open(f"{D}/error-type/index.html").read().replace('<script src="script.js"></script>', "")
sel = k.browser_eval(page_html, [
    'document.querySelector("#mesage-button")',
    'document.querySelector("#message-button")',
    'document.querySelectorAll("button").length',
])
LOG["selector"] = sel
k.render_console(sel, f"{O}/m11-selector-null.png")

# ---------- 3. bug-hunt page: step versions ----------
def make_step(name, fixes, html_fix=False):
    dst = f"{D}/{name}"
    os.makedirs(dst, exist_ok=True)
    for f in ["index.html", "style.css", "script.js"]:
        shutil.copy(f"{D}/bug-hunt/{f}", f"{dst}/{f}")
    s = open(f"{dst}/script.js").read()
    for a, b in fixes: s = s.replace(a, b)
    open(f"{dst}/script.js", "w").write(s)
    return dst

# raw buggy page: what the Console says on load
hunt = capture(f"{D}/bug-hunt/index.html")
LOG["bug-hunt"] = hunt
console_img([(a, b, c, rel_stack(d)) for a, b, c, d in hunt], f"{O}/m11-bughunt-console.png")

# after fixing only the selector: wrong count, and undefined at the end
step1 = make_step("bug-hunt-step1", [('"#tip-txt"', '"#tip-text"')])
k.render_page(f"{step1}/index.html", f"{O}/m11-bughunt-count-390.png", width=390, height=430, full_page=False)
# console.log to inspect index while clicking Next (log line added to a copy)
step1log = make_step("bug-hunt-step1-log", [('"#tip-txt"', '"#tip-text"'),
    ("function showTip() {\n", 'function showTip() {\n  console.log("index is", index, "tip is", tips[index]);\n')])
clicks = capture(f"{step1log}/index.html", [("click", "#next-button")] * 3)
LOG["clicks"] = clicks
console_img([(a, b, c, d) for a, b, c, d in clicks], f"{O}/m11-console-log-index.png")
k.render_page(f"{step1}/index.html", f"{O}/m11-bughunt-undefined-390.png", width=390, height=430, full_page=False,
              actions=[("click", "#next-button")] * 3)

# ---------- 4. keyboard focus, real ----------
# buggy (step1) page: Tab order skips the div "Show help" - record the order for real
def tab_order(path, n):
    page = k._b().new_page(viewport={"width": 390, "height": 760})
    page.goto("file://" + path); page.wait_for_timeout(150)
    seq = []
    for _ in range(n):
        page.keyboard.press("Tab"); page.wait_for_timeout(40)
        seq.append(page.evaluate("document.activeElement.tagName + (document.activeElement.id ? '#' + document.activeElement.id : '') + ' ' + (document.activeElement.textContent || '').trim().slice(0,20)"))
    page.close(); return seq
LOG["tab_buggy"] = tab_order(f"{step1}/index.html", 6)
LOG["tab_fixed"] = tab_order(f"{D}/bug-hunt-fixed/index.html", 6)
k.render_page(f"{D}/bug-hunt-fixed/index.html", f"{O}/m11-focus-help-fixed.png", width=390, height=580, full_page=False,
              actions=[("press", "Tab")] * 5)

# fixed page: verify every planted bug is gone (recorded, not drawn)
fixed = capture(f"{D}/bug-hunt-fixed/index.html", [("click", "#next-button")] * 3)
LOG["fixed_console"] = fixed
def page_state(path, actions):
    page = k._b().new_page(viewport={"width": 390, "height": 760})
    page.goto("file://" + path); page.wait_for_timeout(150)
    for kind, arg in actions:
        if kind == "click": page.click(arg)
        elif kind == "fill": page.fill(arg[0], arg[1])
        page.wait_for_timeout(40)
    st = page.evaluate("({text: document.querySelector('#tip-text').textContent, count: document.querySelector('#tip-count').textContent, msg: document.querySelector('#form-message').textContent, help: getComputedStyle(document.querySelector('#help')).display})")
    page.close(); return st
F = f"{D}/bug-hunt-fixed/index.html"
LOG["fixed_states"] = {
    "load": page_state(F, []),
    "next x3 (wrap)": page_state(F, [("click", "#next-button")] * 3),
    "prev from first": page_state(F, [("click", "#prev-button")]),
    "empty submit": page_state(F, [("fill", ("#new-tip", "   ")), ("click", "button[type=submit]")]),
    "add tip": page_state(F, [("fill", ("#new-tip", "Test the last item.")), ("click", "button[type=submit]")]),
    "help click": page_state(F, [("click", "#help-toggle")]),
}
S1 = f"{step1}/index.html"
LOG["step1_states"] = {
    "empty submit": page_state(S1, [("fill", ("#new-tip", "   ")), ("click", "button[type=submit]")]),
    "help click": page_state(S1, [("click", "#help-toggle")]),
}

# ---------- 5. illustrations ----------
def debugger_svg(w=1000, h=360):
    F_ = I.F; M_ = I.M
    src = open(f"{D}/bug-hunt-step1/script.js").read().split("\n")
    s = f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'>"
    s += f"<rect width='{w}' height='{h}' rx='8' fill='#fff' stroke='#c9d1da'/>"
    s += f"<rect width='{w}' height='32' rx='8' fill='#f1f3f4'/><rect y='24' width='{w}' height='8' fill='#f1f3f4'/>"
    s += f"<text x='14' y='21' {F_} font-size='12' fill='#5f6368'>Elements&#160;&#160;&#160;&#160;Console&#160;&#160;&#160;&#160;<tspan fill='#202124' font-weight='bold'>Sources</tspan>&#160;&#160;&#160;&#160;Network</text>"
    s += f"<rect x='0' y='32' width='170' height='{h-32}' fill='#f8f9fa' stroke='#e0e0e0'/>"
    s += f"<text x='12' y='56' {F_} font-size='11.5' fill='#5f6368'>Page</text><text x='22' y='78' {F_} font-size='12' fill='#202124'>index.html</text><text x='22' y='98' {F_} font-size='12' fill='#202124'>style.css</text>"
    s += f"<rect x='14' y='106' width='150' height='20' fill='#d2e3fc'/><text x='22' y='120' {F_} font-size='12' fill='#202124'>script.js</text>"
    s += f"<rect x='{w-230}' y='32' width='230' height='{h-32}' fill='#f8f9fa' stroke='#e0e0e0'/>"
    s += f"<text x='{w-218}' y='56' {F_} font-size='12' font-weight='bold' fill='#202124'>Scope</text>"
    s += f"<text x='{w-210}' y='78' {M_} font-size='12' fill='#202124'>index: 3</text>"
    s += f"<text x='{w-210}' y='98' {M_} font-size='12' fill='#202124'>tips: Array(3)</text>"
    s += f"<text x='{w-218}' y='130' {F_} font-size='12' font-weight='bold' fill='#202124'>Breakpoints</text>"
    s += f"<text x='{w-210}' y='152' {F_} font-size='12' fill='#202124'>&#9745; script.js:19</text>"
    s += f"<rect x='{w-220}' y='176' width='200' height='26' rx='4' fill='#fef7e0' stroke='#f9ab00'/><text x='{w-210}' y='193' {F_} font-size='11.5' fill='#202124'>Paused on breakpoint</text>"
    y0 = 58
    for i, ln in enumerate(src[17:28]):
        n = 18 + i; y = y0 + i * 22
        if n == 19:
            s += f"<rect x='170' y='{y-15}' width='{w-400}' height='21' fill='#e8f0fe'/>"
            s += f"<path d='M176 {y-12} h26 l8 7 l-8 7 h-26 z' fill='#1a73e8'/>"
            s += f"<text x='190' y='{y}' {M_} font-size='11' fill='#fff' text-anchor='middle'>{n}</text>"
        else:
            s += f"<text x='196' y='{y}' {M_} font-size='11.5' fill='#9aa0a6' text-anchor='middle'>{n}</text>"
        s += f"<text x='222' y='{y}' {M_} font-size='12' fill='#1f2328' xml:space='preserve'>{I.esc(ln)}</text>"
    s += I.tag(w, h) + "</svg>"
    return s
k.render_svg(debugger_svg(), f"{O}/m11-debugger.png", 1000)

k.render_svg(I.flow([("Predict", "write what you|expect to see"), ("Run", "do the action|once"), ("Compare", "expected vs|actual"),
                     ("Change one thing", "one edit,|then save"), ("Retest", "same action,|same check")],
                    title="The debugging loop", h=160), f"{O}/m11-loop.png", 900)

k.close()
with open("/tmp/claude-0/-home-claude/e333ed89-abd5-5ce0-9f36-c634f9ea9b6d/scratchpad/m11-log.json", "w") as f: json.dump(LOG, f, indent=1)
print(json.dumps(LOG, indent=1))
