"""Module 9 (DOM and Events) image build. Real Chromium renders + drawn diagrams."""
import sys, os, base64, html, tempfile; sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I
O = k.OUT; D = "/home/claude/build/demo/m09"
TMP = tempfile.mkdtemp()
facts = {}

def b64(p): return "data:image/png;base64," + base64.b64encode(open(p, "rb").read()).decode()

def side_by_side(pngs_labels, out_png, width=900, note=None):
    """Compose real renders side by side with small drawn labels."""
    cells = "".join(f"<div style='flex:1'><div style='font:600 14px Segoe UI,Arial;color:#1b2b44;margin:0 0 6px'>{html.escape(l)}</div>"
                    f"<img src='{b64(p)}' style='width:100%;border:1px solid #c9d1da;border-radius:6px;display:block'></div>" for p, l in pngs_labels)
    n = f"<div style='font:13px Segoe UI,Arial;color:#37474f;margin-top:10px'>{html.escape(note)}</div>" if note else ""
    doc = f"<div style='padding:16px;background:#fff;display:flex;gap:16px;align-items:flex-start'>{cells}</div>{n}"
    return k._shot(doc, out_png, width)

def page_with_events(path, actions=(), width=390, height=560, shot=None):
    """Load a real page, run real actions, return (console logs, page errors via CDP)."""
    pg = k._b().new_page(viewport={"width": width, "height": height}, device_scale_factor=2)
    cdp = pg.context.new_cdp_session(pg); cdp.send("Runtime.enable")
    logs, errs = [], []
    pg.on("console", lambda m: logs.append(m.text))
    cdp.on("Runtime.exceptionThrown", lambda e: errs.append(e["exceptionDetails"]))
    pg.goto("file://" + path); pg.wait_for_timeout(250)
    snaps = []
    for kind, arg in actions:
        if kind == "click": pg.click(arg)
        elif kind == "press": pg.keyboard.press(arg)
        elif kind == "shot": pg.screenshot(path=arg); snaps.append(arg)
        elif kind == "count": logs.append(f"__count__{len(logs)}")
        pg.wait_for_timeout(120)
    pg.close()
    return logs, errs

# 1. Three layers (illustration)
k.render_svg(I.layers(), f"{O}/m09-layers.png", 900)

# 2. Script in <head> without defer -> null -> TypeError (real)
logs, errs = page_with_events(f"{D}/no-defer/index.html")
e = errs[0]
line = e["lineNumber"] + 1; col = e["columnNumber"] + 1   # CDP is 0-based; DevTools shows 1-based
msg = e.get("exception", {}).get("description") or e.get("text")
# CDP "text" is "Uncaught" and the message lives in exception.description; fetch via pageerror for the message
pg = k._b().new_page(); pe = []
pg.on("pageerror", lambda x: pe.append(f"Uncaught {x.name.replace('Uncaught ','')}: {x.message}"))
pg.goto(f"file://{D}/no-defer/index.html"); pg.wait_for_timeout(250); pg.close()
facts["no_defer_error"] = pe[0]; facts["no_defer_line"] = (line, col)
entries = [("error", f"{pe[0]}\n    at script.js:{line}:{col}")]
k.render_console(entries, f"{O}/m09-head-null.png")

# 3. Same page with defer: no error, list built (real render at 390)
k.render_page(f"{D}/exercise/index.html", f"{TMP}/ex-before.png", width=390, height=470, full_page=False)
k.render_page(f"{D}/exercise/index.html", f"{TMP}/ex-after.png", width=390, height=470, full_page=False, actions=[("click", "#toggle-btn")])
k.render_page(f"{D}/no-defer/index.html", f"{TMP}/nd.png", width=390, height=470, full_page=False)
side_by_side([(f"{TMP}/nd.png", "script in <head>, no defer"), (f"{TMP}/ex-before.png", "same page with defer")], f"{O}/m09-defer-compare.png", 820)
side_by_side([(f"{TMP}/ex-before.png", "Before click"), (f"{TMP}/ex-after.png", "After one click")], f"{O}/m09-toggle-before-after.png", 820)

# 4. querySelector vs querySelectorAll (real Chromium evaluation)
q = open(f"{D}/query.html").read()
ent = k.browser_eval(q, [
    'document.querySelector(".item")',
    'document.querySelectorAll(".item")',
    'document.querySelectorAll(".item").length',
    'document.querySelector(".missing")',
    'document.querySelectorAll(".missing").length',
])
k.render_console(ent, f"{O}/m09-query-vs-all.png")
facts["query"] = ent
ent2 = k.browser_eval(q, [
    'const items = document.querySelectorAll(".item");\nfor (const item of items) {\n  console.log(item.textContent);\n}',
])
# browser_eval collects console logs asynchronously; put logs after the loop input in run order
inputs = [x for x in ent2 if x[0] in ("input", "result", "error")]
logs2 = [x for x in ent2 if x[0] == "log"]
ordered = inputs[:1] + logs2 + inputs[1:]
k.render_console(ordered, f"{O}/m09-for-of-nodelist.png")
facts["forof"] = ent2

# 5. textContent vs innerHTML (real render)
t = f"{D}/text-vs-html.html"
k.render_page(t, f"{O}/m09-textcontent.png", width=600, height=100, full_page=False, actions=[("eval",
  'document.querySelector("#a").textContent = "textContent: <b>Hello</b>";'
  'document.querySelector("#b").innerHTML = "innerHTML: <b>Hello</b>";'
  'document.body.style.cssText = "font:18px Segoe UI,Arial,sans-serif;padding:8px 16px;margin:0;background:#fff";')])

# 6. Break-it: toggleDetails() instead of toggleDetails (real)
pg = k._b().new_page(viewport={"width": 390, "height": 470}, device_scale_factor=2); bl = []
pg.on("console", lambda m: bl.append(m.text))
pg.goto(f"file://{D}/broken/index.html"); pg.wait_for_timeout(250)
pg.screenshot(path=f"{TMP}/br-load.png"); n_load = len(bl)
pg.click("#toggle-btn"); pg.wait_for_timeout(150); pg.click("#toggle-btn"); pg.wait_for_timeout(150)
pg.screenshot(path=f"{TMP}/br-click.png"); n_after = len(bl); pg.close()
facts["broken_logs_on_load"] = n_load; facts["broken_logs_after_two_clicks"] = n_after
side_by_side([(f"{TMP}/br-load.png", "Just loaded (no click yet)"), (f"{TMP}/br-click.png", "After two clicks")], f"{O}/m09-break-call.png", 820)
k.render_console([("log", x) for x in bl], f"{TMP}/br-console.png")

# 7. Keyboard: native button vs div with a click listener (real key presses)
pg = k._b().new_page(); kl = []
pg.on("console", lambda m: kl.append(("log", m.text)))
pg.goto(f"file://{D}/keyboard/index.html"); pg.wait_for_timeout(150)
seq = []
for target in ("real-btn", "fake-btn"):
    pg.keyboard.press("Tab"); focused = pg.evaluate("document.activeElement.id")
    for key in ("Enter", "Space"):
        before = len(kl); pg.keyboard.press(key); pg.wait_for_timeout(60)
        seq.append((focused, key, len(kl) - before))
pg.close()
facts["keyboard"] = seq
facts["keyboard_console"] = kl
k.render_console(kl, f"{O}/m09-keyboard.png")

# 8. Focus ring on the real button after Tab, then Enter (real render)
k.render_page(f"{D}/exercise/index.html", f"{O}/m09-keyboard-focus.png", width=390, height=330, full_page=False,
              actions=[("press", "Tab"), ("press", "Enter")])

# 9. Pattern (illustration)
k.render_svg(I.flow([("1. Find elements", "querySelector(...)|store in const"),
                     ("2. Define behavior", "function toggleDetails() {...}|function buildList() {...}"),
                     ("3. Connect events", 'addEventListener("click",|toggleDetails)')],
                    title="How every script in this course is organized", h=160), f"{O}/m09-pattern.png", 900)

# 10. classList in the Console (real Chromium evaluation)
cl = k.browser_eval('<button id="toggle-btn" type="button">Show details</button>', [
    'document.querySelector("#toggle-btn").classList.add("is-open")',
    'document.querySelector("#toggle-btn").className',
    'document.querySelector("#toggle-btn").classList.contains("is-open")',
    'document.querySelector("#toggle-btn").classList.remove("is-open")',
    'document.querySelector("#toggle-btn").classList.toggle("is-open")',
    'document.querySelector("#toggle-btn").classList.toggle("is-open")',
])
facts["classlist"] = cl
k.render_console(cl, f"{O}/m09-classlist-console.png")
# 11. hidden is overridden by an explicit CSS display (checked, not imaged)
facts["hidden_vs_display"] = k.browser_eval('<p id="x" hidden>plain</p><p id="y" hidden style="display:block">styled</p>', [
    'getComputedStyle(document.querySelector("#x")).display',
    'getComputedStyle(document.querySelector("#y")).display',
    'document.querySelector("#y").hidden'])
k.close()
import json; print(json.dumps(facts, indent=1))
