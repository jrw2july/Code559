import sys, os, tempfile, re; sys.path.insert(0, "/home/claude/build")
import imgkit as k, illus as I
O = k.OUT
home = tempfile.mkdtemp(); env = {"HOME": home, "XDG_CONFIG_HOME": home}
r = lambda c: k.run(c, cwd=home, env=env)
blocks = [
 ("git --version", r("git --version")),
 ("git config --global init.defaultBranch main", r("git config --global init.defaultBranch main")),
 ('git config --global user.name "Your Name"', r('git config --global user.name "Your Name"')),
 ('git config --global user.email "you@example.com"', r('git config --global user.email "you@example.com"')),
 ("git config --global --list", r("git config --global --list")),
]
k.render_terminal(blocks, f"{O}/m00-git-config.png", prompt="PS C:\\Users\\you>")
k.render_terminal([("node --version", r("node --version")), ("npm --version", r("npm --version"))], f"{O}/m00-node-version.png", prompt="PS C:\\Users\\you>")
k.render_terminal([("gh --version", r("gh --version"))], f"{O}/m00-gh-version.png", prompt="PS C:\\Users\\you>")
gh = open("/home/claude/build/gh-auth-raw.txt").read().strip()
k.render_terminal([("gh auth login", gh)], f"{O}/m00-gh-auth-prompts.png", prompt="PS C:\\Users\\you>")
# Explorer with extensions shown (illustration)
k.render_svg(I.explorer("Documents > code559", [("my-site","File folder"),("notes.txt","Text Document"),("index.html","Microsoft Edge HTML Document")]), f"{O}/m00-explorer-extensions.png", 760)
# VS Code Extensions view with Live Preview (illustration)
ext = I.vscode([("Live Preview",0),("Microsoft",1),("Install",1)], "Extension: Live Preview",
  ["Live Preview", "Microsoft  |  ms-vscode.live-server", "", "Hosts a local server in your workspace", "for you to preview your webpages on.", "", "[ Install ]"], panel_title="EXTENSIONS", folder="live preview", status="no folder open")
k.render_svg(ext, f"{O}/m00-vscode-live-preview.png", 900)
# Settings: chat.disableAIFeatures (illustration)
st = I.vscode([("Commonly Used",0),("Text Editor",0),("Chat",0)], "Settings", ["Search: chat.disableAIFeatures", "", "Chat: Disable AI Features", "[x] Disable and hide built-in AI features", "    provided by GitHub Copilot, including", "    chat and inline suggestions."], panel_title="SETTINGS", folder="User", status="no folder open")
k.render_svg(st, f"{O}/m00-vscode-ai-off.png", 900)
# Open in Terminal (illustration)
k.render_svg(I.vscode([("index.html",0)], "index.html", ["<!-- your files appear here -->"], terminal=["PS C:\\Users\\you\\Documents\\code559\\my-site>"], folder="MY-SITE", status="Terminal > New Terminal"), f"{O}/m00-vscode-terminal.png", 900)
k.render_svg(I.flow([("VS Code","editor"),("Live Preview","see the page"),("Git","save history"),("GitHub CLI","talk to GitHub"),("Node.js","run JS outside|the browser")], title="Your toolkit after Module 0"), f"{O}/m00-toolkit.png", 900)
k.close()
print("\n\n".join(f"$ {c}\n{o}" for c,o in blocks))
