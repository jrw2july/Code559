# Brief for writing Code559 blog posts (read fully before starting)

You are writing public blog posts for **Code559**, J.R. Wells's front-end teaching brand (a 559 Solutions project, fivefive9.com). The posts are the free funnel for a paid course: each post teaches one module with the IEIA method and gives away the Exercise, but **holds back the Project** (teaser only).

## Read these first
1. `/home/claude/blog/STYLE-GUIDE.md` — exact post structure, style rules, honesty rules, caption tags. Follow it exactly.
2. `/home/claude/blog/module-00-setup.md` — the finished Module 0 post. Match its voice, depth, length and caption style. Read it fully.
3. `/home/claude/build/imgkit.py` and `/home/claude/build/illus.py` — the image helpers. Use them; you may add helper functions in your OWN script, but **do not edit these two shared files** (other writers are using them at the same time).
4. Optional, for voice: the private packets in the claude.ai Project (Projects tool, `project_read`), e.g. `Lesson_16_-_Real_Form_Controls_-_Feedback_Card_HTML.docx`, `Lesson_18_-_Functions_That_Return_-_Feedback_Card_JS_and_FAQ_Card.docx`, `Lesson_19C_-_JavaScript_-_Objects.docx`, `EXERCISE - JavaScript_Project_Interactive_Interests_Gallery.docx`, and `code559-course-braindump-v2.md`. If the Projects tool is unavailable, skip this; your module notes below are enough. Never copy the pilot student's name, email, username, site, drive letters or folder names into a post.

## What you produce, per module N (two-digit NN)
- `/home/claude/blog/module-NN-slug.md` (slug given below).
- Images in `/home/claude/blog/images/` named `mNN-*.png` ONLY (no other prefix — avoids collisions).
- A build script `/home/claude/build/mods/mNN.py` that regenerates that module's images. Demo files (HTML/CSS/JS pages you render) go in `/home/claude/build/demo/mNN/`.
- Aim for 5–10 images per module. Prefer REAL images wherever this Linux workspace can produce them:
  - **Pages you build** (HTML/CSS/JS demos): render for real with `k.render_page(...)` or `k.browser_frame(...)` (Chromium). Caption `(real: rendered in Chromium)` or `(page real: rendered in Chromium; browser frame drawn)`. Use realistic widths (390 phone, 800 tablet, 1200 desktop) and say which width.
  - **Terminal output**: run commands for real with `k.run(cmd, cwd=...)`, render with `k.render_terminal`. Use prompt text `PS C:\Users\you\Documents\code559\<folder>>`. Caption must end `(real output, rendered; captured on Linux …)` and note anything that differs on Windows. For Git, set a throwaway HOME (see m00.py) with user.name "Your Name", user.email "you@example.com", init.defaultBranch main, so the workspace's real config is untouched.
  - **Console output**: use `k.browser_eval(html, [lines])` (real Chromium evaluation, Console-style) and `k.render_console`. For Node, `k.node_eval(js)`. Caption `(real output, rendered)`.
  - **Everything else** (VS Code windows, GitHub.com pages, DevTools panels you cannot capture, Windows dialogs, diagrams): draw with `illus.py` or your own SVG and caption `(illustration, not a screenshot)`. Illustrations must carry the ILLUSTRATION tag (use `I.tag(w,h)` in custom SVGs). Do not put invented UI wording in quotes inside illustrations as if it were exact; where exact wording matters and you have not verified it, say so.
- **Look at every image you make** (Read the PNG) and fix anything clipped, overlapping or unreadable.

## Honesty rules (non-negotiable; J.R. is strict about this)
- Every command, output and Console result shown in text or image must come from a real run in this workspace. If you state what a command prints, run it first. If something cannot be run here (e.g. `git push`, `gh repo create`, GitHub Pages, Windows-only behavior), say so and mark **[unverified: …]** or describe it as an illustration.
- **Never run `gh auth`, never read or print tokens/credentials, never push to or create anything on GitHub.** Local git only. A safety classifier will block credential exploration; do not try to work around it.
- Facts about the web platform: verify against MDN (WebFetch developer.mozilla.org) when you quote or state something non-obvious, and name the MDN page title in "Go further" / the sources line. No invented video titles, runtimes, statistics or quotes.
- Time estimates say "(estimate)". Measured numbers say how they were measured (e.g. "measured in Chromium at 390 px").
- End each post with the credit footer from the style guide and a "Sources checked 2026-10-09:" line listing the pages you actually checked.

## Course-wide facts
- Windows 11, Edge or Chrome, VS Code with AI features off, Live Preview. Learners installed Git, GitHub CLI and Node in Module 0.
- Learners build ONE personal website across the course in a folder `my-site` (pages: Home, About, Interests, Milestones, Projects, Contact). Generic examples only (`"image-one.jpg"`), reader chooses content. Avoid the "test scores" theme.
- Module 1 ends with "Publish your first page": GitHub Skills *introduction-to-github* exercise, then `git init` → `gh repo create … --push` → GitHub Pages. From Modules 2–11 every post's "Before next module" includes: `- [ ] Saved this module's work to GitHub with the routine: git status → git add . → git commit -m "…" → git push → check the live page`. Full Git (branches, merge, diff, log, .gitignore, README, Issues with `Closes #n`, releases, PR line comments) is taught only in Module 12.
- JavaScript language (Modules 5–8) comes before DOM and events (Module 9). Modules 5–8 are Console/Node only: no `document`, no DOM.
- Teaching method: IEIA (Introduce, Explain, Illustrate, Apply) on every core concept; Predict → Run → Modify → Create → Debug for code; one deliberate break-it step in every Exercise; "Type it, do not paste it."
- Five standing questions (rotate one into Check your understanding): Why does it work? / What value does this variable hold? / What happens if this changes? / What causes this function to run? / What would you test?
- Affiliate placeholders in Go further: `AFFILIATE_W3SCHOOLS_<TOPIC>` with the disclosure line. Packet link placeholder: `PACKET_LINK_MODULE_N`.
- No profanity. Avoid the words "genuinely", "honestly", "straightforward".

## When you finish
Reply with: the files you wrote, the image list with each image's real/illustration status, and every **[unverified]** flag you left, with a one-line reason each. Keep the reply short; the files are the deliverable.
