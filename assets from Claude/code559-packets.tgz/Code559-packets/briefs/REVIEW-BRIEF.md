# Brief: independent test of Code559 blog posts (read fully before starting)

You are testing published tutorial posts for **Code559**, a free front-end course for adult beginners on Windows 11. You did not write these posts. Your job is to find what is wrong, missing or confusing, and to propose fixes. **Do not edit any file in `Code559/`.** Work in your own scratch folder `/home/claude/qa/work-<your modules>/`.

## The material
- Posts: `Code559/blog/module-NN-*.md`; landing page `blog/index.md`; images in `blog/images/`.
- Each post follows a fixed template: intro list → Why this matters → Before you start (+ Checkpoint) → Core concepts (numbered questions) → Exercise → Project (teaser only; the full project is in a paid packet) → Common misconception → Summary → Check your understanding → Before next module → Go further → What to keep → credit footer and "Sources checked" line.
- Paragraph markers are small inline `<img>` badges (`images/brand/marker-*.svg`: introduce/explain/illustrate/apply). Some sections are separated by a floor-plan divider (`<div role="separator">` with `divider-*.svg` images). These are deliberate design choices; do not report them unless they break something.
- Some images carry an "ILLUSTRATION" tag; those are drawn copies of real screens (VS Code, GitHub, DevTools). That is deliberate.
- Known placeholders, do not report: `PACKET_LINK_*`, `AFFILIATE_W3SCHOOLS_*`.

## Course facts (the intent you test against)
- Learners use Windows 11, Edge or Chrome, VS Code with AI features off, Live Preview. Module 0 installs Git, GitHub CLI and Node.
- One personal website is built across the course in a folder `my-site` (Home, About, Interests, Milestones, Projects, Contact).
- Order: 0 Setup · 1 HTML · 2 CSS · 3 Responsive · 4 Forms & Accessibility · 5 JS Primer · 6 JS Language Foundations · 7 Functions · 8 Arrays, Loops, Objects · 9 DOM & Events · 10 Forms & Validation with JS · 11 Debugging & Testing · 12 Git/GitHub (full) · 13 Capstone.
- Modules 5–8 are Console/Node only (no DOM). Full Git (branches, PRs, etc.) is taught only in Module 12; Modules 2–11 use a simple routine (status → add → commit → push → verify). Module 1 ends with a first publish to GitHub Pages.
- Audience: adult beginners, some with English as a second language. Plain, short sentences are intended.

## What to test (be concrete and run things)
1. **Do the Exercise as a learner would**, step by step, literally as written, in your scratch folder. Create every file the steps ask for, with the exact code shown. Render HTML pages in Chromium (Playwright is installed: `from playwright.sync_api import sync_playwright`), run JS with `node`, run local `git` commands with a throwaway HOME (`HOME=$(mktemp -d)`, set user.name/email, `init.defaultBranch main`). Report any step that fails, is ambiguous, skips something, or produces a different result than the post says.
2. **Re-run every code sample and claimed output** in Core concepts (Console results, terminal output, rendered results, measured numbers). Report any mismatch, with what you actually got.
3. **Look at every image the post references** (Read the PNG). Report images that don't match their caption or alt text, are unreadable, clipped, or show wrong information.
4. **Check technical claims** that are non-obvious against MDN / official docs (WebFetch). Report anything wrong or outdated. Things that only exist on Windows or on GitHub.com can't be run here: check them against official docs instead, and say so.
5. **Sequence and gaps:** concepts used before they are taught (in this module or earlier ones), references to earlier/later modules that don't match those modules' actual content, missing prerequisites, steps that assume knowledge the learner doesn't have yet, inconsistent names across modules (file names, folder names, function names).
6. **Clarity for the audience:** jargon used without explanation, instructions a beginner could misread, overly long sections, missing "how do I know it worked" checks.
7. **Template completeness:** missing or out-of-order sections; Check your understanding questions that the post doesn't actually equip the learner to answer.

Never run `gh auth`, never push or create anything on GitHub, never read credentials.

## How to report (your final message; keep it tight)
A list of findings, most severe first. For each:
- **ID** (e.g. M07-3), **module**, **where** (section + a short quote of the text, ≤15 words)
- **Severity:** Blocker (learner cannot proceed, or the post teaches something wrong) · Major (likely to confuse or mislead; claim not backed) · Minor (polish, wording, small inconsistency)
- **Evidence:** what you ran or checked and what you observed (one or two lines)
- **Fix options:** one to three concrete options (e.g. "A: change X to Y; B: add a step …"), each with a rough effort (minutes)

Then two lines: what you tested and could not test (and why). No preamble, no praise.
