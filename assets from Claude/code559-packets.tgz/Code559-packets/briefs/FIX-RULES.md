# Code559 blog: "Consistent" fix package — shared rules (read fully)

You are fixing published tutorial posts in the git clone `Code559/` (branch `blog-consistency-fixes`). The owner (J.R.) approved a specific fix package after a test. You fix ONLY the items assigned to you below, plus the shared rules where they apply to your modules. Do not make other edits ("while I'm here" changes are out of scope). Other fixers are editing other module files at the same time: **only edit your own module files and your own images.** Do not commit; leave changes in the working tree.

Background reading (skim): `Code559-packets/briefs/REVIEW-BRIEF.md` (course facts). The full test report findings for your modules are quoted in your task list below.

## Owner's decisions (apply everywhere in your modules)

1. **Free path:** Module 1 lets free readers publish a first page of `my-site`. From Module 2 on, free readers work in practice folders only; work on `my-site` is the paid packet's Project.
2. **Viewing pages:** Learners open pages directly in Edge or Chrome and press F5 after saving; F12 opens DevTools. Live Preview is optional (Module 0 explains it). Never tell a learner to open the Console from Live Preview.
3. **Names, everywhere:**
   - Stylesheet: `styles.css`.
   - Practice folders: `practice-NN` inside the course folder, where NN is the module number: `practice-01` … `practice-13`. They replace `layout-lab`, `form-lab`, `js-practice`, `m07-practice`, `m08-practice`, `m09-practice`, `m10-practice`, `m11-practice`, `git-practice`, `m13-practice`, etc. Sub-folders inside a practice folder are fine (e.g. `practice-13\goal-counter`).
   - The Module 4 card is the **rating card** (never "feedback card").
   - The personal site folder and repository is **`my-site`** (never `portfolio`). Its live address is `https://your-username.github.io/my-site/`.
4. **"[unverified]" notes:** rewrite each as a plain, friendly reader note with no brackets, telling the reader what to expect or do, e.g. *"Your screen may look slightly different; the button names are what matter."* If your task list says a note is now settled, state the fact plainly (with its source) and drop the hedge.

## Standard wording (use exactly, adapting only the bracketed part)

- **Opening a page / the Console** (first time per module where needed):
  "Open `[file]` in Edge or Chrome (double-click it in File Explorer, or drag it onto a browser window). After each save, press **F5** to reload. Press **F12** (or **Ctrl+Shift+J**) to open DevTools, then click the **Console** tab."
- **Git checklist line, Modules 2–11** ("Before next module"), replacing the current "Saved this module's work to GitHub…" item:
  `- [ ] If you did this module's packet project in my-site, saved it with the routine: git status → git add . → git commit -m "…" → git push → check the live page. (Your practice folder is not saved to GitHub.)`
- **DOM code typed before Module 9** (Modules 3–4 only): introduce such Console lines with: "Type this line exactly as shown. You will learn how it works in Module 9; for now, read the answer it gives."
- **freeCodeCamp line in Go further** (Modules 5–11, where a module name was marked unverified or missing): `- freeCodeCamp: the free [JavaScript Certification](https://www.freecodecamp.org/learn/javascript-v9/) (checked 2026-10-11) has practice on this topic.` — no module names.
- **Re-rendered images whose real output came from a different folder:** caption tag `(real output, rendered; captured on Linux, with the folder path changed to the course folder)`. Never show `/home/claude/...` or any build path in any image or text.

## Accessibility standard

- Focus rings and other interface outlines use **`#b45309`** (contrast 5.0:1 on white; MDN *Color contrast* asks 3:1 for interface parts). Replace the old ambers (`#f4a261`, `#f0a500`, `#e3a008`) in post code AND in the demo pages you re-render, so code and pictures match.

## Images

- Build scripts that made each module's images: `Code559-packets/image-tools/mods/mNN.py` (+ helpers `Code559-packets/image-tools/imgkit.py`, `Code559-packets/image-tools/illus.py`, `Code559-packets/image-tools/mods/m78kit.py`). Demo pages: `Code559-packets/image-tools/demo/mNN/`.
- **Never edit the shared files** (`imgkit.py`, `illus.py`, `m78kit.py`) and never run a script that writes into `/home/claude/blog/images` or into the clone's images folder wholesale. Instead: copy the script and the demo folder into your own folder `/home/claude/qa/fix/mNN/`, change the copy so it writes to `/home/claude/qa/fix/mNN/out/` (e.g. set `O = "/home/claude/qa/fix/mNN/out"` and replace any hard-coded output paths), and render only what you need. Then copy **only the images you were asked to change** into `Code559/blog/images/` under the same file name.
- **Diagrams vs screen copies:** 26 diagram images have had their yellow "ILLUSTRATION" tag removed on purpose; 13 drawn copies of real screens (VS Code, GitHub, DevTools, File Explorer, GitHub Desktop) keep it. If you must re-render a diagram, render it **without** the tag (e.g. temporarily `I.tag = lambda w, h: ""` in your copy). If you re-render a screen copy, keep the tag. Diagram files: m00-toolkit, m01-request-response, m01-url-parts, m02-rule-anatomy, m02-specificity, m03-box-model, m04-brief, m05-error-anatomy, m05-habit, m05-layers, m05-where-js-runs, m06-if-flow, m07-anatomy, m07-description-method, m07-listener-bridge, m08-indexes, m08-loop-anatomy, m08-parallel-vs-objects, m09-layers, m09-pattern, m10-client-server, m10-state-diagram, m11-loop, m12-mental-model, m13-nine-steps, m13-req-to-tasks.
- Every image you change must come from a real run (terminal, Node, Chromium) except drawn screen copies and diagrams. **Look at every image you produce** (Read the PNG) before copying it in.
- Captions in posts: real images keep their "(real …)" tag; drawn images have NO caption tag (the owner removed "(illustration, not a screenshot)" on purpose — do not add it back).

## Post format you must preserve

- Paragraph markers are inline badge images like `<img src="images/brand/marker-explain.svg" alt="Explain" width="24" height="24" style="vertical-align:-0.35em;"> ` at the start of paragraphs; floor-plan dividers are `<div role="separator" …divider-*.svg…></div>` lines. Keep them. New paragraphs you add inside Core concepts start with the right badge (introduce / explain / illustrate / apply) when they play that role; plain notes need no badge.
- Keep the 11-section template and the credit footer. Update the "Sources checked" line if you check new pages.
- Style: short plain sentences, adult beginners (some ESL), no profanity, never the words "genuinely", "honestly", "straightforward".
- **Verify every new claim:** run new commands/code for real; check new facts against official docs (WebFetch). Never run `gh auth`, never push or create anything on GitHub.

## When done

Reply with: files changed; images changed (with real/drawn status); for each assigned item, one line "ID — done: what changed" or "ID — not done: why"; anything you found that conflicts with another module (don't fix other modules; report it). Keep it short.
