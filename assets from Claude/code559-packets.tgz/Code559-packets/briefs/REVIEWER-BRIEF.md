# Brief for an independent packet reviewer — read fully
You did not write this packet. Do NOT edit anything under Code559-packets or /home/claude/qa. Work in /tmp/claude-0/-home-claude/e333ed89-abd5-5ce0-9f36-c634f9ea9b6d/scratchpad/mNNreview. Never run gh auth, never push to a real remote, never read credentials.

Packet: the PDF in Code559-packets/modules/mNN/, built from project.md, finishing.md, troubleshooting.md (if any), selfcheck.md, answers.md there, plus the free lesson Code559/blog/module-NN-*.md. Rules: Code559/blog/STYLE-GUIDE.md, Code559-packets/briefs/FIX-RULES.md, and Code559-packets/briefs/WRITER-BRIEF.md (what the writer was asked to do). Promise: mNN/PLAN.md and the post's "Project (in the full packet)" teaser (exact wording). Earlier packets: Code559-packets/modules/m01..(NN-1).

Check by doing (do not reuse the writer's scratch scripts):
1. Rebuild the needed site state and follow the project steps literally as a beginner; run every step, modify, break-it and debug variant for real (Chromium via Playwright for pages incl. keyboard and Console; Node for scripts); compare every stated result, message, line number and count exactly.
2. Run the Git steps in a throwaway repo (throwaway HOME, local bare remote); compare quoted messages.
3. Check every factual claim against the lesson or MDN/GitHub Docs (WebFetch if needed); look-aheads against later free posts; cross-references to earlier packets. List anything unverified.
4. answers.md correctly answers Check your understanding, the misconception, and self-assessment questions; code for parts written alone works.
5. Promise: delivers the teaser exactly; nothing beyond Modules 0–NN; consistent with earlier modules' names, palette, files.
6. Style: banned words (genuinely/honestly/straightforward), no build paths or real names (the "— J. R. Wells" sign-off on the last page is allowed), "out loud" only for explaining code to yourself, contrast, readability (flag dense passages), step numbers and cross-references, picture tags.
7. PDF: pdftoppm -r 60; every Contents page number; About fits one page; rubric table; cover has no footer; last page About 559 Solutions; no page under ~75% full mid-part (end-of-part pages are fine).

Report (tight): numbered findings most severe first, each: severity (Blocker/Major/Minor), file + location (≤15-word quote), evidence, one-line fix. Then one line on what you tested and could not.
