# Brief for a packet writer (Modules 9–13) — read fully

You write the paid-packet parts for ONE module of the Code559 front-end course. Write ONLY into Code559-packets/modules/mNN/ (your module). Do not edit anything else (not build_packet.py, packetkit.py, Code559, /home/claude/site, other modules). Never run gh auth, never push to any real remote, never read credentials.

## Read first
1. modules/mNN/PLAN.md and Code559-packets/build_packet.py header docstring (each .md starts with "# Part title"; selfcheck.md needs "## Rubric" of "- " lines).
2. The free lesson Code559/blog/module-NN-*.md. Its "## Project (in the full packet)" teaser is the PUBLIC PROMISE: deliver exactly what it says, word by word. Stay inside what Modules 0–NN teach.
3. The finished, approved packets for earlier modules: Code559-packets/modules/m01..m08/*.md (shape, voice, depth, verification). The my-site state your project builds on comes from the earlier packet projects (pages index, about, interests, rate, contact; styles.css with palette and focus rings from m02–m04; helpers.js m07; site-data.js m08). Read those project.md files as needed.
4. Code559/blog/STYLE-GUIDE.md and Code559-packets/briefs/FIX-RULES.md: names (my-site, styles.css, practice-NN, course folder C:\Users\you\Documents\code559, live https://your-username.github.io/my-site/); pages opened in Edge/Chrome, F5 after each save, F12 or Ctrl+Shift+J for the Console; focus rings #b45309 on light, #fdba74 on navy #1d3557, ≥3:1; text ≥4.5:1; "out loud" only for explaining code to yourself; banned words genuinely/honestly/straightforward; no profanity; 6th–10th grade, short sentences, second person, prose paragraphs; no build paths or real names in text or pictures.
5. the Claude project doc code559-course-braindump-v2.md §2–§4.

## Write
- project.md: "# Project: …". "## The brief" (what the finished thing does, exact words where they matter, a real picture if useful), then "## The steps": numbered; "Type it, do not paste it"; predict → run → modify; skeleton snippets with a comment where the reader continues alone; one break-it step and one debug step, each with its real result; a test checklist; hand-off to the Git part.
- finishing.md: "# Finishing work in Git" with NEW items marked.
- troubleshooting.md: 3–6 real problems (symptom / why / fix), real messages; longer lists as a short table.
- selfcheck.md: intro, "## Rubric" (8–9 "I can…" lines), "## Three questions to answer in writing".
- answers.md: the post's Check your understanding, Common misconception, Exercise checks, "## Self-assessment questions" (model answers for Q1 and Q3; Q2 personal: say what a good answer includes), Project checks including full code for every part written alone.
- images/pNN-*.png (optional): real Chromium renders (caption ends "(real: rendered in Chromium at N px)"), real terminal output via the imgkit render_terminal helper (find under /home/claude/qa; import read-only; caption "(real output, rendered; captured on Linux, with the folder path changed to the course folder)"), or drawn screen copies of VS Code/GitHub with the yellow ILLUSTRATION tag drawn in (owner decision: drawn and labeled is fine). Keep pictures short enough not to leave half-empty pages mid-part.

## Lessons from reviewers of earlier packets (avoid these)
- Count output lines exactly; quote errors exactly as printed (caret, line number).
- Error explanations must cover every likely cause (e.g. a missing `}` as well as a stray `;`); long cause lists go to troubleshooting as a short table.
- Don't promise specifics about later modules beyond what their free posts show (read the later post if you mention it).
- The scope sentence must list everything the project uses.
- Use "Core concept N" (lowercase c). Cross-references to steps must name the part ("Project step 9").
- No unverified claims: drop them or write a plain reader note. If you could not test on Windows or live GitHub Pages, say so plainly.
- Readability: no paragraphs over ~100 words; turn inventories into short bullet lists.

## Verify by doing
Scratch folder: /tmp/claude-0/-home-claude/e333ed89-abd5-5ce0-9f36-c634f9ea9b6d/scratchpad/mNNwork. Rebuild the needed my-site state from earlier packets, apply your steps literally, run everything for real (Playwright/Chromium for pages: clicks, keyboard Tab/Enter/Space, Console messages, computed styles, contrast; Node for scripts; Git in a throwaway repo with throwaway HOME and a local bare remote). Extract your code blocks from project.md + answers.md with a script and confirm they assemble into the tested files.

## Build
`cd Code559-packets && python3 build_packet.py NN`. Fix your files if it breaks. Check with pdftoppm -r 60: Contents numbers match, rubric table renders, About page fits one page, no page under ~75% full mid-part.

## Final message (tight)
Files written, page count, what you verified and how, decisions/doubts.
