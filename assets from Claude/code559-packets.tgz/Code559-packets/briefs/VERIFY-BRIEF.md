# Brief: verification re-test of the Code559 "consistent" fix package (read fully)

The posts in `Code559/blog/` (git branch `blog-consistency-fixes`, changes uncommitted) were tested, then fixed. You are an independent checker. You did not write the posts or the fixes. **Do not edit anything in `Code559/`.** Work only in your own scratch folder (named in your task).

## Read first
1. `Code559-packets/briefs/REVIEW-BRIEF.md` — course facts and how to test (render pages in Chromium with Playwright, run JS with `node`, run git with a throwaway HOME). Use its test methods, not its "do not edit" scope note about reporting all findings: here you report only what is asked below.
2. `Code559-packets/briefs/FIX-RULES.md` — the owner's four decisions, the standard wording, names, focus color and image rules the fixes had to follow.
3. Your module task file(s) in `/home/claude/qa/fix/task-*.md` — the list of findings (IDs) the fixers were asked to fix.
4. `/home/claude/qa/fix/INTEGRATION-NOTES.md` — changes made after the fixers finished.

See every change with `git -C Code559 diff main -- blog/<file>` (text) and `git -C Code559 diff --stat main -- blog/images` (images). The pre-fix version of any file: `git -C Code559 show main:blog/<file>`.

## What to do
**A. Each assigned item.** For every item ID in your task file(s), and every integration note that touches your modules, decide: RESOLVED, PARTLY, or NOT RESOLVED. Check by doing, not by reading the fixer's claim: run the changed code, follow the changed steps, look at every changed image (Read the PNG), and check any new fact against the official page (WebFetch). One line of evidence each.

**B. Regressions.** Read every changed passage in the diff. Then do each module's Exercise end to end as a learner, literally as written, in your scratch folder. Report anything the fixes broke or introduced: wrong step numbers or cross-references, code that no longer matches its picture or caption, a claim that is now wrong, a sentence a beginner would misread, a broken image or link, standard wording used wrongly, old names (`style.css`, `portfolio` as a folder, `feedback card`, old practice-folder names), build paths in text or images, Live Preview or a server used for viewing, focus-ring colors that fail 3:1 against what is behind them.

**C. Consistency with the decisions.** Within your modules: free readers have only a first page of `my-site` after Module 1 and work in `practice-NN` folders from Module 2 on; pages are viewed in Edge or Chrome with F5; names match FIX-RULES. Note any text that still assumes otherwise. Also note anything in your modules that contradicts another module (say which; don't test the other module in depth).

## Rules
Never run `gh auth`, never push or create anything on GitHub, never read credentials. Keep your scratch work in your own folder.

## Report (final message, tight, no preamble)
1. **Items:** one line each — `ID — RESOLVED / PARTLY / NOT RESOLVED — evidence`.
2. **New problems:** most severe first. Each: ID-style tag (e.g. V07-1), module, where (section + ≤15-word quote), severity (Blocker / Major / Minor), evidence, and a one-line fix.
3. Two lines: what you tested, and what you could not test and why.
