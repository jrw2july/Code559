# Code559 packets (PRIVATE)

The paid Code559 module packets: the source files, the builders, and the production briefs. **This is the paid product. Keep this repository private.**

## Folder layout

Keep this folder beside the Code559 repository, because the builders read the free lesson from `../Code559/blog`:

```
Documents\GitHub\
  Code559\            free lessons (public)
  Code559-packets\    this folder (private)
  559solutions.com\   website
```

| Path | What it is |
|---|---|
| `modules/m00/build.py` | Module 0 builder (its packet parts are written inside the script) |
| `modules/m01` … `m13/` | Packet parts: `project.md`, `finishing.md`, `troubleshooting.md`, `selfcheck.md`, `answers.md`, packet-only `images/`, and `PLAN.md` (what the packet promises) |
| `build_packet.py` | Builds the PDF for Modules 1–13 |
| `build_epub.py` | Builds the EPUB from a built PDF (all modules) |
| `packetkit.py` | Shared parts: About page, Contents, footer, copyright, About 559 Solutions, print styles |
| `assets/code559-logo.png` | Cover logo |
| `briefs/` | The writer and reviewer instructions used to produce each module |
| `tools/autocheck.py` | Checks the free lessons: template sections, banned words, broken images and links, JavaScript syntax |
| `image-tools/` | Scripts that made the lesson pictures. Archive copy: paths inside still point at the original build workspace; adjust before reuse. |

## One-time setup

1. Python 3.11 or newer, then: `pip install -r requirements.txt`
2. Chromium for printing: `python -m playwright install chromium`
3. Pandoc (EPUB), from https://pandoc.org/installing.html (packets were built with 3.1.3)
4. Poppler (`pdftoppm`, makes the EPUB cover picture). On Windows, one source is https://github.com/oschwartz10612/poppler-windows ; add its `bin` folder to PATH.
5. Java (only for checking EPUBs with epubcheck), for example from https://adoptium.net

These builders ran on Linux. They have not been tested on Windows yet.

## Build

From this folder:

```
python modules/m00/build.py          # Module 0 PDF
python build_packet.py 7             # Module 7 PDF (any of 1-13)
python build_epub.py 7               # Module 7 EPUB (build the PDF first)
python -c "from epubcheck import EpubCheck as E; r=E('modules/m07/Code559-Module-7-Functions.epub'); print(r.valid, r.messages)"
```

Each PDF lands in its module folder (`modules/mNN/Code559-Module-N-Title.pdf`), with the EPUB beside it.

Rebuild a module's packet whenever its free lesson in `../Code559/blog` changes, because Part 1 of every packet is that lesson.

## Checks before uploading to Gumroad

- The Contents page numbers match the pages.
- The cover has no footer; every other page has the © 2026 559 Solutions LLC footer.
- The last page is "About 559 Solutions".
- EPUB check reports valid with no messages.
